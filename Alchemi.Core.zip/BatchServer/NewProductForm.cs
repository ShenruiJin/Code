﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using CaesarApplication.Service.Persistance;
using FuncFramework.Business;
using DealBusinessObject.IDescription;
using CaesarView.View.HelperControls;
using System.Collections;

namespace BatchServer
{
	public partial class NewProductForm : Form
	{
		public NewProductForm()
		{
			InitializeComponent();
		}

		static NewProductForm _product = new NewProductForm();
		/// <summary>
		/// Show the dialog
		/// </summary>
		/// <returns></returns>
		public static new DialogResult Show()
		{
			return _product.ShowDialog();
		}

		public static RunningTask CurrentTask
		{
			get { return NewProductForm._currentTask; }
			set {
				if (value == null)
					NewProductForm._currentTask = CreateEmptyTask();
				else
					NewProductForm._currentTask = value;
				_product.UpdateCurrentTask();
			}
		}
		static RunningTask _currentTask = CreateEmptyTask();
		private static RunningTask CreateEmptyTask()
		{
			RunningTask task = new RunningTask();
			// charge le property param
			task.Calculation = new System.Collections.ArrayList();
			IfNotExistCreate(task.Calculation, "Margin", "0.01");
			task.Bumps = new System.Collections.ArrayList();
			IfNotExistCreate(task.Bumps, "Volatility", "Ask");
			task.Product = new System.Collections.ArrayList();
			IfNotExistCreate(task.Product, "_maturityDate", "3Y");
			return task;
		}

		private void UpdateCurrentTask()
		{
			// ParamSolving
			this.propertyGridExParamSolving.Item.Clear();
			if (_currentTask != null)
			{
				string category;
				CustomProperty prop;
				category = "Calculation";
				{
					prop = new CustomProperty();
					prop.Category = category;
					prop.Name = "CalculationParameters";
					prop.Value = _currentTask.Calculation;
					prop.CustomEditor = new PropertyValueCollectionEditor();
					prop.CustomTypeConverter = new PropertyArrayTypeConverter();
					prop.IsBrowsable = true;
					prop.IsReadOnly = false;
					prop.Description = "the task calculation parameters";
					this.propertyGridExParamSolving.Item.Add(prop);
				}
			}
			// force le dessin
			this.propertyGridExParamSolving.Refresh();

			// Bumps
			this.propertyGridExBumps.Item.Clear();
			if (_currentTask != null)
			{
				string category;
				CustomProperty prop;
				category = "Bumps";
				{
					prop = new CustomProperty();
					prop.Category = category;
					prop.Name = "Bumps";
					prop.Value = _currentTask.Bumps;
					prop.CustomEditor = new PropertyValueCollectionEditor();
					prop.CustomTypeConverter = new PropertyArrayTypeConverter();
					prop.IsBrowsable = true;
					prop.IsReadOnly = false;
					this.propertyGridExBumps.Item.Add(prop);
				}
			}
			// force le dessin
			this.propertyGridExBumps.Refresh();

			// produit
			// Bumps
			this.propertyGridExProduct.Item.Clear();
			if (_currentTask != null)
			{
				string category;
				CustomProperty prop;
				category = "Product";
				{
					prop = new CustomProperty();
					prop.Category = category;
					prop.Name = "Product";
					prop.Value = _currentTask.Product;
					prop.CustomEditor = new PropertyValueCollectionEditor();
					prop.CustomTypeConverter = new PropertyArrayTypeConverter();
					prop.IsBrowsable = true;
					prop.IsReadOnly = false;
					this.propertyGridExProduct.Item.Add(prop);
				}
			}
			// force le dessin
			this.propertyGridExProduct.Refresh();
		}

		/// <summary>
		/// Charge les données
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void NewProductForm_Load(object sender, EventArgs e)
		{
			ITag tagBatch = PersistanceService.ScriptProvider.GetTag("Batch", PersistanceService.CaesarSession);
			IScriptDescriptionCollection listScript = PersistanceService.ScriptProvider.GetScriptsByTags(new ITag[] { tagBatch }, false, PersistanceService.CaesarSession);
			foreach(IScriptDescription desc in listScript)
			{
				this.comboBoxScript.Items.Add(desc.Name);
			}

			UpdateCurrentTask();
		}

		private void comboBoxScript_SelectedIndexChanged(object sender, EventArgs e)
		{
			int index = this.comboBoxScript.SelectedIndex;
			if (index >= 0)
			{
				_currentTask.ScriptName = this.comboBoxScript.SelectedItem.ToString();
			}
		}

		private void comboBoxCalcultationType_SelectedIndexChanged(object sender, EventArgs e)
		{
			int index = this.comboBoxCalcultationType.SelectedIndex;
			// ajoute les param si besoin
			switch (index)
			{
				case 0: // pricing
					// RAS
					break;
				case 1: // solve lineaire
					IfNotExistCreate(_currentTask.Calculation, "Objective", "Swap");
					IfNotExistCreate(_currentTask.Calculation, "Alpha", "1.0");
					IfNotExistCreate(_currentTask.Calculation, "Beta", "0.0");
					IfNotExistCreate(_currentTask.Calculation, "ParamSolving");
					break;
				case 2: // solve
					IfNotExistCreate(_currentTask.Calculation, "Objective", "Swap");
					IfNotExistCreate(_currentTask.Calculation, "Guess", "1.0");
					IfNotExistCreate(_currentTask.Calculation, "ParamSolving");
					break;
				default:
					break;
			}
			// force refresh de la property
			this.propertyGridExParamSolving.Refresh();
		}

		/// <summary>
		/// Ajoute une property si elle n'existe pas
		/// </summary>
		/// <param name="array"></param>
		/// <param name="param"></param>
		private static void IfNotExistCreate(ArrayList array, string param, string value)
		{
			string curValue = RunningTask.GetValue(array, param);
			if (curValue == null)
			{
				PropertyValue prop = new PropertyValue(param, value);
				array.Add(prop);
			}
		}
		/// <summary>
		/// Ajoute une property si elle n'existe pas
		/// </summary>
		/// <param name="array"></param>
		/// <param name="param"></param>
		private static void IfNotExistCreate(ArrayList array, string param)
		{
			IfNotExistCreate(array, param, string.Empty);
		}

	
	}
}
