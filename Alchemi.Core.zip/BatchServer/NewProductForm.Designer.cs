﻿namespace BatchServer
{
	partial class NewProductForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.buttonOk = new System.Windows.Forms.Button();
			this.buttonCancel = new System.Windows.Forms.Button();
			this.label1 = new System.Windows.Forms.Label();
			this.comboBoxScript = new System.Windows.Forms.ComboBox();
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.textBoxDescription = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.comboBoxCalcultationType = new System.Windows.Forms.ComboBox();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.propertyGridExParamSolving = new CaesarView.View.HelperControls.PropertyGridEx();
			this.propertyGridExBumps = new CaesarView.View.HelperControls.PropertyGridEx();
			this.label6 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.propertyGridExProduct = new CaesarView.View.HelperControls.PropertyGridEx();
			this.tableLayoutPanel1.SuspendLayout();
			this.SuspendLayout();
			// 
			// buttonOk
			// 
			this.buttonOk.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.buttonOk.Location = new System.Drawing.Point(274, 537);
			this.buttonOk.Name = "buttonOk";
			this.buttonOk.Size = new System.Drawing.Size(75, 23);
			this.buttonOk.TabIndex = 0;
			this.buttonOk.Text = "Ok";
			this.buttonOk.UseVisualStyleBackColor = true;
			// 
			// buttonCancel
			// 
			this.buttonCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.buttonCancel.Location = new System.Drawing.Point(355, 537);
			this.buttonCancel.Name = "buttonCancel";
			this.buttonCancel.Size = new System.Drawing.Size(75, 23);
			this.buttonCancel.TabIndex = 1;
			this.buttonCancel.Text = "Cancel";
			this.buttonCancel.UseVisualStyleBackColor = true;
			// 
			// label1
			// 
			this.label1.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(54, 7);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(34, 13);
			this.label1.TabIndex = 2;
			this.label1.Text = "Script";
			// 
			// comboBoxScript
			// 
			this.comboBoxScript.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBoxScript.FormattingEnabled = true;
			this.comboBoxScript.Location = new System.Drawing.Point(94, 3);
			this.comboBoxScript.Name = "comboBoxScript";
			this.comboBoxScript.Size = new System.Drawing.Size(312, 21);
			this.comboBoxScript.TabIndex = 3;
			this.comboBoxScript.SelectedIndexChanged += new System.EventHandler(this.comboBoxScript_SelectedIndexChanged);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 2;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 22.24939F));
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 77.75061F));
			this.tableLayoutPanel1.Controls.Add(this.comboBoxScript, 1, 0);
			this.tableLayoutPanel1.Controls.Add(this.label1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.textBoxDescription, 1, 1);
			this.tableLayoutPanel1.Controls.Add(this.label2, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.label3, 0, 6);
			this.tableLayoutPanel1.Controls.Add(this.comboBoxCalcultationType, 1, 6);
			this.tableLayoutPanel1.Controls.Add(this.label4, 1, 7);
			this.tableLayoutPanel1.Controls.Add(this.label5, 0, 8);
			this.tableLayoutPanel1.Controls.Add(this.propertyGridExParamSolving, 1, 8);
			this.tableLayoutPanel1.Controls.Add(this.propertyGridExBumps, 1, 9);
			this.tableLayoutPanel1.Controls.Add(this.label6, 0, 9);
			this.tableLayoutPanel1.Controls.Add(this.label7, 0, 3);
			this.tableLayoutPanel1.Controls.Add(this.propertyGridExProduct, 1, 3);
			this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 10;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
			this.tableLayoutPanel1.Size = new System.Drawing.Size(409, 519);
			this.tableLayoutPanel1.TabIndex = 4;
			// 
			// textBoxDescription
			// 
			this.textBoxDescription.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBoxDescription.Location = new System.Drawing.Point(94, 30);
			this.textBoxDescription.Multiline = true;
			this.textBoxDescription.Name = "textBoxDescription";
			this.textBoxDescription.Size = new System.Drawing.Size(312, 53);
			this.textBoxDescription.TabIndex = 5;
			// 
			// label2
			// 
			this.label2.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(28, 50);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(60, 13);
			this.label2.TabIndex = 6;
			this.label2.Text = "Description";
			// 
			// label3
			// 
			this.label3.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(6, 179);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(82, 13);
			this.label3.TabIndex = 7;
			this.label3.Text = "Calculation type";
			// 
			// comboBoxCalcultationType
			// 
			this.comboBoxCalcultationType.Dock = System.Windows.Forms.DockStyle.Fill;
			this.comboBoxCalcultationType.FormattingEnabled = true;
			this.comboBoxCalcultationType.Items.AddRange(new object[] {
            "Price",
            "SolveLinear",
            "Solve"});
			this.comboBoxCalcultationType.Location = new System.Drawing.Point(94, 175);
			this.comboBoxCalcultationType.Name = "comboBoxCalcultationType";
			this.comboBoxCalcultationType.Size = new System.Drawing.Size(312, 21);
			this.comboBoxCalcultationType.TabIndex = 8;
			this.comboBoxCalcultationType.SelectedIndexChanged += new System.EventHandler(this.comboBoxCalcultationType_SelectedIndexChanged);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Dock = System.Windows.Forms.DockStyle.Fill;
			this.label4.Location = new System.Drawing.Point(94, 199);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(312, 52);
			this.label4.TabIndex = 9;
			this.label4.Text = "Price           = returns premium\r\nSolve          = newton solving of the paramet" +
				"er\r\nSolveLinear = solve for Alpha.Product + Beta = Objective\r\n         ";
			// 
			// label5
			// 
			this.label5.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(13, 322);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(75, 13);
			this.label5.TabIndex = 10;
			this.label5.Text = "Param Solving";
			// 
			// propertyGridExParamSolving
			// 
			// 
			// 
			// 
			this.propertyGridExParamSolving.DocCommentDescription.AccessibleName = "";
			this.propertyGridExParamSolving.DocCommentDescription.AutoEllipsis = true;
			this.propertyGridExParamSolving.DocCommentDescription.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExParamSolving.DocCommentDescription.Location = new System.Drawing.Point(3, 18);
			this.propertyGridExParamSolving.DocCommentDescription.Name = "";
			this.propertyGridExParamSolving.DocCommentDescription.Size = new System.Drawing.Size(0, 52);
			this.propertyGridExParamSolving.DocCommentDescription.TabIndex = 1;
			this.propertyGridExParamSolving.DocCommentImage = null;
			// 
			// 
			// 
			this.propertyGridExParamSolving.DocCommentTitle.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExParamSolving.DocCommentTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
			this.propertyGridExParamSolving.DocCommentTitle.Location = new System.Drawing.Point(3, 3);
			this.propertyGridExParamSolving.DocCommentTitle.Name = "";
			this.propertyGridExParamSolving.DocCommentTitle.Size = new System.Drawing.Size(0, 0);
			this.propertyGridExParamSolving.DocCommentTitle.TabIndex = 0;
			this.propertyGridExParamSolving.DocCommentTitle.UseMnemonic = false;
			this.propertyGridExParamSolving.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGridExParamSolving.HelpVisible = false;
			this.propertyGridExParamSolving.Location = new System.Drawing.Point(94, 254);
			this.propertyGridExParamSolving.Name = "propertyGridExParamSolving";
			this.propertyGridExParamSolving.PropertySort = System.Windows.Forms.PropertySort.NoSort;
			this.propertyGridExParamSolving.SelectedObject = this.propertyGridExParamSolving.Item;
			this.propertyGridExParamSolving.ShowCustomProperties = true;
			this.propertyGridExParamSolving.Size = new System.Drawing.Size(312, 150);
			this.propertyGridExParamSolving.TabIndex = 11;
			this.propertyGridExParamSolving.ToolbarVisible = false;
			// 
			// 
			// 
			this.propertyGridExParamSolving.ToolStrip.AccessibleName = "ToolBar";
			this.propertyGridExParamSolving.ToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
			this.propertyGridExParamSolving.ToolStrip.AllowMerge = false;
			this.propertyGridExParamSolving.ToolStrip.AutoSize = false;
			this.propertyGridExParamSolving.ToolStrip.CanOverflow = false;
			this.propertyGridExParamSolving.ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
			this.propertyGridExParamSolving.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.propertyGridExParamSolving.ToolStrip.Location = new System.Drawing.Point(0, 1);
			this.propertyGridExParamSolving.ToolStrip.Name = "";
			this.propertyGridExParamSolving.ToolStrip.Padding = new System.Windows.Forms.Padding(2, 0, 1, 0);
			this.propertyGridExParamSolving.ToolStrip.Size = new System.Drawing.Size(312, 25);
			this.propertyGridExParamSolving.ToolStrip.TabIndex = 1;
			this.propertyGridExParamSolving.ToolStrip.TabStop = true;
			this.propertyGridExParamSolving.ToolStrip.Text = "PropertyGridToolBar";
			this.propertyGridExParamSolving.ToolStrip.Visible = false;
			// 
			// propertyGridExBumps
			// 
			// 
			// 
			// 
			this.propertyGridExBumps.DocCommentDescription.AccessibleName = "";
			this.propertyGridExBumps.DocCommentDescription.AutoEllipsis = true;
			this.propertyGridExBumps.DocCommentDescription.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExBumps.DocCommentDescription.Location = new System.Drawing.Point(3, 18);
			this.propertyGridExBumps.DocCommentDescription.Name = "";
			this.propertyGridExBumps.DocCommentDescription.Size = new System.Drawing.Size(0, 52);
			this.propertyGridExBumps.DocCommentDescription.TabIndex = 1;
			this.propertyGridExBumps.DocCommentImage = null;
			// 
			// 
			// 
			this.propertyGridExBumps.DocCommentTitle.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExBumps.DocCommentTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
			this.propertyGridExBumps.DocCommentTitle.Location = new System.Drawing.Point(3, 3);
			this.propertyGridExBumps.DocCommentTitle.Name = "";
			this.propertyGridExBumps.DocCommentTitle.Size = new System.Drawing.Size(0, 0);
			this.propertyGridExBumps.DocCommentTitle.TabIndex = 0;
			this.propertyGridExBumps.DocCommentTitle.UseMnemonic = false;
			this.propertyGridExBumps.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGridExBumps.HelpVisible = false;
			this.propertyGridExBumps.Location = new System.Drawing.Point(94, 410);
			this.propertyGridExBumps.Name = "propertyGridExBumps";
			this.propertyGridExBumps.PropertySort = System.Windows.Forms.PropertySort.NoSort;
			this.propertyGridExBumps.SelectedObject = this.propertyGridExBumps.Item;
			this.propertyGridExBumps.ShowCustomProperties = true;
			this.propertyGridExBumps.Size = new System.Drawing.Size(312, 106);
			this.propertyGridExBumps.TabIndex = 13;
			this.propertyGridExBumps.ToolbarVisible = false;
			// 
			// 
			// 
			this.propertyGridExBumps.ToolStrip.AccessibleName = "ToolBar";
			this.propertyGridExBumps.ToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
			this.propertyGridExBumps.ToolStrip.AllowMerge = false;
			this.propertyGridExBumps.ToolStrip.AutoSize = false;
			this.propertyGridExBumps.ToolStrip.CanOverflow = false;
			this.propertyGridExBumps.ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
			this.propertyGridExBumps.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.propertyGridExBumps.ToolStrip.Location = new System.Drawing.Point(0, 1);
			this.propertyGridExBumps.ToolStrip.Name = "";
			this.propertyGridExBumps.ToolStrip.Padding = new System.Windows.Forms.Padding(2, 0, 1, 0);
			this.propertyGridExBumps.ToolStrip.Size = new System.Drawing.Size(312, 25);
			this.propertyGridExBumps.ToolStrip.TabIndex = 1;
			this.propertyGridExBumps.ToolStrip.TabStop = true;
			this.propertyGridExBumps.ToolStrip.Text = "PropertyGridToolBar";
			this.propertyGridExBumps.ToolStrip.Visible = false;
			// 
			// label6
			// 
			this.label6.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(49, 456);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(39, 13);
			this.label6.TabIndex = 14;
			this.label6.Text = "Bumps";
			// 
			// label7
			// 
			this.label7.Anchor = System.Windows.Forms.AnchorStyles.Right;
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(44, 122);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 13);
			this.label7.TabIndex = 15;
			this.label7.Text = "Product";
			// 
			// propertyGridExProduct
			// 
			// 
			// 
			// 
			this.propertyGridExProduct.DocCommentDescription.AccessibleName = "";
			this.propertyGridExProduct.DocCommentDescription.AutoEllipsis = true;
			this.propertyGridExProduct.DocCommentDescription.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExProduct.DocCommentDescription.Location = new System.Drawing.Point(3, 18);
			this.propertyGridExProduct.DocCommentDescription.Name = "";
			this.propertyGridExProduct.DocCommentDescription.Size = new System.Drawing.Size(0, 52);
			this.propertyGridExProduct.DocCommentDescription.TabIndex = 1;
			this.propertyGridExProduct.DocCommentImage = null;
			// 
			// 
			// 
			this.propertyGridExProduct.DocCommentTitle.Cursor = System.Windows.Forms.Cursors.Default;
			this.propertyGridExProduct.DocCommentTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
			this.propertyGridExProduct.DocCommentTitle.Location = new System.Drawing.Point(3, 3);
			this.propertyGridExProduct.DocCommentTitle.Name = "";
			this.propertyGridExProduct.DocCommentTitle.Size = new System.Drawing.Size(0, 0);
			this.propertyGridExProduct.DocCommentTitle.TabIndex = 0;
			this.propertyGridExProduct.DocCommentTitle.UseMnemonic = false;
			this.propertyGridExProduct.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGridExProduct.HelpVisible = false;
			this.propertyGridExProduct.Location = new System.Drawing.Point(94, 89);
			this.propertyGridExProduct.Name = "propertyGridExProduct";
			this.propertyGridExProduct.PropertySort = System.Windows.Forms.PropertySort.NoSort;
			this.propertyGridExProduct.SelectedObject = this.propertyGridExProduct.Item;
			this.propertyGridExProduct.ShowCustomProperties = true;
			this.propertyGridExProduct.Size = new System.Drawing.Size(312, 80);
			this.propertyGridExProduct.TabIndex = 16;
			this.propertyGridExProduct.ToolbarVisible = false;
			// 
			// 
			// 
			this.propertyGridExProduct.ToolStrip.AccessibleName = "ToolBar";
			this.propertyGridExProduct.ToolStrip.AccessibleRole = System.Windows.Forms.AccessibleRole.ToolBar;
			this.propertyGridExProduct.ToolStrip.AllowMerge = false;
			this.propertyGridExProduct.ToolStrip.AutoSize = false;
			this.propertyGridExProduct.ToolStrip.CanOverflow = false;
			this.propertyGridExProduct.ToolStrip.Dock = System.Windows.Forms.DockStyle.None;
			this.propertyGridExProduct.ToolStrip.GripStyle = System.Windows.Forms.ToolStripGripStyle.Hidden;
			this.propertyGridExProduct.ToolStrip.Location = new System.Drawing.Point(0, 1);
			this.propertyGridExProduct.ToolStrip.Name = "";
			this.propertyGridExProduct.ToolStrip.Padding = new System.Windows.Forms.Padding(2, 0, 1, 0);
			this.propertyGridExProduct.ToolStrip.Size = new System.Drawing.Size(312, 25);
			this.propertyGridExProduct.ToolStrip.TabIndex = 1;
			this.propertyGridExProduct.ToolStrip.TabStop = true;
			this.propertyGridExProduct.ToolStrip.Text = "PropertyGridToolBar";
			this.propertyGridExProduct.ToolStrip.Visible = false;
			// 
			// NewProductForm
			// 
			this.AcceptButton = this.buttonOk;
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.CancelButton = this.buttonCancel;
			this.ClientSize = new System.Drawing.Size(429, 563);
			this.Controls.Add(this.tableLayoutPanel1);
			this.Controls.Add(this.buttonCancel);
			this.Controls.Add(this.buttonOk);
			this.Name = "NewProductForm";
			this.ShowInTaskbar = false;
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Create new product";
			this.Load += new System.EventHandler(this.NewProductForm_Load);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.tableLayoutPanel1.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button buttonOk;
		private System.Windows.Forms.Button buttonCancel;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ComboBox comboBoxScript;
		private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
		private System.Windows.Forms.TextBox textBoxDescription;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.ComboBox comboBoxCalcultationType;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private CaesarView.View.HelperControls.PropertyGridEx propertyGridExParamSolving;
		private CaesarView.View.HelperControls.PropertyGridEx propertyGridExBumps;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private CaesarView.View.HelperControls.PropertyGridEx propertyGridExProduct;
	}
}