﻿using System;
using System.Collections.Generic;
using System.Text;
using FuncFramework.PricingBatch;
using FuncFramework.Business.Product;
using FuncFramework.Configuration;
using ScriptTools.Utils;

namespace BatchServer
{
	public static class BatchFactory
	{
		/// <summary>
		/// Créé un ensemble de taches : produit x chaque sous jacent
		/// </summary>
		public static PricingBatch Create(List<string> assets, ProductDataSet product)
		{
			// choppe le panier
			IDataWrapper basketWrapper = product.GetWrapperInField("basket__underlying");
			if (basketWrapper == null)
				throw new Exception("Product must have a basket");

			// la config std
			MonteCarloConfiguration lConfig = new MonteCarloConfiguration(40000, 1.0 / 12.0, StockModelType.LocalVolatility, RateModelType.Deterministic);

			PricingBatch temp = new PricingBatch(assets);
			foreach(string asset in assets)
			{
				// change le panier
				basketWrapper.TryConvert(asset);

				// ajoute la tache
				PricingTask task = new PricingTask(product.Name + " on " + asset, asset, (ProductDataSet)product.Clone(), lConfig, new TreeBump());
				temp.AddTask(task);
			}

			return temp;
		}
	}
}
