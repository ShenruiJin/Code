﻿using System;
using System.Collections.Generic;
using CaesarApplication.Service.Connection;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Strategy;
using FuncFramework.SimulationFactory;
using MarketDataMgr;
using MarketDataMgr.Trees;
using Pricing.MarketData;


namespace BatchServer
{
	/// <summary>
	/// Batch cahrgeant les market data
	/// </summary>
	public class BatchMarketData
	{
		public BatchMarketData()
		{
			// on se connecte
			ConnectionService.ConnectToMarketDataServer();

			// au deal serveur
			ConnectionService.ConnectToDealServer();
		}

		~BatchMarketData()
		{
			ConnectionService.Stop();
		}

        Dictionary<string, IDiscountCurve> _tauxRef = new Dictionary<string, IDiscountCurve>();
		/// <summary>
		/// Retourne une courbe de taux
		/// permet d'eviter de recreer une courbe x fois
		/// </summary>
		/// <param name="ccy"></param>
		/// <returns></returns>
        private IDiscountCurve GetTaux(MarketDataFactory factory, string ccy)
		{
			// on cherche dans le cache
			if (!_tauxRef.ContainsKey(ccy))
			{
				IDiscountCurve Currency = factory.CreateDiscountCurve(ccy);
				_tauxRef.Add(ccy, Currency);
			}

			return _tauxRef[ccy];
		}


		string[] maturity = new string[] { "3m", "6m", "12m", "18m", "24m", "3y", "5y", "10y" };
		double[] strikes = new double[] { 0.9, 0.95, 0.975, 1, 1.025, 1.05, 1.10 };

		/// <summary>
		/// Retourne un header pour le CSV
		/// </summary>
		/// <returns></returns>
		public List<string> MarketDataHeader()
		{
			List<string> lResult = new List<string>();
			for (int i = 0; i < maturity.Length; i++)
			{
				for (int j = 0; j < strikes.Length; j++)
				{
					double strike = (int)(strikes[j] * 100.0);
					string vanille = maturity[i] + "_" + strike + "%";
					// ajoute
					lResult.Add(vanille.ToUpper());
				}
			}
			return lResult;
		}

		/// <summary>
		/// Charge les markets data  
		/// </summary>
		/// <param name="assets"></param>
		public Dictionary<string, List<double>> Run(List<string> assets)
		{
			// charge
			// le gestionnaire de données local pour ne pas surcharger betement la memeoire		
			MarketDataManager myMarketDataMgr = ConnectionService.CreateMarketDataManager();

			// check si le stock existe
			List<string> myAssets = new List<string>();
			foreach (string asset in assets)
			{
				try
				{
					// chekc l'existence
					myMarketDataMgr.CurrentConnection.InstrumentsList.GetInstrument(asset);
					// ajoute
					myAssets.Add(asset);
				}
				catch (KeyNotFoundException)
				{
					LoggingService.Info(typeof(BatchMarketData), "Ignoring : " + asset);
					Console.WriteLine("Ignoring : " + asset);
				}
			}

			// lance la requete
			MarketDataService.CurrentMarketDataTree = new MarketDataTree("MarketData");
			MarketDataService.LoadMarketData(myAssets, "EUR");
			MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree = new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(MarketDataService.CurrentMarketDataTree);
			
			// pour acceder au market data
			MarketDataFactory factory = new MarketDataFactory(tree);

			// on joue avec et on sauve
			Dictionary<string, List<double>> ret = new Dictionary<string, List<double>>();
			foreach (string asset in myAssets)
			{
				// fabrique la vol
				string ccy = factory.GetStockCurrency(asset);
				IDiscountCurve ccyCurve = GetTaux(factory, ccy);
				Pricing.MarketData.Container.StockContainer stock = factory.CreateAction(asset, ccyCurve);

				// les results
				List<double> lResult = new List<double>();
				for (int i = 0; i < maturity.Length; i++)
				{
					double maturityInDays = MarketDataFactory.MaturityToDouble(maturity[i]) * 365.25;
					DateTime matu = DateTime.Today.AddDays(maturityInDays);
					for (int j = 0; j < strikes.Length; j++)
					{
						double strike = strikes[j] * stock.Spot;
						double vol = stock.VolatilitySurface.Volatility(strike, matu);
						// ajoute
						lResult.Add(vol);
					}
				}
				// ajoute
				ret.Add(asset, lResult);
			}
			return ret;
		}
	}
}
