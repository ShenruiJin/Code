﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SpreadsheetGear;
using System.Globalization;
using GlobalDerivativesApplications.Excel;

namespace BatchServer
{
	public partial class GUI : Form
	{
		#region Fields
		List<AssetTask> MyAssets;
		List<string> MyCurrencies;
		RunningTasks MyProduct;
		#endregion

		public GUI()
		{
			InitializeComponent();
		}

		private readonly CultureInfo _culture = new CultureInfo("en-GB");
		private void GUI_Load(object sender, EventArgs e)
		{
			// init la feuille excel
			// Init du tableau
			workbookView.GetLock();
			try
			{
				// Open a workbook into a new workbook set which uses the correct culture.
				IWorkbook workbook = Factory.GetWorkbook(_culture);

				// Display the new workbook in the WorkbookView.
				workbookView.ActiveWorkbook = workbook;

				// Change the display reference to a single range.
				workbookView.DisplayReference = "A:E";

				// Change the text displayed in the WorkbookView tabs.
				workbookView.DisplayReferenceName = "\"My Assets\"";

				// Change the extra color diplayed beyond the last row and column.
				workbookView.ExtraColor = System.Drawing.Color.SlateBlue;

				// Get a reference to the active workbook window info.
				IWorkbookWindowInfo windowInfo = workbookView.ActiveWorkbookWindowInfo;
				// Toggle display of the workbook tabs.
				windowInfo.DisplayWorkbookTabs = false;
				windowInfo.DisplayHorizontalScrollBar = false;

				// les event
				workbookView.RangeChanged += new SpreadsheetGear.Windows.Forms.RangeChangedEventHandler(workbookView_RangeChanged);
			}
			finally
			{
				// NOTE: Must release the workbook set lock.
				workbookView.ReleaseLock();
			}
			// pour les tests
			LoadBatch("Stock");
		}

		/// <summary>
		/// Charge le fichier deal + csv
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void openPricingBatchToolStripMenuItem_Click(object sender, EventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.Filter = "Batch file |*_product.xml";
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				// charge le fichier
				string fileName = dialog.SafeFileName;
				//clean
				string batchExt = "_product.xml";
				if (!fileName.Contains(batchExt))
				{
					MessageBox.Show("Not a valid batch file");
					return;
				}
				fileName = fileName.Remove(fileName.Length - batchExt.Length);
				// go
				LoadBatch(fileName);
			}
		}

		private void saveToolStripMenuItem_Click(object sender, EventArgs e)
		{
			SaveFileDialog dialog = new SaveFileDialog();
			dialog.Filter = "Batch file |*_product.xml";
			if (dialog.ShowDialog() == DialogResult.OK)
			{
				// charge le fichier
				string fileName = dialog.FileName;
				// les ID
				CleanID();
				BatchRunner.SaveRunningTasks(fileName, MyProduct);
			}
		}

		/// <summary>
		/// Charge le fichier
		/// </summary>
		/// <param name="fileName"></param>
		private void LoadBatch(string fileName)
		{
			// charge
			if (!BatchRunner.LoadAssets(fileName, out MyAssets, out MyCurrencies))
				return;
			if (!BatchRunner.LoadRunningTasks(fileName, out MyProduct))
				return;
			// les ID
			CleanID();
			// met à jour la vue
			DataBind();
		}

		/// <summary>
		/// Met à jour le GUI avec les données
		/// </summary>
		private void DataBind()
		{
			// update TreeView
			UpdateTreeview();
			// update les stocks
			workbookView.GetLock();
			try
			{
				// deprotege toutes les cellules
				workbookView.ActiveWorksheet.ProtectContents = false;
				workbookView.ActiveWorksheet.WindowInfo.Zoom = 90;

				// nettoie
				workbookView.ActiveWorksheet.Cells.Clear();
				// Set the color
				workbookView.ActiveWorksheet.Cells.Interior.Color = Color.LightGray;
				workbookView.ActiveWorksheet.Cells.Font.Color = SpreadSheetModel.ColorsManager.SpreadSheet.FontColor;

				// le titre
				string name = "A1:E1";
				SpreadsheetGear.IRange range = workbookView.ActiveWorksheet.Cells[name];
				range.Interior.Color = Color.White;
				range.ColumnWidth = 15;
				range[0, 0].Value = "Security";
				range[0, 0].ColumnWidth = 10;
				range[0, 1].Value = "Currency";
				range[0, 1].ColumnWidth = 10;
				range[0, 2].Value = "Vol Bid";
				range[0, 3].Value = "Vol Ask";
				range[0, 4].Value = "Dividend bump";

				// une petite barre de separation
				FillBorderStyle(range.Borders[BordersIndex.EdgeBottom]);

				// un peu de couleur
				name = "C2:E80";
				range = workbookView.ActiveWorksheet.Cells[name];
				range.Interior.Color = SpreadSheetModel.ColorsManager.SpreadSheet.InteriorColor;

				// On s'occupe des données
				name = "A2:E80";
				range = workbookView.ActiveWorksheet.Cells[name];
				for (int i = 0; i < MyAssets.Count; i++)
				{
					AssetTask task = MyAssets[i];
					int lRow = i;
					range[lRow, 0].Value = task.Name;
					range[lRow, 1].Value = task.Currency;
					range[lRow, 2].Value = task.VolatilityBid;
					range[lRow, 3].Value = task.VolatilityAsk;
					range[lRow, 4].Value = task.Dividend;
				}
			}
			finally
			{
				// NOTE: Must release the workbook set lock.
				workbookView.ReleaseLock();
			}
		}

		/// <summary>
		/// format an excel cell border in a simple style  
		/// </summary>
		/// <param name="border"></param>
		private void FillBorderStyle(IBorder border)
		{
			border.LineStyle = LineStyle.Continuous;
			border.Weight = BorderWeight.Thin;
			border.Color = Color.Black;
		}

		void workbookView_RangeChanged(object sender, SpreadsheetGear.Windows.Forms.RangeChangedEventArgs e)
		{
		}

		/// <summary>
		/// Populate TreeView
		/// </summary>
		private void UpdateTreeview()
		{
			// on trie par nom de script
			Dictionary<string, List<RunningTask>> taskByScript = new Dictionary<string, List<RunningTask>>();
			foreach (RunningTask task in MyProduct.Tasks)
			{
				if (taskByScript.ContainsKey(task.ScriptName))
					taskByScript[task.ScriptName].Add(task);
				else
				{
					List<RunningTask> list = new List<RunningTask>();
					list.Add(task);
					taskByScript.Add(task.ScriptName, list);
				}
			}
			// on affiche
			this.treeView1.BeginUpdate();
			this.treeView1.Nodes.Clear();
			foreach (string taskName in taskByScript.Keys)
			{
				TreeNode node = this.treeView1.Nodes.Add(taskName);
				foreach (RunningTask task in taskByScript[taskName])
				{
					TreeNode nodeMatu = node.Nodes.Add(task.Description);
					nodeMatu.Tag = task;
				}
			}
			this.treeView1.EndUpdate();
			this.treeView1.ExpandAll();
		}

		/// <summary>
		/// Qd on selectionne un produit
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
		{
			if (e.Node.Tag is RunningTask)
			{
				this.pricingTaskControl1.CurrentTask = (RunningTask) e.Node.Tag;
			}
		}

		/// <summary>
		/// Lance le wizard de création d'une nouvelle tache
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void button1_Click(object sender, EventArgs e)
		{
			if (NewProductForm.Show() == DialogResult.OK)
			{
				RunningTask task = NewProductForm.CurrentTask;
				if (!string.IsNullOrEmpty(task.ScriptName))
				{					 
					//ajout
					MyProduct.Tasks.Add(task);
					// les ID
					CleanID();
					// refresh
					DataBind();
				}
			}
		}

		/// <summary>
		/// Nettoie les ID
		/// </summary>
		private void CleanID()
		{
			int id = 0;
			foreach (RunningTask task in MyProduct.Tasks)
			{
				task.ID = id.ToString();
				id++;
			}
		}

		
	}
}
