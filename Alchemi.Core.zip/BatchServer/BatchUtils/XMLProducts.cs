using System;
using System.Collections.Generic;
using System.Xml.Serialization;
using GlobalDerivativesApplications.Serialization;
using CaesarApplication.Service.Logging;
using BatchBusinessObject.BatchTasks;
using BatchServer.BatchExecutors;

namespace BatchServer.BatchUtils
{

    #region transition objects
    /// <summary>
    /// une petite class pour les listes de name-value
    /// </summary>
    public class PropertyValue
    {
        public PropertyValue() { }
        public PropertyValue(string property, string value)
        {
            Property = property;
            Value = value;
        }

        private string _property;
        public string Property
        {
            get { return _property; }
            set { _property = value; }
        }
        private string _value;
        public string Value
        {
            get { return _value; }
            set { _value = value; }
        }
    }


    /// <summary>
    /// Represente un couple solving/pricing + produit avec ces bumps
    /// </summary>
    [XmlRootAttribute("RunningTask", Namespace = "", IsNullable = false)]
    public class RunningTask
    {
        public string ID;
        public string ScriptName;
        public string Description;
        /// <summary>
        /// Type de calcul : solve ou price
        /// </summary>
        public string CalculationType;
        /// <summary>
        /// Name value du type de calcul
        /// </summary>
        [XmlArray("Calculation"), XmlArrayItem("PropertyValue", typeof(PropertyValue))]
        public System.Collections.ArrayList Calculation = new System.Collections.ArrayList();

        /// <summary>
        /// Le produit
        /// </summary>
        [XmlArray("Product"), XmlArrayItem("PropertyValue", typeof(PropertyValue))]
        public System.Collections.ArrayList Product = new System.Collections.ArrayList();

        /// <summary>
        /// Les bumps
        /// </summary>
        [XmlArray("Bumps"), XmlArrayItem("PropertyValue", typeof(PropertyValue))]
        public System.Collections.ArrayList Bumps = new System.Collections.ArrayList();

        /// <summary>
        /// Aide a retrouver une property/value
        /// </summary>
        /// <returns></returns>
        public string GetValue(System.Collections.ArrayList list, string property)
        {
            // les data du produit : pas de try cathc pour ne pas continuer si y'a un pb
            // on vera par la suite qd ce sera safe
            foreach (PropertyValue v in list)
            {
                if (v.Property == property)
                    return v.Value;
            }
            return null;
        }
    }

    /// <summary>
    /// Le fichier qui est une liste de taches
    /// </summary>
    [XmlRootAttribute("RunningTasks", Namespace = "", IsNullable = false)]
    public class RunningTasks
    {
        /// <summary>
        /// Les taches
        /// </summary>
        [XmlArray("Tasks"), XmlArrayItem("RunningTask", typeof(RunningTask))]
        public System.Collections.ArrayList Tasks = new System.Collections.ArrayList();
    }

    #endregion


    public class XMLProducts
    {

        #region attributes

        private RunningTasks _tasks;

        #endregion

        #region constructor

        public XMLProducts(string fileName)
        {
            // charge
            Console.WriteLine("Reading " + fileName + "_product.xml" + "...");
            // liste of products.
            SerializationManager serializer = new SerializationManager(SerializationType.Xml);
            _tasks = serializer.Deserialize<RunningTasks>(fileName + "_product.xml");
            Console.WriteLine(_tasks.Tasks.Count + " products.");
        }

        public XMLProducts(RunningTasks tasks)
        {
            _tasks = tasks;
            Console.WriteLine(_tasks.Tasks.Count + " products.");
        }

        #endregion

        private BatchCalculation ReadCalculation(RunningTask task)
        {
            return new BatchCalculation(
                    task.CalculationType,
                    task.GetValue(task.Calculation, "Margin"),
                    task.GetValue(task.Calculation, "Objective"),
                    task.GetValue(task.Calculation, "Alpha"),
                    task.GetValue(task.Calculation, "Beta"),
                    task.GetValue(task.Calculation, "ParamSolving"),
                    task.GetValue(task.Calculation, "Model"),
                    task.GetValue(task.Calculation, "Engine"),
                    task.GetValue(task.Calculation, "Guess"));
        }

        private ProductCompulsoryProperties ReadCompulsoryProperties(RunningTask task)
        {
            return new ProductCompulsoryProperties(
                task.GetValue(task.Product, "strike"),
                task.GetValue(task.Product, "_maturityDate"));
        }

        private IList<ProductOptionalProperties> ReadOptionalProperties(RunningTask task)
        {
            IList<ProductOptionalProperties> ret = new List<ProductOptionalProperties>();
            foreach (PropertyValue v in task.Product)
            {
                if(v.Property.ToLowerInvariant().CompareTo("strike")!=0 && v.Property.ToLowerInvariant().CompareTo("_maturitydate")!=0)
                {
                    ret.Add(new ProductOptionalProperties(v.Property, v.Value));
                }
            }
            return ret;
        }

        private IList<ProductSensitivity> ReadBumps(RunningTask task)
        {
            IList<ProductSensitivity> ret = new List<ProductSensitivity>();
            foreach (PropertyValue v in task.Bumps)
            {
                ret.Add(new ProductSensitivity(v.Property, v.Value));
            }
            return ret;
        }

        // summary : 
        //      returns an iterator on the products that
        //      were retrieved from the XML file.
        public IEnumerable<KeyValuePair<ProductTask, BatchCalculation>> GetProducts()
        {
            ProductTask temp;
            foreach (RunningTask task in _tasks.Tasks)
			{
                temp = new ProductTask();
                temp.ID = task.ID;
                temp.ScriptName = task.ScriptName;
                temp.Description = task.Description;
                temp.CompulsoryProperties = ReadCompulsoryProperties(task);
                temp.OptionalProperties = ReadOptionalProperties(task);
                temp.Sensitivities = ReadBumps(task);
                yield return new KeyValuePair<ProductTask, BatchCalculation>(temp, ReadCalculation(task));
            }
        }
    }
}
