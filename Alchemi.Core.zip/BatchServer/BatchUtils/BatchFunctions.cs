using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using BatchBusinessObject.BatchTasks;
using BatchServer.BatchExecutors;
using CaesarApplication.Service.Logging;
using FuncFramework.Business.Product;
using Pricing.Engine;

namespace BatchServer.BatchUtils
{
    public static class BatchFunctions
    {


        #region copy methods.
        // summary : 
        //     a file copy method that handles different versions of a file.
        public static void SafeCopy(string src, string dest)
        {
            string temp = dest;
            int i = 1;
            while (File.Exists(temp))
            {
                temp = Path.GetDirectoryName(dest) + "\\" + Path.GetFileNameWithoutExtension(dest) + ".version" + i++ + ".csv";
            }
            if (i != 1)
            {
                File.Move(dest, temp);
            }
            File.Copy(src, dest);
        }


        #endregion

        #region formatage en string et affichage.

        // Formatage des r�sultats de volatilit� pour le stockage dans la base.
        public static string ResultToString(Dictionary<string, List<double>> result)
        {
            string line = "";
            foreach (KeyValuePair<string, List<double>> key in result)
            {
                line += key.Key + ";" + DateTime.Now.ToString() + ";";
                foreach (double vol in key.Value)
                {
                    string volFormatted = (vol * 100.0).ToString("F", System.Globalization.CultureInfo.GetCultureInfo("en-GB"));
                    line += volFormatted + ";";
                }
                line += " \n";
            }
            return line;
        }



        // returns the results from a TaskResult instance formated for storing in the database.
        public static BatchPricingResult PersistBatchResult(int ID, BatchTask task, TaskResult result)
        {
            string variableName = "Error";
            double variableValue = double.NaN;
            string msg = string.Empty;

            try
            {
                if (result.IsOnError)
                {
                    msg = result.Error.Message;
                    msg = msg.Replace("\r\n", " ");
                    msg = msg.Replace("\n", " ");
                }
                else
                    if (task is SolvingLinearTask)
                    {
                        variableName = ((SolvingLinearTask)task).VariableName;
                        if (result.Result.Properties.Contains(variableName))
                        {
                            variableValue = (double)result.Result[variableName];
                        }
                        else
                        {
                            msg = "Error : Value not found on the returned result!";
                        }
                    }
                    else if (task is SolvingTask)
                    {
                        variableName = ((SolvingTask)task).VariableName;
                        if (result.Result.Properties.Contains(variableName))
                        {
                            variableValue = (double)result.Result[variableName];
                        }
                        else
                        {
                            msg = "Error : Value not found on the returned result!";
                        }
                    }
                    else if (task is PricingTask)
                    {
                        variableName = ResultString.Premium;
                        if (result.Result.Properties.Contains(ResultString.Premium))
                        {
                            variableValue = (double)result.Result[ResultString.Premium];
                        }
                        else
                        {
                            msg = "Error : Value not found on the returned result!";
                        }
                    }
                    else
                    {
                        msg = "Error : no corresponding Task type was found!";
                    }
            }
            catch (Exception e)
            {
                msg = e.Message;
            }
            return new BatchPricingResult(ID, variableName, variableValue, msg);

        }

        // summary : converts lists into string lists.
        public static List<string> ListToString<T>(IList<T> list)
        {
            List<string> result = new List<string>();
            foreach (T elt in list)
            {
                result.Add(elt.ToString());
            }
            return result;
        }

        // Used for displaying batch's lists.
        public static void DisplayList<T>(IList<T> list)
        {
            foreach (T a in list)
            {
                Console.WriteLine(a.ToString());
            }
        }

        // Summary:
        // Retourne un header pour le CSV
        public static string MarketDataHeader(string[] maturity, double[] strikes)
        {
            //List<string> lResult = new List<string>();
            string header = "_ID;_Date;";
            for (int i = 0; i < maturity.Length; i++)
            {
                for (int j = 0; j < strikes.Length; j++)
                {
                    double strike = (int)(strikes[j] * 100.0);
                    string vanille = maturity[i] + "_" + strike + "%";
                    header += vanille.ToUpper() + ";";
                }
            }
            return header;
        }


        public static void ResultToCSV(string fileName, string results)
        {
            ResultToCSV(fileName, results, false, null, null);
        }
        public static void ResultToCSV(string fileName, string results, bool addHeaders, string[] maturities, double[] strikes)
        {
            // le fichier temp dans le rep local
            string dir = Path.GetDirectoryName(fileName);
            string tempDir = ".\\TempBatch";
            if (!Directory.Exists(tempDir))
            {
                Directory.CreateDirectory(tempDir);
            }
            string tempFileName = "Batch_" + DateTime.Today.ToString("d") + ".csv";
            tempFileName = tempFileName.Replace('/', '_');
            tempFileName = Path.Combine(tempDir, tempFileName);
            // efface le fichier
            if (File.Exists(tempFileName))
            {
                File.Delete(tempFileName);
            }

            // on sauve le CSV.
            TextWriter tw = new StreamWriter(tempFileName, true, Encoding.ASCII);

            if (addHeaders)
            {
                tw.WriteLine(BatchFunctions.MarketDataHeader(maturities, strikes));
            }

            tw.Write(results);
            tw.Close();

            LoggingService.Info(typeof(Program), "copy files");
            // copy to the final file.
            fileName = fileName + ".csv";
            SafeCopy(tempFileName, fileName);
            // si on est l� c'est que tout c'est bien pass�...on efface le fichier temp
            File.Delete(tempFileName);
        }

        #endregion


        #region subdivisions

        // Deprecated. 
        //summary : returns a subset of a list.
        /*private static IList<T> SubList<T>(IList<T> list, int from, int to)
        {
            IList<T> ret = new List<T>();
            for (int i = from; i < to; i++)
            {
                if (i >= list.Count<T>())
                {
                    break;
                }
                ret.Add(list.ElementAt<T>(i));
            }
            return ret;
        }*/


        // Deprecated.
        // Summary : returns a subset of a list in the same currency.
        /*public static IEnumerable<IList<BatchBasket>> SubLists(IList<BatchBasket> list, string ccy, int p)
        {
            IList<BatchBasket> ret = list.Where<BatchBasket>(elt => elt.GetCurrency() == ccy).ToList<BatchBasket>();
            for (int j = 0; j < ret.Count<BatchBasket>(); j += p + 1)
            {
                yield return SubList<BatchBasket>(ret, j, j + p);
            }
        }*/

        // Summary : returns a subset of a list in the same currency.
        public static IList<BatchBasket> SubLists(IList<BatchBasket> list, string ccy)
        {
            return list.Where(elt => elt.Currency == ccy).ToList();
        }

        #endregion


        #region Logging

        static readonly object locker = new object();

        private static void WriteLine(ConsoleColor color, string message)
        {
            lock (locker)
            {
                Console.ForegroundColor = color;
                Console.WriteLine(message);
            }
        }

        //public static void LogHandler(object sender, Alchemi.Core.LogEventArgs e)
        //{

        //    switch (e.Level)
        //    {
        //        case Alchemi.Core.LogLevel.Debug:
        //            LoggingService.Debug(typeof(BatchExecutor), e.Message);
        //            break;

        //        case Alchemi.Core.LogLevel.Info:
        //            LoggingService.Info(typeof(BatchExecutor), e.Message);
        //            break;
        //        case Alchemi.Core.LogLevel.Error:
        //        case Alchemi.Core.LogLevel.Warn:
        //            LoggingService.Error(typeof(BatchExecutor), e.Message, e.Exception);
        //            WriteLine(ConsoleColor.Red, e.Message);
        //            break;
        //    }
        //}

        #endregion


        #region  functions directly used in the main program
        // Summary : Argument parser.
        public static string GetArgumentValueFrom(string[] parts)
        {
            string[] valueParts = new string[parts.Length - 1];
            Array.Copy(parts, 1, valueParts, 0, valueParts.Length);
            return string.Join(":", valueParts).Trim().Trim('"');
        }

        // message de help (man)
        public static void PrintHelpMessage()
        {
            Console.WriteLine(@"
usage: BatchServer [options]

Valid options:

    /Update /name:DEALID

    /List /type:TYPE

    /Execute /type:TYPE /name:NAME

    /Remove /type:TYPE /name:NAME

    /Create /type:TYPE /name:NAME /fileName:FILENAME

    /Edit /type:TYPE /name:NAME /fileName:FILENAME

    /Export /type:TYPE /name:NAME /fileName:FILENAME /from:FROM_DATE /to:TO_DATE

    /Test:PayoffID /type:TYPE /name:NAME

Description :

    DEALID : the ID of the deal that will be loaded and updated.

    TYPE = [pricing | volatility]. These are the two types of available batches.

    NAME = The name of the batch of the type TYPE that will be executed.

    FILENAME = the path of the file (without extension) that contains the 
               products and assets definition. For Export use, this argument 
               contains the path of the file where the results will be exported.
               if TYPE = volatility, the source file will be a CSV containing
               the assets definitions.
               if TYPE = pricing, the source files will be a CSV file for the
               assets and a XML file for the products.

           Example :
               if the products file's path is ""c:/banque_product.xml"",
               and/or the asset's file is ""c:/banque_asset.csv"",
               FILENAME will be ""c:/banque"".

    FROM_DATE, TO_DATE = the time interval from which we retrieve results.
               The time format is DD/MM/YYYY hh:mm:ss .
               If the time in day is not specified, the time in day of
               FROM_DATE is set to 00:00:00, and the time in day of TO_DATE
               is set to 23:59:59.
               If you want to export just the last result of a batch execution,
               you must set FROM_DATE to ""last"". Thus, you don't need to 
               specify the value of TO_DATE.");
        }

        #endregion

    }
}
