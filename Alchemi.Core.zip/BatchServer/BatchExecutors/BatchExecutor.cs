using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using CaesarApplication.Service.Connection;
using DealBusinessObject;
using CaesarApplication.Service.Persistance;
using GlobalDerivativesApplications.Settings.SophisSettings;


namespace BatchServer.BatchExecutors
{
    public abstract class BatchExecutor
    {
        SophisSettingsManager _sophisSettings;

        private bool _isConnected;

        protected bool IsConnected
        {
            get { return _isConnected; }
        }

        // The constructor connects to the Market Data.
        protected internal BatchExecutor(SophisSettingsManager sophisSettings)
        {
            Console.WriteLine("Connecting to servers...");
            if (sophisSettings != null)
            {
                _sophisSettings = sophisSettings;
                // on se connecte
                GetConnectionToMaketData();
            }
            // au deal serveur
            ConnectionService.ConnectToDealServer();
            if (PersistanceService.ScriptProvider == null)
            {
                throw new DealServerException("A Problem occured while connecting to Deal server!");
            }
            Console.WriteLine("done");
        }

        protected internal void GetConnectionToMaketData()
        {
            ConnectionService.ConnectToMarketDataServer(_sophisSettings);
            _isConnected = true;
            if (!ConnectionService.IsConnectionAvailable(null))
            {
                throw new DealServerException("A Problem occured while connecting to Market Data server!");
            }
        }
    }
}
