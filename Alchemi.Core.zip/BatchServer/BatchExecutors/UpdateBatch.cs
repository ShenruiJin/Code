using System;
using DealBusinessObject.Business;
using DealBusinessObject.IDescription;
using CaesarApplication.Service.Persistance;
using MarketDataMgr.Trees;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Strategy;
using GlobalDerivativesApplications.Settings.SophisSettings;


namespace BatchServer.BatchExecutors
{
    public class UpdateBatch : BatchExecutor
    {

        #region attributes
        
        private string dealID;
        
        #endregion

        #region properties

        public string DealID
        {
            get { return dealID; }
            set { dealID = value; }
        }
        #endregion

        // constructor
        public UpdateBatch (string dealID, SophisSettingsManager sophisSettings)
            : base(sophisSettings)
        {
            this.dealID = dealID;
        }
        

        public void Run()
        {
            LoggingService.Info(typeof(UpdateBatch), "Entering ExecuteHistorizeMarketData");
            Console.WriteLine("Retrieve deals");
            // Retrieve strategies
            DateTime toDate = DateTime.Today;
            DateTime fromDate = toDate.AddMonths(-1);
            IDealDescriptionCollection deals = PersistanceService.DealProvider.GetDeals(fromDate, toDate, PersistanceService.CaesarSession);

            // On charge le deal
            IDealDescription currentDesc = null;
            foreach (IDealDescription dealDesc in deals)
            {
                // on le fait par nom 
                if (dealDesc.Name == dealID)
                {
                    currentDesc = dealDesc;
                    break;
                }
            }
            if (currentDesc == null)
            {
                Console.WriteLine("The deal you tried to update doesn't exist!");
                return;
            }

            Deal myDeal = PersistanceService.DealProvider.ReadDeal(currentDesc, PersistanceService.CaesarSession);
            Console.WriteLine(dealID + " loaded");

            // on l'update
            Console.WriteLine("Loading market data");
            MarketDataTree tree = myDeal.Strategy.MarketDataTree;
            MarketDataService.LoadMarketData(tree, "");
            Console.WriteLine("Done");

            // on le sauve
            Console.WriteLine("Saving");
            myDeal.Strategy.Comments = "Updated on " + DateTime.Now.ToString("dddd, dd MMMM yyyy HH:mm:ss");
            PersistanceService.DealProvider.UpdateDeal(myDeal, PersistanceService.CaesarSession);
            Console.WriteLine("Finished");
            LoggingService.Info(typeof(Program), "Leaving ExecuteHistorizeMarketData");
        }
    }
}
