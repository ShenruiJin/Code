using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Strategy;
using CaesarApplication.Service.Persistance;
using DealBusinessObject.IDescription;
using DealBusinessObject;
using MarketDataMgr.Trees;
using MarketDataMgr;
using CaesarApplication.Service.Connection;
using FuncFramework.SimulationFactory;
using BatchBusinessObject.BatchTasks;
using Pricing.MarketData;
using BatchServer.BatchUtils;
using MarketDataMgr.Connections;
using MarketData;
using GlobalDerivativesApplications;
using GlobalDerivativesApplications.Settings.SophisSettings;
using GlobalDerivativesApplications.Sophis.Parameters.Input;


namespace BatchServer.BatchExecutors
{
    public class VolatilityBatch : BatchExecutor
    {

        #region attributes

        public VolatilityTask Task { get; set; }
        private string _volatilityTaskName;
        public string OutputFileName { get; set; }

        private VolatilityHistorizedResults _result;

        // local variable that are not supposed to be considered as properties.
        // used when executing Run and Export.
        private string[] _maturity = new string[] { "3m", "6m", "12m", "18m", "24m", "3y", "5y", "10y" };
        private double[] _strikes = new double[] { 0.9, 0.95, 0.975, 1, 1.025, 1.05, 1.10 };

        #endregion

        #region properties

        public string VolatilityTaskName
        {
            get { return _volatilityTaskName; }
            set { _volatilityTaskName = value; }
        }

        public VolatilityHistorizedResults Result
        {
            get { return _result; }
            set { _result = value; }
        }
        
        #endregion

        public VolatilityBatch()
            : base(null)
        {
        }

        public VolatilityBatch(string volatilityTaskName, SophisSettingsManager sophisSettings)
            : base(sophisSettings)
        {
            _volatilityTaskName = volatilityTaskName;
        }


        Dictionary<string, Pricing.MarketData.IDiscountCurve> _tauxRef = new Dictionary<string, Pricing.MarketData.IDiscountCurve>();

        private Pricing.MarketData.IDiscountCurve GetTaux(MarketDataFactory factory, string ccy)
        {
            // on cherche dans le cache
            if (!_tauxRef.ContainsKey(ccy))
            {
                Pricing.MarketData.IDiscountCurve Currency = factory.CreateDiscountCurve(ccy);
                _tauxRef.Add(ccy, Currency);
            }

            return _tauxRef[ccy];
        }

        // gets the assets from a file and transforms them into a AssetTask objects.
        private static IList<AssetContext> ReadAssets(string fileName)
        {
            // le gestionnaire de donn�es local pour ne pas surcharger betement la memoire		
            MarketDataManager myMarketDataMgr = ConnectionService.CreateMarketDataManager();
            AssetContext asset;
            IList<AssetContext> listAssets = new List<AssetContext>();
            IList<string> listNames = new List<string>(); // liste de v�rification des r�p�tition.
            string assetFile = fileName + "_asset.csv";
            Console.WriteLine("Reading " + assetFile + "...");
            TextReader tr = new StreamReader(assetFile, Encoding.ASCII);
            string input = null;
            string[] split;
            string assetName;
            while ((input = tr.ReadLine()) != null)
            {
                split = input.Split(';');
                assetName = split[0];

                // // un commentaire ou une string vide.
                if (assetName.StartsWith("//") || string.IsNullOrEmpty(assetName.Trim()))
                {
                    continue;
                }

                // check si le stock existe

                try
                {
                    // check l'existence
                    myMarketDataMgr.CurrentConnection.InstrumentsList.GetInstrument(assetName);
                }
                catch (KeyNotFoundException)
                {
                    LoggingService.Info(typeof(PricingBatchExecutor), "Ignoring : " + assetName);
                    Console.WriteLine("Ignoring : " + assetName);
                    continue;
                }

                if (listNames.Contains(assetName))
                {
                    Console.WriteLine(assetName + " is already in the list - ignored");
                }
                else
                {
                    if (split.Length >= 5)
                    {
                        try
                        {
                            string volBid = split[2];
                            string volAsk = split[3];
                            string dividend = split[4];
                            asset = new AssetContext(split[0], volBid, volAsk, dividend);
                        }
                        catch
                        {
                            asset = new AssetContext(split[0]);
                        }
                    }
                    else if (split.Length == 2)
                    {
                        asset = new AssetContext(split[0]);
                    }
                    else
                    {
                        throw new ArgumentException("The asset file is not well formated!");
                    }
                    listNames.Add(assetName);
                    listAssets.Add(asset);
                }
            }
            tr.Close();
            return listAssets;
        }


        public static VolatilityTask TaskFromFile(string name)
        {
            IList<AssetContext> tempAssets = ReadAssets(name);
            if (tempAssets.Count == 0)
            {
                throw new DealServerException("Failed creating " + name + " : no assets were found!");
            }
            VolatilityTask volTask = new VolatilityTask(name, tempAssets);
            return volTask;
        }

        // stores a task in the database.
        public void CreateTask(string fileName, string name)
        {
            IList<AssetContext> tempAssets = ReadAssets(fileName);
            if (tempAssets.Count == 0)
            {
                throw new DealServerException("Failed creating " + name + " : no assets were found!");
            }
            VolatilityTask volTask = new VolatilityTask(name, tempAssets);
            if (PersistanceService.BatchProvider.CreateVolatilityTask(volTask, PersistanceService.CaesarSession) == null)
            {
                throw new DealServerException("Failed creating " + volTask.Name);
            }
            Console.WriteLine(volTask.VolAssets.Count + " assets.");
        }

        // List of all volatility tasks.
        public IList<IVolatilityTaskDescription> ListVolatilityTasks()
        {
            return PersistanceService.BatchProvider.GetAllVolatilityTasksDescriptions(PersistanceService.CaesarSession);
        }

        // Edit task method.
        public void EditTask(string fileName)
        {
            IList<AssetContext> tempAssets = ReadAssets(fileName);
            if (tempAssets.Count == 0)
            {
                throw new DealServerException("Failed editing " + _volatilityTaskName + " : no assets were found!");
            }
            VolatilityTask volTask = new VolatilityTask(_volatilityTaskName, tempAssets);
            IVolatilityTaskDescription volDesc = PersistanceService.BatchProvider.UpdateVolatilityTask(volTask, PersistanceService.CaesarSession);
            if (volDesc == null)
            {
                throw new DealServerException("Failed editing " + volTask.Name);
            }
        }

        // Remove task method.
        public void RemoveTask()
        {
            if (!PersistanceService.BatchProvider.DeleteVolatilityTask(_volatilityTaskName, PersistanceService.CaesarSession))
            {
                throw new DealServerException("Failed deleting " + _volatilityTaskName);
            }
        }

        // Exporte results to a CSV file.
        public void ExportResults(string fileName, DateTime from, DateTime to)
        {
            string outPut = BatchFunctions.MarketDataHeader(_maturity, _strikes) + "\n";
            IList<VolatilityHistorizedResults> results = PersistanceService.BatchProvider.GetHistorizedVolatilityResult(_volatilityTaskName, from, to, PersistanceService.CaesarSession);
            if (results == null)
            {
                throw new Exception("Couldn't retrieve results from database!");
            }
            else if (results.Count == 0)
            {
                throw new Exception("No stored results were found in the database for the batch " + _volatilityTaskName + " and the time interval that you selected!");
            }
            if (from == DateTime.MinValue)
            {
                outPut += results.First().Result;
            }
            else
            {
                foreach (VolatilityHistorizedResults res in results)
                {
                    outPut += res.Timestamp + " \n";
                    outPut += res.Result + " \n\n";
                }
            }
            BatchFunctions.ResultToCSV(fileName, outPut);
            LoggingService.Info(typeof(Program), "End Exporting results.");
        }

        // execute method.
        public void Run()
        {
            LoggingService.Info(typeof(Program), "Entering volatility batch.");
            if (!IsConnected)
            {
                GetConnectionToMaketData();
            }

            var mdm = ConnectionService.CreateMarketDataManager();
            var gfc = mdm.CurrentConnection as GenericFrameworkConnection;
            if (gfc == null && mdm.CurrentConnection is IConnectionProxy)
            {
                gfc = (mdm.CurrentConnection as IConnectionProxy).UnderlyingConnection as GenericFrameworkConnection;
            }

            // lance la requete
            MarketDataService.CurrentMarketDataTree = new MarketDataTree("MarketData");

            if (Task == null)
                Task = PersistanceService.BatchProvider.ReadVolatilityTask(_volatilityTaskName, PersistanceService.CaesarSession);
            List<string> myAssets = BatchUtils.BatchFunctions.ListToString(Task.VolAssets);
            Console.WriteLine("Reading Market Data...");
            //MarketDataService.LoadMarketData(myAssets, "EUR");
            MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree = new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(MarketDataService.CurrentMarketDataTree);

            // pour acceder au market data
            MarketDataFactory factory = new MarketDataFactory(tree);
            // on joue avec et on sauve
            Dictionary<string, List<double>> ret = new Dictionary<string, List<double>>();
            // peut etre que je dois ajouter subassets.
            int cpt = 0;
            int max = myAssets.Count;

            foreach (string asset in myAssets)
            {
                if (!gfc.InstrumentsList.Instruments.ContainsKey(asset))
                    continue;
                cpt++;

                Tools.IO.StepConsoleProgressBar((double)cpt / (double)max, Console.Out, 50);

                try
                {
                    double[,] vols = gfc.SophisManager2.VolatilityMatrix.GetVolatilityPoints(int.Parse(gfc.InstrumentsList.Instruments[asset].Sicovam),
                                                        _strikes,
                                                        _maturity.Select(x => x.ToMaturity().ToDate(DateTime.Today)).ToArray(),
                                                        false);
                    //double[,] vols = gfc.SophisManager.GetVolatilityPoints(gfc.InstrumentsList.Instruments[asset].Sicovam,
                    //                                      _strikes,
                    //                                      _maturity.Select(x => x.ToMaturity(DateTime.Today).ToDate(DateTime.Today)).ToArray(),
                    //                                      null
                    //                                      );

                    // les results
                    List<double> lResult = new List<double>();
                    for (int i = 0; i < _maturity.Length; i++)
                    {
                        for (int j = 0; j < _strikes.Length; j++)
                        {
                            double vol = vols[j, i];
                            lResult.Add(vol);
                        }
                    }
                    // ajoute
                    ret.Add(asset, lResult);
                }
                catch (Exception e)
                {
                    Console.Error.WriteLine(e.ToString());
                }
            }
            Console.WriteLine(string.Empty);

            if (ret.Count == 0)
            {
                throw new DealServerException("Failed running the volatility batch : " + _volatilityTaskName);
            }

            if (OutputFileName != null && OutputFileName != string.Empty)
            {
                BatchUtils.BatchFunctions.ResultToCSV(OutputFileName, BatchUtils.BatchFunctions.ResultToString(ret), true, _maturity, _strikes);
            }
            else
            {
                _result = new VolatilityHistorizedResults(Task.Name, BatchUtils.BatchFunctions.ResultToString(ret), DateTime.Now);
                if (!PersistanceService.BatchProvider.CreateHistorizedVolatilityResult(_result, PersistanceService.CaesarSession))
                {
                    throw new DealServerException("Failed get historized volatilities : " + _volatilityTaskName);
                }
            }
            LoggingService.Info(typeof(Program), "Leaving volatility batch.");
        }
    }
}
