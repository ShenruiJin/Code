using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using BatchBusinessObject.BatchTasks;
using BatchServer.BatchUtils;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using DealBusinessObject;
using FuncFramework.SimulationFactory.GridSplitter;
using GlobalDerivativesApplications;
using GlobalDerivativesApplications.Settings.SophisSettings;
using MarketDataMgr.Trees;
using FuncFramework.Business.Product;
using FuncFramework.Configuration;


namespace BatchServer.BatchExecutors
{
    /// <summary>
    /// Encapsule l'execution d'un batch de pricing (solving, pricing ...)
    /// </summary>
    public class PricingBatchExecutor : BatchExecutor
    {
        #region attributes

        private string _batchName;
        private BatchHistorizedResults _result;


        #endregion

        #region properties

        public string PricerBatchName
        {
            get { return _batchName; }
            set { _batchName = value; }
        }

        public BatchHistorizedResults Result
        {
            get { return _result; }
            set { _result = value; }
        }

        #endregion

        /// <summary>
        /// Le batch de pricing
        /// </summary>
        /// <param name="batchName">l enom du batch a executer</param>
        public PricingBatchExecutor(SophisSettingsManager sophisSettings)
            : base(sophisSettings)
        {
            try
            {
                // connection grille
                string ip = BatchServer.Properties.Settings.Default.GridServiceIP;
                string msg = GridService.Connect(ip, 8167, "admin", "user");
                Console.WriteLine(msg);
                if (!GridService.IsConnected)
                {
                    throw new Exception();
                }
                // tente une livraison
                if (ip == null)
                {
                    Console.Write("Ship grid .. ");
                    GridService.DeployApplication<FuncFramework.Grid.PricingGrid>(typeof(IPricingGrid));
                    GridService.DeployApplication<FuncFramework.Grid.SolvingGrid>(typeof(ISolvingGrid));
                    GridService.DeployApplication<FuncFramework.Grid.SolvingLinearGrid>(typeof(ISolvinLineargGrid));
                    GridService.DeployApplication<FuncFramework.Grid.LocalVolatilityGrid>(typeof(ICalibrationGrid));
                    GridService.GridServiceVersion = typeof(FuncFramework.Grid.PricingGrid).Assembly.GetName().Version.ToString();
                    Console.WriteLine("done");
                }
                else
                {
                    GridService.GridServiceVersion = "0.0.0.28272";
                    // GridService.GridTag = GDAGrid.GridCore.DBBusinessObjects.GridTag.Local;
                    //  force
                    // FuncFramework.Grid.LocalVolatilityGrid grid = new FuncFramework.Grid.LocalVolatilityGrid();
                }
            }
            catch (Exception)
            {
                throw new DealServerException("A Problem occured while connecting to the Grid service!");
            }
        }

        /// <summary>
        /// Recup les produit x basket a pricer et sauve
        /// </summary>
        public void Run(BatchPricing batch, BatchMarketContext context)
        {
            _result = new BatchHistorizedResults(batch.Name);

            RunOnly(batch, context);

            Console.WriteLine("Saving");
            if (!PersistanceService.BatchProvider.CreateHistorizedBatchResult(_result, PersistanceService.CaesarSession))
            {
                throw new DealServerException("Failed saving the results of the pricing batch : " + _batchName);
            }

            Console.WriteLine("Done.");
        }

        /// <summary>
        /// Recup les produit x basket a pricer
        /// </summary>
        public void RunOnly(BatchPricing batch, BatchMarketContext context)
        {
            Stopwatch pricingWatch = new Stopwatch();
            Stopwatch marketdataWatch = new Stopwatch();


            LoggingService.Info(typeof(Program), "Executing batch " + batch.Name);
            _batchName = batch.Name;
            // Setting up results requirements.
            _result = new BatchHistorizedResults(batch.Name);
            _result.Start();

            LoggingService.Info(typeof(Program), "Execute tasks");
            Console.WriteLine("Starting (" + batch.Count + " tasks)");
            foreach (string ccy in BatchPricing.GetCurrencies(batch))
            {
                // le qto
                Console.WriteLine("Current Currency = " + ccy);

                // on va charger tout d'un coup : on prend tout les sous jacents dans une devise
                Console.Write("Reading market data ...");
                IList<string> assetsList = BatchPricing.GetAssets(batch, ccy);
                MarketDataService.CurrentMarketDataTree = new MarketDataTree("MarketData");
                marketdataWatch.Start();
                MarketDataService.LoadMarketData(assetsList, ccy);
                marketdataWatch.Stop();
                MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree = new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(MarketDataService.CurrentMarketDataTree);
                Console.WriteLine("done");

                // launches and waits for the results.
                Console.WriteLine("Start computation : " + batch.Count + " tasks");

                // le resultat de ce run
                BatchResult result = new BatchResult();
                // liens entre les taches de batch et celle de pricing
                Dictionary<BatchPricingTask, BatchTask> bindTasks = new Dictionary<BatchPricingTask, BatchTask>();
                // on met en cache le tree pour eviter de le renvoyer a chaque pricing
                using (GridConstant constant = new GridConstant())
                {
                    // ajoute au cache
                    constant.Add(tree);

                    // le pricer
                    BatchPricer batchPricer = new BatchPricer(tree);
                    batchPricer.Progress += percent =>
                    {
                        Tools.IO.StepConsoleProgressBar(percent, Console.Out, 80);
                        Console.Write(" " + ccy);
                        Console.Out.Flush();
                    };
                    pricingWatch.Start();
                    batchPricer.Start(result);
                    // we create tasks by listing all the products x Baskets combinations.
                    Console.Write("Enumerate tasks...");
                    // on transforme chaque tache en executable
                    foreach (BatchPricingTask task in batch.Tasks.Where(bpt => bpt.Basket.Currency == ccy))
                    {
                        ProductDataSet product;
                        PricingConfiguration config;
                        TreeBump treeBump;
                        // transforme la tache en version priceable
                        BatchTask lTask = BatchService.GetTask(task, context, tree, out product, out config, out treeBump);
                        // stocke
                        bindTasks.Add(task, lTask);
                        // execute
                        batchPricer.AddTask(lTask, product, config, treeBump);
                    }
                    // on petouille
                    batchPricer.Wait();
                    pricingWatch.Stop();
                }
                Console.WriteLine();
                if (result.Status.Error != null)
                {
                    throw new DealServerException("Failed running the pricing batch : " + _batchName);
                }
                Console.WriteLine("Done");

                // transfert dans la structure de batch Result
                foreach (var couple in bindTasks)
                {
                    // la tache du batch
                    BatchPricingTask pricingTask = couple.Key;
                    // son copain en mode pricing
                    BatchTask task = couple.Value;
                    // le result
                    TaskResult lRes = result.GetResults(task);
                    // trasnfert
                    BatchPricingResult pricingRes = BatchFunctions.PersistBatchResult(pricingTask.ID, task, lRes);
                    // stock
                   _result.AddResult(pricingRes);
                }
            }

            // fin du pricing : un petit tampon
            _result.End();
            LoggingService.Info(typeof(Program), string.Format("Leaving pricing batch. pricing: {0}sec marketdata: {1}sec", pricingWatch.Elapsed.TotalSeconds, marketdataWatch.Elapsed.TotalSeconds));
        }
    }
}
