﻿using System;
using System.Linq;
using BatchServer.BatchUtils;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Serialization;
using BatchBusinessObject.BatchTasks;
using System.Collections.Generic;
using MarketDataMgr;
using CaesarApplication.Service.Connection;
using System.IO;
using System.Text;
using BatchServer.BatchExecutors;
using CaesarApplication.Service.Persistance;
using Pricing.Engine;
using System.Globalization;


namespace BatchServer
{
    /// <summary>
    /// Ensemble d'utilitaires pour créer des batchs/basket ...
    /// </summary>
    public class BatchCreator
    {
        // Summary:
        //     gets the assets from a file and transforms them into AssetTask objects.
        // precondition : 
        //      the file has to be a csv with the Sophis name (bbg) in the first column, and then the base's ID.
        // Parameters:
        //   fileName : 
        //     The files path.
        // Returns:
        //     a list of baskets.
        // precondition : 
        //     CSV file format : | Name | Ccy | VolBid | VolAsk | Bump Div | Basket ID | Weight |
        //  or | Name | Ccy | VolBid | VolAsk | BumpDiv |
        public static IList<BatchBasket> ReadBaskets(string fileName)
        {
            string assetFile = fileName + "_asset.csv";
            Console.WriteLine("Reading " + assetFile + "...");
            // le gestionnaire de données local pour ne pas surcharger betement la memeoire.
            MarketDataManager myMarketDataMgr = ConnectionService.CreateMarketDataManager();

            IDictionary<String, BatchBasket> BasketsDico = new Dictionary<String, BatchBasket>();
            IDictionary<String, IList<string>> NamesDico = new Dictionary<String, IList<string>>();

            // Temporary data to return.
            IList<WeightedAssets> tempList; // the weighted assets.
            BatchBasket tempbasket; // the basket.
            TextReader tr = new StreamReader(assetFile, Encoding.ASCII);
            string input = null;
            string[] split;
            string assetName;
            string basketID;
            while ((input = tr.ReadLine()) != null)
            {
                if (input.Trim().StartsWith("//"))
                {
                    continue;
                }
                split = input.Split(';');
                assetName = split[0];

                if (split.Length != 7 && split.Length != 5)
                {
                    throw new Exception("The assets are not correctly formated in the csv file");
                }

                assetName = split[0];
                string currency = split[1];
                basketID = string.Empty;
                double weight = 1.0;

                if (split.Length == 7) //// basket entry
                {
                    basketID = split[5];
                    weight = Double.Parse(split[6], System.Globalization.CultureInfo.InvariantCulture);
                }

                try
                {
                    // check si le stock existe
                    myMarketDataMgr.CurrentConnection.InstrumentsList.GetInstrument(assetName);
                }
                catch (KeyNotFoundException)
                {
                    LoggingService.Info(typeof(BatchPricing), "Ignoring : " + assetName);
                    Console.WriteLine("Ignoring : " + assetName);
                    continue;
                }

                if (basketID == string.Empty) //// monoasset
                {
                    basketID = assetName + "|" + currency;
                    weight = 1.0;
                }

                if (!BasketsDico.ContainsKey(basketID))
                {
                    tempList = new List<WeightedAssets>();
                    tempbasket = new BatchBasket(tempList, currency);
                    BasketsDico.Add(new KeyValuePair<string, BatchBasket>(basketID, tempbasket));
                    NamesDico.Add(new KeyValuePair<string, IList<string>>(basketID, new List<string>()));
                }



                // avoid repeated assets.
                if (NamesDico[basketID].Contains(assetName + "|" + currency))
                {
                    Console.WriteLine(assetName + " is already in the list - ignored");
                    continue;
                }

                NamesDico[basketID].Add(assetName + "|" + currency);
                BasketsDico[basketID].Assets.Add(new WeightedAssets(assetName, weight));
            }
            tr.Close();

            BasketsDico.Remove(string.Empty);
            List<BatchBasket> taskList = BasketsDico.Values.ToList<BatchBasket>();
            return taskList;
        }

        /// <summary>
        /// Cree rapidos un context
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        public static BatchMarketContext CreateContext(BatchPricing batch)
        {
            IList<string> assets = BatchPricing.GetAssets(batch);

            List<AssetContext> context = new List<AssetContext>();
            foreach (string asset in assets)
            {
                AssetContext ctx = new AssetContext(asset, "-0.0", "0.0", "0.0");
                context.Add(ctx);
            }
            return new BatchMarketContext("Market Context for " + batch.Name, context);
        }


        /// <summary>
        /// Sauvegarde le fichier
        /// </summary>
        /// <param name="fileName"></param>
        /// <param name="tasks"></param>
        /// <returns></returns>
        public static bool SaveRunningTasks(string fileName, RunningTasks tasks)
        {
            // sauvegarde
            try
            {
                // ID
                int id = tasks.Tasks.Count;
                foreach (RunningTask task in tasks.Tasks)
                {
                    id++;
                    task.ID = id.ToString();
                }

                SerializationManager serializer = new SerializationManager(SerializationType.Xml);
                serializer.Serialize(tasks, fileName);
            }
            catch (Exception e)
            {
                LoggingService.Error(typeof(BatchCreator), "Whoops", e);
                Console.WriteLine("Wooops " + e.Message);
                Console.ReadKey();
                return false;
            }
            return true;
        }


        /// <summary>
        /// Exporte results to a CSV file.
        /// </summary>
        public static void ExportResults(string batchName, string fileName, DateTime from, DateTime to)
        {
            IList<BatchHistorizedResults> results = PersistanceService.BatchProvider.GetHistorizedBatchResult(batchName, from, to, PersistanceService.CaesarSession);
            ExportResults(batchName, fileName, results, from);
        }

        /// <summary>
        /// Exporte results to a CSV file.
        /// </summary>
        public static void ExportResults(string batchName, string fileName, IList<BatchHistorizedResults> results, DateTime from, BatchPricing batchForMetaInfo = null)
        {
            string outPut = "";

            if (results == null)
            {
                throw new Exception("Couldn't retrieve results from database!");
            }
            else if (results.Count == 0)
            {
                throw new Exception("No stored results were found in the database for the batch " + batchName + " and the time interval that you selected!");
            }

            CultureInfo outputCulture = CultureInfo.GetCultureInfo("en-GB");
            if (from == DateTime.MinValue)
            {
                BatchHistorizedResults res = results.First();
                foreach (BatchPricingResult key in res.Result)
                {
                    // de l'info
                    outPut += key.TaskID;
                    // optional , just for compatibility with previous version.
                    outPut += res.StartDate.ToShortDateString() + ";";
                    // le result
                    outPut += key.Variable + ";" + key.VariableValue.ToString(outputCulture) + "\n";
                }
            }
            else
            {
                foreach (BatchHistorizedResults res in results)
                {
                    foreach (BatchPricingResult key in res.Result)
                    {
                        if (batchForMetaInfo == null)
                        {
                            outPut += key.TaskID + ";";
                            // optional , just for compatibility with previous version.
                            outPut += res.StartDate.ToShortDateString() + ";";
                            // le result
                            outPut += key.Variable + ";" + key.VariableValue.ToString(outputCulture) + "\n";
                        }
                        else
                        {
                            BatchPricingTask referenceTask = batchForMetaInfo.Tasks.FirstOrDefault(task => task.ID == key.TaskID);

                            outPut += referenceTask.Product.ID + ";";
                            outPut += referenceTask.Product.Description + ";";
                            outPut += referenceTask.Basket.Assets.Stringify("|", wa => wa.Asset) + ";";
                            outPut += referenceTask.Basket.Currency + ";";
                            outPut += "QF = 1;";
                            outPut += res.StartDate.ToShortDateString() + ";";
                            outPut += key.Variable + ";" + key.VariableValue.ToString(outputCulture) + "\n";
                        }
                    }
                    outPut += " \n\n";
                }
            }
            BatchFunctions.ResultToCSV(fileName, outPut);
            LoggingService.Info(typeof(Program), "End Exporting results.");
        }





        /// <summary>
        /// Fabrique une liste de produit pour les emerging
        /// </summary>
        /// <param name="productFile"></param>
        private static void BuildEmergingProductList(RunningTasks MyProduct)
        {
            string[] maturities = new string[] { "1M", "2M", "3M", "6M", "9M", "1Y", "18M" };
            string[] margins = new string[] { "0.0030", "0.0035", "0.0040", "0.0050", "0.0060", "0.01", "0.01" };
            for (int i = 0; i < maturities.Length; i++)
            {
                // reverse 80%
                MyProduct.Tasks.Add(CreateSweetReverseUS(maturities[i], margins[i], "80%", "0.8"));
                MyProduct.Tasks.Add(CreateSweetReverse(maturities[i], margins[i], "80%", "0.8"));
                MyProduct.Tasks.Add(CreateReverseConvertible(maturities[i], margins[i], "80%", "0.8", "1.25"));
                // reverse 70%
                MyProduct.Tasks.Add(CreateSweetReverseUS(maturities[i], margins[i], "70%", "0.7"));
                MyProduct.Tasks.Add(CreateSweetReverse(maturities[i], margins[i], "70%", "0.7"));
                MyProduct.Tasks.Add(CreateReverseConvertible(maturities[i], margins[i], "70%", "0.7", "1.4286"));
                // airbag 
                MyProduct.Tasks.Add(CreateAirbag(maturities[i], margins[i], "70%", "0.7"));
                MyProduct.Tasks.Add(CreateAirbag(maturities[i], margins[i], "80%", "0.8"));
                // call / put
                MyProduct.Tasks.Add(CreateVanillaCall(maturities[i], margins[i]));
                MyProduct.Tasks.Add(CreateVanillaPut(maturities[i], margins[i]));
                // call vs putspread
                MyProduct.Tasks.Add(CreateCallvsPutSpread(maturities[i], margins[i]));
            }
        }

        /// <summary>
        /// Fabrique une liste de produit pour les emerging
        /// </summary>
        /// <param name="productFile"></param>
        private static void BuildRussianProductList(RunningTasks MyProduct)
        {
            string[] maturities = new string[] { "1M", "2M", "3M", "6M", "9M", "1Y", "18M" };
            string[] margins = new string[] { "0.0275", "0.0275", "0.0275", "0.0375", "0.0375", "0.0375", "0.0375" };
            for (int i = 0; i < maturities.Length; i++)
            {
                // turbo 
                MyProduct.Tasks.Add(CreateTurbo(maturities[i], margins[i], "125%", "1.25"));
                MyProduct.Tasks.Add(CreateTurbo(maturities[i], margins[i], "150%", "1.50"));
                MyProduct.Tasks.Add(CreateTurbo(maturities[i], margins[i], "200%", "2.00"));
            }
        }


        /// <summary>
        /// Fabrique une liste de produit pour les indices, batch Gilles Leclerrc
        /// </summary>
        /// <param name="productFile"></param>
        internal static void BuildIndexProductListEquityResearch(RunningTasks MyProduct)
        {
            string[] maturities = new string[] { "1M", "2M", "3M", "6M", "9M", "1Y" };
            string[] margins = new string[] { "0.0030", "0.0035", "0.0040", "0.0042", "0.0045", "0.005" };
            for (int i = 0; i < maturities.Length; i++)
            {
                MyProduct.Tasks.Add(CreateSweetReverse(maturities[i], margins[i], "80%", "0.8", string.Empty + (29 + 2 * i)));
                MyProduct.Tasks.Add(CreateReverseConvertible(maturities[i], margins[i], "100%", "1.0", "1.0", string.Empty + (30 + 2 * i)));
            }

            maturities = new string[] { "1Y", "3Y", "5Y", "10Y" };
            margins = new string[] { "0.005", "0.006", "0.0070", "0.01" };
            for (int i = 0; i < maturities.Length; i++)
            {
                MyProduct.Tasks.Add(CreateSolvingCall(maturities[i], margins[i], string.Empty + (41 + 4 * i)));
                MyProduct.Tasks.Add(CreateAsianCall(maturities[i], margins[i], "3M", string.Empty + (42 + 4 * i)));
                MyProduct.Tasks.Add(CreateCallvsPutSpread(maturities[i], margins[i], string.Empty + (43 + 4 * i)));
                MyProduct.Tasks.Add(CreateAirbag(maturities[i], margins[i], "80%", "0.8", string.Empty + (44 + 4 * i)));
            }
        }

        /// <summary>
        /// Fabrique une liste de produit pour les indices
        /// </summary>
        /// <param name="productFile"></param>
        internal static void BuildIndexProductList(RunningTasks MyProduct)
        {

            string[] maturities = new string[] { "3Y", "5Y", "8Y", "10Y" };

           // 100% KG
            string[] margins = new string[] { "0.010", "0.0170", "0.02", "0.02" };
            for (int i = 0; i < maturities.Length; i++)
            {
                MyProduct.Tasks.Add(CreateSolvingCall(maturities[i], margins[i]));
                MyProduct.Tasks.Add(CreateCallSpread(maturities[i], margins[i], "180%", "1.8"));
                MyProduct.Tasks.Add(CreateCallSpread(maturities[i], margins[i], "160%", "1.6"));
                MyProduct.Tasks.Add(CreateSolvingPut(maturities[i], margins[i]));

                MyProduct.Tasks.Add(CreatePutSpread(maturities[i], margins[i]));

                MyProduct.Tasks.Add(CreateDigitales(maturities[i], margins[i], "100%", "1", "0%", "0", "1y"));
                MyProduct.Tasks.Add(CreateDigitales(maturities[i], margins[i], "115%", "1.15", "0%", "0", "1y"));
                MyProduct.Tasks.Add(CreateDigitales(maturities[i], margins[i], "100%", "1", "5%", "0.05", "1y"));
            }

            margins = new string[] { "0.035", "0.045", "0.055", "0.055" };
            for (int i = 0; i < maturities.Length; i++)
            {
                // autocall
                MyProduct.Tasks.Add(CreateAutocall(maturities[i], margins[i], "60%", "0.6", "1y"));
                MyProduct.Tasks.Add(CreateAutocall(maturities[i], margins[i], "70%", "0.7", "1y"));
                MyProduct.Tasks.Add(CreatePhoenix(maturities[i], margins[i], "85%", "0.85", "60%", "0.6", "1y"));
                MyProduct.Tasks.Add(CreatePhoenix(maturities[i], margins[i], "70%", "0.7", "60%", "0.6", "1y"));
                MyProduct.Tasks.Add(CreatePhoenix(maturities[i], margins[i], "85%", "0.85", "70%", "0.7", "1y"));
                MyProduct.Tasks.Add(CreatePhoenix(maturities[i], margins[i], "70%", "0.7", "70%", "0.7", "1y"));
            }
        }


        #region Differents produits

        // call
        private static RunningTask CreateVanillaCall(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Vanilla";
            task.Description = "Call (K = 100%);" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Price";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("PayoffType", "Call"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }

        // put
        private static RunningTask CreateVanillaPut(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Vanilla";
            task.Description = "Put (K = 100%);" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Price";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("PayoffType", "Put"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));
            task.Bumps.Add(new PropertyValue("Dividend", "Bid"));

            return task;
        }

        // solving de call asian
        private static RunningTask CreateSolvingCall(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Vanilla";
            task.Description = "Call (K = 100%);" + "Margin = " + margin + ";" + maturity;
            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "0.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS | BULLET | 0;5"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }

        // solving de put
        private static RunningTask CreateSolvingPut(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Vanilla";
            task.Description = "Put (K = 100%);" + "Margin = " + margin + ";" + maturity;
            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "0.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("PayoffType", "Put"));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS | BULLET | 0;5"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }


        // solving de Call Spread
        private static RunningTask CreateCallSpread(string maturity, string margin, string CAP, string CapValue, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Call Spread";
            task.Description = "Gearing * Call Spread 100%/" + CAP + ";" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "swap"));
            task.Calculation.Add(new PropertyValue("Guess", "1.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("Cap", CapValue));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS | BULLET | 0;5"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        // solving de Call Spread
        private static RunningTask CreatePutSpread(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Call Spread";
            task.Description = "Put Spread CAP% /100%;" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "swap"));
            task.Calculation.Add(new PropertyValue("Guess", "0.8"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Cap"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("PayoffType", "Put"));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS | BULLET | 0;5"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        /// <summary>
        /// Convert string double to string %
        /// </summary>
        /// <param name="aDouble"></param>
        /// <returns></returns>
        private static string ToPercent(string aDouble)
        {
            return double.Parse(aDouble, System.Globalization.CultureInfo.InvariantCulture).ToString("P");
        }

        // solving de Call UO
        private static RunningTask CreateCallUO(string maturity, string margin, string Barrier, string Rebate, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch CUO";
            task.Description = "CUO " + ToPercent(Barrier) + " Rebate " + ToPercent(Rebate) + ";Margin = " + ToPercent(margin) + ";" + maturity;

            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "0.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("BarrierUO", Barrier));
            task.Product.Add(new PropertyValue("Rebate", Rebate));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS | BULLET | 0;5"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }


        // Digitale
        private static RunningTask CreateDigitales(string maturity, string margin, string barrierTitle, string barrier, string incrmentTitle, string increment, string frequency, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Digital";
            task.Description = "Digitale Natixis SP (Coupon @ " + barrierTitle + " Increment =" + incrmentTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "NATIXIS SP | BULLET | 0;5"));
            task.Calculation.Add(new PropertyValue("Guess", "0.05"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("Barrier", barrier));
            task.Product.Add(new PropertyValue("BarrierIncrement", increment));
            task.Product.Add(new PropertyValue("Frequency", frequency));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS SP | BULLET | 0;5"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        // phoenix
        private static RunningTask CreatePhoenix(string maturity, string margin, string barrierTitle, string barrier, string pdiTitle, string pdi, string frequency, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Phoenix";
            task.Description = "Phoenix Natixis SP (Coupon @ " + barrierTitle + " PDI @ " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "NATIXIS SP | NO BULLET | 0;5"));
            task.Calculation.Add(new PropertyValue("Guess", "0.05"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("PDIBarrier", pdi));
            task.Product.Add(new PropertyValue("CouponBarrier", barrier));
            task.Product.Add(new PropertyValue("Frequency", frequency));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS SP | NO BULLET | 0;5"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            // hybrid
            task.Product.Add(new PropertyValue("Model", "Hybrid"));
            return task;
        }


        // phoenix
        private static RunningTask CreateAutocall(string maturity, string margin, string pdiTitle, string pdi, string frequency, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Autocall";
            task.Description = "Autocall Natixis SP (PDI @ " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "MonteCarlo"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "NATIXIS SP | NO BULLET | 0;5"));
            task.Calculation.Add(new PropertyValue("Guess", "0.05"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("PDIBarrier", pdi));
            task.Product.Add(new PropertyValue("Frequency", frequency));
            task.Product.Add(new PropertyValue("liborCurve", "NATIXIS SP | NO BULLET | 0;5"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            // hybrid
            task.Product.Add(new PropertyValue("Model", "Hybrid"));
            return task;
        }

        #region Extra
        // solving de call asian
        private static RunningTask CreateAsianCall(string maturity, string margin, string Period, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Asian";
            task.Description = "Call Asian " + Period + " K = 100%;" + "Margin = " + margin + ";" + maturity;
            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "0.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("Period", Period));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }

        // solving de call asian
        private static RunningTask CreateAsianFloorCall(string maturity, string margin, string Period, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Asian Floor";
            task.Description = "Call Asian Floor " + Period + " K = 100%;" + "Margin = " + margin + ";" + maturity;
            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "0.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("Period", Period));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }

        // air bag
        private static RunningTask CreateAirbag(string maturity, string margin, string pdiTitle, string pdi, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Airbag";
            task.Description = "AirBag : Call vs PDI(European Barrier = " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Guess", "1.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("BarrierDI", pdi));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        private static RunningTask CreateSweetReverse(string maturity, string margin, string pdiTitle, string pdi, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Sweet Reverse";
            task.Description = "Sweet Reverse (European Barrier = " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "-1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "Discount"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("BarrierDI", pdi));
            task.Product.Add(new PropertyValue("BarrierType", "European"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        private static RunningTask CreateSweetReverseUS(string maturity, string margin, string pdiTitle, string pdi, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Sweet Reverse";
            task.Description = "Sweet Reverse (American Barrier = " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            // le calcul
            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "-1.0"));
            task.Calculation.Add(new PropertyValue("Beta", "Discount"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("BarrierDI", pdi));
            task.Product.Add(new PropertyValue("BarrierType", "American"));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }


        // reverse convertible : short put
        private static RunningTask CreateReverseConvertible(string maturity, string margin, string strikeTitle, string strike, string gearing, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Vanilla";
            task.Description = "Reverse Convertible (" + strikeTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "SolveLinear";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Alpha", "-" + gearing));
            task.Calculation.Add(new PropertyValue("Beta", "Discount"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Coupon"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", strike));
            task.Product.Add(new PropertyValue("PayoffType", "Put"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        // air bag
        private static RunningTask CreateCallvsPDI(string maturity, string margin, string pdiTitle, string pdi, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Airbag";
            task.Description = "AirBag : Call vs PDI(European Barrier = " + pdiTitle + ");" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Guess", "1.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            task.Product.Add(new PropertyValue("BarrierDI", pdi));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }

        // solving de call vs PutSpread
        private static RunningTask CreateCallvsPutSpread(string maturity, string margin, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Call vs PutSpread";
            task.Description = "Gearing.Call Vs PutSpread(80%, 100%);" + "Margin = " + margin + ";" + maturity;

            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "Swap"));
            task.Calculation.Add(new PropertyValue("Guess", "1.0"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Gearing"));
            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("strike", "1.0"));
            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Ask"));

            return task;
        }

        // Turbor 125%
        private static RunningTask CreateTurbo(string maturity, string margin, string gearingTitle, string gearing, string ID = "0")
        {
            RunningTask task = new RunningTask();
            task.ID = ID;
            task.ScriptName = "Batch Turbo";
            task.Description = "Turbo (Gearing = " + gearingTitle + "%);" + "Margin = " + margin + ";" + maturity;

            // le calcul
            task.CalculationType = "Solve";
            task.Calculation.Add(new PropertyValue("Engine", "PDE"));
            task.Calculation.Add(new PropertyValue("Margin", margin));
            task.Calculation.Add(new PropertyValue("Objective", "NATIXIS SP | BULLET | 0;5"));
            task.Calculation.Add(new PropertyValue("Guess", "0.05"));
            task.Calculation.Add(new PropertyValue("ParamSolving", "Cap"));

            // produit
            task.Product.Add(new PropertyValue("_maturityDate", maturity));
            task.Product.Add(new PropertyValue("Gearing", gearing));

            // bump
            task.Bumps.Add(new PropertyValue("Volatility", "Bid"));

            return task;
        }
        #endregion

        #endregion
    }
}
