﻿using System;
using System.Linq;
using System.Collections.Generic;
using Pricing.MarketData;
using CaesarApplication.Service.Connection;
using DealBusinessObject.IDescription;
using log4net.Config;
using CaesarApplication.Service.Logging;
using BatchServer.BatchUtils;
using BatchServer.BatchExecutors;
using CaesarApplication.Properties;
using CaesarApplication.Service.Strategy;
using BatchBusinessObject.BatchTasks;
using CaesarApplication.Service.Persistance;
using GlobalDerivativesApplications.Settings.SophisSettings;
using FuncFramework.SimulationFactory.GridSplitter;
using System.Reflection;


namespace BatchServer
{
    static class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            // Load log4net engine
            XmlConfigurator.Configure();
            LoggingService.Info(typeof(Program), "Caesar Batch is starting...");

            Console.WriteLine("*********************************************");
            Console.WriteLine("*      Welcome to Caesar Batch              *");
            Console.WriteLine("*********************************************");
            Console.WriteLine();

            // not enough arguments?
            if (args.Length <= 0)
            {
                BatchFunctions.PrintHelpMessage();
                return;
            }

            SophisSettingsManager ssm = new SophisSettingsManager("CAESARBATCH");
            ssm.SaveUserDatabaseSettings("PROD", "APP_SOPHIS_FO", "TOP");

            // All possible arguments.
            string task = string.Empty; // the current task to execute.
            string name = string.Empty; // the name of the batch to execute or the deal to update.
            string fileName = string.Empty; // the source file for the pricing or volatility tasks that will be stored in the database.
                                            // or the file where results will be exported from database.
            string type = string.Empty;  // type of the task that will be executed, it's either "volatility" or "pricing".
            string from = string.Empty;  // the start date from which we export results to a file.
            string to = string.Empty;  // the last date to which we export results from database to a file.
            string testID = string.Empty; // testID of the /Test task

            string batchCreatorExpression = string.Empty;

            bool localFlag = false;
            try
            {
                for (int i = 0; i < args.Length; ++i)
                {
                    string[] parts = args[i].Split(new char[] { ':' }, 2);

                    switch (parts[0].ToLowerInvariant())
                    {
                        case "/local":
                            localFlag = true;
                            break;
                        case "/name":
                            name = BatchFunctions.GetArgumentValueFrom(parts);
                            break;
                        case "/type":
                            type = BatchFunctions.GetArgumentValueFrom(parts);
                            if (type.CompareTo("volatility")!=0 && type.CompareTo("pricing")!=0)
                            {
                                throw new ArgumentException(string.Format("Unknown argument [{0}]", parts[0]));
                            }
                            break;
                        case "/filename":
                            fileName = BatchFunctions.GetArgumentValueFrom(parts);
                            break;
                        case "/from":
                            from = BatchFunctions.GetArgumentValueFrom(parts);
                            break;
                        case "/to":
                            to = BatchFunctions.GetArgumentValueFrom(parts);
                            break;
                        case "/test":
                            testID = BatchFunctions.GetArgumentValueFrom(parts);
                            break;
                        case "/create":
                        case "/edit":
                        case "/execute":
                        case "/remove":
                        case "/update":
                        case "/list":
                        case "/export":
                            break;
                        case "/batchcreator":
                            batchCreatorExpression = parts.Skip(1).FirstOrDefault() ?? string.Empty;
                            break;
                        default:
                            throw new ArgumentException(string.Format("Unknown argument [{0}]  , Try BatchServer /help", parts[0]));
                    }
                }
                
                // Quick analyse of the arguments.
                task = (args[0]).ToLowerInvariant().Split(new char[] { ':' }, 2)[0];
                switch (task)
                {
                    case "/create":
                    case "/edit":
                        if (string.IsNullOrEmpty(name.Trim()) || string.IsNullOrEmpty(type.Trim()) || string.IsNullOrEmpty(fileName.Trim()))
                        {
                            throw new ArgumentException(string.Format("Invalid arguments!"));
                        }
                        break;
                    case "/execute":
                    case "/remove":
                        if (string.IsNullOrEmpty(name.Trim()) || string.IsNullOrEmpty(type.Trim())
                            || task == "/test" && string.IsNullOrEmpty(testID))
                        {
                            throw new ArgumentException(string.Format("Invalid arguments!"));
                        }
                        break;
                    case "/update":
                        if (string.IsNullOrEmpty(name.Trim()))
                        {
                            throw new ArgumentException(string.Format("Invalid arguments!"));
                        }
                        break;
                    case "/list":
                        if (string.IsNullOrEmpty(type.Trim()))
                        {
                            throw new ArgumentException(string.Format("Invalid arguments!"));
                        }
                        break;
                    case "/export":
                        if (string.IsNullOrEmpty(type.Trim()) || string.IsNullOrEmpty(name.Trim()) || 
                            string.IsNullOrEmpty(fileName.Trim()) || string.IsNullOrEmpty(from.Trim()) ||
                            (string.IsNullOrEmpty(to.Trim()) && from.ToUpperInvariant().CompareTo("LAST") != 0))
                        {
                            throw new ArgumentException(string.Format("Invalid arguments!"));
                        }
                        break;
                    case "/test":
                        break;
                    default:
                        throw new ArgumentException(string.Format("Unknown argument [{0}]  , Try BatchServer /help", task));
                }
            }
            catch (ArgumentException)
            {
                BatchFunctions.PrintHelpMessage();
                Environment.Exit(-3);
            }

            // on lance
            try
            {
                switch (task)
                {
                    case "/update":
                        Console.WriteLine("Deal Market data update started " + DateTime.Now.ToString("F"));
                        // name : the deal to update.
                        UpdateBatch updaterBatch = new UpdateBatch(name, ssm);
                        updaterBatch.Run();
                        Console.WriteLine("\nUpdate ended " + DateTime.Now.ToShortTimeString());
                        break;
                    case "/list":
                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("List of all the volatility batches in the database:");
                            VolatilityBatch volatilityBatch = new VolatilityBatch();
                            IList<IVolatilityTaskDescription> list = volatilityBatch.ListVolatilityTasks();
                            Console.WriteLine();
                            if (list.Count == 0)
                            {
                                Console.WriteLine(" No batches were found in the database!");
                            }
                            else
                            {
                                Console.WriteLine("Name        Number of assets");
                                BatchFunctions.DisplayList<IVolatilityTaskDescription>(list);
                            }
                            Console.WriteLine();
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            // TODO
                            Console.WriteLine("List of all the pricing batches in the database:");
                            IList<IBatchDescription> list = BatchService.ListTasks();
                            Console.WriteLine();
                            if (list.Count == 0)
                            {
                                Console.WriteLine(" No batches were found in the database!");
                            }
                            else
                            {
                                Console.WriteLine("Name    Number of baskets    Number of products");
                                BatchFunctions.DisplayList<IBatchDescription>(list);
                            }
                            Console.WriteLine();
                        }
                        break;
                    case "/execute":
                        // Set la date 0 pour les pricing
                        MarketDataReference.SetCalculationDate(DateTime.Today);

                        try
                        {
                            Console.Clear();
                        }
                        catch (Exception)
                        {
                        }

                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("Volatility Batch started " + DateTime.Now.ToString("F"));
                            VolatilityBatch volatilityBatch = new VolatilityBatch(name, ssm);
                            if (fileName != null && fileName != string.Empty)
                            {
                                volatilityBatch.Task = VolatilityBatch.TaskFromFile(name);
                                volatilityBatch.OutputFileName = fileName;
                            }

                            volatilityBatch.Run();
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            // TODO
                            Console.WriteLine("Pricing Batch started " + DateTime.Now.ToString("F"));

                            /// load directly the index batch
                            if (localFlag)
                            {
                                GridService.GridTag = GDAGrid.GridCore.DBBusinessObjects.GridTag.Local;

                                Assembly.LoadFrom("FuncFramework.Grid.dll");

                                ConnectionService.ConnectToMarketDataServer(ssm);

                                IList<BatchBasket> baskets = BatchCreator.ReadBaskets(fileName);
                                RunningTasks tasks = new RunningTasks();

                                Action<RunningTasks> Expression = null;

                                var availableCreators = new
                                {
                                    Index = (Action<RunningTasks>)BatchCreator.BuildIndexProductList,
                                    IndexEquityResearch = (Action<RunningTasks>)BatchCreator.BuildIndexProductListEquityResearch
                                };
                                if (!batchCreatorExpression.IsNullOrEmpty())
                                {
                                    try
                                    {
                                        var lambda = System.Linq.Dynamic.DynamicExpression.ParseLambda(availableCreators.GetType(), typeof(Action<RunningTasks>), batchCreatorExpression).Compile();
                                        Expression = lambda.DynamicInvoke(availableCreators) as Action<RunningTasks>;
                                        Expression(tasks);
                                    }
                                    catch(Exception e)
                                    {
                                        Console.Error.WriteLine("Available product sets: " + availableCreators.GetType().GetProperties().Select(p => p.Name).Stringify(", "));
                                        log4net.LogManager.GetLogger("BatchServer").Error(e);
                                        throw;
                                    }
                                }
                                if (Expression == null)
                                {
                                    BatchCreator.BuildIndexProductList(tasks);
                                }

                                BatchPricing batchIndex = new BatchPricing(name);
                                XMLProducts xml = new XMLProducts(tasks);

                                foreach (var taskAndCalculation in xml.GetProducts())
                                {
                                    foreach (BatchBasket basket in baskets)
                                    {
                                        if (testID == null || testID == string.Empty || testID == taskAndCalculation.Key.ScriptName)
                                            batchIndex.AddTask(taskAndCalculation.Key.ScriptName, taskAndCalculation.Key, basket, taskAndCalculation.Value);
                                    }
                                    if (!testID.IsNullOrEmpty() && batchIndex.Count == 1) //// only once if we are debugging a product
                                        break;
                                }
                                PricingBatchExecutor pricingBatch = new PricingBatchExecutor(ssm);
                                pricingBatch.Run(batchIndex, BatchCreator.CreateContext(batchIndex));


                                //pricingBatch.Result 

                                BatchCreator.ExportResults(name, fileName + "_results", new BatchHistorizedResults[] { pricingBatch.Result }, DateTime.Today, batchIndex);

                            }
                            else
                            {
                                // charge le batch
                                LoggingService.Info(typeof(Program), "loading batch");
                                Console.Write("Loading Batch ...");
                                BatchPricing myTask = PersistanceService.BatchProvider.ReadBatch(name, PersistanceService.CaesarSession);
                                Console.WriteLine("Loaded : " + myTask.Count + " tasks");

                                // start
                                PricingBatchExecutor pricingBatch = new PricingBatchExecutor(ssm);
                                pricingBatch.Run(myTask, BatchCreator.CreateContext(myTask));
                            }
                        }
                        Console.WriteLine("\nBatch ended " + DateTime.Now.ToShortTimeString());
                        break;
                    case "/test":
                        {
                            
                        }
                        break;
                    case "/export":
                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("Exporting volatility results at " + DateTime.Now.ToString("F"));
                            VolatilityBatch volatilityBatch = new VolatilityBatch();
                            volatilityBatch.VolatilityTaskName = name;
                            DateTime start = new DateTime();
                            DateTime end = new DateTime();
                            if (from.ToUpperInvariant().CompareTo("LAST") != 0)
                            {
                                start = DateTime.Parse(from, System.Globalization.CultureInfo.GetCultureInfo("en-GB"), System.Globalization.DateTimeStyles.AllowWhiteSpaces);
                                end = DateTime.Parse(to, System.Globalization.CultureInfo.GetCultureInfo("en-GB"), System.Globalization.DateTimeStyles.AllowWhiteSpaces);
                            }
                            if (end.TimeOfDay == TimeSpan.Zero)
                            {
                                end = end.Add(new TimeSpan(23, 59, 59));
                            }
                            volatilityBatch.ExportResults(fileName, start, end);
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            Console.WriteLine("Exporting pricing results at " + DateTime.Now.ToString("F"));
                            DateTime start = new DateTime();
                            DateTime end = new DateTime();
                            if (from.ToUpperInvariant().CompareTo("LAST") != 0)
                            {
                                start = DateTime.Parse(from, System.Globalization.CultureInfo.GetCultureInfo("en-GB"), System.Globalization.DateTimeStyles.AllowWhiteSpaces);
                                end = DateTime.Parse(to, System.Globalization.CultureInfo.GetCultureInfo("en-GB"), System.Globalization.DateTimeStyles.AllowWhiteSpaces);
                            }
                            if (end.TimeOfDay == TimeSpan.Zero)
                            {
                                end = end.Add(new TimeSpan(23, 59, 59));
                            }
                            // export
                            BatchCreator.ExportResults(name, fileName, start, end);
                        }
                        Console.WriteLine("\nBatch ended " + DateTime.Now.ToShortTimeString());
                        break;

                    case "/create":
                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("Create volatility batch started " + DateTime.Now.ToString("F"));
                            VolatilityBatch volatilityBatch = new VolatilityBatch(name, ssm);
                            volatilityBatch.CreateTask(fileName, name);
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            Console.WriteLine("Create pricing batch started " + DateTime.Now.ToString("F"));
                            BatchCreator factory = new BatchCreator();
                            // factory.CreateTask(fileName);
                        }
                        Console.WriteLine("\nCreating Batch finished " + DateTime.Now.ToShortTimeString());
                        break;
                    case "/edit":
                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("Editing volatility batch started " + DateTime.Now.ToString("F"));
                            VolatilityBatch volatilityBatch = new VolatilityBatch(name, ssm);
                            volatilityBatch.EditTask(fileName);
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            Console.WriteLine("Editing pricing batch started " + DateTime.Now.ToString("F"));
                            // BatchService.EditTask(fileName);
                        }
                        Console.WriteLine("\nediting Batch finished " + DateTime.Now.ToShortTimeString());
                        break;
                    case "/remove":
                        if (type.CompareTo("volatility") == 0)
                        {
                            Console.WriteLine("Removing volatility batch started " + DateTime.Now.ToString("F"));
                            VolatilityBatch volatilityBatch = new VolatilityBatch();
                            volatilityBatch.VolatilityTaskName = name;
                            volatilityBatch.RemoveTask();
                        }
                        else if (type.CompareTo("pricing") == 0)
                        {
                            Console.WriteLine("Removing pricing batch started " + DateTime.Now.ToString("F"));
                            BatchService.RemoveTask(name);
                        }
                        Console.WriteLine("\nRemoving Batch ended " + DateTime.Now.ToShortTimeString());
                        break;

                    default:
                        throw new ArgumentException(string.Format("Unknown argument [{0}] , Try BatchServer /help", task));
                }

                LoggingService.Info(typeof(Program), "Caesar Batch is leaving.");
                Console.WriteLine("Caesar Batch executed succefully.");
                Console.WriteLine("Press a key to close!");
            }
            catch (Exception ex)
            {
                LoggingService.Error(ex.TargetSite.DeclaringType.UnderlyingSystemType, "Woops", ex);
                Console.WriteLine(ex.Message);
                Console.WriteLine("Press a key to close!");
            }
        }
    }
}
