﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Security;
using System.Security.Policy;
 

namespace Alchemi.Executor.Sandbox
{
	public class SandboxService
	{
		static int _maxAppdomain = 3;
		static int _appDomainCounter = 0;
		static GridAppDomain _currentAppDomain = null;


		/// <summary>
		/// Niveau de permission pour l'appli
		/// </summary>
		/// <param name="readonlyDir"></param>
		/// <param name="appDir"></param>
		/// <returns></returns>
		private static PermissionSet GetPermissionSetForApp(string readonlyDir, string appDir)
		{
			//return scfg.GetGThreadPermissions(readonlyDir, appDir);
			PermissionSet ps = (PolicyLevel.CreateAppDomainLevel()).GetNamedPermissionSet("FullTrust");
			return ps;
		}

		/// <summary>
		/// Retourne un nouvel appDomain
		/// </summary>
		/// <returns></returns>
		private static GridAppDomain CreateSandboxDomain()
		{
			string appDir = ExecutorUtil.GetApplicationDirectory("Vide et on s'en fout"); 
			Type appDomainExecutorType = typeof(AppDomainExecutor);
			AppDomainSetup info = new AppDomainSetup();

			//we want to seperate the app-base of the new sandboxed domain
			//so that it won't be able to touch the files in the executor itself.
			info.ApplicationBase = appDir;

			string readOnlyDir = Path.GetDirectoryName(appDomainExecutorType.Assembly.Location);
			PermissionSet grantSet = GetPermissionSetForApp(readOnlyDir, appDir);

			// need to load config file here
			string appConfigFile = Path.Combine(appDir, "App.config");
			if (File.Exists(appConfigFile))
				info.ConfigurationFile = "App.config";

			//we could have some assemblies run with higher trust here if needed.
			AppDomain domain = AppDomain.CreateDomain("ExecutorDomain", null, info, grantSet, null);

			AppDomainExecutor executor = (AppDomainExecutor)domain.CreateInstanceFromAndUnwrap(
				appDomainExecutorType.Assembly.Location,
				appDomainExecutorType.FullName);

			//_GridAppDomains is locked by caller, so we don't need to worry about that.
			return new GridAppDomain(domain, executor);
		}

		/// <summary>
		/// Retourne un app domain permettant l'execution safe du pricing
		/// on reutilise les anciens appDomains pour gagner du temps
		/// </summary>
		/// <returns></returns>
		internal static GridAppDomain GetSandbox()
		{
			// premier appel ? on en créé un nouveau
			if (_appDomainCounter == 0)
			{
				// on affecte un nouveau
				_currentAppDomain = CreateSandboxDomain();
			}

			// on incremente
			_appDomainCounter++;

			// retourne l'appDomain courant
			return _currentAppDomain;
		}

		/// <summary>
		/// Nettoie l'app domain si necessaire
		/// </summary>
		internal static void CleanSandbox()
		{
			// a t'on atteint la limite ?
			if (_appDomainCounter > _maxAppdomain)
			{
				_appDomainCounter = 0;
				// on le libere
				try
				{
					if ((_currentAppDomain != null) && (_currentAppDomain.Domain != null))
						AppDomain.Unload(_currentAppDomain.Domain);
				}
				catch { }
			}
		}

		/// <summary>
		/// Nettoie l'app domain si necessaire
		/// </summary>
		public static void Reset()
		{
			_appDomainCounter = 0;
			// on le libere
			try
			{
				if ((_currentAppDomain != null) && (_currentAppDomain.Domain != null))
					AppDomain.Unload(_currentAppDomain.Domain);
			}
			catch { }
		}

	}
}
