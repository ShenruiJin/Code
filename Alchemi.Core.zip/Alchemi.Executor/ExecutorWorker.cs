using System;
using System.Collections.Generic;
using System.Text;
using Alchemi.Core.Owner;
using Alchemi.Core;
using System.IO;
using System.Security.Policy;
using System.Security;
using System.Threading;
using Alchemi.Core.Utility;

using System.Reflection;
using System.IO.IsolatedStorage;

namespace Alchemi.Executor.Sandbox
{
	internal class ExecutorWorker
	{
		private static readonly Logger logger = new Logger();

		private ThreadIdentifier _CurTi;
		private GExecutor _executor;

		private Thread _execThread;

		internal ExecutorWorker(GExecutor executor, ThreadIdentifier ti)
		{
			_CurTi = ti;
			_executor = executor;
		}

		#region Property - _Manager
		private IManager _Manager
		{
			get
			{
				return _executor.Manager;
			}
		}
		#endregion


		#region Property - _Credentials
		private SecurityCredentials _Credentials
		{
			get
			{
				return _executor.Credentials;
			}
		}
		#endregion


		#region Method - ExecuteThreadInAppDomain
		// if we have an exception in the secondary appdomain, it will raise an exception in this method,
		// since the cross-app-domain call uses remoting internally, and it is just as if a remote method 
		// has caused an exception. we have a handler for that below anyway.
		private void ExecuteThreadInAppDomain()
		{
			byte[] rawThread = null;
			GridAppDomain gad = null;
			string threadDir = null;
			try
			{
				logger.Debug("Started ExecuteThreadInAppDomain...");
				logger.Info(string.Format("Executing grid thread # {0}", _CurTi.ThreadId));

				// lance les stop Watch
				System.Diagnostics.Stopwatch lWatch = new System.Diagnostics.Stopwatch();
				lWatch.Start();

				// la zone d'execution
				gad = SandboxService.GetSandbox();

				//get thread from manager
				rawThread = _Manager.Executor_GetThread(_Credentials, _CurTi);
				logger.Debug("Got thread from manager. executing it: " + _CurTi.ThreadId);

				// on laisse le thread dans le repertoire courant
				threadDir = gad.Domain.BaseDirectory; 

				//execute it in its own thread-directory.           
				byte[] finishedThread = gad.Executor.ExecuteThread(rawThread, threadDir);

				logger.Debug(string.Format("ExecuteThread returned for thread # {0}", _CurTi.UniqueId));

				//set its status to finished
				_Manager.Executor_SetFinishedThread(_Credentials, _CurTi, finishedThread, null);

				lWatch.Stop();
				logger.Info(string.Format("Finished executing grid thread # {0} in {1} ms", _CurTi.ThreadId, lWatch.ElapsedMilliseconds));

				// nettoie la sandbox (si besoin)
				SandboxService.CleanSandbox();
			}
			catch (ThreadAbortException)
			{
				if (_CurTi != null)
					logger.Warn(string.Format("aborted grid thread # {0}", _CurTi.UniqueId));
				else
					logger.Warn(string.Format("aborted grid thread # {0}", null));

				Thread.ResetAbort();
			}
			catch (Exception e)
			{
				logger.Info(string.Format("grid thread # {0} failed ({1})", _CurTi.UniqueId, e.GetType()));
				logger.Warn(string.Format("grid thread # {0} failed ({1})", _CurTi.UniqueId, e.GetType()), e);
				try
				{
					_Manager.Executor_SetFinishedThread(_Credentials, _CurTi, rawThread, new RemoteException(e.Message, e));
				}
				catch (Exception ex1)
				{
					if (_CurTi != null)
					{
						logger.Warn("Error trying to set failed thread for App: " + _CurTi.ApplicationId + ", thread=" + _CurTi.ThreadId + ". Original Exception = \n" + e, ex1);
					}
					else
					{
						logger.Warn("Error trying to set failed thread: Original exception = " + e, ex1);
					}
				}
			}
			finally
			{
				try
				{
					logger.Debug("Not Trying to delete thread dir: " + threadDir);
					//if (threadDir != null)
					//    Directory.Delete(threadDir, true);
				}
				catch { }
				// clear the thread ref to "this"
				logger.Debug("Dispose the thread");
				_execThread = null;
				logger.Debug("Exited ExecuteThreadInAppDomain...");
			}
		}
		#endregion


		#region Method - GetPermissionSetForApp
		private PermissionSet GetPermissionSetForApp(string readonlyDir, string appDir)
		{
			SecurityConfig scfg = null;
			try
			{
				//first load the config 
				scfg = SecurityConfig.Load();
			}
			catch (Exception ex)
			{
				logger.Warn("Error loading security config", ex);
				//load the default permission set, and save it to file.
				scfg = new SecurityConfig(true);
				try
				{
					scfg.Save();
				}
				catch (Exception ex1)
				{
					logger.Warn("Error saving security config", ex1);
				}
			}

			//return scfg.GetGThreadPermissions(readonlyDir, appDir);
			PermissionSet ps = (PolicyLevel.CreateAppDomainLevel()).GetNamedPermissionSet("FullTrust");
			return ps;
		}
		#endregion


		#region Method - Start
		internal void Start()
		{
			_execThread = new Thread(new ThreadStart(ExecuteThreadInAppDomain));
			_execThread.Name = "ExecutorWorker-" + _CurTi.UniqueId;
			_execThread.Priority = ThreadPriority.Lowest;
			_execThread.Start();
		}
		#endregion


		#region Method - Stop
		internal void Stop()
		{
			if (_execThread != null && _execThread.IsAlive)
			{
				_execThread.Abort();
			}
		}
		#endregion
	}
}
