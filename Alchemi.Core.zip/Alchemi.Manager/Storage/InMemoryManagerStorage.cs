#region Alchemi copyright and license notice

/*
* Alchemi [.NET Grid Computing Framework]
* http://www.alchemi.net
* Title         :  InMemoryManagerStorage.cs
* Project       :  Alchemi.Core.Manager.Storage
* Created on    :  30 August 2005
* Copyright     :  Copyright � 2005 The University of Melbourne
*                    This technology has been developed with the support of
*                    the Australian Research Council and the University of Melbourne
*                    research grants as part of the Gridbus Project
*                    within GRIDS Laboratory at the University of Melbourne, Australia.
* Author        :  Tibor Biro (tb@tbiro.com)
* License       :  GPL
*                    This program is free software; you can redistribute it and/or
*                    modify it under the terms of the GNU General Public
*                    License as published by the Free Software Foundation;
*                    See the GNU General Public License
*                    (http://www.gnu.org/copyleft/gpl.html) for more 
details.
*
*/
#endregion

using System;
using System.Collections;
using System.Data;
using System.Xml;

using Alchemi.Core;
using Alchemi.Core.Owner;
using Alchemi.Core.Manager;
using Alchemi.Core.Manager.Storage;
using Alchemi.Core.Utility;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Collections.Generic;

namespace Alchemi.Manager.Storage
{
	/// <summary>
	/// Store all manager information in memory.
	/// 
	/// This type of storage is not persistent but usefull for testing or for running 
	/// lightweight managers.
	/// </summary>
	public class InMemoryManagerStorage : ManagerStorageBase, IManagerStorage, IManagerStorageSetup
	{
		#region Seralisation

		bool _continueThread;
		System.Threading.AutoResetEvent _nextSave = new System.Threading.AutoResetEvent(false);
		string DataBaseDirectory = ".\\Database";
		static Dictionary<string, ArrayList> _ListToSerialize = new Dictionary<string,ArrayList>();

		/// <summary>
		/// Ajoute un ArrayList a serialiser
		/// </summary>
		/// <param name="nomDuFichier"></param>
		/// <param name="o"></param>
		private void Serialisation(string nomDuFichier, ArrayList o)
		{
			lock (_ListToSerialize)
			{
				if (!_ListToSerialize.ContainsKey(nomDuFichier))
				{
					_ListToSerialize.Add(nomDuFichier, o);
				}
				else
				{
					// on modifie la liste en attente
					_ListToSerialize[nomDuFichier] = o;
				}
				// indique qu'il y'a des truc a sauver
				_nextSave.Set();
			}
		}

		/// <summary>
		/// Le thread qui serialise en background
		/// </summary>
		private void SerialisationThread()
		{
			_continueThread = true;
			while (_continueThread)
			{
				DateTime now = DateTime.Now;
				// on attend qu'il y'ai du boulot
				_nextSave.WaitOne();

				lock (_ListToSerialize)
				{
					foreach (KeyValuePair<string, ArrayList> key in _ListToSerialize)
					{
						try
						{
							FileStream fs = new FileStream(Path.Combine(DataBaseDirectory, key.Key), FileMode.Create);
							BinaryFormatter sf = new BinaryFormatter();
							sf.Serialize(fs, key.Value);
							fs.Close();
						}
						catch
						{
							// ben rien ... tant pis :(
						}
					}
					_ListToSerialize.Clear();
				}
				// on attend au min X secondes
				double temps = (DateTime.Now - now).TotalSeconds;
				if (temps < 60)
					System.Threading.Thread.Sleep((int) (60 - temps) * 1000);
			}
		}

		private ArrayList Deserialisation(string nomDuFichier)
		{
			// on essaye
			try
			{
				FileStream fs = new FileStream(Path.Combine(DataBaseDirectory, nomDuFichier), FileMode.Open);
				BinaryFormatter sf = new BinaryFormatter();
				Object o = sf.Deserialize(fs);
				fs.Close();
				return o as ArrayList;
			}
			catch
			{
				return new ArrayList();
			}
		}
		#endregion

		#region Permission
		private ArrayList _users = new ArrayList();
		public ArrayList Users
		{
			get {return _users; }
			set { _users = value; }
		}

		private ArrayList _groups = new ArrayList();
		public ArrayList Groups
		{
			get {return _groups; }
			set { _groups = value; }
		}

		private Hashtable _groupPermissions = new Hashtable();
		public Hashtable GroupPermissions
		{
			get { return _groupPermissions; }
			set { _groupPermissions = value; }
		}
		#endregion

		#region database
		private void ReadExecutors()
		{
			if (_executors == null)
				_executors = Deserialisation("Executors.dat");
		}
		private void WriteExecutors()
		{
			Serialisation("Executors.dat", _executors);
		}
		private ArrayList _executors = null;
		public ArrayList Executors
		{
			get { ReadExecutors(); return _executors; }
			set { _executors = value; }
		}

		private void ReadApplications()
		{
			if (_applications == null)
				_applications = Deserialisation("Applications.dat");
		}
		private void WriteApplications()
		{
			Serialisation("Applications.dat", _applications);
		}
		private ArrayList _applications = null;
		public ArrayList Applications
		{
			get { ReadApplications();  return _applications; }
			set { _applications = value; }
		}

		private void ReadThreads()
		{
			if (_threads == null)
				_threads = Deserialisation("Threads.dat");
		}
		private void WriteThreads()
		{
			Serialisation("Threads.dat", _threads);
		}
		private ArrayList _threads = null;
		public ArrayList Threads
		{
			get { ReadThreads();  return _threads; }
			set { _threads = value; }
		}
		#endregion

		System.Threading.Thread threadSave;
		public InMemoryManagerStorage()
		{
			if (!Directory.Exists(DataBaseDirectory))
			{
				Directory.CreateDirectory(DataBaseDirectory);
			}
			threadSave = new System.Threading.Thread(SerialisationThread);
			threadSave.Name = "Serialization Thread";
			threadSave.Start();
		}

		#region IManagerStorage Members

		/// <summary>
		/// Stop le manager sur databse
		/// </summary>
		public void Stop()
		{
			_continueThread = false;
			_nextSave.Set();
		}

		public bool VerifyConnection()
		{
			return true; //for a In-memory storage, the connection is always alive and valid.
		}

        public SystemSummary GetSystemSummary()
        {
            // calculate total number of executors
            int totalExecutors = Executors != null ? Executors.Count : 0;

            // calculate number of unfinished applications
            int unfinishedApps = 0;
            foreach( ApplicationStorageView application in Applications )
            {
                if( application.State == ApplicationState.AwaitingManifest || application.State == ApplicationState.Ready )
                {
                    unfinishedApps++;
                }
            }

            int unfinishedThreads = 0;
			lock (threadLocker)
			{
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.State != ThreadState.Dead && thread.State != ThreadState.Finished)
					{
						unfinishedThreads++;
					}
				}
			}

            float maxPowerValue = 0;
            int powerUsage = 0;
            int powerAvailable = 0;
            float totalUsageValue = 0;

            int connectedExecutorCount = 0;

            foreach( ExecutorStorageView executor in Executors )
            {
                if( executor.Connected )
                {
                    connectedExecutorCount++;
                    maxPowerValue += executor.MaxCpu;
                    powerAvailable += executor.AvailableCpu;
                    powerUsage += executor.CpuUsage;
                    totalUsageValue += executor.TotalCpuUsage * executor.MaxCpu / ( 3600 * 1000 );
                }
            }

            if (connectedExecutorCount != 0)
            {
                powerAvailable /= connectedExecutorCount;
                powerUsage /= connectedExecutorCount;
            }

            string powerTotalUsage = String.Format( "{0} GHz*Hr", Math.Round( totalUsageValue, 6 ) );
            string maxPower = String.Format( "{0} GHz", Math.Round( maxPowerValue / 1000, 6 ) );

            SystemSummary summary = new SystemSummary(
                maxPower,
				connectedExecutorCount,
                powerUsage,
                powerAvailable,
                powerTotalUsage,
                unfinishedApps,
                unfinishedThreads );

            return summary;
        }

		public DataSet RunSqlReturnDataSet(string query)
		{
			return null;
		}

		public void RunSql(string sqlQuery)
		{
		}

		#region Users & Groups
		public void AddUsers(UserStorageView[] users)
		{
            if (users == null)
                return;

			Users.AddRange(users);
		}

		public void UpdateUsers(UserStorageView[] updates)
		{
			if (updates == null)
			{
				return;
			}

			for(int indexInList=0; indexInList<Users.Count; indexInList++)
			{
				UserStorageView userInList = (UserStorageView)Users[indexInList];

				foreach(UserStorageView userInUpdates in updates)
				{
					if (userInList.Username == userInUpdates.Username)
					{
						userInList.Password = userInUpdates.Password;
						userInList.GroupId = userInUpdates.GroupId;
					}
				}
			}
		}

		public void DeleteUser(UserStorageView userToDelete)
		{
			if (userToDelete == null)
			{
				return;
			}

			ArrayList remainingUsers = new ArrayList();

			for(int indexInList=0; indexInList<Users.Count; indexInList++)
			{
				UserStorageView userInList = (UserStorageView)Users[indexInList];

				if (userInList.Username != userToDelete.Username)
				{
					remainingUsers.Add(userInList);
				}
			}

			Users = remainingUsers;
		}

		public bool AuthenticateUser(SecurityCredentials sc)
		{
			if (sc == null)
			{
				return false;
			}

			for(int index=0; index<Users.Count; index++)
			{
				UserStorageView user = (UserStorageView)Users[index];

				if (user.Username == sc.Username && user.PasswordMd5Hash == sc.Password)
				{
					return true;
				}
			}

			return false;
		}

        public UserStorageView[] GetUsers()
        {
            return (UserStorageView[]) Users.ToArray( typeof( UserStorageView ) );
        }
        public UserStorageView GetUser(string username)
        {
            foreach (UserStorageView user in Users)
            {
                if (username == user.Username)
                    return user;
            }
            return null;
        }

		public void AddGroups(GroupStorageView[] groups)
		{
            if (groups == null)
                return;
			Groups.AddRange(groups);
		}
		
		public GroupStorageView[] GetGroups()
		{
			return (GroupStorageView[])Groups.ToArray(typeof(GroupStorageView));
		}

		public GroupStorageView GetGroup(int groupId)
		{
			foreach (GroupStorageView group in Groups)
			{
				if (group.GroupId == groupId)
				{
					return group;
				}
			}

			return null;
		}

		public void AddGroupPermission(int groupId, Permission permission)
		{
			ArrayList permissions = null;

			if (GroupPermissions[groupId] != null)
			{
				permissions = (ArrayList)GroupPermissions[groupId];
			}
			else
			{
				permissions = new ArrayList();

				GroupPermissions.Add(groupId, permissions);
			}

			int index = permissions.IndexOf(permission);

			// only add it if it is not already in the array
			if (index < 0)
			{
				permissions.Add(permission);
			}

			GroupPermissions[groupId] = permissions;
		}

		public Permission[] GetGroupPermissions(int groupId)
		{
			if (GroupPermissions[groupId] == null)
			{
				return new Permission[0];
			}

			ArrayList permissions = (ArrayList)GroupPermissions[groupId];

			return (Permission[])permissions.ToArray(typeof(Permission));
		}

		public PermissionStorageView[] GetGroupPermissionStorageView(int groupId)
		{
			return PermissionStorageView.GetPermissionStorageView(GetGroupPermissions(groupId));
		}

		public void DeleteGroup(GroupStorageView groupToDelete)
		{
			if( groupToDelete == null )
			{
				return;
			}

			ArrayList remainingGroups = new ArrayList();
			ArrayList remainingUsers = new ArrayList();

			foreach (UserStorageView user in Users)
			{
				if (user.GroupId != groupToDelete.GroupId)
				{
					remainingUsers.Add(user);
				}
			}

			foreach (GroupStorageView group in Groups)
			{
				if (group.GroupId != groupToDelete.GroupId)
				{
					remainingGroups.Add(group);
				}
			}

			Groups = remainingGroups;
			Users = remainingUsers;
		}

		public UserStorageView[] GetGroupUsers(int groupId)
		{
			ArrayList result = new ArrayList();

			foreach (UserStorageView user in Users)
			{
				if (user.GroupId == groupId)
				{
					result.Add(user);
				}
			}

			return (UserStorageView[])result.ToArray(typeof(UserStorageView));
		}

		public bool CheckPermission(SecurityCredentials sc, Permission perm)
		{
			// get the user's groupId
			int groupId = -1;
			foreach(UserStorageView user in Users)
			{
				if(String.Compare(user.Username, sc.Username, true) == 0 && user.PasswordMd5Hash == sc.Password)
				{
					groupId = user.GroupId;
					break;
				}
			}

			if (groupId == -1)
			{
				return false;
			}

			foreach(Permission permission in GetGroupPermissions(groupId))
			{
				// in the SQL implementation the higher leverl permissions are considered to 
				// include the lower leverl permissions
				if ((int)permission >= (int)perm)
				{
					return true;
				}
			}

			return false;
		}
		#endregion

		#region Executor
		public string AddExecutor(ExecutorStorageView executor)
		{
			if (executor == null)
			{
				return null;
			}

			string executorId;
			if (executor.ExecutorId == null)
			{
				executorId = Guid.NewGuid().ToString();
			}
			else
			{
				executorId = executor.ExecutorId;
			}

			executor.ExecutorId = executorId;

			Executors.Add(executor);
			// on sauve
			WriteExecutors();
			return executorId;
		}

		public void UpdateExecutor(ExecutorStorageView updatedExecutor)
		{
            if( updatedExecutor == null )
            {
                return;
            }

			ArrayList newExecutorList = new ArrayList();

			foreach(ExecutorStorageView executor in Executors)
			{
				if (executor.ExecutorId == updatedExecutor.ExecutorId)
				{
					newExecutorList.Add(updatedExecutor);
				}
				else
				{
					newExecutorList.Add(executor);
				}
			}

			Executors = newExecutorList;
			// on sauve
			WriteExecutors();
		}

        public void DeleteExecutor(ExecutorStorageView executorToDelete)
        {
            if (executorToDelete == null)
            {
                return;
            }

            ArrayList newExecutorList = new ArrayList();

            foreach (ExecutorStorageView executor in Executors)
            {
                if (executor.ExecutorId != executorToDelete.ExecutorId)
                {
                    newExecutorList.Add(executor);
                }
            }

            Executors = newExecutorList;
			// on sauve
			WriteExecutors();
        }

		public ExecutorStorageView[] GetExecutors()
		{
			return (ExecutorStorageView[])Executors.ToArray(typeof(ExecutorStorageView));
		}

		public ExecutorStorageView[] GetExecutors(TriStateBoolean dedicated)
		{
			return GetExecutors(dedicated, TriStateBoolean.Undefined);
		}

		public ExecutorStorageView[] GetExecutors(TriStateBoolean dedicated, TriStateBoolean connected)
		{
			ArrayList executorList = new ArrayList();

			foreach(ExecutorStorageView executor in Executors)
			{
				bool onlyLookingForDedicatedAndExecutorIsDedicated = (dedicated == TriStateBoolean.True && executor.Dedicated);
				bool dedicatedTestPassed = (onlyLookingForDedicatedAndExecutorIsDedicated || dedicated == TriStateBoolean.Undefined);

				bool onlyLookingForConnectedAndExecutorIsConnected = (connected == TriStateBoolean.True && executor.Connected);
				bool connectedTestPassed = (onlyLookingForConnectedAndExecutorIsConnected || connected == TriStateBoolean.Undefined);
				
				if (dedicatedTestPassed && connectedTestPassed)
				{
					executorList.Add(executor);
				}
			}

			return (ExecutorStorageView[])executorList.ToArray(typeof(ExecutorStorageView));
		}

		public ExecutorStorageView GetExecutor(string executorId)
		{
			foreach(ExecutorStorageView executor in Executors)
			{
				if (executor.ExecutorId == executorId)
				{
					return executor;
				}
			}

			return null;
		}
		#endregion

		#region Applications
		private static object applicationLocker = new object();

		public string AddApplication(ApplicationStorageView application)
		{
			if (application == null)
			{
				return null;
			}

			lock (applicationLocker)
			{
				string applicationId = Guid.NewGuid().ToString();
				// set l'ID
				application.ApplicationId = applicationId;
				// ajoute
				Applications.Add(application);
				// on sauve
				WriteApplications();
				return applicationId;
			}
		}

		public void UpdateApplication(ApplicationStorageView updatedApplication)
		{
			if (updatedApplication == null)
			{
				return;
			}

			lock (applicationLocker)
			{
				ArrayList newApplicationList = new ArrayList();
				foreach (ApplicationStorageView application in Applications)
				{
					if (application.ApplicationId == updatedApplication.ApplicationId)
					{
						newApplicationList.Add(updatedApplication);
					}
					else
					{
						newApplicationList.Add(application);
					}
				}
				Applications = newApplicationList;
				// on sauve
				WriteApplications();
			}
		}

		public ApplicationStorageView[] GetApplications()
		{
			return GetApplications(false);
		}

		public ApplicationStorageView[] GetApplications(bool populateThreadCount)
		{
			lock (applicationLocker)
			{
				ArrayList applicationList = new ArrayList();
				foreach (ApplicationStorageView application in Applications)
				{
					if (populateThreadCount)
					{
						int totalThreads;
						int unfinishedThreads;

						GetApplicationThreadCount(application.ApplicationId, out totalThreads, out unfinishedThreads);

						application.TotalThreads = totalThreads;
						application.UnfinishedThreads = unfinishedThreads;
					}

					applicationList.Add(application);
				}
				return (ApplicationStorageView[])applicationList.ToArray(typeof(ApplicationStorageView));
			}
		}

		public ApplicationStorageView[] GetApplications(string userName, bool populateThreadCount)
		{
			lock (applicationLocker)
			{
				ArrayList applicationList = new ArrayList();
				foreach (ApplicationStorageView application in Applications)
				{
					if (String.Compare(application.Username, userName, false) == 0)
					{
						if (populateThreadCount)
						{
							int totalThreads;
							int unfinishedThreads;

							GetApplicationThreadCount(application.ApplicationId, out totalThreads, out unfinishedThreads);

							application.TotalThreads = totalThreads;
							application.UnfinishedThreads = unfinishedThreads;
						}
						applicationList.Add(application);
					}
				}
				return (ApplicationStorageView[])applicationList.ToArray(typeof(ApplicationStorageView));
			}
		}

		public ApplicationStorageView GetApplication(string applicationId)
		{
			lock (applicationLocker)
			{
				IEnumerator enumerator = Applications.GetEnumerator();
				while (enumerator.MoveNext())
				{
					ApplicationStorageView application = (ApplicationStorageView)enumerator.Current;
					if (application.ApplicationId == applicationId)
					{
						return application;
					}
				}

				// data not found
				return null;
			}
		}

        public void DeleteApplication( ApplicationStorageView applicationToDelete )
        {
            if( applicationToDelete == null )
            {
                return;
            }
			
            ArrayList remainingApplications = new ArrayList();
			lock (threadLocker)
			{
				ArrayList remainingThreads = new ArrayList();
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId != applicationToDelete.ApplicationId)
					{
						remainingThreads.Add(thread);
					}
				}
				// on set la nouvelle structure
				Threads = remainingThreads;
				WriteThreads();
			}

			lock (applicationLocker)
			{
				foreach (ApplicationStorageView application in Applications)
				{
					if (application.ApplicationId != applicationToDelete.ApplicationId)
					{
						remainingApplications.Add(application);
					}
				}

				Applications = remainingApplications;
				// on sauve
				WriteApplications();
			}
		}
		#endregion

		#region Threads
		/// <summary>
		///  un Lock pour le multhitread
		/// </summary>
		private static object threadLocker = new object();

		public int AddThread(ThreadStorageView thread)
		{
			if (thread == null)
			{
				return -1;
			}

			lock (threadLocker)
			{
				// l'id
				thread.InternalThreadId = Threads.Count;
				// set
				Threads.Add(thread);

				// on sauve
				WriteThreads();
			}
			
			return thread.InternalThreadId;
		}

		public void UpdateThread(ThreadStorageView updatedThread)
		{
			if (updatedThread == null)
			{
				return;
			}

			lock (threadLocker)
			{
				ThreadStorageView lThread = null;
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.InternalThreadId == updatedThread.InternalThreadId)
					{
						lThread = thread;
						break;
					}
				}

				// si pas trouv� on se casse
				if (lThread == null)
					return;

				// on vire l'ancien
				Threads.Remove(lThread);
				// on ajoute
				Threads.Add(updatedThread);

				// on sauve
				WriteThreads();
			}
		}

		public ThreadStorageView GetThread(string applicationId, int threadId)
		{
			lock (threadLocker)
			{
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId == applicationId && thread.ThreadId == threadId)
					{
						return thread;
					}
				}
			}

			return null;
		}

		public ThreadStorageView[] GetThreads(ApplicationState appState, params ThreadState[] threadStates)
		{
			lock (threadLocker)
			{
				ArrayList threadList = new ArrayList();
				foreach (ApplicationStorageView application in Applications)
				{
					if (application.State == appState)
					{
						foreach (ThreadStorageView thread in GetThreads(application.ApplicationId, threadStates))
						{
							threadList.Add(thread);
						}
					}
				}
				return (ThreadStorageView[])threadList.ToArray(typeof(ThreadStorageView));
			}
		}

		public ThreadStorageView[] GetThreads(params ThreadState[] state)
		{
			return GetThreads(null, state);
		}

		public ThreadStorageView[] GetThreads(string applicationId, params ThreadState[] threadStates)
		{
			lock (threadLocker)
			{
				ArrayList threadList = new ArrayList();
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId == applicationId || applicationId == null)
					{
						bool threadStateCorrect = false;

						if (threadStates == null || threadStates.Length == 0)
						{
							threadStateCorrect = true;
						}
						else
						{
							foreach (ThreadState state in threadStates)
							{
								if (state == thread.State)
								{
									threadStateCorrect = true;
									break;
								}
							}
						}

						if (threadStateCorrect)
						{
							threadList.Add(thread);
						}
					}
				}
				return (ThreadStorageView[])threadList.ToArray(typeof(ThreadStorageView));
			}
		}

		public ThreadStorageView[] GetExecutorThreads(string executorId, params ThreadState[] threadStates)
		{
			lock (threadLocker)
			{
				ArrayList threadList = new ArrayList();
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ExecutorId == executorId)
					{
						bool threadStateCorrect = false;

						if (threadStates == null || threadStates.Length == 0)
						{
							threadStateCorrect = true;
						}
						else
						{
							foreach (ThreadState state in threadStates)
							{
								if (state == thread.State)
								{
									threadStateCorrect = true;
									break;
								}
							}
						}

						if (threadStateCorrect)
						{
							threadList.Add(thread);
						}
					}
				}
				return (ThreadStorageView[])threadList.ToArray(typeof(ThreadStorageView));
			}
		}

		public ThreadStorageView[] GetExecutorThreads(bool dedicatedExecutor, params ThreadState[] state)
		{
			ArrayList threadList = new ArrayList();
			foreach(ExecutorStorageView executor in Executors)
			{
				if (executor.Dedicated == dedicatedExecutor)
				{
					threadList.AddRange(GetExecutorThreads(executor.ExecutorId, state));
				}
			}
			return (ThreadStorageView[])threadList.ToArray(typeof(ThreadStorageView));
		}

		public ThreadStorageView[] GetExecutorThreads(bool dedicatedExecutor, bool connectedExecutor, params ThreadState[] state)
		{
            ArrayList threadList = new ArrayList();

			foreach(ExecutorStorageView executor in Executors)
			{
				if (executor.Dedicated == dedicatedExecutor && executor.Connected == connectedExecutor)
				{
					threadList.AddRange(GetExecutorThreads(executor.ExecutorId, state));
				}
			}

			return (ThreadStorageView[])threadList.ToArray(typeof(ThreadStorageView));
		}
        
		public void GetApplicationThreadCount(string applicationId, out int totalThreads, out int unfinishedThreads)
		{
			lock (threadLocker)
			{
				totalThreads = unfinishedThreads = 0;
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId == applicationId)
					{
						totalThreads++;

						if (thread.State == ThreadState.Ready || thread.State == ThreadState.Scheduled || thread.State == ThreadState.Started)
						{
							unfinishedThreads++;
						}
					}
				}
			}
		}

		public int GetApplicationThreadCount(string applicationId, ThreadState threadState)
		{
			lock (threadLocker)
			{
				int threadCount = 0;
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId == applicationId && thread.State == threadState)
					{
						threadCount++;
					}
				}
				return threadCount;
			}
		}

		public int GetExecutorThreadCount(string executorId, params ThreadState[] threadState)
		{
			
			int threadCount = 0;
			if (threadState == null && threadState.Length == 0)
			{
				return threadCount;
			}
			lock (threadLocker)
			{
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ExecutorId != null && thread.ExecutorId == executorId)
					{
						foreach (ThreadState state in threadState)
						{
							if (thread.State == state)
							{
								threadCount++;
								break; // no point in continuing since there is only one state for a thread
							}
						}
					}
				}
				return threadCount;
			}
		}

		public void DeleteThread(ThreadStorageView threadToDelete)
		{
			if (threadToDelete == null)
			{
				return;
			}
			lock (threadLocker)
			{
				ThreadStorageView toDelete = null;
				foreach (ThreadStorageView thread in Threads)
				{
					if (thread.ApplicationId != threadToDelete.ApplicationId || thread.ThreadId != threadToDelete.ThreadId)
					{
						toDelete = thread;
					}
				}
				// pas trouv� ?
				if (toDelete == null)
					return;
				// on efface
				Threads.Remove(toDelete);
				// on sauve
				WriteThreads();
			}
		}
		#endregion

		#endregion

		#region "XML storage persistence implementation - incomplete"
		/// THIS FUNCTIONALITY IS NOT FULLY IMPLEMENTED AND IT MIGHT BE DISCARDED ALTOGETHER
		/// 
		/// Loading from an XML file is the perfect tool for complex storage setups which would be useful for more in-depth unit testing
		/// Saving to an XML file could be used to dump the current storage state for troubleshooting, for example to receive faulty storages from the field.


		/// <summary>
		/// Save the current storage state into an XML file.
		/// It is important that the file format is easily editable by humans so test cases can easily be maintained.
		/// For this reason we do not use the build-in persistence modules.
		/// </summary>
		/// <param name="filename"></param>
		public void SaveToHumanReadableXmlFile(string filename)
		{
		}

		/// <summary>
		/// Load the storage information from an XML file.
		/// </summary>
		/// <param name="filename"></param>
		public void LoadFromHumanReadableXmlFile(string filename)
		{
			
		}
		#endregion

		#region IManagerStorageSetup Members

		public void TearDownStorage()
		{
		}

		public void CreateStorage(string databaseName)
		{
		}

		public void InitializeStorageData()
		{
			CreateDefaultObjects(this);
		}

		public void SetUpStorage()
		{
		}

		#endregion
	}
}
