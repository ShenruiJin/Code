#region Alchemi copyright and license notice

/*
* Alchemi [.NET Grid Computing Framework]
* http://www.alchemi.net
*
* Title			:	ExecutorTemplateForm.cs
* Project		:	Alchemi Executor
* Created on	:	2006
* Copyright		:	Copyright � 2006 The University of Melbourne
*					This technology has been developed with the support of 
*					the Australian Research Council and the University of Melbourne
*					research grants as part of the Gridbus Project
*					within GRIDS Laboratory at the University of Melbourne, Australia.
* Author         :  Krishna Nadiminti (kna@csse.unimelb.edu.au) and Rajkumar Buyya (raj@csse.unimelb.edu.au)
* License        :  GPL
*					This program is free software; you can redistribute it and/or 
*					modify it under the terms of the GNU General Public
*					License as published by the Free Software Foundation;
*					See the GNU General Public License 
*					(http://www.gnu.org/copyleft/gpl.html) for more details.
*
*/
#endregion

using System;
using System.Net;
using System.Threading;
using System.Windows.Forms;
using Alchemi.Core;
using Alchemi.Executor;
using Alchemi.ExecutorExec;
using Timer = System.Windows.Forms.Timer;
using log4net;
using System.Reflection;
using Alchemi.Core.EndPointUtils;
using Alchemi.Core.Manager.Storage;
using System.Drawing;
using System.Diagnostics;
using System.IO;
using Alchemi.Core.Utility;
using Alchemi.Core.Owner;
using Alchemi.Executor.Sandbox;

// Configure log4net using the .config file
[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace Alchemi.ExecutorExec
{
	public class ExecutorForm : Form
	{
		protected static readonly Logger logger = new Logger();

		protected TextBox txLog;
		private System.ComponentModel.IContainer components;
		protected MainMenu MainMenu;
		protected MenuItem menuItem1;
		protected MenuItem mmExit;
		protected NotifyIcon TrayIcon;
		protected ContextMenu TrayMenu;
		protected MenuItem tmExit;
		protected MenuItem menuItem2;
		protected MenuItem mmAbout;
		protected Timer HideTimer;

		protected Configuration Config;
		protected ExecutorContainer _container = null;
		protected Button btDisconnect;
		protected Button btConnect;
		private GroupBox groupBox2;
		private Label labelExecutorPort;
		private Label labelExecutorIP;
		private Label labelExecutorName;
		private Label label3;
		private Label label2;
		private Label label1;
		private GroupBox groupBox1;
		private Label labelManagerPort;
		private Label labelManagerIP;
		private Label labelManagerName;
		private Label label10;
		private Label label11;
		private Label label13;
		private System.Diagnostics.PerformanceCounter performanceCounter1;
		private PerformanceGraph performanceGraph;
		private Timer timerPerfomance;
		private Label label4;

		protected static bool silentMode = true;

		public ExecutorForm()
		{
			InitializeComponent();
			this.Text = "Alchemi Executor";		
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null)
				{
					components.Dispose();
				}
				this.TrayIcon.Dispose();				 
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ExecutorForm));
			this.txLog = new System.Windows.Forms.TextBox();
			this.TrayIcon = new System.Windows.Forms.NotifyIcon(this.components);
			this.TrayMenu = new System.Windows.Forms.ContextMenu();
			this.tmExit = new System.Windows.Forms.MenuItem();
			this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
			this.menuItem1 = new System.Windows.Forms.MenuItem();
			this.mmExit = new System.Windows.Forms.MenuItem();
			this.menuItem2 = new System.Windows.Forms.MenuItem();
			this.mmAbout = new System.Windows.Forms.MenuItem();
			this.HideTimer = new System.Windows.Forms.Timer(this.components);
			this.btConnect = new System.Windows.Forms.Button();
			this.btDisconnect = new System.Windows.Forms.Button();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.labelExecutorPort = new System.Windows.Forms.Label();
			this.labelExecutorIP = new System.Windows.Forms.Label();
			this.labelExecutorName = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.labelManagerPort = new System.Windows.Forms.Label();
			this.labelManagerIP = new System.Windows.Forms.Label();
			this.labelManagerName = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			this.label11 = new System.Windows.Forms.Label();
			this.label13 = new System.Windows.Forms.Label();
			this.performanceCounter1 = new System.Diagnostics.PerformanceCounter();
			this.performanceGraph = new Alchemi.ExecutorExec.PerformanceGraph();
			this.timerPerfomance = new System.Windows.Forms.Timer(this.components);
			this.label4 = new System.Windows.Forms.Label();
			this.groupBox2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).BeginInit();
			this.SuspendLayout();
			// 
			// txLog
			// 
			this.txLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.txLog.BackColor = System.Drawing.SystemColors.HighlightText;
			this.txLog.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.txLog.Location = new System.Drawing.Point(12, 159);
			this.txLog.Multiline = true;
			this.txLog.Name = "txLog";
			this.txLog.ReadOnly = true;
			this.txLog.ScrollBars = System.Windows.Forms.ScrollBars.Both;
			this.txLog.Size = new System.Drawing.Size(434, 184);
			this.txLog.TabIndex = 11;
			this.txLog.TabStop = false;
			this.txLog.WordWrap = false;
			this.txLog.DoubleClick += new System.EventHandler(this.txLog_DoubleClick);
			// 
			// TrayIcon
			// 
			this.TrayIcon.ContextMenu = this.TrayMenu;
			this.TrayIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("TrayIcon.Icon")));
			this.TrayIcon.Text = "Alchemi Executor";
			this.TrayIcon.Visible = true;
			this.TrayIcon.Click += new System.EventHandler(this.TrayIcon_Click);
			// 
			// TrayMenu
			// 
			this.TrayMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.tmExit});
			// 
			// tmExit
			// 
			this.tmExit.Index = 0;
			this.tmExit.Text = "Exit";
			this.tmExit.Click += new System.EventHandler(this.tmExit_Click);
			// 
			// MainMenu
			// 
			this.MainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.menuItem1,
            this.menuItem2});
			// 
			// menuItem1
			// 
			this.menuItem1.Index = 0;
			this.menuItem1.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mmExit});
			this.menuItem1.Text = "Executor";
			// 
			// mmExit
			// 
			this.mmExit.Index = 0;
			this.mmExit.Text = "Exit";
			this.mmExit.Click += new System.EventHandler(this.mmExit_Click);
			// 
			// menuItem2
			// 
			this.menuItem2.Index = 1;
			this.menuItem2.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.mmAbout});
			this.menuItem2.Text = "Help";
			// 
			// mmAbout
			// 
			this.mmAbout.Index = 0;
			this.mmAbout.Text = "About";
			this.mmAbout.Click += new System.EventHandler(this.mmAbout_Click);
			// 
			// HideTimer
			// 
			this.HideTimer.Interval = 6000;
			this.HideTimer.Tick += new System.EventHandler(this.HideTimer_Tick);
			// 
			// btConnect
			// 
			this.btConnect.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btConnect.Location = new System.Drawing.Point(12, 130);
			this.btConnect.Name = "btConnect";
			this.btConnect.Size = new System.Drawing.Size(210, 23);
			this.btConnect.TabIndex = 9;
			this.btConnect.Text = "Connect";
			this.btConnect.Click += new System.EventHandler(this.btConnect_Click);
			// 
			// btDisconnect
			// 
			this.btDisconnect.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.btDisconnect.Location = new System.Drawing.Point(240, 130);
			this.btDisconnect.Name = "btDisconnect";
			this.btDisconnect.Size = new System.Drawing.Size(206, 23);
			this.btDisconnect.TabIndex = 10;
			this.btDisconnect.Text = "Disconnect";
			this.btDisconnect.Click += new System.EventHandler(this.btDisconnect_Click);
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.labelExecutorPort);
			this.groupBox2.Controls.Add(this.labelExecutorIP);
			this.groupBox2.Controls.Add(this.labelExecutorName);
			this.groupBox2.Controls.Add(this.label3);
			this.groupBox2.Controls.Add(this.label2);
			this.groupBox2.Controls.Add(this.label1);
			this.groupBox2.Location = new System.Drawing.Point(12, 12);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(210, 103);
			this.groupBox2.TabIndex = 16;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Executor";
			// 
			// labelExecutorPort
			// 
			this.labelExecutorPort.AutoSize = true;
			this.labelExecutorPort.Location = new System.Drawing.Point(93, 78);
			this.labelExecutorPort.Name = "labelExecutorPort";
			this.labelExecutorPort.Size = new System.Drawing.Size(32, 13);
			this.labelExecutorPort.TabIndex = 5;
			this.labelExecutorPort.Text = "Port :";
			this.labelExecutorPort.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// labelExecutorIP
			// 
			this.labelExecutorIP.AutoSize = true;
			this.labelExecutorIP.Location = new System.Drawing.Point(93, 54);
			this.labelExecutorIP.Name = "labelExecutorIP";
			this.labelExecutorIP.Size = new System.Drawing.Size(58, 13);
			this.labelExecutorIP.TabIndex = 4;
			this.labelExecutorIP.Text = "IP Adress :";
			this.labelExecutorIP.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// labelExecutorName
			// 
			this.labelExecutorName.AutoSize = true;
			this.labelExecutorName.Location = new System.Drawing.Point(93, 29);
			this.labelExecutorName.Name = "labelExecutorName";
			this.labelExecutorName.Size = new System.Drawing.Size(83, 13);
			this.labelExecutorName.TabIndex = 3;
			this.labelExecutorName.Text = "Machine name :";
			this.labelExecutorName.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(57, 78);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(32, 13);
			this.label3.TabIndex = 2;
			this.label3.Text = "Port :";
			this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(31, 54);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(58, 13);
			this.label2.TabIndex = 1;
			this.label2.Text = "IP Adress :";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(6, 29);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(83, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Machine name :";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.labelManagerPort);
			this.groupBox1.Controls.Add(this.labelManagerIP);
			this.groupBox1.Controls.Add(this.labelManagerName);
			this.groupBox1.Controls.Add(this.label10);
			this.groupBox1.Controls.Add(this.label11);
			this.groupBox1.Controls.Add(this.label13);
			this.groupBox1.Location = new System.Drawing.Point(240, 12);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(206, 103);
			this.groupBox1.TabIndex = 17;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Manager";
			// 
			// labelManagerPort
			// 
			this.labelManagerPort.AutoSize = true;
			this.labelManagerPort.Location = new System.Drawing.Point(93, 78);
			this.labelManagerPort.Name = "labelManagerPort";
			this.labelManagerPort.Size = new System.Drawing.Size(32, 13);
			this.labelManagerPort.TabIndex = 5;
			this.labelManagerPort.Text = "Port :";
			this.labelManagerPort.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// labelManagerIP
			// 
			this.labelManagerIP.AutoSize = true;
			this.labelManagerIP.Location = new System.Drawing.Point(93, 54);
			this.labelManagerIP.Name = "labelManagerIP";
			this.labelManagerIP.Size = new System.Drawing.Size(58, 13);
			this.labelManagerIP.TabIndex = 4;
			this.labelManagerIP.Text = "IP Adress :";
			this.labelManagerIP.TextAlign = System.Drawing.ContentAlignment.TopRight;
			// 
			// labelManagerName
			// 
			this.labelManagerName.AutoSize = true;
			this.labelManagerName.Location = new System.Drawing.Point(93, 29);
			this.labelManagerName.Name = "labelManagerName";
			this.labelManagerName.Size = new System.Drawing.Size(83, 13);
			this.labelManagerName.TabIndex = 3;
			this.labelManagerName.Text = "Machine name :";
			this.labelManagerName.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.Location = new System.Drawing.Point(57, 78);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(32, 13);
			this.label10.TabIndex = 2;
			this.label10.Text = "Port :";
			this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label11
			// 
			this.label11.AutoSize = true;
			this.label11.Location = new System.Drawing.Point(31, 54);
			this.label11.Name = "label11";
			this.label11.Size = new System.Drawing.Size(58, 13);
			this.label11.TabIndex = 1;
			this.label11.Text = "IP Adress :";
			this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label13
			// 
			this.label13.AutoSize = true;
			this.label13.Location = new System.Drawing.Point(6, 29);
			this.label13.Name = "label13";
			this.label13.Size = new System.Drawing.Size(83, 13);
			this.label13.TabIndex = 0;
			this.label13.Text = "Machine name :";
			this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// performanceCounter1
			// 

			string categoryName = "Processor";
            if (!PerformanceCounterCategory.CounterExists("% Processor Time", categoryName))
            {
                categoryName = "Process";
            }

            this.performanceCounter1.CategoryName = categoryName;
			this.performanceCounter1.CounterName = "% Processor Time";
			this.performanceCounter1.InstanceName = "_Total";
			// 
			// performanceGraph
			// 
			this.performanceGraph.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.performanceGraph.BackColor = System.Drawing.Color.Black;
			this.performanceGraph.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.performanceGraph.ChartType = Alchemi.ExecutorExec.ChartType.Line;
			this.performanceGraph.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.performanceGraph.GridColor = System.Drawing.Color.Green;
			this.performanceGraph.GridPixels = 10;
			this.performanceGraph.InitialHeight = 100;
			this.performanceGraph.LineColor = System.Drawing.Color.Lime;
			this.performanceGraph.Location = new System.Drawing.Point(12, 362);
			this.performanceGraph.Name = "performanceGraph";
			this.performanceGraph.Size = new System.Drawing.Size(434, 104);
			this.performanceGraph.TabIndex = 18;
			// 
			// timerPerfomance
			// 
			this.timerPerfomance.Enabled = true;
			this.timerPerfomance.Interval = 1000;
			this.timerPerfomance.Tick += new System.EventHandler(this.timerPerfomance_Tick);
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.Location = new System.Drawing.Point(12, 346);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(72, 13);
			this.label4.TabIndex = 19;
			this.label4.Text = "CPU usage %";
			// 
			// ExecutorForm
			// 
			this.AcceptButton = this.btConnect;
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(458, 472);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.btDisconnect);
			this.Controls.Add(this.btConnect);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.txLog);
			this.Controls.Add(this.performanceGraph);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Menu = this.MainMenu;
			this.Name = "ExecutorForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Alchemi Executor";
			this.Load += new System.EventHandler(this.ExecutorTemplateForm_Load);
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.performanceCounter1)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}
		#endregion

		//-----------------------------------------------------------------------------------------------        
		//
		// Form Event Handlers
		//
		//-----------------------------------------------------------------------------------------------    

		protected virtual void ExecutorTemplateForm_Load(object sender, EventArgs e)
		{
			//normally this should not cause any problems,
			//but during design-time, it is needed to avoid exceptions due to things that dont mean anything during design time.
			try
			{
				Logger.LogHandler += new LogEventHandler(this.LogHandler);

				AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(DefaultErrorHandler);

				//for windows forms apps unhandled exceptions on the main thread
				Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);

				// configuration 
				try
				{
					// en fait en faisant le deserialize on chope l'ancien ID attribu� a cet executor
					Config = Configuration.Deserialize();
				}
				catch
				{
					Config = new Configuration();
				}

				// l� on y go en dur
				EndPointConfiguration lManagerConfig = new EndPointConfiguration(AlchemiRole.Manager);
				lManagerConfig.RemotingMechanism = RemotingMechanism.TcpBinary;
				lManagerConfig.Host = System.Configuration.ConfigurationManager.AppSettings["GridServiceIP"];
				lManagerConfig.Port = 9001;
				Config.ManagerEndPoint = lManagerConfig;

				EndPointConfiguration lHereConfig = new EndPointConfiguration(AlchemiRole.Executor);
				lHereConfig.RemotingMechanism = RemotingMechanism.TcpBinary;
				string lHostName = Dns.GetHostName();
				lHereConfig.FriendlyName = lHostName;
				lHereConfig.HostNameForPublishing = lHostName;
				IPHostEntry ipEntry = Dns.GetHostEntry(lHostName);
				IPAddress[] addr = ipEntry.AddressList;
				lHereConfig.Host = addr[0].ToString();
				lHereConfig.Port = 9002;
				Config.OwnEndPoint = lHereConfig;

				// credential
				Config.Username = "executor";
				Config.Password = "executor";

				// ok la config est bonne :)
				Config.ConnectVerified = true;

				// normal exec startup mode.
				_container = new ExecutorContainer();
				_container.Config = Config;
				_container.GotDisconnected += new GotDisconnectedEventHandler(this.Executor_GotDisconnected);
				_container.GotKilled += new EventHandler(_container_GotKilled);
				_container.GotRestarted += new EventHandler(_container_GotRestarted);

				// premiere connection  
				ConnectExecutor();
				UpdateUI();
				HideTimer.Enabled = true;
			}
			catch { }
		}

	

		private void LogHandler(object sender, LogEventArgs e)
		{
			// Create a logger for use in this class
			ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
			switch (e.Level)
			{
				case LogLevel.Debug:
					string message = e.Source + ":" + e.Member + " - " + e.Message;
					logger.Debug(message, e.Exception);
					break;
				case LogLevel.Info:
					logger.Info(e.Message);
					// allez on bourrine notre fenetre
					Log(e.Message);
					break;
				case LogLevel.Error:
					logger.Error(e.Message, e.Exception);
					break;
				case LogLevel.Warn:
					logger.Warn(e.Message, e.Exception);
					break;
			}
		}

		/// <summary>
		/// On ferme et on relance
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void _container_GotRestarted(object sender, EventArgs e)
		{
			Log("Got restarted!");
			this.Restart();
		}

		/// <summary>
		/// On ferme tout court
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void _container_GotKilled(object sender, EventArgs e)
		{
			Log("Got killed!");
			this.Exit();
		}

		//happens only for non-dedicated mode.
		private void Executor_GotDisconnected()
		{
			//flag to find out if the disconnect was a manual operation by the user.
			if (btDisconnect.Tag == null)
			{
				try
				{
					Log("Got disconnected!");

					// on clear la connection courante completement
					Log("Clearing connection...");
					_container.Disconnect();

					int i = 0;
					// on essaye jusqu'a la mort :)
					while (true)
					{
						Log("Try connecting ... " + i++);
						ConnectExecutor();

						// on se casse si c'est tout bon, sinon boucle infernale
						if (_container.Connected)
							break;

						// 30s
						Thread.Sleep(30 * 1000);
					}

				}
				catch (Exception e)
				{
					logger.Error("Error Executor_GotDisconnected ", e);
				}
			}

			//reset it here
			btDisconnect.Tag = null; 			

			// refresh sur l'ui
			this.BeginInvoke((MethodInvoker)delegate
			{
				UpdateUI();
			});
		}

		/// <summary>
		/// Met � jour l'UI et les EndPoints
		/// </summary>
		private void UpdateUI()
		{
			// ici on met � jour la partie locale
			this.labelExecutorName.Text = Config.OwnEndPoint.FriendlyName;
			this.labelExecutorIP.Text = Config.OwnEndPoint.Host;
			this.labelExecutorPort.Text = Config.OwnEndPoint.Port.ToString();

			// idem pour le manager
			string managerName = "Not connected";
			if (Started)
			{
				managerName = Config.ManagerEndPoint.FriendlyName;
				this.btConnect.Enabled = false;
				this.btDisconnect.Enabled = true;
			}
			else
			{
				this.btConnect.Enabled = true;
				this.btDisconnect.Enabled = false;
			}
			this.labelManagerName.Text = managerName;
			this.labelManagerIP.Text = Config.ManagerEndPoint.Host;
			this.labelManagerPort.Text = Config.ManagerEndPoint.Port.ToString();
		}

		//-----------------------------------------------------------------------------------------------    

		private void btConnect_Click(object sender, EventArgs e)
		{
			ConnectExecutor();
			UpdateUI();
		}

		//-----------------------------------------------------------------------------------------------    

		private void mmExit_Click(object sender, EventArgs e)
		{
			Exit();
		}

		//-----------------------------------------------------------------------------------------------    

		protected override void WndProc(ref Message m)
		{
			const int WM_SYSCOMMAND = 0x0112;
			const int SC_CLOSE = 0xF060;
			if (m.Msg == WM_SYSCOMMAND & (int)m.WParam == SC_CLOSE)
			{
				// 'X' button clicked .. minimise to system tray
				timerPerfomance.Enabled = false;
				Hide();
				return;
			}
			base.WndProc(ref m);
		}

		//-----------------------------------------------------------------------------------------------    

		private void TrayIcon_Click(object sender, EventArgs e)
		{
			timerPerfomance.Enabled = true;
			Restore();
		}

		//-----------------------------------------------------------------------------------------------    

		private void tmExit_Click(object sender, EventArgs e)
		{
			Exit();
		}

		 
		//-----------------------------------------------------------------------------------------------    

		private void mmAbout_Click(object sender, EventArgs e)
		{
			ShowSplashScreen();
		}

		//-----------------------------------------------------------------------------------------------    

		static void DefaultErrorHandler(object sender, UnhandledExceptionEventArgs args)
		{
			Exception e = (Exception)args.ExceptionObject;
			//            if (e.GetType() == typeof(AppDomainUnloadedException))
			//            {
			//                // can't figure out why this exception is being thrown .. in any case, seems safe to ignore it
			//                //return;
			//            }
			HandleAllUnknownErrors(sender.ToString(), e);
		}

		//-----------------------------------------------------------------------------------------------    

		private void HideTimer_Tick(object sender, EventArgs e)
		{
			Hide();
			HideTimer.Enabled = false;
			timerPerfomance.Enabled = false;
		}

		//-----------------------------------------------------------------------------------------------        
		//
		// Core Methods
		//
		//-----------------------------------------------------------------------------------------------    

		protected void Log(string s)
		{
			this.BeginInvoke((MethodInvoker)delegate
			{
				if (txLog != null && !txLog.IsDisposed)
				{
					if (txLog.Text.Length + s.Length >= txLog.MaxLength)
					{
						//remove all old stuff except the last 10 lines.
						string[] s1 = new string[10];
						for (int i = 0; i < 10; i++)
						{
							s1[9 - i] = txLog.Lines[txLog.Lines.Length - 1 - i];
						}
						txLog.Lines = s1;
					}
					txLog.AppendText(s + Environment.NewLine);
				}
			});
		}


		//-----------------------------------------------------------------------------------------------            

		private void Restore()
		{
			this.WindowState = FormWindowState.Normal;
			this.Show();
			this.Activate();
		}

		//-----------------------------------------------------------------------------------------------    

		private void btDisconnect_Click(object sender, EventArgs e)
		{
			DisconnectExecutor();
			UpdateUI();
		}

		//-----------------------------------------------------------------------------------------------

		private void ShowSplashScreen()
		{
			SplashScreen ss = new SplashScreen();
			ss.ShowDialog();
		}

		private void txLog_DoubleClick(object sender, EventArgs e)
		{
			txLog.Clear();
		}

		private void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
		{
			HandleAllUnknownErrors(sender.ToString(), e.Exception);
		}

		static void HandleAllUnknownErrors(string sender, Exception e)
		{
			logger.Error("Unknown Error from: " + sender, e);
			if (!silentMode)
			{
				MessageBox.Show(e.ToString(), "Unexpected Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}


		/// <summary>
		/// Specifies whether the Executor is Connected
		/// </summary>
		protected bool Started
		{
			get
			{
				bool started = false;
				started = _container == null ? false : _container.Connected;
				return started;
			}
		}

		protected void Restart()
		{
			DisconnectExecutor();
			Application.Restart();
		}

		protected void Exit()
		{
			DisconnectExecutor();
			Application.Exit();
		}

		protected void DisconnectExecutor()
		{
			if (!Started)
			{
				return;
			}

			try
			{			 
				//set a flag to show that this is a manual disconnect,
				//so should not reconnect.
				btDisconnect.Tag = "true";
				_container.Disconnect();
				Log("Disconnected successfully.");				 
			}
			catch (Exception ex)
			{
				Log("Error disconnecting from Manager." + ex.Message);
			}
		}

		/// <summary>
		/// update les fichiers d'application
		/// </summary>
		/// <returns></returns>
		protected bool UpdateApplicationFiles()
		{
			try
			{
				// on clean les appdomain qui bloque ces fichiers
				SandboxService.Reset();

				// le repertoire de destination
				string appFolder = Application.StartupPath + "\\Applications";
				DirectoryInfo src = new DirectoryInfo(appFolder);
				try
				{
					if (!Directory.Exists(appFolder))
						Directory.CreateDirectory(appFolder);
				}
				catch
				{
					Log("Updating : Failed to create folder Application");
					return false;
				}

				// la version actuelle
				int lCurrentVersion = 0;
				try
				{
					FileInfo[] files = src.GetFiles("version.*");
					if (files.Length > 0)
					{
						string ext = Path.GetExtension(files[0].FullName);
						lCurrentVersion = int.Parse(ext.Replace(".", ""));
					}
				}
				catch
				{
					Log("Updating : Failed to retreive file version");
					return false;
				}

				Log("Attempting to connect to Updater...");
				try
				{
					bool isOnError = false;
					// l'objet distant permettant de rapattrier les fichiers
					string updaterUri = "tcp://" + Config.ManagerEndPoint.Host + ":9003/PricingDllUpdater";
					IDirectoryUpdater updater = (IDirectoryUpdater)Activator.GetObject(typeof(IDirectoryUpdater), updaterUri);
					FileDependencyCollection deps = updater.GetFiles(lCurrentVersion);
					if (deps.Count != 0)
					{
						Log("Updating : Local application version : " + lCurrentVersion);
						// On nettoie l'ancien
						foreach (FileInfo file in src.GetFiles())
						{
							try
							{
								file.Delete();
							}
							catch { }
						}

						// on recopie les nouveaux
						foreach (FileDependency file in deps)
						{
							Log("Updating : " + Path.GetFileName(file.FileName));
							try
							{
								string dest = Path.Combine(appFolder, Path.GetFileName(file.FileName));
								file.Unpack(dest);
							}
							catch
							{
								Log("Updating : Error with " + Path.GetFileName(file.FileName));
								isOnError = true;
							}
						}
					}
					else
					{
						Log("No need to update.");
					}

					if (isOnError)
						return false;
				}
				catch
				{
					Log("Updating : Error while connecting to server");
					return false;
				}
			}
			catch (Exception ex)
			{
				Log("Error while updating. " + ex.Message);
				return false;
			}
			return true;
		}

		/// <summary>
		/// Connection de l'executor au monitor
		/// </summary>
		protected void ConnectExecutor()
		{
			if (Started)
			{
				return;
			}

			//reset it here
			btDisconnect.Tag = null;

			// Update les fichiers
			if (!UpdateApplicationFiles())
			{
				// erreur : on ne peut pas garder cet executor : trop dangereux d'utiliser de vieilles versions
				Log("Error while updating...exectuor is off");
				return;
			}

			// On se connecte pour de bon
            try 
            {
                Log("Attempting to connect to Manager...");
                _container.Connect();
				try
				{
					Config.ManagerEndPoint.FriendlyName = Dns.GetHostEntry(Config.ManagerEndPoint.Host).HostName;
				}
				catch { }
				Log("Connected to Manager on " + Config.ManagerEndPoint.FriendlyName);
			}
			catch (Exception ex)
			{
				Log("Error connecting to manager. " + ex.Message);
			}
		}

		private void timerPerfomance_Tick(object sender, EventArgs e)
		{
			this.performanceGraph.UpdateChart((double)performanceCounter1.NextValue());
		}
	}
}