﻿using CaesarApplication.Service.Connection;
using log4net;
using log4net.Config;
using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading;
using BatchPriceIndexes;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using PricingServer;
using CaesarApplication.QuoteCalculator;
using System.Globalization;
using CaesarApplication.BlotterAsService;
using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Logging;
using FuncFramework.Business;
using CaesarExtensions.Indices.Reporting;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Blotter.Tasks;
using GlobalDerivativesApplications.Reporting;
using GlobalDerivativesApplications;
using CaesarApplication.NRT;
using CaesarApplication.Service.PricingEngine;
using System.IO;
//using GlobalDerivativesApplications;
//using GlobalDerivativesApplications.Reporting;

namespace Caesar.BatchPriceIndexes
{
    internal class Program
    {

        private static int Main(string[] args)
        {
            string directoriesToPrice = null;

            string nrtExeFileToTest = null;
            string nrtFilePath = null;
            bool nrtMode = false;

            string startDate = null;
            string endDate = null;
            string runLocal = null;
            bool isFolder = false;
            string configDate = null;
            string configName = null;
            string resultDirectory = null;
            int nbDaysLag = -1;

            int? nbCalculatedDays = null;

            string indexToPrice = null;
            int? projectId = null;
            string taskId = null;

            bool skipReporting = false;
            bool skipBooking = false;
            bool sendMailAnyWay = false;

            string mailPrefix = string.Empty;
            string[] dataHandlers = null;

            string env = null;
            string outputPath = null;

            bool executeTasks = false;
            bool executeSophisCompare = false;
            bool executeBookingCompare = false;

            bool useIndexDtoSicovam = false;

            bool executeSophisPrice = false;

            bool executeTheroricalPrice = false;

            bool executeRealizedPrice = true;

            args.Consume("waitDebugger", opt =>
            {
                Console.WriteLine("Waiting for debugger to attach");
                while (!Debugger.IsAttached)
                {
                    Thread.Sleep(100);
                }
                Console.WriteLine("Debugger attached");
            })
            .Consume("nrtExeFileToTest", (optname, value) => nrtExeFileToTest = value, LongOptFormat: "--")
            .Consume("resultDirectory", (optname, value) => resultDirectory = value, LongOptFormat: "--")
            .Consume("nrtFilePath", (optname, value) => nrtFilePath = value, LongOptFormat: "--")
            .Consume("nrtMode", (optname, value) => nrtMode = bool.Parse(value), LongOptFormat: "--")
            .Consume("runLocal", (optname, value) => runLocal = value, LongOptFormat: "--")
            .Consume("isFolder", (optname, value) => isFolder = !string.IsNullOrEmpty(value) && Convert.ToBoolean(value), LongOptFormat: "--")
            .Consume("startDate", (optname, value) => startDate = value, LongOptFormat: "--")
            .Consume("endDate", (optname, value) => endDate = value, LongOptFormat: "--")
            .Consume("configDate", (optname, value) => configDate = value, LongOptFormat: "--")
            .Consume("nbDaysLag", (optname, value) => nbDaysLag = int.Parse(value), LongOptFormat: "--")
            .Consume("configName", (optname, value) => configName = value, LongOptFormat: "--")
            .Consume("env", (optname, value) => env = value, LongOptFormat: "--")
            .Consume("outputPath", (optname, value) => outputPath = value, LongOptFormat: "--")
            .Consume("directoriesToPrice", (optname, value) => directoriesToPrice = value.Replace("->", StrategyTree.PathDelimiter.ToString()), LongOptFormat: "--")
            .Consume("indexToPrice", (optname, value) => indexToPrice = value.Replace("->", StrategyTree.PathDelimiter.ToString()), LongOptFormat: "--")
            .Consume("projectId", (optname, value) => projectId = int.Parse(value), LongOptFormat: "--")
            .Consume("taskId", (optname, value) => taskId = value, LongOptFormat: "--")
            .Consume("skipBooking", (optname, value) => skipBooking = bool.Parse(value), LongOptFormat: "--")
            .Consume("skipReporting", (optname, value) => skipReporting = bool.Parse(value), LongOptFormat: "--")
            .Consume("sendMailAnyWay", (optname, value) => bool.TryParse(value, out sendMailAnyWay), LongOptFormat: "--")
            .Consume("executeTasks", (optname, value) => bool.TryParse(value, out executeTasks), LongOptFormat: "--")
            .Consume("executeSophisCompare", (optname, value) => bool.TryParse(value, out executeSophisCompare), LongOptFormat: "--")
             .Consume("executeSophisPrice", (optname, value) => bool.TryParse(value, out executeSophisPrice), LongOptFormat: "--")
            .Consume("executeBookingCompare", (optname, value) => bool.TryParse(value, out executeBookingCompare), LongOptFormat: "--")
            .Consume("env", (optname, value) => env = value, LongOptFormat: "--")
            .Consume("useIndexDtoSicovam", (optname, value) => useIndexDtoSicovam = bool.Parse(value), LongOptFormat: "--")
            .Consume("executeTheroricalPrice", (optname, value) => executeTheroricalPrice = bool.Parse(value), LongOptFormat: "--")
            .Consume("executeRealizedPrice", (optname, value) => executeRealizedPrice = bool.Parse(value), LongOptFormat: "--")
            .Consume("nbCalculationDays", (optname, value) =>
            {
                int nbCalculatedDaysLocal;

                if (int.TryParse(value, out nbCalculatedDaysLocal))
                {
                    nbCalculatedDays = nbCalculatedDaysLocal;
                }
            }, LongOptFormat: "--")
            .Consume("mailPrefix", (optname, value) => mailPrefix = value, LongOptFormat: "--")
            .Consume("dataHandlers", (optname, value) =>
            {
                if (!string.IsNullOrWhiteSpace(value))
                {
                    dataHandlers = value.Split(';');
                }

                AppDomain.CurrentDomain.SetData("DataSourceSelectionInstance", dataHandlers);

            }, LongOptFormat: "--");

            args = ConnectionService.ConfigureFromCommandLine(args);

            BatchPricerRunConfig runConfig = CreateBatchPricerRunLocalConfig(resultDirectory, startDate, endDate, runLocal, configDate, configName, nbDaysLag, indexToPrice, projectId, skipBooking, skipReporting, mailPrefix, sendMailAnyWay, nbCalculatedDays, dataHandlers, isFolder, directoriesToPrice, nrtFilePath, nrtMode, nrtExeFileToTest);

            // Set log4net property
            GlobalContext.Properties["pid"] = Process.GetCurrentProcess().Id;
            GlobalContext.Properties["username"] = Environment.UserName;
            // Launch log4net engine
            XmlConfigurator.Configure();

            TimeSeriesProviderInitializer.CheckHistoricBloombergIsAvailable();

            //// Server
            ConnectionService.ConnectToDealServer();

            if (taskId != null)
            {
                try
                {
                    var reportRobot = new ReportBot();
                    var result = reportRobot.LoadAndRunReportingTask(taskId);
                    return result ? 0 : 100;
                }
                catch (Exception e)
                {
                    Console.WriteLine(string.Format("Error while executing task {0} : {1}", taskId, e.Message));
                    return 100;
                }
            }

            PricingService.PricingServerFactory = new PricingServerFactory();
            int returnCode = 0;
            try
            {
                if (executeTasks)
                {
                    ExecuteTasks();
                }
                else if (executeSophisPrice)
                {
                    new SophisOptionPricer(env, outputPath).CalculateRealizedValuesTimeSeries(File.ReadAllLines(configName), useIndexDtoSicovam, executeRealizedPrice, executeTheroricalPrice);
                }
                else if (executeSophisCompare || executeBookingCompare)
                {
                    var result = new FileBookingManager(-nbDaysLag, DateTime.Today).Compute(configName);

                    new FileBookingManagerReportingService().SendReport(result);
                }
                else if (nrtMode)
                {
                    new NRTEngine().LaunchNRT(runConfig);
                }
                else
                {
                    BatchPricer pricer = new BatchPricer(runConfig);

                    returnCode = pricer.Price() ? 0 : 50;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Global error");
                Console.WriteLine(ex);
                //BatchPricer.SendErrorStatusMail(ex.ToString());
                returnCode = 100;
            }

            return returnCode;
        }

        private static void ExecuteTasks()
        {
            bool anyTaskHasBeenExecuted = false;
            bool hasFailed = false;
            StringBuilder executionReport = new StringBuilder();


            executionReport.AppendFormat("Execution task run at {0}\r\n", DateTime.Now);

            //  PersistanceService.IndexProvider.SaveStatuses(
            //      new QuoteTask(new ProjectDTO {project_name = "NXSHOOE"},
            //          new IndexDTO {ticker = "SL NXS Europe" + IndexPathHelper.Delimiter + "SL NXS Index" },
            //          new IndexQuoteDTO { date_version = DateTime.Today }) { Completed = true}.AsArray(), UserService.CaesarSession);

            var executionTaskManager = new ExecutionTaskManager(new IndexDBProviderFactory());
            var tasksToExecute = PersistanceService.IndexProvider.LoadExecutionTasksToExecute(UserService.CaesarSession);

            tasksToExecute.ForEach(x => x.Status = ExecutionTaskDTOStatus.Executing);
            tasksToExecute.ForEach(x => x.StatusDate = DateTime.Now);

            PersistanceService.IndexProvider.SaveExecutionTasks(tasksToExecute, UserService.CaesarSession);

            foreach (var executionTaskDto in tasksToExecute)
            {
                anyTaskHasBeenExecuted = true;

                LogAndAppend(executionReport, "Start execute task {0} for {1} created by {2} at {3}",
                    executionTaskDto.Id, executionTaskDto.TaskKey, executionTaskDto.CreatorLogin, executionTaskDto.CreationDate);
                try
                {
                    var task = executionTaskManager.GetExecutionTask(executionTaskDto);

                    task.Execute();

                    task.Comment = task.Comment ?? "";

                    executionTaskDto.StatusDescription = task.Comment.Substring(0, Math.Min(task.Comment.Length, 500));
                    executionTaskDto.Status = ExecutionTaskDTOStatus.ExecutedWithSuccess;
                    LogAndAppend(executionReport, "Success execute task {0} for {1} created by {2} at {3}",
                        executionTaskDto.Id, executionTaskDto.TaskKey, executionTaskDto.CreatorLogin,
                        executionTaskDto.CreationDate);
                }
                catch (Exception ex)
                {
                    executionTaskDto.Status = ExecutionTaskDTOStatus.ExecutedWithErrors;
                    executionTaskDto.StatusDescription = ex.ToString().Substring(0, Math.Min(ex.ToString().Length, 500));
                    LoggingService.Error(typeof(Program), ex);
                    LogAndAppend(executionReport, "Failure execute task {0} for {1} created by {2} at {3}",
                        executionTaskDto.Id, executionTaskDto.TaskKey, executionTaskDto.CreatorLogin,
                        executionTaskDto.CreationDate);

                    executionReport.AppendLine(ex.ToString());

                    hasFailed = true;
                }

                tasksToExecute.ForEach(x => x.StatusDate = DateTime.Now);
                PersistanceService.IndexProvider.SaveExecutionTasks(executionTaskDto.AsArray(), UserService.CaesarSession);
                LogAndAppend(executionReport, "End execute task {0} for {1} created by {2} at {3}",
                    executionTaskDto.Id, executionTaskDto.TaskKey, executionTaskDto.CreatorLogin, executionTaskDto.CreationDate);
            }

            if (anyTaskHasBeenExecuted)
            {
                var senderMail = "eda25-desk-quant-applications@natixis.com";
                Tools.System.SendEmailEWS(senderMail,
                                            ConfigurationManager.AppSettings["SupportMailingList"].Split(',', ';'),
                                            "[CaesarPostValidationTasksk]" + (hasFailed ? "FAIL" : "SUCCESS"),
                                            executionReport.ToString(),
                                            impersonatedAddress: senderMail, userName: "nt_eqd_sos", password: "Ba13h,7j");
            }
        }

        private static void LogAndAppend(StringBuilder logStringBuilder, string format, params object[] parameters)
        {
            var str = string.Format(format, parameters);

            LoggingService.InfoFormatted(typeof(Program), str);
            logStringBuilder.AppendLine(str);
        }


        private static BatchPricerRunConfig CreateBatchPricerRunLocalConfig(string resultDirectory, string startDate, string endDate, string runLocal, string configDateStr, string configName, int nbDaysLag, string indexToPrice, int? projectId, bool skipBooking, bool skipReporting, string mailPrefix, bool sendMailAnyWay, int? nbCalculatedDays, string[] dataHandlers, bool isFolder, string directoriesToPrice, string nrtFilePath, bool nrtMode, string nrtExeFileToTest)
        {
            bool toRunLocal = runLocal.IsNotNull() && runLocal.ToLower().Equals("true");

            DateTime tmp;
            DateTime? start = null;
            DateTime? end = null;
            DateTime? configDate = null;

            if (DateTime.TryParseExact(startDate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out tmp))
                start = tmp;
            if (endDate != null && DateTime.TryParseExact(endDate, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out tmp))
                end = tmp;
            if (DateTime.TryParseExact(configDateStr, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out tmp))
                configDate = tmp;

            return new BatchPricerRunConfig(resultDirectory, toRunLocal, start, end, configDate, configName, nbDaysLag, indexToPrice, projectId, skipBooking, skipReporting, mailPrefix, sendMailAnyWay, nbCalculatedDays, dataHandlers) { FolderToPrice = isFolder ? indexToPrice : null, DirectoriesToPrice = directoriesToPrice, NrtFilePath = nrtFilePath, NrtMode = nrtMode, NrtExeFileToTest = nrtExeFileToTest };
        }

        private static string TryToBuildAllIndexes(bool onlyError)
        {
            var result = new StringBuilder();

            var projectDTOs = PersistanceService.IndexProvider.ReadAllProjects(PersistanceService.CaesarSession);
            foreach (var item in projectDTOs)
            {
                var indexes =
                    PersistanceService.IndexProvider.ReadProject(item.id, null, PersistanceService.CaesarSession)
                        .indexes.ToList();
                foreach (var itemIndex in indexes)
                {
                    var elementIndex = PersistanceService.IndexToStrategy(itemIndex);

                    try
                    {
                        var waitEvt = new AutoResetEvent(false);

                        elementIndex.Product.Build();

                        elementIndex.Product.BuildError += (sender, args) => result.AppendLine(GetStringFromError(onlyError, args.Error));
                        elementIndex.Product.BuildFinished += (sender, args) => waitEvt.Set();

                        waitEvt.WaitOne(10000);
                    }
                    catch (Exception ex)
                    {
                        result.AppendLine(string.Format("ERROR Ex : {0}", ex));
                    }
                }
            }

            return result.ToString();
        }

        private static string GetStringFromError(bool onlyError, CompilerErrorCollection compilerErrorCollection)
        {
            var res = new StringBuilder();

            foreach (CompilerError err in compilerErrorCollection)
            {
                if (err.IsWarning)
                {
                    if (!onlyError)
                    {
                        res.AppendLine(string.Format("WARN:{0}", err));
                    }
                }
                else
                {
                    res.AppendLine(string.Format("ERROR:{0}", err));
                }
            }

            return res.ToString();
        }
    }
}
