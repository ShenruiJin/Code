﻿using System;
using System.Collections.Generic;
using CaesarApplication.QuoteCalculator;

namespace BatchPriceIndexes
{
    public class BatchPricer
    {
        private BatchPricerRunConfig config; 
        private List<PriceIndexItem> _items;

        public BatchPricer(BatchPricerRunConfig config)
        {
            this.config = config;

        }

        /// <summary>
        /// Price
        /// </summary>
        public bool Price()
        {
            IndexPricingResultNotifier indexPricingResultNotifier = new IndexPricingResultNotifier();
            indexPricingResultNotifier.LaunchPricing(config);

            if (config.RunLocal)
            {
                indexPricingResultNotifier.WriteRunLocalInfo(config);
            }

            if (!config.RunLocal || config.SendMailAnyWay)
            {
                indexPricingResultNotifier.SendResultMail(config);
            }

            return indexPricingResultNotifier.IsSuccess;
        }

        public static void SendErrorStatusMail(string exception)
        {
            IndexPricingResultNotifier.SendErrorStatusMail( exception);
        }
    }
}
