﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using RemotingInterfaces;
using BbgProcesser;
using Estimators;
using StructuringControls;

namespace BBClient
{
    partial class MainForm
    {
        #region Computing helpers
        // Convert the perf matrix to a last close quantoed array
        private double[] ConvertToLastQuantoed(double[,] perfMatrix)
        {
            double[] lastQuantoed =  new double[_nbNonQuantoSecurities];

            string quantoCurrency = Convert.ToString(_comboBoxQuanto.SelectedValue);
            for (int counter = 0; counter < _nbNonQuantoSecurities; counter++)
            {
                // Retrieve the last close
                int indexLastData = perfMatrix.GetLength(1) - 1;
                double lastClose = perfMatrix[counter, indexLastData];

                // Retrieve the quanto
                string quantoSecurity = Convert.ToString(_correlationDataTable.Rows[counter][_colCurrency]);
                // Penny stocks
                if (quantoSecurity == "GBp")
                {
                    lastClose /= 100;
                }
                double quanto = 0;
                if (quantoCurrency == quantoSecurity)
                {
                    quanto = 1;
                }
                else
                {
                    string forex = quantoSecurity + quantoCurrency;
                    for (int counterForex = _nbNonQuantoSecurities; counterForex < _securityList.Count; counterForex++)
                    {
                        if (forex == _securityList[counterForex])
                        {
                            quanto = perfMatrix[counterForex, indexLastData];
                            if (quantoSecurity == "JPY")
                            {
                                quanto /= 100;
                            }
                            else if (quantoSecurity == "KRW")
                            {
                                quanto /= 1000;
                            }
                        }
                    }
                }
                lastQuantoed[counter] = lastClose * quanto;
            }

            return lastQuantoed;
        }
        #endregion
        
        #region Query generation
        // Création de la query sur les données static à partir de la liste des SJ
        private BbgQuery GenerateStaticQuery()
        {
            // Init the request list
            List<string> requestList = new List<string>();
            requestList.Add(BbgField.Name);
            requestList.Add(BbgField.Country);
            requestList.Add(BbgField.Currency);
            requestList.Add("ID_SEDOL1");

            // Single query for each field in the static list
            BbgQuery query = new BbgQuery();

            try
            {
                // Add each selected query field if not present
                foreach (string field in requestList)
                {
                    if (!query.FieldsList.Contains(field))
                    {
                        query.FieldsList.Add(field);
                    }
                }
                // Add the requested securities
                for (int counter = 0; counter < this._dataGridViewNonCorrel.Rows.Count; counter++)
                {
                    object sjValue = this._dataGridViewNonCorrel[_colSecurity, counter].Value;
                    if (sjValue != null)
                    {
                        string underlying = sjValue.ToString().ToUpper();
                        if (underlying.Trim() != string.Empty && !query.SecuritiesList.Contains(underlying))
                        {
                            query.SecuritiesList.Add(underlying);
                        }
                    }
                }
                // Update the security list
                _securityList = query.SecuritiesList.GetRange(0, query.SecuritiesList.Count);
                query.IsStatic = true;
            }
            catch (Exception ex)
            {
                ShowMessageBox("Error on query generation : " + ex.Message);
            }

            return query;
        }

        // Création de la query des données histos (close, volume) à partir de la liste des SJ
        private BbgQuery GenerateHistoricQuery()
        {
            // Init the request list
            List<string> requestList = new List<string>();
            requestList.Add(BbgField.ClosePrice);
            requestList.Add(BbgField.Volume);
            //requestList.Add("PX_LAST_EURO");    // Last close in Euro

            BbgQuery query = new BbgQuery();

            // Add each selected query field if not present
            foreach (string field in requestList)
            {
                if (!query.FieldsList.Contains(field))
                {
                    query.FieldsList.Add(field);
                }
            }

            query.Periodicity = BbgPeriodicity.Daily;
            // Add the requested securities
            List<string> doublonSecurities = new List<string>();
            for (int counter = 0; counter < this._dataGridViewNonCorrel.Rows.Count; counter++)
            {
                object sjValue = this._dataGridViewNonCorrel[_colSecurity, counter].Value;
                if (sjValue != null)
                {
                    string underlying = sjValue.ToString().ToUpper();
                    if (underlying.Trim() != string.Empty && !query.SecuritiesList.Contains(underlying))
                    {
                        query.SecuritiesList.Add(underlying);
                    }
                    else if (query.SecuritiesList.Contains(underlying))
                    {
                        if (!doublonSecurities.Contains(underlying))
                        {
                            doublonSecurities.Add(underlying);
                        }
                    }
                }
            }
            // Show message box to inform the duplicate underlyings have been deleted, if any
            string messageErreurDuplicate = "The basket contained the following duplicate securities, which have been deleted.";
            if (doublonSecurities.Count > 0)
            {
                foreach (string security in doublonSecurities)
                {
                    messageErreurDuplicate += "\n" + security;
                }
                ShowMessageBox(messageErreurDuplicate);
            }
            // Update the number of non-quanto securities
            _nbNonQuantoSecurities = query.SecuritiesList.Count;
            // Add the quanto effect : get the currency of each underlying
            // Invoke needs to be used since we're trying to access the main thread from another thread
            RetrieveObject tempDeleg = delegate() { return ((DataRowView)_comboBoxQuanto.Items[_comboBoxQuanto.SelectedIndex])[_colValue]; };
            string quantoCurrency = Convert.ToString(this.Invoke(tempDeleg));
            foreach (DataRow row in _correlationDataTable.Rows)
            {
                string forex = String.Empty;
                if (row[BbgField.Currency] != null)
                {
                    string securityQuanto = Convert.ToString(row[BbgField.Currency]);
                    if (securityQuanto.Trim() != String.Empty && quantoCurrency != securityQuanto)
                    {
                        forex = securityQuanto + quantoCurrency;
                        if (!query.SecuritiesList.Contains(forex))
                        {
                            query.SecuritiesList.Add(forex);
                        }
                    }
                }
            }
            // Update the security list
            _securityList = query.SecuritiesList;

            // Get data up to n years ago plus a few days for cushion, where n = max horizon
            // End date is 2 weekdays ago
            // 1 day to be sure that data is present
            // 1 day due to the previous day use for asian values
            int backDays = -1;
            if (DateTime.Today.DayOfWeek == DayOfWeek.Monday)
            {
                backDays = -3;
            }
            int nbYearsBack = Convert.ToInt32(_horizonList[_horizonList.Count - 1]);
            query.EndDate = DateTime.UtcNow.Date.AddDays(backDays).Date;
            // *2 factor for graphical analysis
            query.StartDate = query.EndDate.AddYears(-nbYearsBack*2).AddDays(-5).Date;
            // Force the start date to be on a tuesday to give 
            // an additional blanket for available data computation
            while (query.StartDate.DayOfWeek != DayOfWeek.Tuesday)
            {
                query.StartDate = query.StartDate.AddDays(-1);
            }

            return query;
        }
        #endregion

        #region Custom correlations
        public void SetAsGroup(int groupNumber)
        {
            // Delete from other groups, add to the selected one
            for(int groupCounter = 0; groupCounter < _correlationGroups.Count; groupCounter++)
            {
                List<int> customGroup = _correlationGroups[groupCounter];
                for (int i = 0; i < _nbNonQuantoSecurities; i++)
                {
                    if (_dataGridViewNonCorrel[_colSecurity, i].Selected)
                    {
                        for (int j = 0; j < _nbNonQuantoSecurities; j++)
                        {
                            if (_correlationDataTable.Rows[j][_colSecurity].ToString() ==
                                _dataGridViewNonCorrel[_colSecurity, i].Value.ToString())
                            {
                                _correlationDataTable.Rows[j][_colGroupIndex] = groupNumber;
                                if (customGroup.Contains(j) && groupCounter != groupNumber)
                                {
                                    customGroup.Remove(j);
                                }
                                else if (!customGroup.Contains(i) && groupCounter == groupNumber)
                                {
                                    customGroup.Add(j);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void SetCustomCorrelBumps(List<BumpPlot> bumpList)
        {
            UpdateDataGridCorrelsHisto(bumpList);
        }

        private List<List<int>> _correlationGroups;
        #endregion
    }
}
