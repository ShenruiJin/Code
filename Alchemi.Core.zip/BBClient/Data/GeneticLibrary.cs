﻿using FuncFramework.Business;
using PricingBase.Product;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaesarApplication.Service.Logging;

namespace BBClient.Data
{
    public class GeneticLibrary
    {

        public class GeneticAlgorithm
        {
            /// <summary>
            ///  Constructor
            /// </summary>
            /// <param name="InitialPopulation"></param>
            /// <param name="AlgorithmParameters"></param>
            /// <param name="SelectionMethod"></param>
            /// <param name="CrossoverMethod"></param>
            /// <param name="ReinsertionMethod"></param>
            /// <param name="PricingSettingsFinalIteration"></param>
            /// <param name="repriceFinalPopulation"></param>
            public GeneticAlgorithm(Structures.PopulationOfBaskets InitialPopulation, 
                                    GAparameters AlgorithmParameters, SelectionMethodDelegate SelectionMethod, 
                                    CrossoverMethodDelegate CrossoverMethod, ReinsertionMethodDelegate ReinsertionMethod,
                                    Structures.PricingSettingsForBasket PricingSettingsFinalIteration,
                                    bool repriceFinalPopulation)
            {
                _currentPopulation = InitialPopulation.Copy();
                _previousPopulation =  _currentPopulation.Copy();
                _isConverged = false;
                _repriceFinalPopulation = repriceFinalPopulation;
                _AlgoStats = new GAstats();
                _Parameters = AlgorithmParameters;
                _SelectionMethod = SelectionMethod;
                _CrossOverMethod = CrossoverMethod;
                _ReinsertionMethod = ReinsertionMethod;
                _PricingSettingsFinalIteration = PricingSettingsFinalIteration;
            }
            /// <summary>
            /// Run the algorithm i.e. "evolve"
            /// </summary>
            /// <param name="BaseProdForPricing"></param>
            /// <param name="backgroundworker"></param>
            /// <param name="e"></param>
            public void Evolve(Dictionary<string, Structures.BasketOfUnderlyings> _pricingCache, StrategyDataSetElement BaseProdForPricing, BackgroundWorker backgroundworker, DoWorkEventArgs e, double delta, double vega, double cega)
            {
                backgroundworker.ReportProgress(0, this);
                do
                {
                    if(!backgroundworker.CancellationPending)
                    {
                        Evolve1Generation(_pricingCache, BaseProdForPricing, backgroundworker, e,  delta,  vega,  cega);
                        // Progress as an int
                        double prog = (double)_AlgoStats.GenerationsCounter / _Parameters.nGenerations * 100;
                        int progress = (int)Math.Round(prog);
                        backgroundworker.ReportProgress(progress, this);
                    }
                    else
                    {
                        _algoCancelled = true;
                        _isConverged = true;
                        e.Cancel = true;
                    }
                    
                    
                } while (_isConverged == false);

                if(_repriceFinalPopulation)
                {
                    //Reprice one last time ("good settings")
                    foreach (Structures.BasketOfUnderlyings Basket in _currentPopulation.BasketsList)
                    {
                        Basket.ReplacePricingSettings(_PricingSettingsFinalIteration);
                    }
                    _currentPopulation.Evaluate(_pricingCache,BaseProdForPricing, backgroundworker, e, true,  delta,  vega,  cega);
                    _currentPopulation.SortPopulation(true);
                }

                
                
            }

            /// <summary>
            /// Makes a population of children/offspring from the current population
            /// </summary>
            /// <param name="_AlgoStats"></param>
            /// <returns></returns>
            private Structures.PopulationOfBaskets MakeChildrenPopulation(GAstats _AlgoStats)
            {
                
                // Select parents: an even number (to make pair). Either by Eugenics or another method
                int nToSelect = _currentPopulation.Size % 2 == 0 ? _currentPopulation.Size : _currentPopulation.Size + 1;
                List<Structures.BasketOfUnderlyings>  ParentsSelected = _SelectionMethod(_currentPopulation, _Parameters.Random, _Parameters);        
                                
                #region Crossover

                // Crossover of parents two by two
                Structures.BasketOfUnderlyings Parent1;
                Structures.BasketOfUnderlyings Parent2;
                List<Structures.BasketOfUnderlyings> Children = new List<Structures.BasketOfUnderlyings>();
                int i = 0;
                do
                {
                    Parent1 = ParentsSelected[i].Copy();
                    Parent2 = ParentsSelected[i + 1].Copy();
                    _CrossOverMethod(Parent1, Parent2, _Parameters, _AlgoStats);
                    AlgorithmStatistics.NumberOfCrossovers++;
                    Children.Add(Parent1);
                    Children.Add(Parent2);
                    i += 2;
                } while (Children.Count < _currentPopulation.Size);



                #endregion

                Structures.PopulationOfBaskets ChildrenPopulation = new Structures.PopulationOfBaskets(Children, FitnessForMinimization, _Parameters.OptimizationGoal, _Parameters.SortBasis, _Parameters.Random);

                //Mutation
                foreach (Structures.BasketOfUnderlyings Basket in ChildrenPopulation.BasketsList)
                {
                    Basket.Mutate(_Parameters, _currentPopulation.UnderlyingSpace, _AlgoStats);
                }
                return ChildrenPopulation;
            }

            /// <summary>
            /// Do one iteration of the genetic algorithm
            /// </summary>
            /// <param name="BaseProdForPricing"></param>
            /// <param name="backgroundworker"></param>
            /// <param name="e"></param>
            private void Evolve1Generation(Dictionary<string, Structures.BasketOfUnderlyings> _pricingCache, StrategyDataSetElement BaseProdForPricing, BackgroundWorker backgroundworker, DoWorkEventArgs e, double delta, double vega, double cega)
            {
                LoggingService.Info(typeof(GeneticLibrary), "[Basket Optimizer] - New population : "+ _AlgoStats.GenerationsCounter+1);
                // Make a new population 
                Structures.PopulationOfBaskets ChildrenPopulation = MakeChildrenPopulation(_AlgoStats);
                ChildrenPopulation.Evaluate(_pricingCache, BaseProdForPricing, backgroundworker, e, false,  delta,  vega,  cega);
                // Update the old population
                _previousPopulation =  _currentPopulation.Copy();
                //Reinsert them
                _ReinsertionMethod(_currentPopulation, ChildrenPopulation, _Parameters);
                _currentPopulation.SortPopulation();
                _previousPopulation.SortPopulation();
                //Refresh statistics
                _currentPopulation.ComputePopulationStatistics();
                _AlgoStats.RefreshStats();
                LoggingService.Info(typeof(GeneticLibrary), "[Basket Optimizer] - Best Basket"+ string.Join(",", _AlgoStats.BestBasketEver.UnderlyingsTickers.ToArray()));
                LoggingService.Info(typeof(GeneticLibrary), "[Basket Optimizer] - Worst Basket" + string.Join(",", _AlgoStats.WorstBasketEver.UnderlyingsTickers.ToArray()));

                // Check the convergence
                _isConverged = CheckConvergence(); 
                
            }

            /// <summary>
            /// Check if the algorithm has converged
            /// </summary>
            /// <returns></returns>
            private bool CheckConvergence()
            {
                // double conv;
                // First check on number of iterations
                if(_AlgoStats.GenerationsCounter >= _Parameters.nGenerations)
                {
                    return true;
                }

                //Second Check on the convergence???????? can stop too early (same basket is the best two generations in a row)
                /*if(_Parameters.SortBasis == SortType.Raw)
                {
                    conv = Math.Abs((_currentPopulation.BestBasket().Premium / _previousPopulation.BestBasket().Premium) - 1.0);
                }
                else
                {
                    conv = Math.Abs((_currentPopulation.BestBasket().Fitness / _previousPopulation.BestBasket().Fitness) - 1.0);
                }
               
                if(conv < _Parameters.ConvergencePercentage)
                {
                    return true;
                }
                */
                return false;
            }

            /// <summary>
            /// Statistics (updated at every iteration)
            /// </summary>
            public class GAstats
            {
                public GAstats()
                {
                    _generationCount = 0;
                    _nCrossovers = 0;
                    _nMutations = 0;
                    _generationOfBestBasket = 0;
                    _BestBasketEver = _currentPopulation.BestBasket;
                    _WorstBasketEver = _currentPopulation.WorstBasket;
                    PremiaHistory = new Dictionary<int, double>();
                    PremiaHistory.Add(0, _currentPopulation.BestBasket.Premium);
                }

                public void RefreshStats()
                {
                    _generationCount++;
                    if (_currentPopulation.BestBasket.IsBetterThan(_BestBasketEver, _Parameters))
                    {
                        _BestBasketEver = _currentPopulation.BestBasket;
                        _generationOfBestBasket = _generationCount;
                    }

                    if (_currentPopulation.WorstBasket.IsWorseThan(_WorstBasketEver, _Parameters))
                    {
                        _WorstBasketEver = _currentPopulation.WorstBasket;
                    }
                    
                    PremiaHistory.Add(_generationCount, _BestBasketEver.Premium);
                }
                public void IncrementCrossovers()
                {
                    _nCrossovers++;
                }

                #region Private

                private Structures.BasketOfUnderlyings _BestBasketEver;
                private Structures.BasketOfUnderlyings _WorstBasketEver;
                private int _generationCount;
                private int _generationOfBestBasket;
                private int _nCrossovers;
                private int _nMutations;

                #endregion

                #region Public
                public Structures.BasketOfUnderlyings BestBasketEver
                {
                    get { return _BestBasketEver; }
                    set { _BestBasketEver = value; }
                }
                public Structures.BasketOfUnderlyings WorstBasketEver
                {
                    get { return _WorstBasketEver; }
                    set { _WorstBasketEver = value; }
                }
                public int GenerationsCounter
                {
                    get { return _generationCount; }
                }
                public int NumberOfCrossovers
                {
                    get { return _nCrossovers; }
                    set { _nCrossovers = value; }
                }
                public int NumberOfMutations
                {
                    get { return _nMutations; }
                    set { _nMutations = value; }
                }

                public int BestBasketGeneration { get { return _generationOfBestBasket; } }
                public Dictionary<int, double> PremiaHistory;
                #endregion
            }
            
            #region Private 
                       
            private bool _isConverged;
            private bool _algoCancelled;
            private string _errorMessage;
            private bool _repriceFinalPopulation;
            private static Structures.PopulationOfBaskets _currentPopulation;
            private static Structures.PopulationOfBaskets _previousPopulation;
            private SelectionMethodDelegate _SelectionMethod;
            private ReinsertionMethodDelegate _ReinsertionMethod;
            private CrossoverMethodDelegate _CrossOverMethod;
            private FitnessFunctionDelegate _FitnessFunction;
            private static GAparameters _Parameters;
            private GAstats _AlgoStats;
            private Structures.PricingSettingsForBasket _PricingSettingsFinalIteration;

            #endregion

            #region Public

            public GAstats AlgorithmStatistics{ get{ return _AlgoStats; } }
            public Structures.PopulationOfBaskets CurrentPopulation { get { { return _currentPopulation; } } }
            public string ErrorMessage { get { return _errorMessage; } set { _errorMessage = value; } }
            public bool AlgorithmWasCancelled { get { return _algoCancelled; } }
            
            #endregion
        }
        
        public class GAparameters
        {            
            public GAparameters(OptimizationGoal OptimGoal, SortType SortBasis, int numbGenerations, int populationSize, int basketSize,
                                double probabilityCrossover, double probabilityMutation, double probabilityTournamentWin,
                                double replacementPercentage, Random RandomGen)
            {
                _nGenerations = numbGenerations;
                _popSize = populationSize;
                _basketSize = basketSize;
                _pCrossover = probabilityCrossover;
                _pMutation = probabilityMutation;
                _pMutation = probabilityMutation;
                _pWinTournament = probabilityTournamentWin;
                _replacementPercent = replacementPercentage;
                _nReplacement = (int) Math.Ceiling(_replacementPercent * _popSize);
                _OptimGoal = OptimGoal;
                _SortBasis = SortBasis;
                Random = RandomGen;

            }
            #region  Private

            private OptimizationGoal _OptimGoal;
            private SortType _SortBasis;
            private int _nGenerations;
            private int _popSize;
            private int _basketSize;
            private int _nReplacement;
            private double _pCrossover;
            private double _pMutation;
            private double _pWinTournament;
            private double _replacementPercent;
            
            #endregion

            #region  Public
            public OptimizationGoal OptimizationGoal { get { return _OptimGoal; } }
            public SortType SortBasis { get { return _SortBasis; } }
            public int nGenerations { get { return _nGenerations; } }
            public int nReplacement { get { return _nReplacement; } }
            public int PopulationSize { get { return _popSize; } }
            public int BasketSize { get { return _basketSize; } }
            public double CrossoverProbability { get { return _pCrossover; } }
            public double MutationProbability { get { return _pMutation; } }
            public double TournamentWinProbability { get { return _pWinTournament; } }
            public double ReplacementPercentage { get { return _replacementPercent; } }

            public Random Random;

            #endregion

        }

        #region Selection methods


        /// <summary>
        /// Roulette selection (by fitness) that returns a list of baskets
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static List<Structures.BasketOfUnderlyings> RouletteSelectionByFitness(Structures.PopulationOfBaskets Population, Random Random,
                                                                                      GAparameters Parameters)
        {
            // The number of parents to select(always pair for crossover)
            int nToSelect = Population.Size % 2 == 0 ? Population.Size : Population.Size + 1;
            List<Structures.BasketOfUnderlyings> ParentsSelected = new List<Structures.BasketOfUnderlyings>();
            Structures.BasketOfUnderlyings BasketSelected;
            do
            {
                BasketSelected = SingleRouletteSelectionByFitness(Population, Random, Parameters);
                ParentsSelected.Add(BasketSelected);
            } while (ParentsSelected.Count < nToSelect);
            return ParentsSelected;
    }


        /// <summary>
        /// Roulette selection (by rank) that returns a list of baskets
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static List<Structures.BasketOfUnderlyings> RouletteSelectionByRank(Structures.PopulationOfBaskets Population, Random Random,
                                                                                   GAparameters Parameters)
        {
            // The number of parents to select(always pair for crossover)
            int nToSelect = Population.Size % 2 == 0 ? Population.Size : Population.Size + 1;
            List<Structures.BasketOfUnderlyings> ParentsSelected = new List<Structures.BasketOfUnderlyings>();
            Structures.BasketOfUnderlyings BasketSelected;
            do
            {
                BasketSelected = SingleRouletteSelectionByRank(Population, Random, Parameters);
                ParentsSelected.Add(BasketSelected);
            } while (ParentsSelected.Count < nToSelect);
            return ParentsSelected;
        }


        /// <summary>
        /// Selection by tournament that returns a list of baskets
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static List<Structures.BasketOfUnderlyings> SelectionByTournament(Structures.PopulationOfBaskets Population, Random Random,
                                                                                 GAparameters Parameters)
        {
            // The number of parents to select(always pair for crossover)
            int nToSelect = Population.Size % 2 == 0 ? Population.Size : Population.Size + 1;
            List<Structures.BasketOfUnderlyings> ParentsSelected = new List<Structures.BasketOfUnderlyings>();
            Structures.BasketOfUnderlyings BasketSelected;
            do
            {
                BasketSelected = SingleTournamentSelection(Population, Random, Parameters);
                ParentsSelected.Add(BasketSelected);
            } while (ParentsSelected.Count < nToSelect);
            return ParentsSelected;
        }

        /// <summary>
        /// Selection by elitism (take the best)
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static List<Structures.BasketOfUnderlyings> Elitism(Structures.PopulationOfBaskets Population, Random Random, GAparameters Parameters)
        {
            List<Structures.BasketOfUnderlyings> BasketsList = new List<Structures.BasketOfUnderlyings>();
            Population.SortPopulation();
            int nToSelect = Population.Size % 2 == 0 ? Population.Size : Population.Size + 1;

            for (int i = 0; i < nToSelect; i++)
            {
                BasketsList.Add(Population.BasketsList[i].Copy());
            }
            return BasketsList;
        }


        /// <summary>
        /// Roulette selection of a basket with probability related to its fitness (higher fitness = higher probability of being selected)
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static Structures.BasketOfUnderlyings SingleRouletteSelectionByFitness(Structures.PopulationOfBaskets Population, Random Random,
                                                                                      GAparameters Parameters)
        {
            Structures.BasketOfUnderlyings SelectedBasket;
            Population.SortPopulation();
            double sumAllPremia = 0;
            foreach (Structures.BasketOfUnderlyings Basket in Population.BasketsList)
            {
                sumAllPremia += Basket.Fitness;
            }
            // A random number in [ 0  , sumAllPremia ]
            double r = 0 + sumAllPremia * Random.NextDouble();
            double sumPrices = 0;
            int k = 0;

            // Add the prices until we reach r
            do
            {
                sumPrices += Population.BasketsList[k].Fitness;
                k++;
            } while (sumPrices < r);
            SelectedBasket = Population.BasketsList[k - 1].Copy();
            return SelectedBasket;
        }
        
        /// <summary>
        /// Roulette selection of a basket with probability related to its rank within the population (higher rank = higher probability of being selected)
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static Structures.BasketOfUnderlyings SingleRouletteSelectionByRank(Structures.PopulationOfBaskets Population, Random Random,
                                                                                   GAparameters Parameters)
        {
            Structures.BasketOfUnderlyings SelectedBasket;
            Population.SortPopulation(); 
            int r = Random.Next(0, Population.BasketsList.Count);
            double sumRanks = 0;
            int k = 0;
            do
            {
                sumRanks += Population.Size - Population.BasketsList[k].Rank - 1; // rank is base 0
            } while (sumRanks < r);

            SelectedBasket = Population.BasketsList[k].Copy();
            return SelectedBasket;
        }

        /// <summary>
        /// Tournament Selection of a basket
        /// </summary>
        /// <param name="Population"></param>
        /// <param name="Random"></param>
        /// <param name="Parameters"></param>
        /// <returns></returns>
        public static Structures.BasketOfUnderlyings SingleTournamentSelection(Structures.PopulationOfBaskets Population, Random Random,
                                                                               GAparameters Parameters)
        {
            Structures.BasketOfUnderlyings SelectedBasket;
            // We randomly select the i-th and j-th basket of the population. i will be the better basket, swap the index if needed
            int i = Random.Next(0, Population.BasketsList.Count);
            int j = Random.Next(0, Population.BasketsList.Count);

            if (Population.BasketsList[j].IsBetterThan(Population.BasketsList[i], Parameters))
            {
                i = i + j;
                j = i - j;
                i = i - j;
            }
            // Generate a number ~ U(0,1). The best basket is selected witht that probability 
            double proba = Random.NextDouble();
            if (proba <= Parameters.TournamentWinProbability)
            {
                SelectedBasket = Population.BasketsList[i].Copy();
            }
            else
            {
                SelectedBasket = Population.BasketsList[j].Copy();
            }
            return SelectedBasket;
        }

        

        #endregion

        #region Crossover methods
        public static void CrossoverSinglePointProbable(Structures.BasketOfUnderlyings Basket1, 
                                                        Structures.BasketOfUnderlyings Basket2, 
                                                        GAparameters AlgorithmParameters, GeneticAlgorithm.GAstats Statistics)
        {
            double p = AlgorithmParameters.Random.NextDouble();
            if(p <= AlgorithmParameters.CrossoverProbability)
            {
                int crossoverIndex = AlgorithmParameters.Random.Next(0, Basket1.Size - 1);
                CrossoverAfterIndexWithDuplicateCheck(Basket1, Basket2, crossoverIndex);

                Statistics.IncrementCrossovers();
            }
        }

        public static void CrossoverSinglePointCertain(Structures.BasketOfUnderlyings Basket1,
                                                       Structures.BasketOfUnderlyings Basket2,
                                                       GAparameters AlgorithmParameters, GeneticAlgorithm.GAstats Statistics)
        {
            int crossoverIndex = AlgorithmParameters.Random.Next(0, Basket1.Size - 1);
            CrossoverAfterIndexWithDuplicateCheck(Basket1, Basket2, crossoverIndex);
            Basket1.isEvaluated = false;
            Basket2.isEvaluated = false;
            Statistics.IncrementCrossovers();
        }
        #endregion

        #region Reinsertion methods
        public static void Eugenics( Structures.PopulationOfBaskets oldPopulation, Structures.PopulationOfBaskets ChildrenToInsert,
                                    GAparameters Parameters)
        {
            Structures.BasketOfUnderlyings tempBasket;
            oldPopulation.SortPopulation();
            ChildrenToInsert.SortPopulation();

            for (int i = 0; i < Parameters.nReplacement; i++)
            {
                if (oldPopulation.BasketsList[Parameters.PopulationSize - i -1].IsWorseThan(ChildrenToInsert.BasketsList[i],Parameters))
                {
                    tempBasket = ChildrenToInsert.BasketsList[i].Copy();
                    if (oldPopulation.DoesNotContainsBasket(tempBasket))
                    {
                        oldPopulation.BasketsList[Parameters.PopulationSize - i -1 ] = tempBasket;
                    }
                }
            }
            oldPopulation.SortPopulation();

        }

        public static void GenerationalReplacement(Structures.PopulationOfBaskets oldPopulation, Structures.PopulationOfBaskets ChildrenToInsert,
                                                   GAparameters Parameters)
        {
            Structures.BasketOfUnderlyings tempBasket;
            oldPopulation.SortPopulation();
            ChildrenToInsert.SortPopulation();

            for (int i = 0; i < Parameters.nReplacement; i++)
            {
                tempBasket = ChildrenToInsert.BasketsList[i].Copy();
                if (oldPopulation.DoesNotContainsBasket(tempBasket))
                {
                    oldPopulation.BasketsList[Parameters.PopulationSize - i - 1] = ChildrenToInsert.BasketsList[i].Copy(); 
                } 
            }
            oldPopulation.SortPopulation();

        }

        #endregion

        #region Fitness
        public static double FitnessIsPremium(Structures.BasketOfUnderlyings Basket, Structures.PopulationOfBaskets Population)
        {
            return Basket.Premium;
        }

        public static double FitnessForMinimization(Structures.BasketOfUnderlyings Basket, Structures.PopulationOfBaskets Population)
        {
            return 1.0 / (100 + Basket.Premium);
        }
        #endregion

        #region Methods for Basket Objects

        /// <summary>
        /// Swap two underlyings at a given index
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        public static void Swap(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {
            Basket1.Replace(index, Basket1.UnderlyingsDictionary[Basket1.UnderlyingsTickers[index]].Copy());
            Basket2.Replace(index, Basket2.UnderlyingsDictionary[Basket2.UnderlyingsTickers[index]].Copy());
        }

        /// <summary>
        /// Crossover of two parents after index (no check for duplicates)
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        public static void CrossoverAfterIndex(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {
            // Save the underlyings to swap
            for (int i = index; i < Basket1.Size; i++)
            {
                Swap(Basket1, Basket2, i);
            }
            Basket1.RefreshTickers();
            Basket2.RefreshTickers();
        }

        /// <summary>
        /// Crossover of two parents before index (no check for duplicates)
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        public static void CrossoverBeforeIndex(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {
            // Save the underlyings to swap
            for (int i = 0; i < index; i++)
            {
                Swap(Basket1, Basket2, i);
            }
            Basket1.RefreshTickers();
            Basket2.RefreshTickers();
        }

        /// <summary>
        /// Crossover of two parents after index (Check for duplicates)
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        public static void CrossoverAfterIndexWithDuplicateCheck(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {

            // Save the underlyings to swap
            for (int i = index; i < Basket1.Size; i++)
            {
                if (Basket1.UnderlyingsDictionary != null)
                {
                    if (Basket1.UnderlyingsDictionary.ContainsKey(Basket1.UnderlyingsTickers[i]) &&
                        Basket2.UnderlyingsDictionary.ContainsKey(Basket2.UnderlyingsTickers[i]))
                    {
                        Basket1.ReplaceWithCheckForDuplicate(Basket1.UnderlyingsDictionary[Basket1.UnderlyingsTickers[i]],Basket2.UnderlyingsDictionary[Basket2.UnderlyingsTickers[i]].Copy());
                        Basket2.ReplaceWithCheckForDuplicate(Basket2.UnderlyingsDictionary[Basket2.UnderlyingsTickers[i]],Basket1.UnderlyingsDictionary[Basket1.UnderlyingsTickers[i]].Copy());
                    }
                }
            }
            Basket1.RefreshTickers();
            Basket2.RefreshTickers();
        }

        /// <summary>
        /// Crossover of two parents before index (Check for duplicates)
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        public static void CrossoverBeforeIndexWithDuplicateCheck(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {

            // Save the underlyings to swap
            for (int i = 0; i < index; i++)
            {
                Basket1.ReplaceWithCheckForDuplicate(Basket1.UnderlyingsDictionary[Basket1.UnderlyingsTickers[i]], Basket2.UnderlyingsDictionary[Basket2.UnderlyingsTickers[i]]);
                Basket2.ReplaceWithCheckForDuplicate(Basket2.UnderlyingsDictionary[Basket2.UnderlyingsTickers[i]], Basket1.UnderlyingsDictionary[Basket1.UnderlyingsTickers[i]]);
            }
            Basket1.RefreshTickers();
            Basket2.RefreshTickers();
        }

        /// <summary>
        /// Count how many underlyings baskets have in common
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static int CountUnderlyingsInCommon(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {
            int count = 0;
            List<Structures.Underlying> tempUnderlyingsList = Basket2.UnderlyingsDictionary.Values.ToList();
            for (int i = 0; i < tempUnderlyingsList.Count; i++)
            {
                if (Basket1.ContainsUnderlying(tempUnderlyingsList[i]))
                {
                    count++;
                }
            }
            return count;
        }

        /// <summary>
        /// Returns the percentage of underlyings two baskets have in common
        /// </summary>
        /// <param name="Basket1"></param>
        /// <param name="Basket2"></param>
        /// <param name="index"></param>
        /// <returns></returns>
        public static double PercentageOfUnderlyingsInCommon(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Basket2, int index)
        {
            double count = 0;
            List<Structures.Underlying> tempUnderlyingsList = Basket2.UnderlyingsDictionary.Values.ToList();
            for (int i = 0; i < tempUnderlyingsList.Count; i++)
            {
                if (Basket1.ContainsUnderlying(tempUnderlyingsList[i]))
                {
                    count++;
                }
            }
            return count / Basket1.Size;
        }

        #endregion


    }

    #region Enum

    public enum OptimizationGoal
    {
        Maximize = 0,
        Minimize = 1,
    }

    public enum SelectionType
    {
        RouletteByFitness = 0,
        RouletteByRank = 1,
        Tournament = 2,
        Eugenics = 1,
    }

    public enum SortType
    {
        Raw = 0,
        Scaled = 1,
    }

    #endregion


    #region Delegates

    public delegate double FitnessFunctionDelegate(Structures.BasketOfUnderlyings Basket, Structures.PopulationOfBaskets Population);

    public delegate List<Structures.BasketOfUnderlyings> SelectionMethodDelegate (Structures.PopulationOfBaskets Population, Random rnd, GeneticLibrary.GAparameters Parameters);

    public delegate Structures.BasketOfUnderlyings SelectionDelegate(Structures.PopulationOfBaskets Population, Random rnd, 
                                                                     GeneticLibrary.GAparameters Parameters);

    public delegate void CrossoverMethodDelegate(Structures.BasketOfUnderlyings Basket1, Structures.BasketOfUnderlyings Population, 
                                                 GeneticLibrary.GAparameters AlgorithmParameters, GeneticLibrary.GeneticAlgorithm.GAstats Statistics);
    
    public delegate void ReinsertionMethodDelegate(Structures.PopulationOfBaskets CurrentPopulation, Structures.PopulationOfBaskets NewPopulation, 
                                                   GeneticLibrary.GAparameters Parameters );

    #endregion

}





