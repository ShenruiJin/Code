﻿using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace BBClient
{
    public struct IntDoublePoint
    {
        public int Int;
        public double Double;
    }
    public struct IntStringPoint
    {
        public int Int;
        public string String;
    }

}
