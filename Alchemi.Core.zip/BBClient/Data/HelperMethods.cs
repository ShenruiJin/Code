﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using GlobalDerivativesApplications.Pricer;
using System.Reflection;
using System.Security.Cryptography;
using CaesarApplication.Service.Strategy;
using FuncFramework.Configuration;
using Pricing.Engine;
using MarketDataMgr.Trees;
using PricingBase.Product;
using FuncFramework.Business;
using DealServerInterface;
using System.Threading;
using BbgProcesser;
using Estimators;
using FuncFramework.SimulationFactory;
using GlobalDerivativesApplications.Data.MarketData;
using Correlations = GlobalDerivativesApplications.Data.MarketData.Correlations;

namespace BBClient.Data
{
    public static class HelperMethods
    {
        /// <summary>
        /// Pricing Method for Genetic Algorithm
        /// </summary>
        /// <param name="product"></param>
        /// <param name="myBasket"></param>
        /// <param name="nbSimulations"></param>
        /// <param name="stockModel"></param>
        /// <param name="RateModel"></param>
        /// <returns></returns>
        public static IResult PriceBasketOfUnderlyings(StrategyDataSetElement product, Structures.BasketOfUnderlyings myBasket, int nbSimulations, StockModelType stockModel, RateModelType RateModel)
        {
            PricingBase.Product.CsInfoContainer.Basket b = new PricingBase.Product.CsInfoContainer.Basket();
            List<Structures.Underlying> Underlyings = myBasket.UnderlyingsDictionary.Values.ToList();
            b.Resize(myBasket.Size);
            // Add underlyings to the basket
            for (int i = 0; i < myBasket.Size; i++)
            {
                b.ModelName[i] = Underlyings[i].Ticker;
                b.Weight[Underlyings[i].Ticker] = myBasket.Weight;
                //((FuncFramework.Business.Product.StandardProduct.GenericProduct)bp).MarketDataTree.OriginalTree.Tree.AddSubTree("marketData" + MarketDataTree.PathDelimiter + "underlying", b.ModelName[i]);
            }

            var dw = product.Product.GetWrapperInField("basket__underlying") as ScriptTools.Utils.BasketDataWrapper;
            var mat =
                (product.Product.GetWrapperInField("_referenceDate") as ScriptTools.Utils.DateTimeDataWrapper).Data +
                (product.Product.GetWrapperInField("_maturityDate") as ScriptTools.Utils.TimeSpanDataWrapper).Data;
            if (dw != null)
            {
                dw.Data = b;
            }
            //MonteCarloConfiguration lConfig = new MonteCarloConfiguration(nbSimulations, 1.0 / 10.0, stockModel, RateModel, RateVolType.DefaultCaesar);
            MonteCarloConfiguration lConfig = new MonteCarloConfiguration(99999, nbSimulations,1.0 /10.0, stockModel, RateModel,new LSMConfiguration(), RateVolType.DefaultCaesar);
            product.Configuration = lConfig;
            //Structures.PricingSettingsForBasket _PricingSettings = new Structures.PricingSettingsForBasket(1000, StockModelType.BlackScholes, RateModelType.Deterministic);

            double[,] correlMatrix = RetrieveCorrels(myBasket.UnderlyingsTickers, myBasket.BaseCurrency);
            if (mat != null)
                UpdateCorrelationMatrix(myBasket.UnderlyingsTickers,product.MarketDataTree, correlMatrix, mat);
            Exception error;
            IResult outputresult = null;
            EventWaitHandle ewh = new EventWaitHandle(false, EventResetMode.ManualReset);
            PricingService.Price(product, PolicyType.LocalPricing, out error, (sds, msg, result) =>
            {
                outputresult = result;
                ewh.Set();
            });

            //// le moteur de calcul
            //IEngine lEngine = lConfig.GetEngine(((FuncFramework.Business.Product.StandardProduct.GenericProduct)BaseProd).MarketDataTree, null);
            //// on price
            //lEngine.Product = BaseProd;
            //lEngine.Initialize();
            //lEngine.Precompute();
            //lEngine.Compute();
            //lEngine.Postcompute();
            //lEngine = null;

            ewh.WaitOne();
            return outputresult;

        }

        public static void UnsafeSetValue(object target, string fieldName, object value)
        {
            Type ty = target.GetType();
            FieldInfo fi = null;

            while (fi == null && ty != null)
            {
                fi = ty.GetField(fieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                ty = ty.BaseType;
            }
            fi.SetValue(target, value);
        }



        /// <summary>
        /// Make a List of BasketOfUnderlyingsObjects
        /// </summary>
        /// <param name="TickersList"></param>
        /// <param name="tenor"></param> 
        /// <param name="strike"></param>
        /// <param name="currency"></param>
        /// <param name="BloombergData"></param>
        /// <returns></returns>
        public static List<Structures.Underlying> MakeUnderlyingList(List<string> TickersList, double tenor, double strike, 
                                                                     string currency, Structures.BbgData BloombergData)
        {
            List<Structures.Underlying> underlyingsList = new List<Structures.Underlying>();
            double liquid;
            string stockCcy;
            foreach (string ticker in TickersList)
            {

                if(BloombergData.DataLiquidities.TryGetValue(ticker, out liquid)
                    && BloombergData.DataCurrencies.TryGetValue(ticker, out stockCcy))
                {
                    underlyingsList.Add(new Structures.Underlying(ticker, tenor, strike, currency, BloombergData));
                }
                
            }
            return underlyingsList;
        }

        /// <summary>
        /// Make a List of BasketOfUnderlyingsObjects (just using tickers)
        /// </summary>
        /// <param name="TickersList"></param>
        /// <param name="tenor"></param>
        /// <param name="strike"></param>
        /// <param name="currency"></param>
        /// <returns></returns>
        public static List<Structures.Underlying> MakeUnderlyingList(List<string> TickersList, double tenor, double strike,
                                                                     string currency)
        {
            List<Structures.Underlying> underlyingsList = new List<Structures.Underlying>();
            foreach (string ticker in TickersList)
            {
                underlyingsList.Add(new Structures.Underlying(ticker, tenor, strike, currency));
            }
            return underlyingsList;
        }


        /// <summary>
        /// Make a List of BasketOfUnderlyingsObjects (and retrieve data via Bloomberg Requests, used for filtering and stock selection)
        /// </summary>
        /// <param name="TickersList"></param>
        /// <param name="tenor"></param>
        /// <param name="strike"></param>
        /// <param name="currency"></param>
        /// <param name="FullNames"></param>
        /// <param name="Countries"></param>
        /// <param name="Currencies"></param>
        /// <param name="Ratings"></param>
        /// <param name="Liquidities"></param>
        /// <param name="SubSectors"></param>
        /// <returns></returns>
        public static List<Structures.Underlying> MakeUnderlyingListFromTickers(List<string> TickersList, double tenor, double strike, string currency,
                                                                                Dictionary<string, string> FullNames, Dictionary<string, string> Countries,
                                                                                Dictionary<string, string> Currencies, Dictionary<string, double> Ratings,
                                                                                Dictionary<string, double> Liquidities, Dictionary<string, string> SubSectors)
        {
            List<Structures.Underlying> underlyingsList = new List<Structures.Underlying>();
            string dummyStringName;
            string dummyStringCountry;
            string dummyStringCurrency;
            bool dummyBool;
            foreach (string ticker in TickersList)
            {
                dummyBool = FullNames.TryGetValue(ticker, out dummyStringName);
                dummyBool = Countries.TryGetValue(ticker, out dummyStringCountry);
                dummyBool = Currencies.TryGetValue(ticker, out dummyStringCurrency);

                // Add if there is Bloomberg info
                if (dummyStringName != null && dummyStringCountry != null && dummyStringCurrency != null)
                {
                    underlyingsList.Add(new Structures.Underlying(ticker, tenor, strike, currency, FullNames, Countries,
                                                                  Currencies, Ratings, Liquidities, SubSectors));
                }
            }
            return underlyingsList;
        }

        /// <summary>
        /// Remove underlyings with negative spots
        /// </summary>
        /// <param name="UnderlyingsListInput"></param>
        public static void CleanNegativeSpots(List<Structures.Underlying> UnderlyingsListInput)
        {
            UnderlyingsListInput.RemoveAll(ul => ul.Spot <= 0);
        }

        /// <summary>
        /// Remove underlyings with negative volatilities
        /// </summary>
        /// <param name="UnderlyingsListInput"></param>
        public static void CleanNegativeVols(List<Structures.Underlying> UnderlyingsListInput)
        {
            UnderlyingsListInput.RemoveAll(ul => ul.Volatility <= 0);
        }

        /// <summary>
        /// Check if the instruments exist on Bloomberg
        /// </summary>
        /// <param name="instrumentList"></param>
        /// <returns></returns>
        public static List<string> CheckInstrumentsOnBbg(List <MarketData.Instrument> instrumentList)
        {
           List<string> resultList = DataRetrieval.FilterBbgStocks(instrumentList);
           return resultList;
        }


        /// <summary>
        /// Find underlying corresponding to the ticker given and delete it from the underlying list
        /// </summary>
        /// <param name="underlyingToDelete"></param>
        /// <param name="underlyingList"></param>
        /// <returns></returns>
        public static List<Structures.Underlying> DeleteUnderlyingFromList(string underlyingToDelete, List<Structures.Underlying> underlyingList)
        {
            List<Structures.Underlying> ResultUnderlyingList = new List<Structures.Underlying>();
            foreach (Structures.Underlying underlying in underlyingList)
            {
                if(underlyingToDelete != underlying.Ticker)
                {
                    ResultUnderlyingList.Add(underlying);
                }
            }
            return ResultUnderlyingList;

        }


        /// <summary>
        /// Get the list of countries represented by these underlyings
        /// </summary>
        /// <param name="underlyingsList"></param>
        /// <returns></returns>
        public static List<string> GetCountriesList(List<Structures.Underlying> underlyingsList)
        {
            List<string>  countriesList = new List<string>();
            foreach (Structures.Underlying underlying in underlyingsList)
            {
                if(!countriesList.Contains(underlying.Country))
                {
                    countriesList.Add(underlying.Country);
                }             
            }
            return countriesList;
        }


        /// <summary>
        ///  Remove illiquid underlyings
        /// </summary>
        /// <param name="underlyList"></param>
        /// <param name="liquidityMin"></param>
        /// <returns></returns>
        public static List<Structures.Underlying> ApplyLiquidityFilter(List<Structures.Underlying> underlyList, double liquidityMin)
        {
            List<Structures.Underlying> underlyListResult = new List<Structures.Underlying>();
            foreach(Structures.Underlying underlying in underlyList)
            {
                if(underlying.Liquidity > liquidityMin)
                {
                    underlyListResult.Add(underlying);
                }
            }
            return underlyListResult;
        }


        /// <summary>
        /// Get a randomly generated population of Baskets from an underlying space
        /// </summary>
        /// <param name="UnderlyingsUniverse"></param>
        /// <param name="AlgorithmParameters"></param>
        /// <param name="PricingSettings"></param>
        /// <param name="FitnessFunction"></param>
        /// <returns></returns>
        public static Structures.PopulationOfBaskets GetInitialPopulation(Dictionary<string, Structures.Underlying> UnderlyingsUniverse, ref GeneticLibrary.GAparameters AlgorithmParameters,
                                                                          Structures.PricingSettingsForBasket PricingSettings, FitnessFunctionDelegate FitnessFunction)
        {
            int k;
            Structures.Underlying UnderlyingSelected;
            List<Structures.Underlying> UniverseList = UnderlyingsUniverse.Values.ToList();
            List<Structures.BasketOfUnderlyings> BasketsListForInitialPopulation = new List<Structures.BasketOfUnderlyings>();
            List<Structures.Underlying> UnderlyingsForBasket;
            List<string> tempBasketTickers;
            // Make the baskets but leave one for the underlyings not represented
            for (int i = 0; i < AlgorithmParameters.PopulationSize - 1 ; i++)
            {
                UnderlyingsForBasket = new List<Structures.Underlying>();
                tempBasketTickers = new List<string>();
                // Pick underlyings and add them if they are not represented
                do
                {
                    k = AlgorithmParameters.Random.Next(0, UnderlyingsUniverse.Count);
                    UnderlyingSelected = UniverseList[k].Copy();
                    tempBasketTickers = UnderlyingsForBasket.Select(ul => ul.Ticker).ToList();
                    if (tempBasketTickers.DoesNotContain(UnderlyingSelected.Ticker))
                    {
                        UnderlyingsForBasket.Add(UnderlyingSelected);
                    }
                } while (UnderlyingsForBasket.Count < AlgorithmParameters.BasketSize);

                BasketsListForInitialPopulation.Add(new Structures.BasketOfUnderlyings(UnderlyingsForBasket, PricingSettings));
            }

            // Get the underlyings not represented
            bool mustAdd = false;
            List<Structures.Underlying> UnderlyingsNotRepresented = new List<Structures.Underlying>();
            foreach (Structures.Underlying Underlying in UniverseList)
            {
                foreach (Structures.BasketOfUnderlyings Basket in BasketsListForInitialPopulation)
                {
                    if (Basket.DoesNotContainUnderlying(Underlying))
                    {
                        mustAdd = true;
                    }
                    else
                    {
                        mustAdd = false;
                        break;
                    }
                }
                if (mustAdd && UnderlyingsNotRepresented.DoesNotContain(Underlying))
                {
                    UnderlyingsNotRepresented.Add(Underlying);
                }
            }


               

            // Make the last basket
            // if all Baskets were represented then we make one more as before
            if (UnderlyingsNotRepresented.Count == 0)
            {
                UnderlyingsForBasket = new List<Structures.Underlying>();
                tempBasketTickers = new List<string>();
                // Pick underlyings and add them if they are not represented
                do
                {
                    k = AlgorithmParameters.Random.Next(0, UnderlyingsUniverse.Count);
                    UnderlyingSelected = UniverseList[k].Copy();
                    tempBasketTickers = UnderlyingsForBasket.Select(ul => ul.Ticker).ToList();
                    if (tempBasketTickers.DoesNotContain(UnderlyingSelected.Ticker))
                    {
                        UnderlyingsForBasket.Add(UnderlyingSelected);
                    }
                } while (UnderlyingsForBasket.Count < AlgorithmParameters.BasketSize);

                BasketsListForInitialPopulation.Add(new Structures.BasketOfUnderlyings(UnderlyingsForBasket, PricingSettings));
            }

            // Some underlyings were not represented
            else
            {
                UnderlyingsForBasket = new List<Structures.Underlying>();
                tempBasketTickers = new List<string>();
                // We have less underlyings not represented than the basket size: we put them all in and complete the basket randomly
                if (UnderlyingsNotRepresented.Count <= AlgorithmParameters.BasketSize)
                {
                    // Put them in
                    foreach (Structures.Underlying Underlying in UnderlyingsNotRepresented)
                    {
                        UnderlyingsForBasket.Add(Underlying);
                    }

                    // Complete randomly
                    while (UnderlyingsForBasket.Count < AlgorithmParameters.BasketSize)
                    {
                        k = AlgorithmParameters.Random.Next(0, UnderlyingsUniverse.Count);
                        UnderlyingSelected = UniverseList[k];
                        tempBasketTickers = UnderlyingsForBasket.Select(ul => ul.Ticker).ToList();
                        if (tempBasketTickers.DoesNotContain(UnderlyingSelected.Ticker))
                        {
                            UnderlyingsForBasket.Add(UnderlyingSelected);
                        }
                    }
                }

                // Many underlyings not represented
                else
                {
                    for (int j = 0; j < AlgorithmParameters.BasketSize; j++)
                    {
                        UnderlyingsForBasket.Add(UnderlyingsNotRepresented[j]);
                    }
                }
                BasketsListForInitialPopulation.Add(new Structures.BasketOfUnderlyings(UnderlyingsForBasket, PricingSettings));
            }


            Structures.PopulationOfBaskets resultPopulation = new Structures.PopulationOfBaskets(BasketsListForInitialPopulation, FitnessFunction,
                                                                                                 AlgorithmParameters.OptimizationGoal,
                                                                                                 AlgorithmParameters.SortBasis, AlgorithmParameters.Random);
            return resultPopulation;

        }

        /// <summary>
        /// Check if two lists of strings are equal
        /// </summary>
        /// <param name="List1"></param>
        /// <param name="List2"></param>
        /// <returns></returns>
        public static bool StringListsAreEqual (List<string> List1, List<string> List2)
        {
            if(List1.Count != List2.Count)
            {
                return false;
            }
            else
            {
                List1.Sort();
                List2.Sort();
                for(int i=0; i<List1.Count;i++)
                {
                    if(List1[i] != List2[i])
                    {
                        return false;                      
                    }
                }
                return true;
            }
        }

        private static double[,] RetrieveCorrels(List<string> underlyingList, string curreny)
        {
            double[,] correlationMatrix = new double[underlyingList.Count, underlyingList.Count];
            try
            {
                // For a 3Y horizon
                int horizon = 3;
                List<double> horizonList = new List<double>();
                horizonList.Add(horizon);
                // Retrieve vols and forwards
                CorrelFactory tempFactory = new CorrelFactory(underlyingList, curreny,
                    CalculationPeriod.Daily, horizonList, false);

                double[,] perfMatrix;
                Dictionary<double, CorrelationPack> correlationPackMap;
                Dictionary<double, double[]> liquidityMap;
                DataSet ds = tempFactory.StartCorrelComputations();
                tempFactory.EndCorrelComputation(ds, out perfMatrix, out correlationPackMap, out liquidityMap);

                correlationMatrix = correlationPackMap[horizon].CorrelationMatrix;
            }
            catch (Exception e)
            {
                System.Console.WriteLine(e.Message);
            }
            return correlationMatrix;
        }

        public static void SetCorrelationValue(string name1, string name2, double value, MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree)
        {
                MarketDataProperty property = new MarketDataProperty();
                ICorrelations correls = new Correlations(name1, name2, "1Y".Repeat(1), value.Repeat(1));
                property.Value = correls;

                tree.AddOverloadedProperty(MarketDataMgr.Trees.Ext.OverloadedMarketDataTree.CorrelationPath(name1, name2), property);
            
        }

        public static void UpdateCorrelationMatrix(List<string> underlyingsListInput, MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree, double[,] correlations,DateTime maturity)
        {

            MarketDataFactory marketDataFactory = new MarketDataFactory(tree);
            foreach (string s1 in underlyingsListInput)
            {
                foreach (string s2 in underlyingsListInput)
                {
                    if (marketDataFactory.Correlation(s1, s2,maturity)==0.0)
                        SetCorrelationValue(s1, s2, correlations[0, 0], tree);

                }

            }

        }


    }
}
