﻿using CaesarApplication.Service.Strategy;
using FuncFramework.Business;
using FuncFramework.Configuration;
using GlobalDerivativesApplications.Finance;
using Pricing.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using CaesarApplication.Service.Logging;
using FuncFramework.Business.RiskAnalysis;
using FuncFramework.Configuration.Bumper;
using GlobalDerivativesApplications.Data.MarketData;
using MarketDataMgr.Trees;

namespace BBClient.Data
{
    public class Structures
    {
        /// <summary>
        /// Class representing an underlying, containing relevant data (currency, spot, country, sector, volatility, forward)
        /// Used to make baskets of underlyings for the genetic algorithm
        /// </summary>

        public class Underlying
        {
            #region Constructors

            /// Constructor using dictionaries :
            /// Sets: ticker, maturity, strike, base currency(e.g. EUR for Natixis), full name of the stock, country, currencies, ratings,
            ///       liquidity, subsector
            public Underlying(string ticker, double maturity, double strike, string baseCurrency,
                              Dictionary<string, string> StocksDataFullNames, Dictionary<string, string> StocksDataCountries,
                              Dictionary<string, string> StocksDataCurrencies, Dictionary<string, double> StocksDataRatings,
                              Dictionary<string, double> StocksDataLiquidities, Dictionary<string, string> StocksDataSubSectors)
            {
                _ticker = ticker;
                _maturity = maturity;
                _strike = strike;
                _baseccy = baseCurrency;
                _spot = 0;
                _name = DataRetrieval.GetStockName(ticker, StocksDataFullNames);
                _country = DataRetrieval.GetStockCountry(ticker, StocksDataCountries);
                _ccy = DataRetrieval.GetStockCurrency(ticker, StocksDataCurrencies).ToUpper();
                _rating = DataRetrieval.GetStockAnalystRating(ticker, StocksDataRatings);
                _liquid = DataRetrieval.GetStockLiquidity(ticker, StocksDataLiquidities);
                _subSector = DataRetrieval.GetStockSubSector(ticker, StocksDataSubSectors);
                _nameIsLoaded = true;
                _countryIsLoaded = true;

                _volatilityIsLoaded = false;
                _forwardIsLoaded = false;

            }

            /// Constructor using only tickers
            public Underlying(string ticker, double maturity, double strike, string baseCurrency)
            {
                _ticker = ticker;
                _maturity = maturity;
                _strike = strike;
                _baseccy = baseCurrency;
                _volatilityIsLoaded = false;
                _forwardIsLoaded = false;
                _nameIsLoaded = false;
                _countryIsLoaded = false;
                _ccyIsLoaded = false;
                _ratingIsLoaded = false;
                _sectorIsLoaded = false;
                _liquidityIsLoaded = false;
                _fxIsLoaded = false;
            }

            /// Constructor from BbgData object
            /// Sets : ticker, maturity, strike, base currency, full name, country, currencym rating, subsector, liquidity
            public Underlying(string ticker, double maturity, double strike, string baseCurrency, BbgData BloombergData)
            {
                double fx;
                // Provided data
                _ticker = ticker;
                _maturity = maturity;
                _strike = strike;
                _baseccy = baseCurrency;
                _volatilityIsLoaded = false;
                _forwardIsLoaded = false;

                // Get the Bloomberg Data
                _nameIsLoaded = BloombergData.DataFullNames.TryGetValue(_ticker, out _name);
                _countryIsLoaded = BloombergData.DataCountries.TryGetValue(_ticker, out _country);
                _ccyIsLoaded = BloombergData.DataCurrencies.TryGetValue(_ticker, out _ccy);
                _ratingIsLoaded = BloombergData.DataRatings.TryGetValue(_ticker, out _rating);
                _sectorIsLoaded = BloombergData.DataSubSectors.TryGetValue(_ticker, out _subSector);
                _liquidityIsLoaded = BloombergData.DataLiquidities.TryGetValue(_ticker, out _liquid);
                _fxIsLoaded = BloombergData.DataFX.TryGetValue(_ccy, out fx);
                _liquid /= fx;
            }

            /// Copy Constructor
            /// Sets : 
            public Underlying(Underlying  UnderlyingInput)
            {
                _ticker = UnderlyingInput._ticker;
                _maturity = UnderlyingInput._maturity;
                _strike = UnderlyingInput._strike;
                _baseccy = UnderlyingInput._baseccy;
                _isDataOK = UnderlyingInput._isDataOK;
                _volatilityIsLoaded = UnderlyingInput._volatilityIsLoaded; 
                _forwardIsLoaded = UnderlyingInput._forwardIsLoaded; 
                _nameIsLoaded = UnderlyingInput._nameIsLoaded; 
                _spotIsLoaded = UnderlyingInput._spotIsLoaded;
                _countryIsLoaded = UnderlyingInput._countryIsLoaded;
                _sectorIsLoaded = UnderlyingInput._sectorIsLoaded;
                _ratingIsLoaded = UnderlyingInput._ratingIsLoaded;
                _ccyIsLoaded = UnderlyingInput._ccyIsLoaded;
                _liquidityIsLoaded = UnderlyingInput._liquidityIsLoaded;
                _fxIsLoaded = UnderlyingInput._fxIsLoaded; ;



                // Bloomberg Data
                _name = UnderlyingInput._name;
                _country = UnderlyingInput._country;
                _ccy = UnderlyingInput._ccy;
                _rating = UnderlyingInput._rating;
                _subSector = UnderlyingInput._subSector;
                _liquid = UnderlyingInput._liquid;

            }
            
            #endregion

            #region Methods

            private void GetLiquidity()
            {
                // Get the FX and convert
                double ForexFlash = MarketDataService.GetLiveSpot(ForexTools.CurrenciesToFX(_ccy, "EUR"));               
            }

            /// <summary>
            /// Get the spot price from the Sophis data object and use it to compute the liquidity level (volume traded * spot * fx)
            /// </summary>
            /// <param name="DataFromSophis"></param>
            public void GetSpot(SophisData DataFromSophis)
            {
                try
                {
                    _isDataOK = DataFromSophis.UnderlyingSpotsDictionary.TryGetValue(_ticker, out _spot);
                    _liquid *= _spot;
                }
                catch(Exception)
                {
                    _spot = 0;
                }
            }

            /// <summary>
            /// Get the volatility from the Sophis data object
            /// </summary>
            /// <param name="DataFromSophis"></param>
            public void GetVol(SophisData DataFromSophis)
            {
                _isDataOK = DataFromSophis.UnderlyingVolsDictionary.TryGetValue(_ticker, out _vol);
                _volatilityIsLoaded = _isDataOK ? true : false;
            }

            /// <summary>
            /// Get the skew from the Sophis data object
            /// </summary>
            /// <param name="DataFromSophis"></param>
            public void GetSkew(SophisData DataFromSophis)
            {
                _isDataOK = DataFromSophis.UnderlyingSkewsDictionary.TryGetValue(_ticker, out _skew);
            }

            /// <summary>
            /// Get the forward from the Sophis data object
            /// </summary>
            /// <param name="DataFromSophis"></param>
            public void GetForward(SophisData DataFromSophis)
            {
                _isDataOK = DataFromSophis.UnderlyingForwardsDictionary.TryGetValue(_ticker, out _forward);
                _forwardIsLoaded = _isDataOK ? true : false;
            }

            public Underlying Copy ()
            {
                return new Underlying(this);
            }

            #endregion

            #region Private members

            private double _maturity;
            private double _vol;
            private double _spot;
            private double _skew;
            private double _forward;
            private double _liquid;
            private double _strike;
            private double _rating;
            private string _ccy;
            private string _baseccy;
            private string _ticker;
            private string _name;
            private string _country;
            private string _subSector;
            private bool _isDataOK;
            private bool _volatilityIsLoaded;
            private bool _forwardIsLoaded;
            private bool _nameIsLoaded; 
            private bool _spotIsLoaded;
            private bool _countryIsLoaded;
            private bool _sectorIsLoaded;
            private bool _ratingIsLoaded;
            private bool _ccyIsLoaded;
            private bool _liquidityIsLoaded;
            private bool _fxIsLoaded;
            
            #endregion

            #region Public Accessors

            public double Maturity { get { return _maturity; } }
            public double Strike { get { return _strike; } }
            public double Volatility { get { return _vol; } }
            public double Spot { get { return _spot; } }
            public double Skew { get { return _skew; } }
            public double Forward { get { return _forward; } }
            public double Liquidity { get { return _liquid; } }
            public string Currency { get { return _ccy; } }
            public string Ticker { get { return _ticker; } }
            public string Name { get { return _name; } }
            public string Country { get { return _country; } }
            public double Rating { get { return _rating; } }
            public string SubSector { get { return _subSector; } }
            public string BaseCurrency { get { return _baseccy; } }
            public bool isDataOK { get { return _isDataOK; } }
            public bool VolatilityIsLoaded { get { return _volatilityIsLoaded; }  }
            public bool ForwardIsLoaded { get { return _forwardIsLoaded; } }
            public bool NameIsLoaded { get { return _nameIsLoaded; } }
            public bool CountryIsLoaded { get { return _countryIsLoaded; } }
            public bool SectorIsLoaded { get { return _sectorIsLoaded; } }
            public bool RatingIsLoaded { get { return _ratingIsLoaded; } }
            public bool CurrencyIsLoaded { get { return _ccyIsLoaded; } }
            public bool LiquidityIsLoaded { get { return _liquidityIsLoaded; } }
            public bool SpotIsLoaded { get { return _spotIsLoaded; } }
            public bool FXisLoaded { get { return _fxIsLoaded; } }
            #endregion

        }


        /// <summary>
        /// Make a copy of a list of underlyings (useful in BasketOfUnderlyings objects)
        /// </summary>
        /// <param name="UnderlyingsListToCopy"></param>
        /// <returns></returns>
        public static List<Underlying> CopyUnderlyingsList(List<Underlying> UnderlyingsListToCopy)
        {
            List<Underlying> UnderlyingsListResult = new List<Underlying>();
            foreach(Underlying Underlying in UnderlyingsListToCopy)
            {
                UnderlyingsListResult.Add(Underlying.Copy());
            }
            return UnderlyingsListResult;
        }

        /// <summary>
        /// Make a copy of a dictionary of underlyings (useful in BasketOfUnderlyings objects)
        /// </summary>
        /// <param name="UnderlyingsDictionaryToCopy"></param>
        /// <returns></returns>
        public static Dictionary<string, Underlying> CopyUnderlyingsDictionary(Dictionary<string, Underlying> UnderlyingsDictionaryToCopy)
        {
            List<Underlying> tempUnderlyingsList = CopyUnderlyingsList(UnderlyingsDictionaryToCopy.Values.ToList());
            Dictionary<string, Underlying> resultDictionary = new Dictionary<string, Underlying>();
            foreach( Underlying ul in tempUnderlyingsList)
            {
                resultDictionary.Add(ul.Ticker, ul.Copy());
            }
            return resultDictionary;
        }
        
        /// <summary>
        /// Bloomberg data class containing sector, full name, currency etc for underlyings
        /// </summary>
        public class BbgData
        {
            /// <summary>
            /// Constructor via Bloomberg queries
            /// </summary>
            /// <param name="underlyingsTickers"></param>
            public BbgData(List<string> underlyingsTickers)
            {
                DataFullNames = new Dictionary<string, string>();
                DataCountries = new Dictionary<string, string>();
                DataCurrencies = new Dictionary<string, string>();
                DataSubSectors = new Dictionary<string, string>();
                DataRatings = new Dictionary<string, double>();
                DataLiquidities = new Dictionary<string, double>();

                DataRetrieval.GetBloombergDataViaQueries(underlyingsTickers, ref DataFullNames, ref DataCurrencies, ref DataCountries, ref DataRatings, ref DataLiquidities, ref DataSubSectors);
            }

            /// <summary>
            /// Constructor via .csv files (containing data)
            /// </summary>
            /// <param name="underlyingsTickers"></param>
            /// <param name="FilePaths"></param>
            public BbgData(List<string> underlyingsTickers, Dictionary<string, string> FilePaths)
            {
                string path;
                // Dictionaries
                bool dummy = FilePaths.TryGetValue("Names", out path);
                DataFullNames = DataRetrieval.GetStocksDataFullName(path);
                dummy = FilePaths.TryGetValue("Countries", out path);
                DataCountries = DataRetrieval.GetStocksDataCountry(path);
                dummy = FilePaths.TryGetValue("Currencies", out path);
                DataCurrencies = DataRetrieval.GetStocksDataCurrency(path);
                dummy = FilePaths.TryGetValue("SubSectors", out path);
                DataSubSectors = DataRetrieval.GetStocksDataSubSectors(path);
                dummy = FilePaths.TryGetValue("Ratings", out path);
                DataRatings = DataRetrieval.GetStocksDataRating(path);
                dummy = FilePaths.TryGetValue("Liquidities", out path);
                DataLiquidities = DataRetrieval.GetStocksDataLiquidity(path);
            }
            
            public Dictionary<string, string> DataFullNames;
            public Dictionary<string, string> DataCountries;
            public Dictionary<string, string> DataCurrencies;
            public Dictionary<string, string> DataSubSectors;
            public Dictionary<string, double> DataRatings;
            public Dictionary<string, double> DataLiquidities;
            public Dictionary<string, double> DataFX;

        }


        /// <summary>
        /// Sophis Data object containing vol, forward, spot for underlyings
        /// </summary>
        public class SophisData
        {
            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="underlyingsTickers"></param>
            /// <param name="currency"></param>
            /// <param name="maturity"></param>
            /// <param name="strike"></param>
            public SophisData(List<string> underlyingsTickers, string currency, double maturity, double strike)
            {
                // First take all given tickers as good.
                _OKtickers = underlyingsTickers;
                _ccy = currency;
                _maturity = maturity;
                _strike = strike;
            }

            /// <summary>
            /// Method to load spots
            /// </summary>
            /// <param name="backgroundworker"></param>
            /// <param name="e"></param>
            public void LoadSpots(BackgroundWorker backgroundworker, DoWorkEventArgs e)
            {
                // Load spots 100 at a time
                List<string>  tempTickers = new List<string>();
                Dictionary<string, double> tempSpotsDictionary;
                double prog = 0.0;
                int progress = 0;
                _UnderlyingSpotsDictionary = new Dictionary<string, double>();
                int counter = 0;
                for (int i= 0; i<_OKtickers.Count; i++)
                {
                    
                    // Under 200, keep adding
                    if (counter < 200)
                    {
                        tempTickers.Add(_OKtickers[i]);
                        counter++;
                    }
                    // Over 200, time to load !!
                    else
                    {
                        tempSpotsDictionary = new Dictionary<string, double>();
                        // Load and add them
                        try
                        {
                            if (backgroundworker.CancellationPending == true)
                            {
                                e.Cancel = true;
                                return;
                            }

                            tempSpotsDictionary = DataRetrieval.GetSpotsDictionary(tempTickers);
                            foreach(KeyValuePair<string, double> Pair in tempSpotsDictionary)
                            {
                                _UnderlyingSpotsDictionary.Add(Pair.Key, Pair.Value);
                            }
                            prog = (double)_UnderlyingSpotsDictionary.Count / _OKtickers.Count * 100;
                            progress = (int) Math.Round(prog);
                            backgroundworker.ReportProgress(progress);
                        }
                        catch(Exception)
                        {
                            counter = 0;
                            continue;
                        }
                        // Re-initialize
                        tempTickers = new List<string>();
                        tempSpotsDictionary = new Dictionary<string, double>();
                        counter = 0;
                    }
                    
                }
            }

            /// <summary>
            /// method to load vols and skews
            /// </summary>
            public void LoadVolsSkews()
            {
                try
                {
                    // Get the vol and skew
                    _UnderlyingVolsDictionary = DataRetrieval.GetVolSkew(_OKtickers, _ccy, _maturity, _strike, out _UnderlyingSkewsDictionary);
                    // Update the tickers
                    //m_OKtickers = m_UnderlyingSpotsDictionary.Keys.ToList();
                }
                catch(Exception)
                {

                }
            }

            /// <summary>
            /// Method to load forwards
            /// </summary>
            public void LoadFwds()
            {
                try
                {
                    // Get the fwd
                    _UnderlyingForwardsDictionary = DataRetrieval.GetForward(_OKtickers, _ccy, _maturity);
                    // Update the tickers
                    _OKtickers = _UnderlyingSpotsDictionary.Keys.ToList();
                }
                catch
                {

                }
            }
            
            // Private members
            private Dictionary<string, double> _UnderlyingSpotsDictionary;
            private Dictionary<string, double> _UnderlyingVolsDictionary;
            private Dictionary<string, double> _UnderlyingSkewsDictionary;
            private Dictionary<string, double> _UnderlyingForwardsDictionary;
            private string _ccy;
            private double _maturity;
            private double _strike;
            private List<string> _OKtickers;
            
            // Public accessors
            public Dictionary<string, double> UnderlyingSpotsDictionary { get { return _UnderlyingSpotsDictionary; } }
            public Dictionary<string, double> UnderlyingVolsDictionary { get { return _UnderlyingVolsDictionary; } }
            public Dictionary<string, double> UnderlyingSkewsDictionary { get { return _UnderlyingSkewsDictionary; } }
            public Dictionary<string, double> UnderlyingForwardsDictionary { get { return _UnderlyingForwardsDictionary; } }
        }


        /// <summary>
        /// Pricing Settings for the optimization
        /// </summary>
        public class PricingSettingsForBasket
        {
            public PricingSettingsForBasket(int nbSim, StockModelType StockModelInput, RateModelType RateModelInput)
            {
                _nbSimulations = nbSim;
                _StockModel = StockModelInput;
                _RateModel = RateModelInput;

            }

            public void UpdateSettings(PricingSettingsForBasket NewSettings)
            {
                _nbSimulations = NewSettings.NumberOfSimulations;
                _StockModel = NewSettings.StockModel;
                _RateModel = NewSettings.RateModel;
            }
            private int _nbSimulations;
            private StockModelType _StockModel;
            private RateModelType _RateModel;

            public int NumberOfSimulations { get { return _nbSimulations; } }
            public StockModelType StockModel { get { return _StockModel; } }
            public RateModelType RateModel { get { return _RateModel; } }

        }   
        

        /// <summary>
        ///  Class representing a basket of underlyings. Contains a list of underlyings, maturity and strike (needed for pricing) and can be priced using the Evaluae method
        /// </summary>
        public class BasketOfUnderlyings 
        {
            public BasketOfUnderlyings(List<Underlying> underlyingsList, PricingSettingsForBasket PricingSettings)
            {
                _strike = underlyingsList[0].Strike;
                _maturity = underlyingsList[0].Maturity;
                _baseccy = underlyingsList[0].BaseCurrency;
                _basketSize = underlyingsList.Count;
                _PricingSettings = PricingSettings;
                _rank = -1;

                weights = new List<double>();
                equiWeight = 1.0 / _basketSize;
                

                _UnderlyingsDictionary = new Dictionary<string, Underlying>();
                foreach (Underlying underlying in underlyingsList)
                {
                    _UnderlyingsDictionary.Add(underlying.Ticker, underlying.Copy());
                    weights.Add(equiWeight);
                }
                _UnderlyingsList = _UnderlyingsDictionary.Values.ToList();
                RefreshTickers();

                _isEvaluated =  false;
                               
            }

            public BasketOfUnderlyings(BasketOfUnderlyings BasketInput)
            {
                _strike = BasketInput._strike;
                _maturity = BasketInput._maturity;
                _basketSize = BasketInput._basketSize;
                _PricingSettings = BasketInput._PricingSettings;
                _baseccy = BasketInput._baseccy;
                weights = BasketInput.weights;
                equiWeight = BasketInput.equiWeight;
                _rank = BasketInput._rank;

                _UnderlyingsDictionary = CopyUnderlyingsDictionary(BasketInput._UnderlyingsDictionary);
                _UnderlyingsTickers = BasketInput._UnderlyingsTickers;

                _pricingResult = BasketInput._pricingResult;
                _premium = BasketInput._premium;
                _fitness = BasketInput._fitness;
                _variance = BasketInput._variance;
                _isEvaluated = BasketInput._isEvaluated;
            }

            /// <summary>
            /// Returns a copy of the basket using the copy constructor
            /// </summary>
            /// <returns></returns>
            public BasketOfUnderlyings Copy()
            {
                return new BasketOfUnderlyings(this);
            }


            #region Computations

            /// <summary>
            /// Price the basket, get the premium, fitness (from premium, used in the genetic algorithm) and variance
            /// </summary>
            /// <param name="Product"></param>
            /// <param name="PricingSettings"></param>
            /// <param name="FitnessFunction"></param>
            /// <param name="Population"></param>
            public void Evaluate(StrategyDataSetElement Product, FitnessFunctionDelegate FitnessFunction, PopulationOfBaskets Population , BackgroundWorker backgroundworker, DoWorkEventArgs e, bool isFinalPopulation, double delta, double vega, double cega)
            {
                if(!_isEvaluated || isFinalPopulation)
                {
                    try
                    {
                        if (!backgroundworker.CancellationPending)
                        {
                            //LoggingService.Info(typeof(Structures),"[Basket Optimizer] - Start Pricing : " + this.UnderlyingsTickers[0] + " " + this.UnderlyingsTickers[1]);

                            if (isFinalPopulation)
                            {
                                _pricingResult = HelperMethods.PriceBasketOfUnderlyings(Product, this,_PricingSettings.NumberOfSimulations, _PricingSettings.StockModel,_PricingSettings.RateModel);
                                _premium = (double) _pricingResult[ResultString.Premium];
                                _variance = (double)_pricingResult[ResultString.Variance];
                            }
                            else
                            {
                                double sv = GetSyntheticVol(_UnderlyingsTickers, _strike,DateTime.Today.AddDays(_maturity));
                                LoggingService.Info(typeof(Structures), "[Basket Optimizer] - GetSyntheticVol : " + sv);


                                double vegaAndCorrel =  MarketDataService.GetSyntheticVolatility(_UnderlyingsTickers, Enumerable.Repeat(1.0/ _UnderlyingsTickers.Count, _UnderlyingsTickers.Count).ToList(), _strike, DateTime.Today.AddDays(_maturity));
                                LoggingService.Info(typeof(Structures), "[Basket Optimizer] - GetSyntheticVol And Correl  : " + vegaAndCorrel);

                                //_premium = vega * vegaAndCorrel;
                                _premium = vega * GetSyntheticVol(_UnderlyingsTickers, _strike, DateTime.Today.AddDays(_maturity)) / _UnderlyingsTickers.Count;
                                _premium += delta*GetSyntheticForward(_UnderlyingsTickers, DateTime.Today.AddDays(_maturity))/ _UnderlyingsTickers.Count;
                                 _premium += cega*GetSyntheticCorrel(_UnderlyingsTickers, DateTime.Today.AddDays(_maturity)) / _UnderlyingsTickers.Count;

                                _variance = 0.0;
                            }
                            _fitness = FitnessFunction(this, Population);
                            
                            _isEvaluated = true;
                            LoggingService.Info(typeof(Structures), "[Basket Optimizer] - Premium : " + _premium);
                        }
                        else
                        {
                            e.Cancel = true;
                        }
                       
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                        _premium = 0;
                        _fitness = 0;
                        _variance = 0;
                    }
                }                
            }

            public static double GetSyntheticVol(List<string> underlyingsTickers, double strike, DateTime maturity)
            {
                double syntheticvol = 0.0;
                foreach (string underlyingsTicker in underlyingsTickers)
                {
                    syntheticvol += MarketDataService.GetVolatilitySurface(underlyingsTicker).Volatility(strike * MarketDataService.GetSpot(underlyingsTicker), maturity);
                }
                return syntheticvol;
            }
            public static double GetSyntheticForward(List<string> underlyingsTickers, DateTime maturity)
            {
                double syntheticForward = 0.0;
                foreach (string underlyingsTicker in underlyingsTickers)
                {
                    syntheticForward+=MarketDataService.GetForwardCurve(underlyingsTicker).Forward(maturity)/MarketDataService.GetSpot(underlyingsTicker);
                }
                return syntheticForward;
            }
            public static double GetSyntheticCorrel(List<string> underlyingsTickers, DateTime maturity)
            {

                double[,]  correlMatrix = new double[underlyingsTickers.Count, underlyingsTickers.Count];
                for (int i = 0; i < underlyingsTickers.Count; i++)
                {
                    for (int j = 0; j < i; j++)
                    {
                        correlMatrix[i, j] = MarketDataService.GetCorrelation(underlyingsTickers[i], underlyingsTickers[j], maturity);
                        correlMatrix[j, i] = correlMatrix[i, j];
                    }
                    correlMatrix[i, i] = 1.0;
                }
                return MarketDataService.GetSyntheticCorrelation(underlyingsTickers, maturity, correlMatrix);
            }

            /// <summary>
            /// Compute basket characteristics (synthetic vol, correl etc)
            /// </summary>
            private void ComputeBasketParams()
            {
                //Refresh tickers and parameters
                _UnderlyingsTickers = UnderlyingsDictionary.Select(ul => ul.Value.Ticker).ToList();
                _basketSize = _UnderlyingsTickers.Count;
                equiWeight = 1.0 / _basketSize;
                weights = new List<double>();
                for(int i=0 ; i < _basketSize ; i++)
                {
                    weights.Add(equiWeight);
                }
                ComputeCorrelationMatrix();
                _correlSynthetic = ComputeSyntheticCorrelation();
                _correlAverage = ComputeAverageCorrelation();
                _volSynthetic = ComputeSyntheticVolatility();

            }

            /// <summary>
            /// Get correlation matrix
            /// </summary>
            private void ComputeCorrelationMatrix()
            {
                List<Underlying> tempUnderlyingsList = UnderlyingsDictionary.Values.ToList();
                RHO = new double[_basketSize, _basketSize];
                for (int i = 0; i < _basketSize; i++)
                {
                    for (int j = 0; j < i; j++)
                    {
                        RHO[i, j] = MarketDataService.GetCorrelation(tempUnderlyingsList[i].Ticker, tempUnderlyingsList[j].Ticker, _maturity);
                        RHO[j, i] = RHO[i, j];
                    }
                    RHO[i, i] = 1.0;
                }
            }

            /// <summary>
            /// Get the synthetic correlation of the basket
            /// </summary>
            /// <returns></returns>
            private double ComputeSyntheticCorrelation()
            {
                // Synthetic correlation
                // calcul de la correl moyenne
                double sigma = 0.0;
                double rhoSynthetic = 0.0;
                List<Underlying> tempUnderlyingsList = UnderlyingsDictionary.Values.ToList();
                for (int i = 0; i < tempUnderlyingsList.Count; i++)
                {
                    for (int j = 0; j < i; j++)
                    {
                        rhoSynthetic += RHO[i, j] * tempUnderlyingsList[i].Volatility * tempUnderlyingsList[j].Volatility;
                        sigma += tempUnderlyingsList[i].Volatility * tempUnderlyingsList[j].Volatility;
                    }
                }
                if (sigma != 0)
                {
                    rhoSynthetic /= sigma;
                }
                return rhoSynthetic;
            }

            /// <summary>
            /// Get the average correlation of the basket
            /// </summary>
            /// <returns></returns>
            private double  ComputeAverageCorrelation()
            {
                // calcul de la correl moyenne
                int nbCorrels;
                double rhoij, rhoMean;
                rhoMean = 0;
                nbCorrels = 0;

                for (int i = 0; i < _basketSize; i++)
                {
                    for (int j = 0; j < i; j++)
                    {
                        rhoij = RHO[i, j];
                        rhoMean += rhoij;
                    }
                }
                if (nbCorrels != 0)
                {
                    rhoMean /= nbCorrels;
                }
                return rhoMean;
            }

            /// <summary>
            /// Gett the synthetic volatility of the basket
            /// </summary>
            /// <returns></returns>
            private double ComputeSyntheticVolatility()
            {
                // calcul de la correl moyenne
                List<Underlying> tempUnderlyingsList = UnderlyingsDictionary.Values.ToList();
                double sigma = 0.0;
                for (int i = 0; i < _basketSize; i++)
                {
                    double sigma_i = tempUnderlyingsList[i].Volatility;
                    for (int j = 0; j <= i; j++)
                    {
                        double sigma_j = tempUnderlyingsList[j].Volatility;
                        if (i == j)
                            sigma += weights[i]*weights[j] * sigma_i * sigma_j;
                        else
                        {
                            sigma += 2.0 * weights[i]*weights[j] * RHO[i,j] * sigma_i * sigma_j;
                        }
                    }
                }
                return Math.Sqrt(sigma);
            }

            #endregion

            #region Basket check/comparison

            /// <summary>
            /// Check if the basket contains the underlying using its ticker
            /// </summary>
            /// <param name="ticker"></param>
            public bool ContainsUnderlying(string ticker)
            {
                if (_UnderlyingsDictionary.ContainsKey(ticker))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Check if the basket contains the underlying object
            /// </summary>
            /// <param name="underlying"></param>
            public bool ContainsUnderlying(Underlying underlying)
            {
                if (UnderlyingsDictionary.ContainsKey(underlying.Ticker))
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }

            /// <summary>
            /// Check if the basket does not cont the underlying using its ticker
            /// </summary>
            /// <param name="ticker"></param>
            public bool DoesNotContainUnderlying(string ticker)
            {
                return !ContainsUnderlying(ticker);
            }

            /// <summary>
            /// Check if the basket does not cont the underlying object
            /// </summary>
            /// <param name="underlying"></param>
            public bool DoesNotContainUnderlying(Underlying underlying)
            {
                return !ContainsUnderlying(underlying);
            }

            /// <summary>
            /// Compare two baskets' composition i.e. see if they have the same underlyings
            /// </summary>
            /// <param name="OtherBasket"></param>
            public bool HasSameComposition(BasketOfUnderlyings OtherBasket)
            {
                bool result;
                List<Underlying> tempUnderlyingsList = OtherBasket.UnderlyingsDictionary.Values.ToList();
                // First check if they have the same size
                if (_basketSize != OtherBasket.Size)
                {
                    result = false;
                }
                else
                {
                    result = true;
                    for (int i = 0; i < _basketSize; i++)
                    {
                        if (this.DoesNotContainUnderlying(tempUnderlyingsList[i]))
                        {
                            result = false;
                            break;
                        }
                    }
                }
                return result;
            }

            /// <summary>
            /// Compare two baskets in terms of premium/fitness & optimization goald (minimize/maximize)
            /// </summary>
            /// <param name="OtherBasket"></param>
            /// <param name="Parameters"></param>
            public bool IsBetterThan(BasketOfUnderlyings OtherBasket, GeneticLibrary.GAparameters Parameters)
            {
                if (Parameters.OptimizationGoal == OptimizationGoal.Maximize)
                {
                    if (Parameters.SortBasis == SortType.Raw)
                    {
                        if (_premium > OtherBasket.Premium && _isEvaluated)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        if (_fitness > OtherBasket.Fitness && _isEvaluated)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
                else
                {
                    if (Parameters.SortBasis == SortType.Raw)
                    {
                        if (_premium < OtherBasket.Premium && _isEvaluated)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                    else
                    {
                        if (_fitness < OtherBasket.Fitness && _isEvaluated)
                        {
                            return true;
                        }
                        else
                        {
                            return false;
                        }
                    }
                }
            }

            /// <summary>
            /// Compare two baskets in terms of premium/fitness & optimization goald (minimize/maximize)
            /// </summary>
            /// <param name="OtherBasket"></param>
            /// <param name="Parameters"></param>
            public bool IsWorseThan(BasketOfUnderlyings OtherBasket, GeneticLibrary.GAparameters Parameters)
            {
                return !IsBetterThan(OtherBasket, Parameters);
            }

            /// <summary>
            ///  Get the composition of a basket, a string of all the underlying tickers seperated by comas
            /// </summary>
            /// <returns></returns>
            public string GetComposition()
            {
                string result = string.Empty;
                var parameters = UnderlyingsTickers.ToArray();
                result = string.Join(" , ", parameters);

                //result.Remove(result.Length - 1, 2);
                return result;
            }

            /// <summary>
            ///  Refresh the tickers (needed when dictionary changed)
            /// </summary>
            public void RefreshTickers()
            {
                // Get the tickers from the dictionary and sort them alphabetically
                _UnderlyingsTickers = _UnderlyingsDictionary.Keys.ToList();
                _UnderlyingsTickers.Sort();
            }

            
            #endregion

            #region Basket Modification

            /// <summary>
            /// Remove an underyling from the basket using its ticker
            /// </summary>
            /// <param name="underlying"></param>
            private void Remove(string underlying)
            {
                // Remove and refresh
                _UnderlyingsDictionary.Remove(underlying);
                RefreshTickers();
                _basketSize--;
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Remove a list of underylings from the basket using their tickers
            /// </summary>
            /// <param name="underlying"></param>
            private void Remove(List<string> underlyingsList)
            {
                // Remove list and refresh
                foreach (string underlying in underlyingsList)
                {
                    _UnderlyingsDictionary.Remove(underlying);
                }
                RefreshTickers();
                _basketSize -= underlyingsList.Count;
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Remove an underyling from the basket using its corresponding index
            /// </summary>
            /// <param name="index"></param>
            private void Remove(int index)
            {
                List<Underlying> tempUnderlyingsList = _UnderlyingsDictionary.Values.ToList();
                _UnderlyingsDictionary.Remove(tempUnderlyingsList[index].Ticker);
                RefreshTickers();
                _basketSize--;
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Remove an underyling object from the basket 
            /// </summary>
            /// <param name="underlying"></param>
            private void Remove(Underlying underlying)
            {
                _UnderlyingsDictionary.Remove(underlying.Ticker);
                RefreshTickers();
                _basketSize--;
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Remove a list of underylings object from the basket 
            /// </summary>
            /// <param name="underlyingsList"></param>
            private void Remove(List<Underlying> underlyingsList)
            {
                foreach(Underlying underlying in underlyingsList)
                {
                    _UnderlyingsDictionary.Remove(underlying.Ticker);
                }
                RefreshTickers();
                _basketSize -= underlyingsList.Count;
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Add an underlying object to the basket
            /// </summary>
            /// <param name="underlying"></param>
            private void Add(Underlying underlying)
            {
                _UnderlyingsDictionary.Add(underlying.Ticker, underlying.Copy());
                RefreshTickers();
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                _basketSize++;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Add a a list of underlyings to the basket
            /// </summary>
            /// <param name="underlyingsList"></param>
            private void Add(List<Underlying> underlyingsList)
            {
                foreach(Underlying underlying in underlyingsList)
                {
                    _UnderlyingsDictionary.Add(underlying.Ticker, underlying.Copy());
                }
                RefreshTickers();
                _basketSize += underlyingsList.Count;
                _isEvaluated = false;
                _variance = 0;
                _premium = 0;
                _fitness = 0;
                //ComputeBasketParams();
            }

            /// <summary>
            /// Add an underlying object to the basket if not already present
            /// </summary>
            /// <param name="underlying"></param>
            private void AddWithDuplicateCheck(Underlying underlying)
            {
                if(!_UnderlyingsDictionary.ContainsKey(underlying.Ticker))
                {
                    _UnderlyingsDictionary.Add(underlying.Ticker, underlying.Copy());
                    RefreshTickers();
                    _basketSize++;
                    _isEvaluated = false;
                    _premium = 0;
                    _variance = 0;
                    _fitness = 0;
                    //ComputeBasketParams();
                }
            }

            /// <summary>
            /// Add a list of underlyings to the basket if not already present
            /// </summary>
            /// <param name="underlyingsList"></param>
            private void AddWithDuplicateCheck(List<Underlying> underlyingsList)
            {
                foreach (Underlying underlying in underlyingsList)
                {
                    if(!_UnderlyingsDictionary.ContainsKey(underlying.Ticker))
                    {
                        _UnderlyingsDictionary.Add(underlying.Ticker, underlying.Copy());
                        RefreshTickers();
                        _basketSize++;
                        _isEvaluated = false;
                        _premium = 0;
                        _variance = 0;
                        _fitness = 0;
                        //ComputeBasketParams();
                    }
                }
            }

            /// <summary>
            /// Replace an underlying object (found using its ticker) in the basket by another
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void Replace(string underlyingToReplace, Underlying underlyingToAdd)
            {
                this.Remove(underlyingToReplace);
                this.Add(underlyingToAdd.Copy());
                RefreshTickers();
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
            }

            /// <summary>
            /// Replace an underlying object in the basket (using its ticker) by another if not already present
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void ReplaceWithCheckForDuplicate(string underlyingToReplace, Underlying underlyingToAdd)
            {
                if(this.DoesNotContainUnderlying(underlyingToAdd))
                {
                    this.Remove(underlyingToReplace);
                    this.AddWithDuplicateCheck(underlyingToAdd.Copy());
                    RefreshTickers();
                    _isEvaluated = false;
                    _premium = 0;
                    _variance = 0;
                    _fitness = 0;
                }    
            }

            /// <summary>
            /// Replace an underlying object in the basket by another 
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void Replace(Underlying underlyingToReplace, Underlying underlyingToAdd)
            {
                this.Remove(underlyingToReplace);
                this.Add(underlyingToAdd.Copy());
                RefreshTickers();
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
            }

            /// <summary>
            /// Replace an underlying object in the basket by another if not already present
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void ReplaceWithCheckForDuplicate(Underlying underlyingToReplace, Underlying underlyingToAdd)
            {
                if(this.DoesNotContainUnderlying(underlyingToAdd))
                {
                    this.Remove(underlyingToReplace);
                    this.AddWithDuplicateCheck(underlyingToAdd.Copy());
                    RefreshTickers();
                    _isEvaluated = false;
                    _premium = 0;
                    _variance = 0;
                    _fitness = 0;
                }
                
            }

            /// <summary>
            /// Replace an underlying object in the basket (using its index) by another
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void Replace(int index , Underlying underlyingToAdd)
            {
                this.Remove(index);
                this.Add(underlyingToAdd.Copy());
                RefreshTickers();
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
            }

            /// <summary>
            /// Replace an underlying object in the basket (using its index) by another if not already present
            /// </summary>
            /// <param name="underlyingToReplace"></param>
            /// <param name="underlyingToAdd"></param>
            public void ReplaceWithCheckForDuplicate(int index, Underlying underlyingToAdd)
            {
                if(this.DoesNotContainUnderlying(underlyingToAdd))
                {
                    this.Remove(index);
                    this.AddWithDuplicateCheck(underlyingToAdd.Copy());
                    RefreshTickers();
                    _isEvaluated = false;
                    _premium = 0;
                    _variance = 0;
                    _fitness = 0;
                }     
            }

            /// <summary>
            /// Mutate the basket (replace randomly an underlying) given a probability
            /// </summary>
            /// <param name="Parameters"></param>
            /// <param name="UnderlyingSpace"></param>
            /// <param name="AlgorithmStatistics"></param>
            public void Mutate(GeneticLibrary.GAparameters Parameters, Dictionary<string, Underlying> UnderlyingSpace,
                               GeneticLibrary.GeneticAlgorithm.GAstats AlgorithmStatistics)
            {
                double r = Parameters.Random.NextDouble();
                List<Structures.Underlying> Universe = UnderlyingSpace.Values.ToList();
                if(r <= Parameters.MutationProbability)
                {
                    Underlying UnderlyingToAdd;
                    int toAddPosition = Parameters.Random.Next(0, UnderlyingSpace.Count - 1);
                    UnderlyingToAdd = Universe[toAddPosition].Copy();
                    while(_UnderlyingsDictionary.ContainsKey(UnderlyingToAdd.Ticker))
                    {
                        toAddPosition = Parameters.Random.Next(0, UnderlyingSpace.Count - 1);
                        UnderlyingToAdd = Universe[toAddPosition].Copy();
                    }

                    int mutationPosition = Parameters.Random.Next(0, _basketSize - 1);
                    ReplaceWithCheckForDuplicate(mutationPosition, UnderlyingToAdd);
                    AlgorithmStatistics.NumberOfMutations++;
                    RefreshTickers();
                    _isEvaluated = false;
                    _premium = 0;
                    _variance = 0;
                    _fitness = 0;
                }
            }

            /// <summary>
            /// Mutate the basket for sure
            /// </summary>
            /// <param name="UnderlyingSpace"></param>
            /// <param name="rnd"></param>
            public void Mutate( Dictionary<string, Underlying> UnderlyingSpace, Random rnd)
            {
                Underlying UnderlyingToAdd;
                int toAddPosition = rnd.Next(0, UnderlyingSpace.Count - 1);
                UnderlyingToAdd = UnderlyingSpace.Values.ToList()[toAddPosition].Copy();
                while (_UnderlyingsDictionary.ContainsKey(UnderlyingToAdd.Ticker))
                {
                    toAddPosition = rnd.Next(0, UnderlyingSpace.Count - 1);
                    UnderlyingToAdd = UnderlyingSpace.Values.ToList()[toAddPosition].Copy();
                }
                
                int mutationPosition = rnd.Next(0, _basketSize - 1);
                Replace(mutationPosition, UnderlyingToAdd);
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
                RefreshTickers();
            }

            public void ReplacePricingSettings(PricingSettingsForBasket NewPricingSettings)
            {
                _PricingSettings.UpdateSettings(NewPricingSettings);
                _isEvaluated = false;
                _premium = 0;
                _variance = 0;
                _fitness = 0;
            }

            #endregion

            #region Private members

            private double _premium;
            private double _variance;
            private double _correlSynthetic;
            private double _volSynthetic;
            private double _correlAverage;
            public double _maturity;
            private double equiWeight;
            public double _strike;
            private double[,] RHO;
            private double _fitness;
            private bool _isEvaluated;
            private int _basketSize;
            private int _rank;
            private List<string> _UnderlyingsTickers;
            private List<double> weights;
            private PricingSettingsForBasket _PricingSettings;
            private IResult _pricingResult;
            private string _baseccy;
            private Dictionary<string, Underlying> _UnderlyingsDictionary;
            private List<Underlying> _UnderlyingsList;

            #endregion

            #region Public members

            public Dictionary<string, Underlying> UnderlyingsDictionary { get { return _UnderlyingsDictionary; } }
            public List<Underlying> UnderlyingsList { get { return _UnderlyingsList; } }
            public int Size {get { return _basketSize; } }
            public bool isEvaluated
            {
                get { return _isEvaluated; }
                set { _isEvaluated = value; }
            }
            public List<string> UnderlyingsTickers { get { return _UnderlyingsTickers; } }
            public double Fitness{get {return _fitness; }}
            public double Weight { get { return equiWeight; } }
            public PricingSettingsForBasket PricingSettings { get { return _PricingSettings; } }
            public string BaseCurrency { get { return _baseccy; } }
            public double Premium { get { return _premium; } }
            public double Variance { get { return _variance; } }
            public int Rank
            {
                get { return _rank; }
                set
                {
                    if (value >= 0)
                    {
                        _rank = value;
                    }
                    
                }
            }
           
            #endregion
        }

        
        public static List<BasketOfUnderlyings> CopyBasketsList(List<BasketOfUnderlyings> BasketsListToCopy)
        {

            
            List<BasketOfUnderlyings> BasketsListResult = new List<BasketOfUnderlyings>();
            foreach (BasketOfUnderlyings Basket in BasketsListToCopy)
            {
                BasketsListResult.Add(Basket.Copy());
            }
            return BasketsListResult;
        }

        /// <summary>
        /// Class representing a population of baskets, used in the genetic algorihm
        /// </summary>
        public class PopulationOfBaskets
        {
            

            /// <summary>
            /// Constructor
            /// </summary>
            /// <param name="BasketsListArg"></param>
            /// <param name="FitnessFunctionArg"></param>
            /// <param name="OptimizationGoal"></param>
            /// <param name="SortBasis"></param>
            /// <param name="Random"></param>
            public PopulationOfBaskets(List<BasketOfUnderlyings> BasketsListArg, FitnessFunctionDelegate FitnessFunctionArg, 
                                       OptimizationGoal OptimizationGoal, SortType SortBasis, Random Random)
            {
                _BasketsList = CopyBasketsList(BasketsListArg);
                _Statistics = new PopulationStatistics();
                _populationSize = _BasketsList.Count;
                _FitnessFunction = FitnessFunctionArg;
                _OptimizationGoal = OptimizationGoal;
                _SortBasis = SortBasis;
                GetUnderlyingSpace();
                _isEvaluated = false;
            }

            /// <summary>
            /// Copy Constructor
            /// </summary>
            /// <param name="PopulationInput"></param>
            public PopulationOfBaskets(PopulationOfBaskets PopulationInput)
            {
                _BasketsList = CopyBasketsList(PopulationInput._BasketsList);
                _UnderlyingSpace = CopyUnderlyingsDictionary(PopulationInput._UnderlyingSpace);
                _populationSize = PopulationInput._populationSize;
                _FitnessFunction = PopulationInput._FitnessFunction;
                _OptimizationGoal = PopulationInput._OptimizationGoal;
                _SortBasis = PopulationInput._SortBasis;
                _Statistics = new PopulationStatistics(PopulationInput.Statistics);
                _isEvaluated = PopulationInput.isEvaluated;

                //Stats
                //Copy the stats

                _populationSize = PopulationInput._populationSize;
                _Best = PopulationInput._Best.Copy();
                _Worst = PopulationInput._Worst.Copy();
                
            }

            /// <summary>
            /// Statistics class
            /// </summary>
            public class PopulationStatistics
            {
                public PopulationStatistics()
                {
                    _avg=0;
                    _med=0;
                    _stdev=0;
                    _var=0;
                    _max=0;
                    _min=0;
                    _sum=0;
                    _fitavg = 0;
                    _fitmed = 0;
                    _fitstdev = 0;
                    _fitvar = 0;
                    _fitmax = 0;
                    _fitmin = 0;
                    _fitsum = 0;
            }

                public PopulationStatistics(PopulationStatistics StatisticsInput)
                {
                    _avg = StatisticsInput._avg;
                    _med = StatisticsInput._med;
                    _stdev = StatisticsInput._stdev;
                    _var = StatisticsInput._var;
                    _max = StatisticsInput._max;
                    _min = StatisticsInput._min;
                    _sum = StatisticsInput._sum;
                    _fitavg = StatisticsInput._fitavg;
                    _fitmed = StatisticsInput._fitmed;
                    _fitstdev = StatisticsInput._fitstdev;
                    _fitvar = StatisticsInput._fitvar;
                    _fitmax = StatisticsInput._fitmax;
                    _fitmin = StatisticsInput._fitmin;
                    _fitsum = StatisticsInput._fitsum;
                }
                #region Private

                // Objective scores
                private double _avg;        
                private double _med;
                private double _stdev;
                private double _var;
                private double _max;
                private double _min;
                private double _sum;

                // Same but fitness
                private double _fitavg;
                private double _fitmed;
                private double _fitstdev;
                private double _fitvar;
                private double _fitmax;
                private double _fitmin;
                private double _fitsum;

                #endregion

                #region Public Accessors

                public double AveragePremium {get { return _avg; } }
                public double MedianPremium { get { return _med; } }
                public double StandardDeviationPremium { get { return _stdev; } }
                public double VariancePremium { get { return _var; } }
                public double MaximumPremium { get { return _max; } }
                public double MinimumPremium { get { return _min; } }
                public double SumPremia { get { return _sum; } }

                public double AverageFitness { get { return _fitavg; } }
                public double MedianFitness { get { return _fitmed; } }
                public double StandardDeviationFitness { get { return _fitstdev; } }
                public double VarianceFitness { get { return _fitvar; } }
                public double MaximumFitness { get { return _fitmax; } }
                public double MinimumFitness { get { return _fitmin; } }
                public double SumFitnesses { get { return _fitsum; } }

                #endregion

                public void ComputeStatistics(List<BasketOfUnderlyings> BasketsList)
                {
                    //Objective scores stats
                    _avg = Maths.Statistics.Statistics.GetMean(BasketsList.Select(basket => basket.Premium).ToList());
                    _stdev = Maths.Statistics.Statistics.GetStandardDeviation(BasketsList.Select(basket => basket.Premium).ToList());
                    _var = Maths.Statistics.Statistics.GetVariance(BasketsList.Select(basket => basket.Premium).ToList());
                    _max = Maths.Statistics.Statistics.GetMaximum(BasketsList.Select(basket => basket.Premium).ToList());
                    _min = Maths.Statistics.Statistics.GetMinimum(BasketsList.Select(basket => basket.Premium).ToList());
                    _sum = BasketsList.Select(basket => basket.Premium).ToList().Sum();
                    _med = Maths.Statistics.Statistics.GetMedian(BasketsList.Select(basket => basket.Premium).ToList());

                    //Fitness scores stats
                    _fitavg = Maths.Statistics.Statistics.GetMean(BasketsList.Select(basket => basket.Fitness).ToList());
                    _fitstdev = Maths.Statistics.Statistics.GetStandardDeviation(BasketsList.Select(basket => basket.Fitness).ToList());
                    _fitvar = Maths.Statistics.Statistics.GetVariance(BasketsList.Select(basket => basket.Fitness).ToList());
                    _fitmax = Maths.Statistics.Statistics.GetMaximum(BasketsList.Select(basket => basket.Fitness).ToList());
                    _fitmin = Maths.Statistics.Statistics.GetMinimum(BasketsList.Select(basket => basket.Fitness).ToList());
                    _fitsum = BasketsList.Select(basket => basket.Fitness).ToList().Sum();
                }
            }

            
            /// <summary>
            /// Make a copy of the population
            /// </summary>
            /// <returns></returns>
            public PopulationOfBaskets Copy()
            {
                return new PopulationOfBaskets(this);
            }

            

            #region Methods

            /// <summary>
            /// Get the underlying space you are working with i.e. all the assets that are represented in the population
            /// </summary>
            private void GetUnderlyingSpace()
            {
                _UnderlyingSpace = new Dictionary<string, Underlying>();
                foreach (BasketOfUnderlyings Basket in _BasketsList)
                {
                    foreach (Underlying underlying in Basket.UnderlyingsDictionary.Values.ToList())
                    {
                        // Add it to the underlying space if it is not there
                        if (!_UnderlyingSpace.ContainsKey(underlying.Ticker))
                        {
                            _UnderlyingSpace.Add(underlying.Ticker, underlying);
                        }
                    }
                }

            }

            /// <summary>
            /// Evaluate the population i.e. price all baskets 
            /// </summary>
            /// <param name="BaseProd"></param>
            public void Evaluate( Dictionary<string, BasketOfUnderlyings> _pricingCache, StrategyDataSetElement BaseProd, BackgroundWorker backgroundworker, DoWorkEventArgs e, bool isFinalPopulation, double delta, double vega, double cega)
            {

                for (int index = 0; index < _BasketsList.Count; index++)
                {

                    BasketOfUnderlyings basket = _BasketsList[index];
                    LoggingService.Info(typeof(Structures), "[Basket Optimizer] - Current Basket : " + string.Join(",",basket.UnderlyingsTickers.ToArray()));
                    string key = null;
                    basket.UnderlyingsTickers.Sort();
                    foreach (var ssj in basket.UnderlyingsTickers)
                    {
                        key += ssj;
                    }

                    if (!backgroundworker.CancellationPending)
                    {
                        if ( (key != null && !_pricingCache.ContainsKey(key)))
                        {
                            basket.Evaluate(BaseProd, _FitnessFunction, this, backgroundworker, e, false,  delta,  vega,  cega);
                            if (key != null && !_pricingCache.ContainsKey(key)) _pricingCache.Add(key, basket);
                        }
                        else
                        {
                            if (key != null) _BasketsList[index] = _pricingCache[key];
                            LoggingService.Info(typeof(Structures), "[Basket Optimizer] - " + key + " already priced");
                        }
                    }
                    else
                    {
                        e.Cancel = true;
                    }
                }

                if (isFinalPopulation)
                {
                    var sortedBasketsList = _BasketsList.OrderBy(x => x.Premium).ToList();
                    for (int index2 = 0; index2 < Math.Min(_BasketsList.Count, 10); index2++)
                    {

                        BasketOfUnderlyings basket = sortedBasketsList[index2];
                        LoggingService.Info(typeof(Structures), "[Basket Optimizer] - Current Basket : " + string.Join(",", basket.UnderlyingsTickers.ToArray()));
                        string key = null;
                        basket.UnderlyingsTickers.Sort();
                        foreach (var ssj in basket.UnderlyingsTickers)
                        {
                            key += ssj;
                        }

                        if (!backgroundworker.CancellationPending)
                        {
                                basket.Evaluate(BaseProd, _FitnessFunction, this, backgroundworker, e, true, delta, vega, cega);
                                if (key != null && !_pricingCache.ContainsKey(key)) _pricingCache.Add(key, basket);
                        }
                        else
                        {
                            e.Cancel = true;
                        }
                        _BasketsList[index2] = basket;
                    }
                }

                // Check if population as a whole is evaluated
                _isEvaluated = true;
                foreach(BasketOfUnderlyings Basket in _BasketsList)
                {
                    if(!Basket.isEvaluated)
                    {
                        _isEvaluated = false;
                        break;
                    }
                }
                ComputePopulationStatistics(isFinalPopulation);
            }

            /// <summary>
            /// Compute the population statistics
            /// </summary>
            /// <param name="BaseProd"></param>
            public void ComputePopulationStatistics(bool isFinalPopulation = false)
            {
                _Statistics.ComputeStatistics(_BasketsList);
               
                _populationSize = _BasketsList.Count;
                _Best = GetBestBasket(isFinalPopulation);
                _Worst = GetWorstBasket(isFinalPopulation);
            }
            
            /// <summary>
            ///  Add a basket to the population
            /// </summary>
            /// <param name="Basket"></param>
            public void AddBasket(BasketOfUnderlyings Basket)
            {
                _BasketsList.Add(Basket.Copy());
                ComputePopulationStatistics();
            }
            
            /// <summary>
            /// Get the best basket of the population (definition of best depends on the optimization goal)
            /// </summary>
            /// <returns></returns>
            public BasketOfUnderlyings GetBestBasket(bool isFinalPopulation= false)
            {
                BasketOfUnderlyings resultBasket = _BasketsList[0].Copy();
                // Initial value (ensure it is an evaluated one)
                for(int i=0; i< Math.Min(_BasketsList.Count, 10); i++)
                {
                    if(_BasketsList[i].isEvaluated)
                    {
                        resultBasket =  _BasketsList[i].Copy();
                        break;
                    }
                }
                
                // Optimization goal : MAX
                if(_OptimizationGoal == OptimizationGoal.Maximize)
                {
                    // Using prices
                    if(_SortBasis == SortType.Raw)
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Premium > resultBasket.Premium && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }
                    // Using fitness
                    else
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Fitness > resultBasket.Fitness && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }  
                }
                // Optimization goal : MIN
                else
                {
                    // Using prices
                    if (_SortBasis == SortType.Raw)
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Premium < resultBasket.Premium && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }
                    // Using fitness
                    else
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Fitness < resultBasket.Fitness && BasketsList[i].isEvaluated)
                            {
                                resultBasket = _BasketsList[i].Copy();
                            }
                        }
                    }
                }
                
                return resultBasket;
            }

            /// <summary>
            /// Get the worst basket of the population (definition of worst depends on the optimization goal)
            /// </summary>
            /// <returns></returns>
            public BasketOfUnderlyings GetWorstBasket(bool isFinalPopulation= false)
            {
                BasketOfUnderlyings resultBasket =  _BasketsList[0].Copy();
                // Initial value
                for (int i = 0; i < Math.Min(_BasketsList.Count, 10); i++)
                {
                    if (_BasketsList[i].isEvaluated)
                    {
                        resultBasket =  _BasketsList[i].Copy();
                        break;
                    }
                }
                // Optimization goal : MAX
                if (_OptimizationGoal == OptimizationGoal.Maximize)
                {
                    // Using prices
                    if (_SortBasis == SortType.Raw)
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Premium < resultBasket.Premium && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }
                    // Using fitness
                    else
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Fitness < resultBasket.Fitness && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }

                }
                // Optimization goal : MIN
                else
                {
                    // Using prices
                    if (_SortBasis == SortType.Raw)
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Premium > resultBasket.Premium && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }
                    // Using fitness
                    else
                    {
                        for (int i = 1; i < _populationSize; i++)
                        {
                            if (BasketsList[i].Fitness > resultBasket.Fitness && BasketsList[i].isEvaluated)
                            {
                                resultBasket =  _BasketsList[i].Copy();
                            }
                        }
                    }

                }

                return resultBasket;
            }
            
            /// <summary>
            /// Sort the population (best ones first)
            /// </summary>
            public void SortPopulation(bool isFinalPopulation= false)
            {
                //if (_isSorted) return;
                if(_OptimizationGoal == OptimizationGoal.Maximize)
                {
                    if(_SortBasis == SortType.Raw)
                    {
                        if (isFinalPopulation) _BasketsList = _BasketsList.GetRange(0, 10).OrderByDescending(basket => basket.Premium).ToList().Concat(_BasketsList.GetRange(10, _BasketsList.Count - 10).OrderByDescending(basket => basket.Premium).ToList()).ToList();
                        else _BasketsList = _BasketsList.OrderByDescending(basket => basket.Premium).ToList();
                    }
                    else
                    {
                        _BasketsList = _BasketsList.OrderByDescending(basket => basket.Fitness).ToList();
                    }

                }
                else
                {
                    if (_SortBasis == SortType.Raw)
                    {
                        if (isFinalPopulation) _BasketsList = _BasketsList.GetRange(0, 10).OrderBy(basket => basket.Premium).ToList().Concat(_BasketsList.GetRange(10, _BasketsList.Count - 10).OrderBy(basket => basket.Premium).ToList()).ToList();
                        else _BasketsList = _BasketsList.OrderBy(basket => basket.Premium).ToList();
                    }
                    else
                    {
                        _BasketsList = _BasketsList.OrderBy(basket => basket.Fitness).ToList();
                    }
                }
                _isSorted = true;
                /*


                BasketOfUnderlyings tempBasket;
                // Optimization goal : most expensive
                if (_OptimizationGoal == OptimizationGoal.Maximize)
                {
                    // Using prices
                    if (_SortBasis == SortType.Raw)
                    {
                        for (int i = 0; i < _populationSize; i++)
                        {
                            for (int j = i + 1; j < _populationSize; j++)
                            {
                                if (_BasketsList[i].Premium < _BasketsList[j].Premium)
                                {
                                    tempBasket = (BasketOfUnderlyings) _BasketsList[j].Clone();
                                    _BasketsList[j] = (BasketOfUnderlyings) _BasketsList[i].Clone();
                                    _BasketsList[i] = (BasketOfUnderlyings) tempBasket.Clone();
                                }
                            }
                        }
                    }
                    // Using fitness
                    else
                    {
                        // Using prices
                        for (int i = 0; i < _populationSize; i++)
                        {
                            for (int j = i + 1; j < _populationSize; j++)
                            {
                                if (_BasketsList[i].Fitness < _BasketsList[j].Fitness)
                                {
                                    tempBasket = (BasketOfUnderlyings) _BasketsList[j].Clone();
                                    _BasketsList[j] = (BasketOfUnderlyings) _BasketsList[i].Clone();
                                    _BasketsList[i] = (BasketOfUnderlyings) tempBasket.Clone();
                                }
                            }
                        }
                    }    
                }
                // Optimization goal : least expensive
                else
                {
                    if (_SortBasis == SortType.Raw)
                    {
                        for (int i = 0; i < _populationSize; i++)
                        {
                            for (int j = i + 1; j < _populationSize; j++)
                            {
                                if (_BasketsList[i].Premium > _BasketsList[j].Premium)
                                {
                                    tempBasket = (BasketOfUnderlyings) _BasketsList[j].Clone();
                                    _BasketsList[j] = (BasketOfUnderlyings) _BasketsList[i].Clone();
                                    _BasketsList[i] = (BasketOfUnderlyings) tempBasket.Clone();
                                }
                            }
                        }
                    }
                    // Using fitness (we always maximize!)
                    else
                    {
                        for (int i = 0; i < _populationSize; i++)
                        {
                            for (int j = i + 1; j < _populationSize; j++)
                            {
                                if (_BasketsList[i].Fitness < _BasketsList[j].Fitness)
                                {
                                    tempBasket = (BasketOfUnderlyings) _BasketsList[j].Clone();
                                    _BasketsList[j] = (BasketOfUnderlyings) _BasketsList[i].Clone();
                                    _BasketsList[i] = (BasketOfUnderlyings) tempBasket.Clone();
                                }
                            }
                        }
                    }
                }
                */
                // Refresh ranks (base zero)
                foreach (BasketOfUnderlyings Basket in _BasketsList)
                {
                    Basket.Rank = _BasketsList.FindIndex(b =>b.UnderlyingsDictionary == Basket.UnderlyingsDictionary);
                }
                //_isSorted = true;
            }

            /// <summary>
            /// Shuffle the population
            /// </summary>
            public void ShufflePopulation()
            {

            }

            /// <summary>
            /// Check if the population contains the underlying (i.e. underlying is represented in the population)
            /// </summary>
            /// <param name="Underlying"></param>
            /// <returns></returns>
            public bool ContainsUnderlying(Underlying Underlying)
            {
                bool result = false;
                foreach (BasketOfUnderlyings Basket in BasketsList)
                {
                    // If a basket contains it then okay we can break here
                    if (Basket.ContainsUnderlying(Underlying))
                    {
                        result = true;
                        break;
                    }
                }
                return result;
            }

            /// <summary>
            /// Check if the population does not contain the underlying (i.e. underlying is represented in the population)
            /// </summary>
            /// <param name="Underlying"></param>
            /// <returns></returns>
            public bool DoesNotContainsUnderlying(Underlying Underlying)
            {
                return !ContainsUnderlying(Underlying);
            }

            /// <summary>
            /// Check if the population contains the basket
            /// </summary>
            /// <param name="BasketInput"></param>
            /// <returns></returns>
            public bool ContainsBasket(BasketOfUnderlyings BasketInput)
            {
                List<string> tempBasketTickers;
                bool isEqual;
                List<string> TickersInput = BasketInput.UnderlyingsTickers;
                TickersInput.Sort();
                bool result = false;
                if(TickersInput.Count != _BasketsList[0].Size)
                {
                    return false;
                }
                foreach (BasketOfUnderlyings Basket in _BasketsList)
                {
                    tempBasketTickers = Basket.UnderlyingsTickers;
                    tempBasketTickers.Sort();
                    isEqual = HelperMethods.StringListsAreEqual(tempBasketTickers, TickersInput);
                    if (isEqual)
                    {
                        result = true;
                        break;
                    }
                }
                return result;
                /*

                         
                bool result = false;
                bool tempbool;
                List< List<string> > PopulationTickers = new List< List<string> >();
                List<string> TempList;
                List<string> basketInputList = new List<string>();
                basketInputList = BasketInput.UnderlyingsDictionary.Keys.ToList();
                
                // Get lists of tickers for each basket in population
                foreach (BasketOfUnderlyings basket in BasketsList)
                {
                    TempList = basket.UnderlyingsDictionary.Keys.ToList();
                    PopulationTickers.Add(TempList);
                }

                //Now check (for each member of the population) if it contains all the tickers
                foreach(List<string> BasketTickers in PopulationTickers)
                {
                    tempbool = true;
                    foreach(string ticker in basketInputList)
                    {
                        if(!BasketTickers.Contains(ticker))
                        {
                            tempbool = false;
                        }
                    }
                    // If tempbool never changed then all the tickers were in, so we can break and return true !
                    // Otherwise we try again for the next basket
                    if (tempbool == true)
                    {
                        result = true;
                        break;
                    }
                }
                // Either loop was broken and result was true, or reached the end so result is false
                return result;
                */
            }

            /// <summary>
            /// Check if the population does not contain the basket
            /// </summary>
            /// <param name="BasketInput"></param>
            /// <returns></returns>
            public bool DoesNotContainsBasket(BasketOfUnderlyings BasketInput)
            {
                return !ContainsBasket(BasketInput);
            }
                        
            #endregion

            #region Private members

            private OptimizationGoal _OptimizationGoal;
            private SortType _SortBasis;
            private int _populationSize;
            private bool _isEvaluated;
            private bool _isSorted;
            // Best Basket
            private BasketOfUnderlyings _Best;
            // Worst Basket
            private BasketOfUnderlyings _Worst;
            private List<BasketOfUnderlyings> _BasketsList;
            private FitnessFunctionDelegate _FitnessFunction;
            private Dictionary<string, Underlying> _UnderlyingSpace;
            private PopulationStatistics _Statistics;

            #endregion

            #region Public members

            public OptimizationGoal OptimizationsGoal { get { return _OptimizationGoal; } }
            public bool isEvaluated { get { return _isEvaluated; } }
            public bool isSorted { get { return _isSorted; } }
            public SortType SortBasis { get { return _SortBasis; } }
            public int Size { get { return _populationSize; } }
            //Make public so can mutate
            public List<BasketOfUnderlyings> BasketsList
            {
                get { return _BasketsList; }
                set { _BasketsList = value; }
            }
            public Dictionary<string, Underlying> UnderlyingSpace { get { return _UnderlyingSpace; } }
            public BasketOfUnderlyings BestBasket { get { return _Best; } }
            public BasketOfUnderlyings WorstBasket { get { return _Worst; } }
            public PopulationStatistics Statistics { get { return _Statistics; } }
            #endregion

        }

        public class BasketSensi : BaseMeta
        {
            public double Epsilon { get; } = 0.001;
            private Structures.BasketOfUnderlyings myBasket;
            private StrategyDataSetElement product;
            private MonteCarloConfiguration pricingSettings;
            private TreeBump treeBump;

            public BasketSensi(StrategyDataSetElement product, Structures.BasketOfUnderlyings myBasket, MonteCarloConfiguration pricingConfiguration)
            {
                this.myBasket = myBasket;
                this.product = product;
                this.pricingSettings = pricingConfiguration;

                treeBump = new TreeBump();
                VolatilityBumper volBumper = new VolatilityBumper(Epsilon);
                CorrelationBumperParallel correlBumper = new CorrelationBumperParallel(Epsilon);
                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    treeBump.AddAssetBump(underlyingTicker, "Volatility", volBumper);
                    treeBump.AddAssetBump(underlyingTicker, "Correlation", volBumper);
                    //bmp.AddAssetBump(underlyingTicker,"volatility", volBumper);
                    //bmp.AddAssetBump(underlyingTicker, "Skew", volBumper);

                    Configure(product.MarketDataTree, treeBump, pricingConfiguration);
                }
            }

            public double GetVega(PricingSettingsForBasket pricingSettings, StrategyDataSetElement product, Structures.BasketOfUnderlyings myBasket, MonteCarloConfiguration pricingConfiguration)
            {
                var pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x0 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    //BumpVolatility(underlyingTicker, Epsilon, 0.0);
                    MarketDataProperty lProperty;
                    string path = MarketDataTree.GetUnderlyingPath(underlyingTicker) + MarketDataTree.PathDelimiter + "volatility";
                    if (marketData.TryFindProperty(path, out lProperty))
                    {
                        IVolatilityMatrix lvVolatilityMatrix = lProperty.Value as IVolatilityMatrix;
                        
                        lvVolatilityMatrix = (IVolatilityMatrix) treeBump.Bump(underlyingTicker, "Volatility",(IVolatilityMatrix) lProperty.Value);
                    }
                }


                pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x1 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    CleanBumps(underlyingTicker);
                }
                
                double vega = (x1 - x0) ;
                return vega;

            }

            public double GetDelta(PricingSettingsForBasket pricingSettings, StrategyDataSetElement product, Structures.BasketOfUnderlyings myBasket, double maturity)
            {
                var pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x0 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    //SetFixingHisto(underlyingTicker, product.Product.FixingCalendar.ReferenceDate, MarketDataService.GetSpot(underlyingTicker));
                    /* QuoteHistory qh = new QuoteHistory();
                     TimeSerie ts = new TimeSerie();
                     ts[product.Product.FixingCalendar.ReferenceDate] = MarketDataService.GetSpot(underlyingTicker);
                     qh.Values[underlyingTicker] = ts;
                     UnsafeSetValue(product.Product, "_basketHistory", qh);
                     //BumpSpot(underlyingTicker, Epsilon);*/

                    BumpRepo(underlyingTicker, (-1/ (maturity/365.25))*Math.Log(1+Epsilon));

                }

                pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x1 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    CleanBumps(underlyingTicker);
                   
                }

                double delta = (x1 - x0) ;
                return delta;

            }
            private static void UnsafeSetValue(object target, string fieldName, object value)
            {
                Type ty = target.GetType();
                FieldInfo fi = null;

                while (fi == null && ty != null)
                {
                    fi = ty.GetField(fieldName, BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
                    ty = ty.BaseType;
                }

                fi.SetValue(target, value);
            }

            public double GetCega (PricingSettingsForBasket pricingSettings, StrategyDataSetElement product, Structures.BasketOfUnderlyings myBasket)
            {
                CorrelationBumperParallel _bumper = new CorrelationBumperParallel(0.001);
                var pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x0 = (double)pricingResult[ResultString.Premium];

                /*foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    BumpCorrel(CorrelationBumpType.Parallel, Epsilon);
                }*/

                for (int i = 0; i < myBasket.UnderlyingsTickers.Count; i++)
                {
                    // la correl entre lui meme et lui meme
                    //correlationMatrix[i, i] = 1.0;
                    // avec les autres
                    for (int j = 0; j < i; j++)
                    {
                        string lPath = MarketDataMgr.Trees.Ext.OverloadedMarketDataTree.CorrelationPath(myBasket.UnderlyingsTickers[i], myBasket.UnderlyingsTickers[j]);
                        MarketDataProperty lProperty;
                        if (product.MarketDataTree.TryFindProperty(lPath, out lProperty))
                        {
                            ICorrelations lCorrelCurve = lProperty.Value as ICorrelations;
                            lCorrelCurve = (ICorrelations)_bumper.Bump(lCorrelCurve);
                            //((ICorrelations)lProperty.Value).Values = lCorrelCurve.Values;
                            /*product.MarketDataTree.OriginalTree.Tree.RemoveProperty(lPath, "correlation");
                            product.MarketDataTree.OriginalTree.Tree.AddProperty(lPath, "correlation", lProperty);*/
                            //product.MarketDataTree.AddOverloadedCorrelationProperty(myBasket.UnderlyingsTickers[i], myBasket.UnderlyingsTickers[j], "correlation", lCorrelCurve);
                        }
                    }
                }

                pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x1 = (double)pricingResult[ResultString.Premium];

                /* foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                 {
                     CleanBumps(underlyingTicker);
                 }*/

                double cega = (x1 - x0);
                return cega;
            }
            public override IResult Meta()
            {

                TreeBump bmp = new TreeBump();
                VolatilityBumper volBumper = new VolatilityBumper(Epsilon);
                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    bmp.AddAssetBump(underlyingTicker, "Volatility", volBumper);
                    //bmp.AddAssetBump(underlyingTicker,"volatility", volBumper);
                    //bmp.AddAssetBump(underlyingTicker, "Skew", volBumper);

                    Configure(product.MarketDataTree, bmp, pricingSettings);
                }

                var pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x0 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    BumpVolatility(underlyingTicker, Epsilon, 0.0);
                }

                pricingResult = HelperMethods.PriceBasketOfUnderlyings(product, myBasket, pricingSettings.NumberOfSimulations, pricingSettings.StockModel, pricingSettings.RateModel);
                double x1 = (double)pricingResult[ResultString.Premium];

                foreach (var underlyingTicker in myBasket.UnderlyingsTickers)
                {
                    CleanBumps(underlyingTicker);
                }

                double vega = (x1 - x0);

                // Tente une calibration en amont
                PrefetchCalibration();
                // puis price
                return Price();
            }
        }


        public class BasketRef
        {
            public double Delta { get; }
            public double Vega { get; }
            public double Cega { get; }
            public double Volref { get; }
            public double Forwardref { get; }
            public double Correlref { get; }

            public BasketRef(double delta, double vega, double cega, double volref, double forwardref, double correlref)
            {
                this.Delta = delta;
                this.Vega = vega;
                this.Cega = cega;
                this.Volref = volref;
                this.Forwardref = forwardref;
                this.Correlref = correlref;
            }
        }
      

    }

}
