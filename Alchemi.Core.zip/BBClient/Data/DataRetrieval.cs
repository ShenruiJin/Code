﻿using BbgProcesser;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Connection;

using Pricing.MarketData.Container;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CaesarApplication.Service.Strategy;

using RemotingInterfaces;
using System.Data;
using System.Globalization;
using System.IO;
using MarketDataMgr;
using MarketDataMgr.Connections;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using GlobalDerivativesApplications.Finance;
using MarketDataMgr.Trees;
using FuncFramework.Business;
using System.ComponentModel;

namespace BBClient.Data
{
    public static class DataRetrieval
    {
        #region Sophis Data

        /// <summary>
        /// Make a dictionnary of the the FX-EUR rates (needed to get liquidity of stocks)
        /// </summary>
        /// <param name="CurrenciesList"></param>
        /// <param name="backgroundworker"></param>
        /// <param name="e"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetFXrates(List<string> CurrenciesList, BackgroundWorker backgroundworker, DoWorkEventArgs e)
        {
            List<string> CCyList = CurrenciesList.Distinct().ToList();
            Dictionary<string, double> FXDictionary = new Dictionary<string, double>();
            double ForexFlash;
            foreach (string ccy in CCyList)
            {
                if (backgroundworker.CancellationPending == true)
                {
                    e.Cancel = true;
                    return FXDictionary;
                }
                ForexFlash = MarketDataService.GetLiveSpot(ForexTools.CurrenciesToFX(ccy, "EUR"));
                FXDictionary.Add(ccy, ForexFlash);
            }
            return FXDictionary;
        }

        /// <summary>
        /// Get a list of all the instruments
        /// </summary>
        /// <returns></returns>
        public static Dictionary<string, MarketData.Instrument> GetAllInstruments()
        {
            return ConnectionService.CreateMarketDataManager().CurrentConnection.InstrumentsList.Instruments;
        }

        /// <summary>
        /// Make a dictionary of the spots for each underlying
        /// </summary>
        /// <param name="underlyingsTickers"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetSpotsDictionary(List<string> underlyingsTickers)
        {
            ConnectionService.ConnectToMarketDataServer();
            MarketDataManager marketDataMgr = ConnectionService.CreateMarketDataManager();
            var gfc = marketDataMgr.CurrentConnection as GenericFrameworkConnection;
            List<double> lSpot = new List<double>();
            List<string> TickersCheckedForSpot = new List<string>();
            IList<SpotInput> spotInputList = SpotInput.CreateList(underlyingsTickers, DateTime.Now);

            lSpot = gfc.SophisManager2.Spot.GetList(spotInputList, useAsyncApi: true).Select(x=>x.Value).ToList();   

            var Dico = underlyingsTickers.Zip(lSpot, (k, v) => new { Key = k, Value = v }).ToDictionary(x => x.Key, x => x.Value);
            Dictionary<string, double> SpotsDictionary = new Dictionary<string, double>();
            // remove bad spots
            double value;
            foreach ( KeyValuePair< string, double >  Entry in Dico)
            {
                value = Entry.Value;
                if(Entry.Value > 0 )
                {
                    SpotsDictionary.Add(Entry.Key, value);
                }
            }
            return SpotsDictionary;
        }

        /// <summary>
        /// Make a list of all instruments
        /// </summary>
        /// <returns></returns>
        public static List<MarketData.Instrument> GetAllSophisInstruments()
        {
            // Get all instruments and convert the dictionnary to List
            return ConnectionService.CreateMarketDataManager().CurrentConnection.InstrumentsList.Instruments.Values.ToList();
        }

        /// <summary>
        /// Keep the stocks from a list of instruments
        /// </summary>
        /// <param name="Instruments"></param>
        /// <returns></returns>
        public static List<MarketData.Instrument> GetStocks(List<MarketData.Instrument> Instruments)
        {
            List<MarketData.Instrument> StockList = new List<MarketData.Instrument>();
            foreach (MarketData.Instrument instr in Instruments)
            {

                /* InstrumentType
                Currency = 1       ,   Forex = 2     ,      Fund = 3       ,      Index = 4         ,     Inflation = 5     , 
                InterestRate = 6   ,   Stock = 7     ,      Others = 8     ,      NoDrift = 9       ,     Option = 10       ,
                Package = 11       ,   Future = 12   ,      Swap = 13      ,      Commission = 14   ,     FundNoDrift = 15  ,
                Exchange = 16

                */
                // Add if it is a stock or an index
                if (instr.Type == InstrumentType.Stock)
                {
                    StockList.Add(instr);
                }

            }
            return StockList;
        }

        /// <summary>
        /// Keep the stocks and indices (and some other non clean stuff) for a list of instruments
        /// </summary>
        /// <param name="Instruments"></param>
        /// <returns></returns>
        public static List<MarketData.Instrument> GetStocksAndIndices(List<MarketData.Instrument> Instruments)
        {
            List<MarketData.Instrument> StockList = new List<MarketData.Instrument>();
            foreach (MarketData.Instrument instr in Instruments)
            {

                /* InstrumentType
                Currency = 1       ,   Forex = 2     ,      Fund = 3       ,      Index = 4         ,     Inflation = 5     , 
                InterestRate = 6   ,   Stock = 7     ,      Others = 8     ,      NoDrift = 9       ,     Option = 10       ,
                Package = 11       ,   Future = 12   ,      Swap = 13      ,      Commission = 14   ,     FundNoDrift = 15  ,
                Exchange = 16

                */
                // Add if it is a stock or an index
                if (instr.Type == InstrumentType.Stock || instr.Type == InstrumentType.Index)
                {
                    StockList.Add(instr);
                }

            }
            return StockList;
        }

        
        /// <summary>
        /// Make a volatility and skew dictionary for a list of underlyings
        /// </summary>
        /// <param name="underlyingList"></param>
        /// <param name="ccy"></param>
        /// <param name="maturity"></param>
        /// <param name="strike"></param>
        /// <param name="SkewsDictionary"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetVolSkew(List<string> underlyingList, string ccy, double maturity, double strike, 
                                                            out Dictionary<string, double> SkewsDictionary)
        {
            // The dictionaries
            Dictionary<string, double> VolsDictionary = new Dictionary<string, double>();
            SkewsDictionary = new Dictionary<string, double>();

            // Put underlying in a list to use the functions below
            List<StockContainer> marketDataList = new List<StockContainer>();
            
            // Retrieve vols and forwards
            SophisServerManager.RetrieveUnderlyingVolFwd(underlyingList, ccy, out marketDataList);

            // Get vol and skew
            double strikeSkewRight = 1.1;
            double strikeSkewLeft = 0.9;
            double vol;
            double skew;
            string ticker;
            for(int i=0; i< marketDataList.Count;i++)
            {
                ticker = marketDataList[i].Name;
                vol = double.IsNaN(strikeSkewLeft) ?
                    SophisServerManager.VolatilityFromMarketData(marketDataList[i], strike, maturity, out skew) :
                    SophisServerManager.VolatilityFromMarketData(marketDataList[i], strike, maturity,
                        strikeSkewLeft, strikeSkewRight, out skew);
                VolsDictionary.Add(ticker, vol);
                SkewsDictionary.Add(ticker, skew);
            }
        
            return VolsDictionary;
        }

        /// <summary>
        /// Make a dictionary of the forwards for a list of underlyings
        /// </summary>
        /// <param name="underlyingList"></param>
        /// <param name="ccy"></param>
        /// <param name="maturity"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetForward(List<string> underlyingList, string ccy, double maturity)
        {
            Dictionary<string, double> FwdsDictionary = new Dictionary<string, double>();
            // Put underlying in a list to use the functions below
            List<StockContainer> marketDataList = new List<StockContainer>();
            
            // Retrieve vols and forwards
            SophisServerManager.RetrieveUnderlyingVolFwd(underlyingList, ccy, out marketDataList);

            // Forward
            double forward;
            string ticker;
            for (int i = 0; i < marketDataList.Count; i++)
            {
                ticker = marketDataList[i].Name;
                forward = SophisServerManager.ForwardFromMarketData(marketDataList[i], maturity);
                FwdsDictionary.Add(ticker, forward);

            }
            
            return FwdsDictionary;
        }

        /// <summary>
        /// Load market data (for a list of underlyings), needed for pricing
        /// </summary>
        /// <param name="tree"></param>
        /// <param name="UnderlyingsDictionary"></param>
        public static void LoadMarketData(MarketDataTree tree, Dictionary<string, Structures.Underlying> UnderlyingsDictionary)
        {
            List<string> UnderlyingsTickers = UnderlyingsDictionary.Values.ToList().Select(ul => ul.Ticker).Distinct().ToList();
            PricingBase.Product.CsInfoContainer.Basket b = new PricingBase.Product.CsInfoContainer.Basket();

            b.Resize(UnderlyingsTickers.Count);
            // Add underlyings to the basket
            for (int i = 0; i < UnderlyingsTickers.Count; i++)
            {
                b.ModelName[i] = UnderlyingsTickers[i];
                b.Weight[UnderlyingsTickers[i]] = 1.0 / UnderlyingsTickers.Count;
            }
            
            // On load le tree
            MarketDataService.LoadMarketData(UnderlyingsTickers, UnderlyingsDictionary.Values.ToList()[0].BaseCurrency, tree, true);
        }

        #endregion

        #region Bloomberg Data
        // Via queries
        
        /// <summary>
        /// Take the instruments, check if they exist on Bloomberg, return the list of tickers
        /// </summary>
        /// <param name="instrumentList"></param>
        /// <returns></returns>
        public static List<string> FilterBbgStocks(List<MarketData.Instrument> instrumentList)
        {
            List<string> resultList = new List<string>();
            string tempString;
            BbgQuery query = new BbgQuery();
            try
            {
                // The Bloomberg query
                query.FieldsList.Add("NAME");
                var instr = instrumentList.Select(inst => inst.BbgCode).ToList();
                query.SecuritiesList.AddRange(instr);
                query.IsStatic = true;
                DataSet staticDataDs = Remoter.Send(query);
                DataTable dataTable = staticDataDs.Tables[BbgMnemonics.DataTableIndex];

                foreach (DataRow elem in dataTable.Rows)
                {
                    tempString = ((System.Data.DataRow)elem).ItemArray[0].ToString();
                    // Remove the "Equity" part
                    tempString = tempString.Remove(tempString.Length - 6);
                    tempString = tempString.TrimEnd();
                    resultList.Add(tempString);
                }
            }
            catch(Exception)
            {

            }
            return resultList;
        }

        /// <summary>
        /// Same as above and save the tickers which did not work
        /// </summary>
        /// <param name="TickersList"></param>
        /// <param name="FailedTickers"></param>
        /// <returns></returns>
        public static List<string> FilterBbgStocks(List<string> TickersList, ref List<string> FailedTickers)
        {
            List<string> resultList = new List<string>();
            FailedTickers = new List<string>();
            string tempString;
            BbgQuery query = new BbgQuery();
            try
            {
                query.FieldsList.Add("NAME");
                query.SecuritiesList.AddRange(TickersList);
                query.IsStatic = true;
                DataSet staticDataDs = Remoter.Send(query);
                DataTable dataTable = staticDataDs.Tables[BbgMnemonics.DataTableIndex];
                foreach (DataRow elem in dataTable.Rows)
                {
                    tempString = ((System.Data.DataRow)elem).ItemArray[0].ToString().TrimEnd();
                    tempString = tempString.Remove(tempString.Length - 6);
                    tempString = tempString.TrimEnd();
                    resultList.Add(tempString);
                }


                FailedTickers = TickersList.Except(resultList).ToList();

            }
            catch(Exception)
            {

            }
            return resultList;
        }

        /// <summary>
        /// Get the bloomberg data (saved in lists passed by ref). Data retrieved by live queries
        /// </summary>
        /// <param name="Tickers"></param>
        /// <param name="Currencies"></param>
        /// <param name="Countries"></param>
        /// <param name="Ratings"></param>
        /// <param name="SubSectors"></param>
        public static void GetBloombergData(ref List<string> Tickers, ref List<string> Currencies,
                                            ref List<string> Countries, ref List<double> Ratings,
                                            ref List<string> SubSectors)
        {
            string dummyTicker;
            string dummyCurrency;
            string dummyCountry;
            string dummySubSector;
            bool dummyBool;
            double dummyRating;
            BbgQuery query = new BbgQuery();

            try
            {
                query.FieldsList.Add("CRNCY");
                query.FieldsList.Add("COUNTRY_FULL_NAME");
                query.FieldsList.Add("BEST_ANALYST_RATING");
                query.FieldsList.Add("ICB_SUBSECTOR_NAME");
                query.SecuritiesList.AddRange(Tickers);
                query.IsStatic = true;
                DataSet staticDataDs = Remoter.Send(query);
                DataTable dataTable = staticDataDs.Tables[BbgMnemonics.DataTableIndex];
                Tickers.Clear();
                Currencies.Clear();
                Countries.Clear();
                Ratings.Clear();
                SubSectors.Clear();
                foreach (DataRow elem in dataTable.Rows)
                {
                    dummyTicker = ((System.Data.DataRow)elem).ItemArray[0].ToString();
                    dummyTicker = dummyTicker.Remove(dummyTicker.Length - 6);
                    dummyTicker = dummyTicker.TrimEnd();
                    Tickers.Add(dummyTicker);
                    dummyCurrency = ((System.Data.DataRow)elem).ItemArray[1].ToString().ToUpper();
                    Currencies.Add(dummyCurrency);
                    dummyCountry = ((System.Data.DataRow)elem).ItemArray[2].ToString().ToUpper().TrimEnd();
                    dummyCountry = char.ToUpper(dummyCountry[0]) + dummyCountry.Substring(1).ToLower();
                    Countries.Add(dummyCountry);
                    dummyBool = double.TryParse(((System.Data.DataRow)elem).ItemArray[3].ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out dummyRating);
                    Ratings.Add(dummyRating);
                    dummySubSector = ((System.Data.DataRow)elem).ItemArray[4].ToString();
                    SubSectors.Add(dummySubSector);
                }
            }
            catch(Exception)
            {

            }
        }

        /// <summary>
        /// Get the bloomberg data (saved in dictionaries passed by ref). Data retrieved by live queries
        /// </summary>
        /// <param name="Tickers"></param>
        /// <param name="Names"></param>
        /// <param name="Currencies"></param>
        /// <param name="Countries"></param>
        /// <param name="Ratings"></param>
        /// <param name="Liquidities"></param>
        /// <param name="SubSectors"></param>
        public static void GetBloombergDataViaQueries(List<string> Tickers, ref Dictionary<string, string> Names,  ref Dictionary<string, string> Currencies,
                                                      ref Dictionary<string, string> Countries, ref Dictionary<string, double> Ratings,
                                                      ref Dictionary<string, double> Liquidities, ref Dictionary<string, string> SubSectors)
        {
            string dummyTicker;
            string dummyName;
            string dummyCurrency;
            string dummyCountry;
            string dummySubSector;
            bool dummyBool;
            double dummyRating;
            double dummyLiquidity;
            BbgQuery query = new BbgQuery();
            try
            {
                query.FieldsList.Add("NAME");
                query.FieldsList.Add("CRNCY");
                query.FieldsList.Add("COUNTRY_FULL_NAME");
                query.FieldsList.Add("BEST_ANALYST_RATING");
                query.FieldsList.Add("ICB_SUBSECTOR_NAME");
                query.FieldsList.Add("VOLUME_AVG_30D");
                query.SecuritiesList.AddRange(Tickers);
                query.IsStatic = true;
                DataSet staticDataDs = Remoter.Send(query);
                DataTable dataTable = staticDataDs.Tables[BbgMnemonics.DataTableIndex];


                foreach (DataRow elem in dataTable.Rows)
                {
                    dummyTicker = ((System.Data.DataRow)elem).ItemArray[0].ToString();
                    dummyTicker = dummyTicker.Remove(dummyTicker.Length - 6);
                    dummyTicker = dummyTicker.TrimEnd();

                    dummyName = ((System.Data.DataRow)elem).ItemArray[1].ToString().ToUpper();
                    Names.Add(dummyTicker, dummyName);

                    dummyCurrency = ((System.Data.DataRow)elem).ItemArray[2].ToString().ToUpper();
                    Currencies.Add(dummyTicker, dummyCurrency);

                    dummyCountry = ((System.Data.DataRow)elem).ItemArray[3].ToString().ToUpper().TrimEnd();
                    dummyCountry = char.ToUpper(dummyCountry[0]) + dummyCountry.Substring(1).ToLower();
                    Countries.Add(dummyTicker, dummyCountry);

                    dummyBool = double.TryParse(((System.Data.DataRow)elem).ItemArray[4].ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out dummyRating);
                    Ratings.Add(dummyTicker, dummyRating);

                    dummySubSector = ((System.Data.DataRow)elem).ItemArray[5].ToString();
                    SubSectors.Add(dummyTicker, dummySubSector);

                    dummyBool = double.TryParse(((System.Data.DataRow)elem).ItemArray[6].ToString(), NumberStyles.Any, CultureInfo.InvariantCulture, out dummyLiquidity);
                    Ratings.Add(dummyTicker, dummyLiquidity);
                }
            }
            catch(Exception)
            {

            }
        }

        // Via .csv files
                // Clean-up
        public static List<string> CleanBbgStocks(List<string> Tickers, List<BasketOptimizerNew.StockData> StockDataList)
        {
            List<string> resultList = new List<string>();
            List<string> BbgTickers = StockDataList.Select(stock => stock.Ticker).ToList();
            foreach (string ticker in Tickers)
            {
                if (BbgTickers.Contains(ticker))
                {
                    resultList.Add(ticker);
                }
            }
            return resultList;
        }
        public static List<string> CleanBbgStocks(List<string> Tickers, List<BasketOptimizerNew.StockData> StockDataList, ref List<string> FailedTickers)
        {
            List<string> resultList = new List<string>();
            FailedTickers = new List<string>();
            List<string> BbgTickers = StockDataList.Select(stock => stock.Ticker).ToList();
            foreach (string ticker in Tickers)
            {
                if (BbgTickers.Contains(ticker))
                {
                    resultList.Add(ticker);
                }
                else
                {
                    FailedTickers.Add(ticker);
                }
            }
            return resultList;
        }
                //Data
        
        /// <summary>
        /// Get the stock name from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionaryNames"></param>
        /// <returns></returns>
        public static string GetStockName(string ticker, Dictionary<string, string> DictionaryNames)
        {
            string result;
            bool dummy = DictionaryNames.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Get the stock country from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionaryCountries"></param>
        /// <returns></returns>
        public static string GetStockCountry(string ticker, Dictionary<string, string> DictionaryCountries)
        {
            string result;
            bool dummy = DictionaryCountries.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Get the stock currency from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionaryCurrencies"></param>
        /// <returns></returns>
        public static string GetStockCurrency(string ticker, Dictionary<string, string> DictionaryCurrencies)
        {
            string result;
            bool dummy = DictionaryCurrencies.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Get the stock subsector from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionarySubSectors"></param>
        /// <returns></returns>
        public static string GetStockSubSector(string ticker, Dictionary<string, string> DictionarySubSectors)
        {
            string result;
            bool dummy = DictionarySubSectors.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Get the stock rating from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionaryRatings"></param>
        /// <returns></returns>
        public static double GetStockAnalystRating(string ticker, Dictionary<string, double> DictionaryRatings)
        {
            double result;
            bool dummy = DictionaryRatings.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Get the stock liquidity from dictionary
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="DictionaryLiquidities"></param>
        /// <returns></returns>
        public static double GetStockLiquidity(string ticker, Dictionary<string, double> DictionaryLiquidities)
        {
            double result;
            bool dummy = DictionaryLiquidities.TryGetValue(ticker, out result);
            return result;
        }

        /// <summary>
        /// Make the names dictionary following the path
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetStocksDataFullName(string sPath)
        {
            Dictionary<string, string> StocksDataFullName = new Dictionary<string, string>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                if (StocksDataFullName.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataFullName.Add(sTempData[1], sTempData[3]);
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataFullName;
        }

        /// <summary>
        /// Make the countrie dictionary following the path
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetStocksDataCountry(string sPath)
        {
            Dictionary<string, string> StocksDataCountry = new Dictionary<string, string>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                if (StocksDataCountry.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataCountry.Add(sTempData[1], sTempData[3]);
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataCountry;
        }

        /// <summary>
        /// Make the currencies dictionary following the path
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetStocksDataCurrency(string sPath)
        {
            Dictionary<string, string> StocksDataCurrency = new Dictionary<string, string>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                if (StocksDataCurrency.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataCurrency.Add(sTempData[1], sTempData[3].ToUpper());
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataCurrency;
        }

        /// <summary>
        /// Make the ratings dictionary following the path
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetStocksDataRating(string sPath)
        {
            Dictionary<string, double> StocksDataRating = new Dictionary<string, double>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                double dummyValue;
                bool dummy = double.TryParse(sTempData[3], NumberStyles.Any, CultureInfo.InvariantCulture, out dummyValue);
                if (StocksDataRating.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataRating.Add(sTempData[1], dummyValue);
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataRating;
        }

        /// <summary>
        /// Make liquidity dictionary following the path
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, double> GetStocksDataLiquidity(string sPath)
        {
            Dictionary<string, double> StocksDataLiquidity = new Dictionary<string, double>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                double dummyValue;
                bool dummy = double.TryParse(sTempData[3], NumberStyles.Any, CultureInfo.InvariantCulture, out dummyValue);
                if (StocksDataLiquidity.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataLiquidity.Add(sTempData[1], dummyValue);
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataLiquidity;
        }

        /// <summary>
        /// Make the subsectors dictionary
        /// </summary>
        /// <param name="sPath"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetStocksDataSubSectors(string sPath)
        {
            Dictionary<string, string> StocksDataSubSectors = new Dictionary<string, string>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                if (StocksDataSubSectors.Keys.DoesNotContain(sTempData[1]))
                {
                    StocksDataSubSectors.Add(sTempData[1], sTempData[3]);
                }
                sLine = srReader.ReadLine();
            }
            return StocksDataSubSectors;
        }


        #endregion

        
    }
}

