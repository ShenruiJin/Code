﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BBClient
{
    public class DBSchema
    {        
        public const string BbgDescriptiveField = "Field";
        public const string BbgDescriptiveType = "Type";
        public const string BbgDescriptiveIsDynamic = "IsDynamic";
        public const string BbgDescriptiveBindsTo = "BindsTo";
    }
}
