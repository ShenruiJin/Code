﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BbgProcesser;
using Estimators;
using StructuringControls;

namespace BBClient
{
    partial class CorrelationForm
    {
        #region Custom correlations
        public void SetAsGroup(int groupNumber)
        {
            // Delete from other groups, add to the selected one
            for(int groupCounter = 0; groupCounter < _correlationGroups.Count; groupCounter++)
            {
                List<int> customGroup = _correlationGroups[groupCounter];
                for (int i = 0; i < _nbNonQuantoSecurities; i++)
                {
                    if (_dataGridViewNonCorrel[_colSecurity, i].Selected)
                    {
                        for (int j = 0; j < _nbNonQuantoSecurities; j++)
                        {
                            if (_correlationDataTable.Rows[j][_colSecurity].ToString() ==
                                _dataGridViewNonCorrel[_colSecurity, i].Value.ToString())
                            {
                                _correlationDataTable.Rows[j][_colGroupIndex] = groupNumber;
                                if (customGroup.Contains(j) && groupCounter != groupNumber)
                                {
                                    customGroup.Remove(j);
                                }
                                else if (!customGroup.Contains(i) && groupCounter == groupNumber)
                                {
                                    customGroup.Add(j);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void SetCustomCorrelBumps(List<BumpPlot> bumpList)
        {
            _activeBumps = bumpList;
            UpdateDataGridCorrelsHisto(false);
        }

        private List<List<int>> _correlationGroups;
        #endregion
    }
}
