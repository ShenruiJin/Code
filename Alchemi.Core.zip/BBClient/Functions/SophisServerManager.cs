﻿using System;
using System.Collections.Generic;
using System.Text;
using MarketDataMgr;
using MarketDataMgr.Connections;
using MarketDataMgr.Requests;
using SharpTools.Data;
using MarketDataMgr.Trees;
using MarketDataTools.Constants;

namespace BBClient
{
    static class SophisServerManager
    {
        private static int _marketDataServerPort;
        private static string _marketDataServerIp;
        private static SophisConnection _sophisConnection;
        private static MarketDataManager _manager;
        private static DateTime _date;

        public static int MarketDataServerPort
        {
            get { return SophisServerManager._marketDataServerPort; }
        } 

        public static string MarketDataServerIp
        {
            get { return SophisServerManager._marketDataServerIp; }
        }

        // Init the connection
        public static void InitConnection(string ip, int port)
        {
            _date = DateTime.Now.Date;
            string date = DateUtils.ToSophisDate(_date).ToString();
            _marketDataServerIp = ip;
            _marketDataServerPort = port;
            _sophisConnection = new SophisConnection("Sophis", _marketDataServerIp, _marketDataServerPort, date);
            _manager = new MarketDataManager(_sophisConnection);
            _manager.CurrentTree = new MarketDataTree("myTree");
        }

        public static void RetrieveVolForwardList(List<string> underlyingList, double maturity,
            out List<MarketData.Volatility> volList, out List<MarketData.MarketDataDouble> forwardList)
        {
            volList = new List<MarketData.Volatility>();
            forwardList = new List<MarketData.MarketDataDouble>();
            string date = DateUtils.ToSophisDate(_date.AddDays((int)(maturity * 365.25))).ToString();

            // Reset the connection
            InitConnection(_marketDataServerIp, _marketDataServerPort);

            // Vol/Forward/Spot retrieval
			List<string> requestValues = new List<string>(new string[] { "forward", "volatility", "spot" });
            try
            {
                RequestsBatch batchRequests = new RequestsBatch();
                for (int counter = 0; counter < underlyingList.Count; counter++)
                {
                    string sj = underlyingList[counter];
                    // Add to batch each request retrieval
					foreach (string requestValue in requestValues)
					{
						Request requestMd = new Request("marketData" + ParsingConstants.RequestSeparator +
							"underlying" + ParsingConstants.RequestSeparator + sj,
							requestValue, sj + ParsingConstants.ArgumentSeparator + date);
						batchRequests.AddRequest(requestMd);
					}
                }

                // Get Vols
				_manager.LoadProperties(batchRequests);
                
                // Fill return lists
                foreach (string sj in underlyingList)
                {
					string prefix = "marketData" + MarketDataTree.PathDelimiter +
						"underlying" + MarketDataTree.PathDelimiter + sj + MarketDataTree.PathDelimiter;
					MarketData.Spot spot = (MarketData.Spot)_manager.GetProperty(prefix + "spot").Value;
					MarketData.MarketDataDouble forward = (MarketData.MarketDataDouble)_manager.GetProperty(prefix + "forward").Value;
                    forwardList.Add(new MarketData.MarketDataDouble(forward.Data / spot.Value));
					volList.Add((MarketData.Volatility)_manager.GetProperty(prefix + "volatility").Value);
                }
            }
            catch (Exception e)
            {
                throw(new Exception("Error while retrieving volatility and forward market data : " + e.Message));
            }
        }

        // Interpolation et parsing de vol via la matrice du marketdataserver
        // Version où on est uniquement intéressé par la vol
        public static double VolatilityFromMarketData(MarketData.Volatility vol, 
            double strike, double maturity)
        {
            double skew = 0;
            return VolatilityFromMarketData(vol, strike, maturity, out skew);
        }

        // Version skew ATM forward
        public static double VolatilityFromMarketData(MarketData.Volatility vol, double strike,
            double maturity, out double skew)
        {
            skew = 0;
            return VolatilityFromMarketData(vol, strike, maturity, 0.9, 1.1, out skew);
        }

        // Version full paramétrable
        public static double VolatilityFromMarketData(MarketData.Volatility vol, double strike, 
            double maturity, double strikeSkewLeft, double strikeSkewRight, out double skew)
        {
            // Conversion from custom maturities to double
            List<double> maturities = new List<double>();
            for (int i = 0; i < vol.Maturities.Count; i++)
            {
                string customMat = vol.Maturities[i];
                // Get the multiplying factor from the last character
                double factMult = 1;
                if (customMat.ToLower().EndsWith("d"))
                {
                    factMult = 1 / 365.25;
                }
                else if (customMat.ToLower().EndsWith("m"))
                {
                    factMult = 1 / 12.0;
                }
                // Parse to double from maturity string minus the last character
                double localMaturity = double.NaN;
                double.TryParse(customMat.Remove(customMat.Length - 1), out localMaturity);
                maturities.Add(localMaturity * factMult);
            }

            // Interpolation pour les 3 valeurs : vol(K,T), volSkew(KLeft, T), volSkew(KRight, T)
            double[] volValues = new double[3];
            double[] volStrikes = new double[volValues.Length];
            volStrikes[0] = strike;
            volStrikes[1] = strikeSkewLeft;
            volStrikes[2] = strikeSkewRight;
            for (int interpolCounter = 0; interpolCounter < volValues.Length; interpolCounter++)
            {
                #region Maturities
                int bottomIndexMaturity = 0;
                int counter = bottomIndexMaturity;
                while (counter < maturities.Count && maturities[counter] <= maturity)
                {
                    bottomIndexMaturity = counter;
                    counter++;
                }
                int topIndexMaturity = maturities.Count - 1;
                counter = topIndexMaturity;
                while (counter >= 0 && maturities[counter] >= maturity)
                {
                    topIndexMaturity = counter;
                    counter--;
                }
                #endregion
                double bottomMaturity = maturities[bottomIndexMaturity];
                double topMaturity = maturities[topIndexMaturity];

                #region Strikes
                int bottomIndexStrike = 0;
                counter = bottomIndexStrike;
                while (counter < vol.Strikes.Count && vol.Strikes[counter] <= volStrikes[interpolCounter])
                {
                    bottomIndexStrike = counter;
                    counter++;
                }
                int topIndexStrike = vol.Strikes.Count - 1;
                counter = topIndexStrike;
                while (counter >= 0 && vol.Strikes[counter] >= volStrikes[interpolCounter])
                {
                    topIndexStrike = counter;
                    counter--;
                }
                #endregion
                double bottomStrike = vol.Strikes[bottomIndexStrike];
                double topStrike = vol.Strikes[topIndexStrike];

                // Interpolation proprement dite
                double vol1 = vol.Matrix[bottomIndexMaturity][bottomIndexStrike];
                double vol2 = vol.Matrix[topIndexMaturity][bottomIndexStrike];
                double vol3 = vol.Matrix[bottomIndexMaturity][topIndexStrike];
                double vol4 = vol.Matrix[topIndexMaturity][topIndexStrike];

                // Calculer comme moyenne de l'interpolation sur axe des maturités 
                // et celle sur celui des strike
                double interpolationValue1 = vol1;
                if (vol1 != vol2 && bottomMaturity != topMaturity)
                {
                    interpolationValue1 += (vol2 - vol1) *
                        (maturity - bottomMaturity) / (bottomMaturity - topMaturity);
                }
                double interpolationValue2 = vol3;
                if (vol3 != vol4 && bottomMaturity != topMaturity)
                {
                    interpolationValue2 += (vol4 - vol3) *
                        (maturity - bottomMaturity) / (bottomMaturity - topMaturity);
                }

                volValues[interpolCounter] = (bottomStrike != topStrike) ?
                    (interpolationValue1 * (topStrike - volStrikes[interpolCounter]) +
                    interpolationValue2 * (volStrikes[interpolCounter] - bottomStrike)) / (topStrike - bottomStrike) : 
                    (interpolationValue1 + interpolationValue2) / 2;
            }
            
            // Skew = volStrikeLeft - volStrikeRight
            skew = volValues[1] - volValues[2];
            // Return vol
            return volValues[0];
        }

        public static Dictionary<string, double[]> MarketDataHistory(List<string> requestData,
            DateTime startDate, DateTime endDate)
        {
            Dictionary<string, double[]> resultDictionary = new Dictionary<string, double[]>();

            // Reset the connection
            InitConnection(_marketDataServerIp, _marketDataServerPort);

            // For each vol/skew/forward request, retrieve the entire set of data from startdate to enddate
            foreach (string request in requestData)
            {
                List<double> value = new List<double>();
                string[] requestParams = request.Split(new string[] { _delimiter }, StringSplitOptions.RemoveEmptyEntries);

                // Minimum number of params = 3 : type, underlying, 1st param
                if (requestParams.Length < 3)
                {
                    throw new Exception("Parameters missing in custom request " + value);
                }
                // Check numeric format constraint validity
                for (int paramIndex = 2; paramIndex < requestParams.Length; paramIndex++)
                {
                    double dummyDouble = 0;
                    if (!double.TryParse(requestParams[paramIndex], out dummyDouble))
                    {
                        throw new Exception("Numeric format error in custom request " + value);
                    }
                }
                // Retrieve market data type and underlyings
                if(!StringToMarketDataType.ContainsKey(requestParams[0].ToLower()))
                {
                    throw new Exception("Custom request data type unknown : " + requestParams[0]);
                }
                MarketDataHistoryType dataType = StringToMarketDataType[requestParams[0].ToLower()];
                string sj = requestParams[1];
                List<double> dynamicParams = new List<double>();

                string sophisRequest = String.Empty;

                // Request parsing               
                switch (dataType)
                {
                    case MarketDataHistoryType.Vol:
                        sophisRequest = "volatility";
                        if(requestParams.Length < 4)
                        {
                            throw new Exception("Missing number of parameters for vol request.");
                        }
                        dynamicParams.Add(double.Parse(requestParams[2]));
                        dynamicParams.Add(double.Parse(requestParams[3]));
                        break;
                    case MarketDataHistoryType.Skew:
                        sophisRequest = "volatility";
                        if(requestParams.Length < 5)
                        {
                            throw new Exception("Missing number of parameters for skew request.");
                        }
                        dynamicParams.Add(double.Parse(requestParams[2]));
                        dynamicParams.Add(double.Parse(requestParams[3]));
                        dynamicParams.Add(double.Parse(requestParams[4]));
                        break;
                    case MarketDataHistoryType.Forward:
                        sophisRequest = "forward";
                        dynamicParams.Add(double.Parse(requestParams[2]));
                        break;
                    default:
                        break;
                }

                // Data retrieval
                for (DateTime currentDate = startDate; currentDate <= endDate; currentDate = currentDate.AddDays(1))
                {
                    while (currentDate.DayOfWeek == DayOfWeek.Saturday || currentDate.DayOfWeek == DayOfWeek.Sunday)
                    {
                        currentDate = currentDate.AddDays(1);
                    }
                    string date = DateUtils.ToSophisDate(currentDate).ToString();
                    
                    try
                    {
                        Request req = new Request("marketData" + ParsingConstants.RequestSeparator + "underlying" +
                            ParsingConstants.RequestSeparator + sj,
                            sophisRequest, sj + ParsingConstants.ArgumentSeparator + date);
                        _manager.LoadProperty(req);
                    }
                    catch (Exception e)
                    {
                        throw (new Exception("Error while retrieving forward market data with underlying " + sj +
                            ": " + e.Message));
                    }

                    double histoValue = 0;
                    switch (dataType)
                    {
                        case MarketDataHistoryType.Vol:
                            MarketData.Volatility histoVol = (MarketData.Volatility)_manager.
                                GetProperty("marketData.underlying." + sj + ".volatility").Value;
                            histoValue = VolatilityFromMarketData(histoVol, dynamicParams[2], dynamicParams[3]);
                            break;
                        case MarketDataHistoryType.Skew:
                            MarketData.Volatility histoVolSkew = (MarketData.Volatility)_manager.
                                GetProperty("marketData.underlying." + sj + ".volatility").Value;
                            VolatilityFromMarketData(histoVolSkew, 100, dynamicParams[4], 
                                dynamicParams[2], dynamicParams[3], out histoValue);
                            break;
                        case MarketDataHistoryType.Forward:
                            MarketData.MarketDataDouble forward = (MarketData.MarketDataDouble)_manager.
                                GetProperty("marketData.underlying." + sj + ".forward").Value;
                            histoValue = forward.Data;
                            break;
                        default:
                            break;
                    }
                    value.Add(histoValue);
                }

                resultDictionary.Add(request, value.ToArray());
            }

            return resultDictionary;
        }

        private static string _delimiter = "#";
        public static string Delimiter
        {
            get { return _delimiter; }
        }
        private static Dictionary<string, MarketDataHistoryType> _stringToMarketDataType;
        public static Dictionary<string, MarketDataHistoryType> StringToMarketDataType
        {
            get
            {
                if (_stringToMarketDataType == null)
                {
                     _stringToMarketDataType = new Dictionary<string,MarketDataHistoryType>();
                    _stringToMarketDataType.Add("vol", MarketDataHistoryType.Vol);
                    _stringToMarketDataType.Add("skew", MarketDataHistoryType.Skew);
                    _stringToMarketDataType.Add("fwd", MarketDataHistoryType.Forward);
                }
                return _stringToMarketDataType;
            }
        }
    }

    public enum MarketDataHistoryType
    {
        Vol,
        Skew,
        Forward
    }
}
