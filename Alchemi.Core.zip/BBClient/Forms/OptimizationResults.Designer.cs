﻿namespace BBClient.Forms
{
    partial class OptimizationResults
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ToolBoxOptimisationParams = new System.Windows.Forms.GroupBox();
            this.labelAlgoState = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.labelBestBasketGeneration = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.buttonClose = new System.Windows.Forms.Button();
            this.labelMutations = new System.Windows.Forms.Label();
            this.labelCrossovers = new System.Windows.Forms.Label();
            this.labelGenerations = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.labelPremium = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.labelViewPopulationMember = new System.Windows.Forms.Label();
            this.numericUpDownSelectedIndividual = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.comboBoxSelectedBasket = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.dataGridViewBasket = new System.Windows.Forms.DataGridView();
            this.SecurityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ToolBoxOptimisationParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSelectedIndividual)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBasket)).BeginInit();
            this.SuspendLayout();
            // 
            // ToolBoxOptimisationParams
            // 
            this.ToolBoxOptimisationParams.Controls.Add(this.labelAlgoState);
            this.ToolBoxOptimisationParams.Controls.Add(this.label9);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelBestBasketGeneration);
            this.ToolBoxOptimisationParams.Controls.Add(this.label8);
            this.ToolBoxOptimisationParams.Controls.Add(this.buttonClose);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelMutations);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelCrossovers);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelGenerations);
            this.ToolBoxOptimisationParams.Controls.Add(this.label7);
            this.ToolBoxOptimisationParams.Controls.Add(this.label6);
            this.ToolBoxOptimisationParams.Controls.Add(this.label4);
            this.ToolBoxOptimisationParams.Controls.Add(this.label3);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelPremium);
            this.ToolBoxOptimisationParams.Controls.Add(this.label2);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelViewPopulationMember);
            this.ToolBoxOptimisationParams.Controls.Add(this.numericUpDownSelectedIndividual);
            this.ToolBoxOptimisationParams.Controls.Add(this.label1);
            this.ToolBoxOptimisationParams.Controls.Add(this.comboBoxSelectedBasket);
            this.ToolBoxOptimisationParams.Controls.Add(this.label5);
            this.ToolBoxOptimisationParams.Controls.Add(this.dataGridViewBasket);
            this.ToolBoxOptimisationParams.Dock = System.Windows.Forms.DockStyle.Top;
            this.ToolBoxOptimisationParams.Location = new System.Drawing.Point(0, 0);
            this.ToolBoxOptimisationParams.Name = "ToolBoxOptimisationParams";
            this.ToolBoxOptimisationParams.Size = new System.Drawing.Size(496, 403);
            this.ToolBoxOptimisationParams.TabIndex = 1;
            this.ToolBoxOptimisationParams.TabStop = false;
            this.ToolBoxOptimisationParams.Text = "Optimization Results";
            // 
            // labelAlgoState
            // 
            this.labelAlgoState.AutoSize = true;
            this.labelAlgoState.Location = new System.Drawing.Point(54, 32);
            this.labelAlgoState.Name = "labelAlgoState";
            this.labelAlgoState.Size = new System.Drawing.Size(89, 13);
            this.labelAlgoState.TabIndex = 31;
            this.labelAlgoState.Text = "Algorithm finished";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(13, 32);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 13);
            this.label9.TabIndex = 30;
            this.label9.Text = "State:";
            // 
            // labelBestBasketGeneration
            // 
            this.labelBestBasketGeneration.AutoSize = true;
            this.labelBestBasketGeneration.Location = new System.Drawing.Point(176, 147);
            this.labelBestBasketGeneration.Name = "labelBestBasketGeneration";
            this.labelBestBasketGeneration.Size = new System.Drawing.Size(13, 13);
            this.labelBestBasketGeneration.TabIndex = 29;
            this.labelBestBasketGeneration.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(13, 147);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(157, 13);
            this.label8.TabIndex = 28;
            this.label8.Text = "Best basket found in generation";
            // 
            // buttonClose
            // 
            this.buttonClose.Location = new System.Drawing.Point(16, 342);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(100, 42);
            this.buttonClose.TabIndex = 27;
            this.buttonClose.Text = "Close";
            this.buttonClose.UseVisualStyleBackColor = true;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // labelMutations
            // 
            this.labelMutations.AutoSize = true;
            this.labelMutations.Location = new System.Drawing.Point(176, 239);
            this.labelMutations.Name = "labelMutations";
            this.labelMutations.Size = new System.Drawing.Size(13, 13);
            this.labelMutations.TabIndex = 26;
            this.labelMutations.Text = "0";
            // 
            // labelCrossovers
            // 
            this.labelCrossovers.AutoSize = true;
            this.labelCrossovers.Location = new System.Drawing.Point(176, 212);
            this.labelCrossovers.Name = "labelCrossovers";
            this.labelCrossovers.Size = new System.Drawing.Size(13, 13);
            this.labelCrossovers.TabIndex = 25;
            this.labelCrossovers.Text = "0";
            // 
            // labelGenerations
            // 
            this.labelGenerations.AutoSize = true;
            this.labelGenerations.Location = new System.Drawing.Point(176, 184);
            this.labelGenerations.Name = "labelGenerations";
            this.labelGenerations.Size = new System.Drawing.Size(13, 13);
            this.labelGenerations.TabIndex = 24;
            this.labelGenerations.Text = "0";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Mutations count:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 212);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(92, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "Crossovers count:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(97, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Generations count:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(394, 357);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(15, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "%";
            // 
            // labelPremium
            // 
            this.labelPremium.AutoSize = true;
            this.labelPremium.Location = new System.Drawing.Point(353, 357);
            this.labelPremium.Name = "labelPremium";
            this.labelPremium.Size = new System.Drawing.Size(13, 13);
            this.labelPremium.TabIndex = 19;
            this.labelPremium.Text = "0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(282, 357);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(53, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Score :";
            // 
            // labelViewPopulationMember
            // 
            this.labelViewPopulationMember.AutoSize = true;
            this.labelViewPopulationMember.Enabled = false;
            this.labelViewPopulationMember.Location = new System.Drawing.Point(13, 100);
            this.labelViewPopulationMember.Name = "labelViewPopulationMember";
            this.labelViewPopulationMember.Size = new System.Drawing.Size(150, 13);
            this.labelViewPopulationMember.TabIndex = 16;
            this.labelViewPopulationMember.Text = "View final population member :";
            // 
            // numericUpDownSelectedIndividual
            // 
            this.numericUpDownSelectedIndividual.Enabled = false;
            this.numericUpDownSelectedIndividual.Location = new System.Drawing.Point(179, 93);
            this.numericUpDownSelectedIndividual.Name = "numericUpDownSelectedIndividual";
            this.numericUpDownSelectedIndividual.Size = new System.Drawing.Size(59, 20);
            this.numericUpDownSelectedIndividual.TabIndex = 15;
            this.numericUpDownSelectedIndividual.ValueChanged += new System.EventHandler(this.numericUpDownSelectedIndividual_ValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 70);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(36, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "View :";
            // 
            // comboBoxSelectedBasket
            // 
            this.comboBoxSelectedBasket.Items.AddRange(new object[] {
            "Best Basket Ever",
            "Worst basket Ever",
            "Basket of Final Population"});
            this.comboBoxSelectedBasket.Location = new System.Drawing.Point(87, 67);
            this.comboBoxSelectedBasket.Name = "comboBoxSelectedBasket";
            this.comboBoxSelectedBasket.Size = new System.Drawing.Size(151, 21);
            this.comboBoxSelectedBasket.TabIndex = 17;
            this.comboBoxSelectedBasket.SelectedIndexChanged += new System.EventHandler(this.comboBoxSelectedBasket_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(282, 16);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(102, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Basket underlyings :";
            // 
            // dataGridViewBasket
            // 
            this.dataGridViewBasket.AllowUserToAddRows = false;
            this.dataGridViewBasket.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBasket.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SecurityColumn});
            this.dataGridViewBasket.Location = new System.Drawing.Point(285, 32);
            this.dataGridViewBasket.Name = "dataGridViewBasket";
            this.dataGridViewBasket.RowHeadersVisible = false;
            this.dataGridViewBasket.Size = new System.Drawing.Size(103, 302);
            this.dataGridViewBasket.TabIndex = 1;
            // 
            // SecurityColumn
            // 
            this.SecurityColumn.DataPropertyName = "Security";
            this.SecurityColumn.HeaderText = "Security";
            this.SecurityColumn.Name = "SecurityColumn";
            // 
            // OptimizationResults
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(496, 409);
            this.Controls.Add(this.ToolBoxOptimisationParams);
            this.Name = "OptimizationResults";
            this.Text = "OptimizationResults";
            this.ToolBoxOptimisationParams.ResumeLayout(false);
            this.ToolBoxOptimisationParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownSelectedIndividual)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBasket)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ToolBoxOptimisationParams;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridViewBasket;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBoxSelectedBasket;
        private System.Windows.Forms.Label labelViewPopulationMember;
        private System.Windows.Forms.NumericUpDown numericUpDownSelectedIndividual;
        private System.Windows.Forms.Label labelPremium;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecurityColumn;
        private System.Windows.Forms.Label labelMutations;
        private System.Windows.Forms.Label labelCrossovers;
        private System.Windows.Forms.Label labelGenerations;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Label labelBestBasketGeneration;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label labelAlgoState;
        private System.Windows.Forms.Label label9;
    }
}