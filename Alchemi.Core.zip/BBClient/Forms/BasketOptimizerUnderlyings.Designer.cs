﻿using RemotingInterfaces;
namespace BBClient
{
    partial class BasketOptimizerUnderlyings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BasketOptimizerUnderlyings));
            this.panel1 = new System.Windows.Forms.Panel();
            this._buttonAddSubBasket = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this._buttonOpenBbgSector = new System.Windows.Forms.Button();
            this._buttonPreviewAll = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this._comboBoxBasket = new System.Windows.Forms.ComboBox();
            this._panelBasketDefinitions = new System.Windows.Forms.Panel();
            this.sophisSecuritiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cCDataSet = new CCDataSet();
            this.sophisSecuritiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter();
            this.bbgFieldsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bbgDescriptiveFieldsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter();
            this._previewGridView = new StructuringControls.ExcelDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.datagridviewcolumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this._labelPreviewBasket = new System.Windows.Forms.Label();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bbgFieldsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._previewGridView)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 469);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(904, 20);
            this.panel1.TabIndex = 4;
            // 
            // _buttonAddSubBasket
            // 
            this._buttonAddSubBasket.Location = new System.Drawing.Point(209, 12);
            this._buttonAddSubBasket.Name = "_buttonAddSubBasket";
            this._buttonAddSubBasket.Size = new System.Drawing.Size(100, 23);
            this._buttonAddSubBasket.TabIndex = 4;
            this._buttonAddSubBasket.Text = "New basket";
            this._buttonAddSubBasket.UseVisualStyleBackColor = true;
            this._buttonAddSubBasket.Click += new System.EventHandler(this._buttonAddSubBasket_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this._buttonOpenBbgSector);
            this.panel3.Controls.Add(this._buttonPreviewAll);
            this.panel3.Controls.Add(this.label1);
            this.panel3.Controls.Add(this._comboBoxBasket);
            this.panel3.Controls.Add(this._buttonAddSubBasket);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(0, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(750, 47);
            this.panel3.TabIndex = 5;
            // 
            // _buttonOpenBbgSector
            // 
            this._buttonOpenBbgSector.Location = new System.Drawing.Point(533, 12);
            this._buttonOpenBbgSector.Name = "_buttonOpenBbgSector";
            this._buttonOpenBbgSector.Size = new System.Drawing.Size(117, 23);
            this._buttonOpenBbgSector.TabIndex = 8;
            this._buttonOpenBbgSector.Text = "Open Bbg sector list";
            this._buttonOpenBbgSector.UseVisualStyleBackColor = true;
            this._buttonOpenBbgSector.Click += new System.EventHandler(this._buttonOpenBbgSector_Click);
            // 
            // _buttonPreviewAll
            // 
            this._buttonPreviewAll.Location = new System.Drawing.Point(656, 12);
            this._buttonPreviewAll.Name = "_buttonPreviewAll";
            this._buttonPreviewAll.Size = new System.Drawing.Size(88, 23);
            this._buttonPreviewAll.TabIndex = 7;
            this._buttonPreviewAll.Text = "Preview all";
            this._buttonPreviewAll.UseVisualStyleBackColor = true;
            this._buttonPreviewAll.Click += new System.EventHandler(this._buttonPreviewAll_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(30, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Basket :";
            // 
            // _comboBoxBasket
            // 
            this._comboBoxBasket.FormattingEnabled = true;
            this._comboBoxBasket.Location = new System.Drawing.Point(82, 14);
            this._comboBoxBasket.Name = "_comboBoxBasket";
            this._comboBoxBasket.Size = new System.Drawing.Size(121, 21);
            this._comboBoxBasket.TabIndex = 5;
            this._comboBoxBasket.SelectedIndexChanged += new System.EventHandler(this._comboBoxBasket_SelectedIndexChanged);
            // 
            // _panelBasketDefinitions
            // 
            this._panelBasketDefinitions.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelBasketDefinitions.Location = new System.Drawing.Point(0, 47);
            this._panelBasketDefinitions.Name = "_panelBasketDefinitions";
            this._panelBasketDefinitions.Size = new System.Drawing.Size(750, 422);
            this._panelBasketDefinitions.TabIndex = 6;
            // 
            // sophisSecuritiesBindingSource
            // 
            this.sophisSecuritiesBindingSource.DataMember = "SophisSecurities";
            this.sophisSecuritiesBindingSource.DataSource = this.cCDataSet;
            // 
            // cCDataSet
            // 
            this.cCDataSet.DataSetName = "CCDataSet";
            this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // sophisSecuritiesTableAdapter
            // 
            this.sophisSecuritiesTableAdapter.ClearBeforeFill = true;
            // 
            // bbgFieldsBindingSource
            // 
            this.bbgFieldsBindingSource.DataMember = "BbgDescriptiveFields";
            this.bbgFieldsBindingSource.DataSource = this.cCDataSet;
            // 
            // bbgDescriptiveFieldsTableAdapter
            // 
            this.bbgDescriptiveFieldsTableAdapter.ClearBeforeFill = true;
            // 
            // _previewGridView
            // 
            this._previewGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LemonChiffon;
            this._previewGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this._previewGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._previewGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.datagridviewcolumn2});
            this._previewGridView.CorrelationDataTable = null;
            this._previewGridView.DataComplete = "OK";
            this._previewGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._previewGridView.EmphasisColor = System.Drawing.Color.Red;
            this._previewGridView.EmphasizedCount = -2147483648;
            this._previewGridView.GroupIndexColumn = -2147483648;
            this._previewGridView.GroupList = ((System.Collections.Generic.List<System.Collections.Generic.List<int>>)(resources.GetObject("_previewGridView.GroupList")));
            this._previewGridView.HistoricalDataIncompleteColumn = -2147483648;
            this._previewGridView.IncompleteColor = System.Drawing.Color.Red;
            this._previewGridView.IsCustomGroup = false;
            this._previewGridView.IsPaintable = false;
            this._previewGridView.Location = new System.Drawing.Point(0, 18);
            this._previewGridView.MissingColor = System.Drawing.Color.Red;
            this._previewGridView.MissingData = "#N/A Sec";
            this._previewGridView.MissingDataReferenceColumn = -2147483648;
            this._previewGridView.Name = "_previewGridView";
            this._previewGridView.ReadOnly = true;
            this._previewGridView.RowHeadersVisible = false;
            this._previewGridView.Size = new System.Drawing.Size(154, 451);
            this._previewGridView.TabIndex = 7;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Security";
            this.dataGridViewTextBoxColumn1.HeaderText = "";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // datagridviewcolumn2
            // 
            this.datagridviewcolumn2.DataPropertyName = "Group";
            this.datagridviewcolumn2.HeaderText = "Column1";
            this.datagridviewcolumn2.Name = "datagridviewcolumn2";
            this.datagridviewcolumn2.ReadOnly = true;
            this.datagridviewcolumn2.Visible = false;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this._panelBasketDefinitions);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(750, 469);
            this.panel2.TabIndex = 8;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this._previewGridView);
            this.panel4.Controls.Add(this._labelPreviewBasket);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(750, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(154, 469);
            this.panel4.TabIndex = 9;
            // 
            // _labelPreviewBasket
            // 
            this._labelPreviewBasket.BackColor = System.Drawing.Color.Blue;
            this._labelPreviewBasket.Dock = System.Windows.Forms.DockStyle.Top;
            this._labelPreviewBasket.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this._labelPreviewBasket.Location = new System.Drawing.Point(0, 0);
            this._labelPreviewBasket.Name = "_labelPreviewBasket";
            this._labelPreviewBasket.Size = new System.Drawing.Size(154, 18);
            this._labelPreviewBasket.TabIndex = 20;
            this._labelPreviewBasket.Text = "No basket defined";
            this._labelPreviewBasket.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // BasketOptimizerUnderlyings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(904, 489);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BasketOptimizerUnderlyings";
            this.Text = "Advanced Basket Creation";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bbgFieldsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._previewGridView)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button _buttonAddSubBasket;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox _comboBoxBasket;
        private System.Windows.Forms.Button _buttonPreviewAll;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel _panelBasketDefinitions;
        private System.Windows.Forms.BindingSource sophisSecuritiesBindingSource;
        private CCDataSet cCDataSet;
        private RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter sophisSecuritiesTableAdapter;
        private System.Windows.Forms.BindingSource bbgFieldsBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter bbgDescriptiveFieldsTableAdapter;
        private StructuringControls.ExcelDataGridView _previewGridView;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label _labelPreviewBasket;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn datagridviewcolumn2;
        private System.Windows.Forms.Button _buttonOpenBbgSector;
    }
}