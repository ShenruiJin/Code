﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using BbgProcesser;
using RemotingInterfaces;
using CaesarApplication.Service.Connection;

namespace BBClient
{
    delegate void NoArgThread();

    public partial class BasketOptimizerUnderlyings : Form
    {
        public event EventHandler RefreshBasket;
        public BasketOptimizerUnderlyings(BasketOptimizer basketOptimizer)
        {
            InitializeComponent();
			InitForm(basketOptimizer);

			// Launch data retrieval
			InitData();
        }

        private void InitForm(BasketOptimizer basketOptimizer)
        {
            this.FormClosing += new FormClosingEventHandler(BasketOptimizerUnderlyings_FormClosing);
            _basketOptimizer = basketOptimizer;
            _listBasketDefinition = new List<BasketDefinition>();

            // Datatable definition
            _previewDataTable = new DataTable();
            _previewDataTable.Columns.Add("Security", typeof(string));
            _previewDataTable.Columns.Add("Group", typeof(int));
            while (_previewDataTable.Rows.Count < 50)
            {
                _previewDataTable.Rows.Add(_previewDataTable.NewRow());
            }

            // Init Gui
            _previewGridView.DataSource = _previewDataTable;
            _previewGridView.GroupIndexColumn = _previewDataTable.Columns.Count - 1;
            _previewGridView.IsCustomGroup = true;

            AddNewBasket();
        }

		private void InitData()
		{
			// TODO: This line of code loads data into the 'cCDataSet.BbgDescriptiveFields' table. You can move, or remove it, as needed.
			this.bbgDescriptiveFieldsTableAdapter.Fill(this.cCDataSet.BbgDescriptiveFields);
			// TODO: This line of code loads data into the 'cCDataSet.SophisSecurities' table. You can move, or remove it, as needed.
			this.sophisSecuritiesTableAdapter.Fill(this.cCDataSet.SophisSecurities);
		}


        void BasketOptimizerUnderlyings_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
            if (RefreshBasket != null)
            {
                RefreshBasket(this, new EventArgs());
            }
        }

        // Return bbg description for every underlying if it exists - if not, build it first
		public DataTable GetDescriptiveBbgData()
        {
            return cCDataSet.SophisSecurities;
        }

        private void _buttonAddSubBasket_Click(object sender, EventArgs e)
        {
			AddNewBasket();
			// Uncomment to enable database update
			//UpdateDescriptiveBbgInfo();
        }

        private void AddNewBasket()
        {
			BasketDefinition bd = new BasketDefinition(this);
            bd.Location = new Point(0, 0);
            bd.PreviewBasket += new EventHandler(bd_PreviewBasket);
            _panelBasketDefinitions.Controls.Add(bd);
            _panelBasketDefinitions.Controls.SetChildIndex(bd, 0);
            bd.Dock = DockStyle.Fill;
            _listBasketDefinition.Add(bd);
            _comboBoxBasket.Items.Add(_panelBasketDefinitions.Controls.Count);
            _comboBoxBasket.SelectedIndex = _panelBasketDefinitions.Controls.Count - 1;
        }

        #region Preview methods
        // Event handler for single preview by a BasketDefinition
        private void bd_PreviewBasket(object sender, EventArgs e)
        {
            PreviewSingleBasket(sender as BasketDefinition);
        }

        // Change the displayed basket
        private void ShowBasket(int counter)
        {
            _panelBasketDefinitions.Controls[_panelBasketDefinitions.Controls.Count - counter - 1].Visible = true;
            for (int i = 0; i < _panelBasketDefinitions.Controls.Count; i++)
            {
                if (i != _panelBasketDefinitions.Controls.Count - counter - 1)
                {
                    _panelBasketDefinitions.Controls[i].Visible = false;
                }
            }
        }

        private void _comboBoxBasket_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowBasket(_comboBoxBasket.SelectedIndex);
        }

        private void _buttonPreviewAll_Click(object sender, EventArgs e)
        {
            List<KeyValuePair<string, int>> securityGroupList = new List<KeyValuePair<string, int>>();

            // Loop through each Basket to extract its underlying list
            for (int counter = 0; counter < _listBasketDefinition.Count; counter++ )
            {
                BasketPreview(ref securityGroupList, counter);
            }
            DisplayPreview(securityGroupList);
            _labelPreviewBasket.Text = "Global basket";
        }

        private void PreviewSingleBasket(BasketDefinition basketDef)
        {
            Predicate<BasketDefinition> predBasketDef = new Predicate<BasketDefinition>(
                delegate(BasketDefinition bd) { return bd == basketDef; });
            int counter = _listBasketDefinition.FindIndex(predBasketDef);
            List<KeyValuePair<string, int>> securityGroupList = new List<KeyValuePair<string, int>>();
            BasketPreview(ref securityGroupList, counter);
            DisplayPreview(securityGroupList);

            _labelPreviewBasket.Text = "Basket " + (counter + 1);
        }

        // General method to retrieve the basket data
        private int BasketPreview(ref List<KeyValuePair<string, int>> securityGroupList, int counter)
        {
            int nbStocks = 0;
            if (counter < _listBasketDefinition.Count && securityGroupList != null)
            {
                BasketDefinitionComposition compo = _listBasketDefinition[counter].GetComposition();
                if (compo.UnderlyingList != null)
                {
                    foreach (string underlying in compo.UnderlyingList)
                    {
                        securityGroupList.Add(new KeyValuePair<string, int>(underlying, counter));
                    }
                    nbStocks = compo.NbStocks;
                }
            }

            return nbStocks;
        }

        // GUI method to display underlyings in the preview datagrid
        private void DisplayPreview(List<KeyValuePair<string, int>> securityGroupList)
        {
            List<string> listNonDuplicates = new List<string>();
            List<string> listDuplicates = new List<string>();
            _previewDataTable.Rows.Clear();
            foreach (KeyValuePair<string, int> valuePair in securityGroupList)
            {
                if (!listNonDuplicates.Contains(valuePair.Key))
                {
                    _previewDataTable.Rows.Add(new object[] { valuePair.Key, valuePair.Value });
                    listNonDuplicates.Add(valuePair.Key);
                }
                else
                {
                    if (!listDuplicates.Contains(valuePair.Key))
                    {
                        listDuplicates.Add(valuePair.Key);
                    }
                }
            }

            // Message window if stocks have been removed due to several occurrences
            if (listDuplicates.Count > 0)
            {
                string errorString = "Duplicate securities among baskets ; the following underlyings have been removed after their first occurrence.";
                foreach (string str in listDuplicates)
                {
                    errorString += "\n" + str;
                }
                MessageBox.Show(errorString);
            }
        }

        public List<KeyValuePair<string, int>> GetAdvancedBasket(ref List<int> listNbStocks)
        {
            List<KeyValuePair<string, int>> securityGroupList = new List<KeyValuePair<string, int>>();
            listNbStocks = new List<int>();
            // Loop through each Basket to extract its underlying list
            for (int counter = 0; counter < _listBasketDefinition.Count; counter++)
            {
                listNbStocks.Add(BasketPreview(ref securityGroupList, counter));                
            }
            return securityGroupList;
        }
        #endregion

		/// <summary>
		/// Update the SophisSecurities table with all liquidity info
		/// </summary>
        private void UpdateDescriptiveBbgInfo()
        {
			// Only update if initialization has been done correctly (ie open the correlation form)
			if (CorrelFactory.ForexFactors.Count > 0)
			{
				// Init the request list
				List<string> requestList = new List<string>();

				// Single query for each field in the static list
				BbgQuery query = new BbgQuery();
				// Force the close to be retrieved for liquidity calculations
				DataSet ds = new DataSet();

				try
				{
					// Add each query field in the DB
					foreach (DataRow row in cCDataSet.BbgDescriptiveFields.Rows)
					{
						string field = Convert.ToString(row[DBSchema.BbgDescriptiveField]);
						if (!query.FieldsList.Contains(field))
						{
							query.FieldsList.Add(field);
						}
					}
                    // If retrieving from file, uncomment these lines
                    System.IO.TextReader tr = new System.IO.StreamReader("C:\\natixis\\ListSophis.txt");
                    string ul = string.Empty;
                    while ((ul = tr.ReadLine()) != null)
                    {
                        ul = tr.ReadLine().Trim();
                        if (!query.SecuritiesList.Contains(ul) && ul != string.Empty)
                        {
                            query.SecuritiesList.Add(ul);
                        }
                        DataRow newRow = cCDataSet.SophisSecurities.NewRow();
                        newRow[BbgMnemonics.Security] = ul;
                        cCDataSet.SophisSecurities.Rows.Add(newRow);

                    }
                    tr.Close();
                    

					// Add each security in the DB
					foreach (DataRow row in cCDataSet.SophisSecurities.Rows)
					{
						string underlying = Convert.ToString(row[BbgMnemonics.Security]).ToUpper();
						if (underlying.Trim() != string.Empty && !query.SecuritiesList.Contains(underlying))
						{
							query.SecuritiesList.Add(underlying);
						}
					}
					query.IsStatic = true;
					ds = Remoter.Send(query);
					DataTable dataTable = ds.Tables[BbgMnemonics.DataTableIndex];

					// New data retrieval, this time non static
					query.FieldsList.Clear();
					query.FieldsList.Add(_priceMnemonic);
					query.IsStatic = false;
					// Add currencies
					foreach (DataRow row in dataTable.Rows)
					{
						string currency = Convert.ToString(row[BbgMnemonics.Currency]).ToUpper();
						if (!query.SecuritiesList.Contains(currency + _priceQuanto))
						{
							query.SecuritiesList.Add(currency + _priceQuanto);
						}
					}
					DataSet priceDataSet = Remoter.Send(query);

					dataTable.Columns.Add(_priceMnemonic, typeof(double));
					foreach (DataRow row in dataTable.Rows)
					{
						string underlying = Convert.ToString(row[BbgMnemonics.Security]).ToUpper();
						string currency = Convert.ToString(row[BbgMnemonics.Currency]).ToUpper();
						string priceAsString = priceDataSet.Tables[BbgMnemonics.DataTableIndex].Select(
							BbgMnemonics.Security + " = '" + underlying + "'")[0][_priceMnemonic].ToString();
						DataRow[] quantoSelect = priceDataSet.Tables[BbgMnemonics.DataTableIndex].Select(
							BbgMnemonics.Security + " = '" + currency + _priceQuanto + _curncySuffix + "'");
						string quantoAsString = quantoSelect.Length > 0 ?
							quantoSelect[0][_priceMnemonic].ToString() : "1";
						double price = 0;
						double.TryParse(priceAsString, out price);
						double quanto = 0;
						double.TryParse(quantoAsString, out quanto);
						row[_priceMnemonic] = price * quanto;
					}

					// Hack code to convert volumes from strings to numbers
					Dictionary<string, string> convertColumns = new Dictionary<string, string>();

					// Retrieve columns which have a non-consistent data type
					foreach (DataRow row in cCDataSet.BbgDescriptiveFields.Rows)
					{
						string field = row[DBSchema.BbgDescriptiveField].ToString();
						if (row[DBSchema.BbgDescriptiveType].ToString() != dataTable.Columns[field].DataType.Name.ToLower())
						{
							if (!convertColumns.ContainsKey(field))
							{
								convertColumns.Add(field, row[DBSchema.BbgDescriptiveType].ToString());
							}
						}
					}

					// Create temporary columns, fill with converted data, drop old columns and change name
					foreach (string key in convertColumns.Keys)
					{
						// Create a temporary column of the required type
						Type curType = Type.GetType("System." + convertColumns[key], false, true);
						if (curType == null)
						{
							curType = typeof(string);
						}
						dataTable.Columns.Add(_tempColPrefix + key, curType);

						// Add converted data
						foreach (DataRow row in dataTable.Rows)
						{
							object convertedData = null;
							if (curType.IsValueType)
							{
								convertedData = 0;
							}
							try
							{
								if (curType == typeof(double))
								{
									double result;
									double.TryParse(row[key].ToString(), out result);
									convertedData = result;
								}
								else if (curType == typeof(int))
								{
									int result;
									int.TryParse(row[key].ToString(), out result);
									convertedData = result;
								}
								else
								{
									convertedData = Convert.ChangeType(row[key].ToString(), curType);
								}
							}
							// Data conversion error
							catch
							{
							}
							row[_tempColPrefix + key] = convertedData;
						}

						// Drop old column
						dataTable.Columns.Remove(key);

						// Update name
						dataTable.Columns[_tempColPrefix + key].ColumnName = key;
					}

					// Average value computation override
					foreach (DataRow row in cCDataSet.BbgDescriptiveFields.Rows)
					{
						// If we need to recalculate this column values
						if (Convert.ToInt32(row[DBSchema.BbgDescriptiveIsDynamic]) == 1)
						{
							string bindToColumn = Convert.ToString(row[DBSchema.BbgDescriptiveBindsTo]);
							string columnName = row[DBSchema.BbgDescriptiveField].ToString();
							if (dataTable.Columns[columnName].DataType == typeof(double))
							{
								foreach (DataRow subRow in dataTable.Rows)
								{
									string currency = subRow[BbgMnemonics.Currency].ToString().ToUpper();
									double price = Convert.ToDouble(subRow[_priceMnemonic].ToString());
									// For quanto factor
									if (CorrelFactory.ForexFactors.ContainsKey(currency + _priceQuanto))
									{
										price /= CorrelFactory.ForexFactors[currency + _priceQuanto];
									}
									// For penny stocks
									if (currency != _priceQuanto && CorrelFactory.ForexFactors.ContainsKey(currency + currency))
									{
										price /= CorrelFactory.ForexFactors[currency + currency];
									}
									double bindingData = Convert.ToDouble(subRow[bindToColumn].ToString());
									subRow[columnName] = price * bindingData;
								}
							}
						}
					}

					foreach (DataRow row in dataTable.Rows)
					{
						string underlying = Convert.ToString(row[BbgMnemonics.Security]).ToUpper();
                        bool isFound = false;
						foreach (DataRow row2 in cCDataSet.SophisSecurities.Rows)
						{
							string underlying2 = Convert.ToString(row2[BbgMnemonics.Security]).ToUpper();
                            
							if (underlying.StartsWith(underlying2) && underlying2 != String.Empty)
							{
								foreach (DataColumn col in cCDataSet.SophisSecurities.Columns)
								{
									if (dataTable.Columns.Contains(col.ColumnName) && col.ColumnName != BbgMnemonics.Security && col.ColumnName != "Type")
									{
										row2[col.ColumnName] = row[col.ColumnName];
                                        isFound = true;
									}
								}
							}
						}
                        if (!isFound)
                        {
                            DataRow row3 = cCDataSet.SophisSecurities.NewRow();
                            foreach (DataColumn col in cCDataSet.SophisSecurities.Columns)
                            { 
                                if (dataTable.Columns.Contains(col.ColumnName) && col.ColumnName != BbgMnemonics.Security && col.ColumnName != "Type")
                                {
                                    row3[col.ColumnName] = row[col.ColumnName];
                                }
                            }
                            cCDataSet.SophisSecurities.Rows.Add(row3);
                        }
					}
					sophisSecuritiesTableAdapter.Update(cCDataSet.SophisSecurities);

				}
				catch (Exception ex)
				{
					MessageBox.Show("Error on securities data retrieval : " + ex.Message);
				}

				_bbgDescriptiveDs = ds;
			}
        }

        private void _buttonOpenBbgSector_Click(object sender, EventArgs e)
        {
			string path = @"\\cib.net\shareparis\Soft\ED_ExcelTools\Parameters\Caesar\DB\BloombergCodes.xls";
            if (!System.IO.File.Exists(path))
            {
                MessageBox.Show("The file " + path + " cannot be accessed.");
            }
            else
            {
                System.Diagnostics.Process.Start(path);
            }
        }

        private BasketOptimizer _basketOptimizer;
        private List<BasketDefinition> _listBasketDefinition;
        private DataSet _bbgDescriptiveDs;
        private DataTable _previewDataTable;
        private const string _tempColPrefix = "TempCol";
        private const string _priceMnemonic = "LAST_PRICE";
        private const string _priceQuanto = "EUR";
        private const string _curncySuffix = " Curncy";
    }
}