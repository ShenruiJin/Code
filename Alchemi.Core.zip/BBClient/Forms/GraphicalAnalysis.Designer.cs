﻿namespace BBClient
{
    partial class GraphicalAnalysis
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GraphicalAnalysis));
            this._zedGraphControl = new ZedGraph.ZedGraphControl();
            this._button = new System.Windows.Forms.Button();
            this._saveFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.SuspendLayout();
            // 
            // _zedGraphControl
            // 
            this._zedGraphControl.Location = new System.Drawing.Point(154, 69);
            this._zedGraphControl.Name = "_zedGraphControl";
            this._zedGraphControl.ScrollGrace = 0;
            this._zedGraphControl.ScrollMaxX = 0;
            this._zedGraphControl.ScrollMaxY = 0;
            this._zedGraphControl.ScrollMaxY2 = 0;
            this._zedGraphControl.ScrollMinX = 0;
            this._zedGraphControl.ScrollMinY = 0;
            this._zedGraphControl.ScrollMinY2 = 0;
            this._zedGraphControl.Size = new System.Drawing.Size(670, 349);
            this._zedGraphControl.TabIndex = 0;
            this._zedGraphControl.ZoomButtons = System.Windows.Forms.MouseButtons.None;
            // 
            // _button
            // 
            this._button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this._button.Location = new System.Drawing.Point(12, 12);
            this._button.Name = "_button";
            this._button.Size = new System.Drawing.Size(84, 23);
            this._button.TabIndex = 1;
            this._button.Text = "Save to file ...";
            this._button.UseVisualStyleBackColor = true;
            this._button.Click += new System.EventHandler(this._button_Click);
            // 
            // _saveFileDialog
            // 
            this._saveFileDialog.Filter = "CSV files|*.csv|All file|*.*";
            // 
            // GraphicalAnalysis
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 442);
            this.Controls.Add(this._button);
            this.Controls.Add(this._zedGraphControl);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "GraphicalAnalysis";
            this.Text = "Graphical Correlation Analysis";
            this.Resize += new System.EventHandler(this.GraphicalAnalysis_Resize);
            this.Load += new System.EventHandler(this.GraphicalAnalysis_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ZedGraph.ZedGraphControl _zedGraphControl;
        private System.Windows.Forms.Button _button;
        private System.Windows.Forms.SaveFileDialog _saveFileDialog;
    }
}