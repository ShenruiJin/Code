﻿using ScriptTools.Reflection;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BBClient.Forms
{
    public partial class ProductSelectionOptimizer : BBForm
    {
        public ProductSelectionOptimizer(int count)
        {
            InitializeComponent();
            combBoxproductSelect.Items.Clear();
            for (int i=0; i< count;i++)
            {
                combBoxproductSelect.Items.Add(CaesarApplication.Service.Strategy.StrategyService.CurrentStrategy.GetLeafProducts()[i].Product.Name);
            }
            combBoxproductSelect.SelectedIndex = 0;
        }

        private void buttonContinue_Click(object sender, EventArgs e)
        {
            int index = combBoxproductSelect.SelectedIndex;
            var strategydatasetelement = CaesarApplication.Service.Strategy.StrategyService.CurrentStrategy.GetLeafProducts()[index];
                        
            if (strategydatasetelement.Product.IsBuilded)
            {
                var product = strategydatasetelement.Product;
                var BaseProduct = product.GetPricingProduct(false, strategydatasetelement.MarketDataTree);
                var allAvailableWrappers = GenericCompiler.CreateDataDescription(BaseProduct);

                //GenericCompiler.SetField(BaseProduct, "_strike", 0.80);
                double strike;
                double tenor;
                string currency = "EUR";
                TimeSpan maturity;
                PricingBase.Product.CsInfoContainer.Currency ccy;

                strike = (double)GenericCompiler.GetField(BaseProduct, "strike");
                maturity = (TimeSpan)GenericCompiler.GetField(BaseProduct, "_maturityDate");
                tenor = maturity.Days;
                ccy = (PricingBase.Product.CsInfoContainer.Currency)GenericCompiler.GetField(BaseProduct, "currency");
                currency = ccy.Name;
                BasketOptimizerNew BasketOptimizer = new BasketOptimizerNew(index, tenor, strike, currency);
                this.Hide();
                BasketOptimizer.Show();

            }
            else
            {
                string errorString = "Please make sure specify a deal to start an optimization";
                MessageBox.Show(errorString);
            }

        }

        
    }
}
