﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace BBClient
{
    public partial class ClientSettings : Form
    {
        public ClientSettings()
        {
            InitializeComponent();

            // Retrieve the server url if there is a settings file
            try
            {
                foreach (string key in ConfigurationManager.AppSettings)
                {
                    if (key == _keyServerUrl)
                    {
                        this._textBoxBbgServerUrl.Text = ConfigurationManager.AppSettings[key];
                    }
                    else if (key == _keyMarketDataServerUrl)
                    {
                        this._textBoxMarketDataServerUrl.Text = ConfigurationManager.AppSettings[key];
                    }
                }
            }
            catch
            {
                MessageBox.Show("Error while loading the settings file.\nSave an url and restart the program to fix this.");
            }
        }

        private void _buttonSave_Click(object sender, EventArgs e)
        {
            // Open App.Config of executable
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            // Add an Application Setting
            config.AppSettings.Settings.Remove(_keyServerUrl);
            config.AppSettings.Settings.Add(_keyServerUrl, _textBoxBbgServerUrl.Text);

            string marketDataServerUrl = _textBoxMarketDataServerUrl.Text;
            //if (marketDataServerUrl.Contains(":"))
            //{
                config.AppSettings.Settings.Remove(_keyMarketDataServerUrl);
                string[] urlSplit = marketDataServerUrl.Split(':');
                config.AppSettings.Settings.Add(_keyMarketDataServerUrl, urlSplit[0] + ":8000");
            //}
            //else
            //{
            //    MessageBox.Show("Market data server url textbox doesn't contain a ':' ; check data entry");
            //}

            // Save the changes in App.config file
            config.Save(ConfigurationSaveMode.Modified);

            // Force a reload of a changed section
            ConfigurationManager.RefreshSection("appSettings");
        }

        private static string _keyServerUrl = "serverUrl";
        private static string _keyMarketDataServerUrl = "marketDataServerUrl";

        public string Url
        {
            get { return this._textBoxBbgServerUrl.Text; }
            set { this._textBoxBbgServerUrl.Text = value; }
        }

        public string DataServerIp
        {
            get
            {
				return _textBoxMarketDataServerUrl.Text.Split(':')[0];
            }
        }

        public int DataServerPort
        {
            get
            {
                if (_textBoxMarketDataServerUrl.Text.Contains(":"))
                {
                    return int.Parse(_textBoxMarketDataServerUrl.Text.Split(':')[1]);
                }
                else
                {
                    return 8000; // int.MaxValue;
                }
            }
        }
    }
}