﻿namespace BBClient
{
    partial class ClientSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._buttonSave = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this._textBoxBbgServerUrl = new System.Windows.Forms.TextBox();
            this._labelUrl = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this._textBoxMarketDataServerUrl = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // _buttonSave
            // 
            this._buttonSave.DialogResult = System.Windows.Forms.DialogResult.OK;
            this._buttonSave.Location = new System.Drawing.Point(226, 127);
            this._buttonSave.Name = "_buttonSave";
            this._buttonSave.Size = new System.Drawing.Size(109, 23);
            this._buttonSave.TabIndex = 0;
            this._buttonSave.Text = "Save settings";
            this._buttonSave.UseVisualStyleBackColor = true;
            this._buttonSave.Click += new System.EventHandler(this._buttonSave_Click);
            // 
            // button2
            // 
            this.button2.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.button2.Location = new System.Drawing.Point(341, 127);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Cancel";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // _textBoxBbgServerUrl
            // 
            this._textBoxBbgServerUrl.Location = new System.Drawing.Point(138, 37);
            this._textBoxBbgServerUrl.Name = "_textBoxBbgServerUrl";
            this._textBoxBbgServerUrl.Size = new System.Drawing.Size(253, 20);
            this._textBoxBbgServerUrl.TabIndex = 2;
            this._textBoxBbgServerUrl.Text = "tcp://10.14.6.37:7654/RemoteBbg";
            // 
            // _labelUrl
            // 
            this._labelUrl.AutoSize = true;
            this._labelUrl.Location = new System.Drawing.Point(19, 40);
            this._labelUrl.Name = "_labelUrl";
            this._labelUrl.Size = new System.Drawing.Size(120, 13);
            this._labelUrl.TabIndex = 3;
            this._labelUrl.Text = "Bloomberg server URL :";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this._textBoxMarketDataServerUrl);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this._textBoxBbgServerUrl);
            this.groupBox1.Controls.Add(this._labelUrl);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(404, 109);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Connection settings";
            // 
            // _textBoxMarketDataServerUrl
            // 
            this._textBoxMarketDataServerUrl.Location = new System.Drawing.Point(138, 72);
            this._textBoxMarketDataServerUrl.Name = "_textBoxMarketDataServerUrl";
            this._textBoxMarketDataServerUrl.Size = new System.Drawing.Size(253, 20);
            this._textBoxMarketDataServerUrl.TabIndex = 4;
            this._textBoxMarketDataServerUrl.Text = "10.14.18.122:8000";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(37, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(102, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "Sophis server URL :";
            // 
            // ClientSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(428, 162);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this._buttonSave);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Name = "ClientSettings";
            this.Text = "Settings";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button _buttonSave;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox _textBoxBbgServerUrl;
        private System.Windows.Forms.Label _labelUrl;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox _textBoxMarketDataServerUrl;
        private System.Windows.Forms.Label label1;
    }
}