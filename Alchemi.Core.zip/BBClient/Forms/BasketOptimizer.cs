﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Maths.Optimization;
using MarketDataMgr;
using MarketDataMgr.Connections;
using MarketDataMgr.Requests;
using MarketDataMgr.Trees;
using BbgProcesser;
using Estimators;
using Pricing.MarketData.Container;

namespace BBClient
{
    public partial class BasketOptimizer : BBForm
    {
        public BasketOptimizer()
        {
            InitializeComponent();

            _optimizerUnderlyings = new BasketOptimizerUnderlyings(this);
            _optimizerUnderlyings.RefreshBasket += new EventHandler(_optimizerUnderlyings_RefreshBasket);
            this.FormClosing += new FormClosingEventHandler(BasketOptimizer_FormClosing);
            InputsPrecomputation(true);

            // Init colonnes des datatable
            InitDatatables();           
            UpdateDatagrids();
        }

        private void _optimizerUnderlyings_RefreshBasket(object sender, EventArgs e)
        {
            List<string> underlyingList = new List<string>();
            GetBasketUnderlyings(ref underlyingList, true);
        }

        private void BasketOptimizer_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        #region GUI
        // Init colonnes datatables
        private void InitDatatables()
        {
            _doubleColumns = new List<string>(new string[]{_colQuanto,_colSkew,_colVol,_colForward,_colGroup});

            // Init colonnes proprement dite
            _listAllDataTable = new DataTable();
            foreach (DataGridViewColumn column in _dataGridViewListAll.Columns)
            {
                if (column is DataGridViewTextBoxColumn)
                {
                    Type colType = _doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                    _listAllDataTable.Columns.Add(column.DataPropertyName, colType);
                }
                else if (column is DataGridViewCheckBoxColumn)
                {
                    _listAllDataTable.Columns.Add(column.DataPropertyName, typeof(int));
                }
            }
            //_listAllDataTable.Columns.Add(_colGroup, typeof(int));

            _resultDataTable = new DataTable();
            foreach (DataGridViewTextBoxColumn column in _dataGridViewResult.Columns)
            {
                Type colType = _doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                _resultDataTable.Columns.Add(column.DataPropertyName, colType);
            }

            // Affectation des datatables
            _dataGridViewListAll.DataSource = _listAllDataTable;
            _dataGridViewResult.DataSource = _resultDataTable;

            // Init Gui
            _dataGridViewListAll.GroupIndexColumn = _listAllDataTable.Columns.Count - 1;
            _dataGridViewListAll.IsCustomGroup = true;

            // Retrieve data
            this.currenciesTableAdapter.Fill(this.cCDataSet.Currencies);

            // Init quantos
            for (int counterQuanto = 0; counterQuanto < cCDataSet.Currencies.Rows.Count; counterQuanto++)
            {
                if (Convert.ToString(cCDataSet.Currencies.Rows[counterQuanto][_colValue]) == _initQuanto)
                {
                    _comboBoxQuanto.SelectedIndex = counterQuanto;
                }
            }
        }

        // Màj données
        private void UpdateDatagrids()
        {
            // List all DG
            List<string> underlyingList = new List<string>();
            while (_listAllDataTable.Rows.Count < 50)
            {
                DataRow row = _listAllDataTable.NewRow();
                _listAllDataTable.Rows.Add(row);
            }

            // Result DG
            _resultDataTable.Rows.Clear();
        }

        private void UpdateResultDatagrid(int[] solution)
        {
            // If no stock is fixed nor unused
            _resultDataTable.Rows.Clear();
            for (int counter = 0; counter < solution.Length; counter++)
            {
                int position = solution[counter];

                DataRow row = _resultDataTable.NewRow();
                row[_colSecurity] = _listAllDataTable.Rows[position][_colSecurity];
                row[_colVol] = _vols[position];
                row[_colSkew] = _skews[position];
                row[_colQuanto] = _quantos[position];
                row[_colForward] = _forwards[position];
                _resultDataTable.Rows.Add(row);
            }

            // Màj couleurs rows
            _dataGridViewResult.EmphasizedCount = _nbStocks;

            DataTable tempSpeedTable = _listAllDataTable.Copy();
            // Update the main datatable
            for (int counter = 0; counter < solution.Length; counter++)
            {
                _listAllDataTable.Rows[counter][_colVol] = _vols[counter];
                _listAllDataTable.Rows[counter][_colSkew] = _skews[counter];
                _listAllDataTable.Rows[counter][_colQuanto] = _quantos[counter];
                _listAllDataTable.Rows[counter][_colForward] = _forwards[counter];
            }

            // Set data columns visible
            foreach (DataGridViewColumn col in _dataGridViewListAll.Columns)
            {
                if (_doubleColumns.Contains(col.DataPropertyName) && col.DataPropertyName != _colGroup)
                {
                    col.Visible = true;
                }
            }

			// Gimmick pour rafraîchir la taille affichée du datagridview ; origine du bug d'affichage toujours inconnue
			this.Size = new Size(this.Width, this.Height + 1);
			this.Size = new Size(this.Width, this.Height - 1);

        }

        private void BasketOptimizer_Load(object sender, EventArgs e)
        {
        }


        private void _buttonCheckBasket_Click(object sender, EventArgs e)
        {
            if (_optimizerUnderlyings == null || _optimizerUnderlyings.IsDisposed)
            {
                _optimizerUnderlyings = new BasketOptimizerUnderlyings(this);
            }

            _optimizerUnderlyings.Show();
        }

        // Clear input basket
        private void _buttonClearBasket_Click(object sender, EventArgs e)
        {
            _underlyingList = new List<string>();
            
            // Reinit stock list
            _oldInputs = new KeyValuePair<List<string>, string>(new List<string>(), String.Empty);
            _securityGroupList = new List<KeyValuePair<string, int>>();
            _listNbStocksConstraint = new List<int>();

			// Clear the security cell for each row
			for (int i = 0; i < _dataGridViewListAll.RowCount; i++)
			{
				_dataGridViewListAll[0, i].Value = String.Empty;
			}

			_listAllDataTable.Clear();
            DataTable tempSpeedTable = _listAllDataTable.Copy();
            while (tempSpeedTable.Rows.Count < 50)
            {
                DataRow row = tempSpeedTable.NewRow();
                tempSpeedTable.Rows.Add(row);
            }
            _listAllDataTable = tempSpeedTable;
			_dataGridViewListAll.DataSource = _listAllDataTable;
        }

        // Override the parse in the DG to handle percentages
        private void _dataGridViewListAll_CellParsing(object sender, DataGridViewCellParsingEventArgs e)
        {
            if (e.ColumnIndex > 1)
            {
                string beforeParse = e.Value.ToString().Replace("%", String.Empty);
                double newValue = double.NaN;
                double.TryParse(beforeParse, out newValue);
                e.Value = newValue / 100;
                e.ParsingApplied = true;
            }
        }
        #endregion

        #region Matrices computations
        private bool WeightMatrixComputation(out double[,] weightMatrix)
        {
            bool isDataOk = true;
            List<string> listUnderlyings = _underlyingList;
            //isDataOk &= GetBasketUnderlyings(ref listUnderlyings);
            int nbUnderlyings = listUnderlyings.Count;
            weightMatrix = new double[nbUnderlyings, nbUnderlyings];

            // Retrieve data
            if (_isNewData || !_lastRetrievalOk)
            {
                isDataOk &= RetrieveBasketData();
            }
            
            // Weight normalization
            NormalizeWeights();

            // Double loop to fill the matrix
            for (int i = 0; i < nbUnderlyings; i++)
            {
                for (int j = 0; j < nbUnderlyings; j++)
                {
                    // Linear part
                    if (i == j)
                    {
                        // Add forwards
                        weightMatrix[i, j] += _forwardWeight * _forwards[i];
                        // Add vols
                        weightMatrix[i, j] += _volWeight * _vols[i];
                        // Add skews
                        weightMatrix[i, j] += _skewWeight * _skews[i];
                        // Add quantos
                        weightMatrix[i, j] += _quantoWeight * _quantos[i];
                        weightMatrix[i, j] += _correlationWeight * _correlations[i, j];
                    }
                    // Quadratic part
                    else
                    {
                        // Add correlations
                        weightMatrix[i, j] += _correlationWeight * _correlations[i, j];
                        // Add covariances
                        weightMatrix[i, j] += _covarianceWeight * _covariance[i, j];
                    }
                }
            }

            // Remove fixed stocks
            foreach (int fixedUnderlying in _fixedUnderlyingList)
            {
                for (int i = 0; i < nbUnderlyings; i++)
                {
                    weightMatrix[i, i] += weightMatrix[i, fixedUnderlying];
                }
            }
            List<int> unfixedUnderlying = new List<int>();
            for (int i = 0; i < nbUnderlyings; i++)
            {
                if (!_fixedUnderlyingList.Contains(i))
                {
                    unfixedUnderlying.Add(i);
                }
            }
            nbUnderlyings -= _fixedUnderlyingList.Count;
            double[,] newWeightMatrix = new double[nbUnderlyings, nbUnderlyings];
            for (int i = 0; i < nbUnderlyings; i++)
            {
                int iPrime = unfixedUnderlying[i];
                for (int j = 0; j < nbUnderlyings; j++)
                {
                    int jPrime = unfixedUnderlying[j];
                    newWeightMatrix[i, j] = weightMatrix[iPrime, jPrime];
                }
            }
            weightMatrix = newWeightMatrix;

            return isDataOk;
        }

        private void NormalizeWeights()
        {
            // Quadratic factor fix
            double quadraticFactor = Math.Max(1, _nbStocks + _fixedUnderlyingList.Count - 1);
            _correlationWeight /= quadraticFactor;

            // Normalization
            double normalizationFactor = 1;
            double[] sensis = new double[] { _forwardWeight, _volWeight, _skewWeight, _quantoWeight, 
                _correlationWeight, _covarianceWeight };
            foreach (double sensi in sensis)
            {
                normalizationFactor = Math.Max(normalizationFactor, Math.Abs(sensi)) * quadraticFactor;
            }

            _forwardWeight /= normalizationFactor;
            _volWeight /= normalizationFactor;
            _skewWeight /= normalizationFactor;
            _quantoWeight /= normalizationFactor;
            _correlationWeight /= normalizationFactor;
            _covarianceWeight /= normalizationFactor;
        }

        // Allocate the arrays - returns true if first time
        private void InputsPrecomputation(bool isLoading)
        {
            List<string> sjList = new List<string>();
            if (!isLoading)
            {
                GetBasketUnderlyings(ref sjList, false);
            }
            // Forwards
            _forwards = new double[sjList.Count];
            // Vols
            _vols = new double[sjList.Count];
            // Skews
            _skews = new double[sjList.Count];
            // Quantos
            _quantos = new double[sjList.Count];
            // Correlations
            _correlations = new double[sjList.Count, sjList.Count];
            // Covariance
            _covariance = new double[sjList.Count, sjList.Count];
        }

        private bool GetBasketUnderlyings(ref List<string> underlyingList, bool reinitTable)
        {
            bool isOk = true;
            underlyingList = new List<string>();

            for (int counter = 0; counter < _listAllDataTable.Rows.Count; counter++)
            {
                DataRow row = _listAllDataTable.Rows[counter];
                row[0] = row[0].ToString().ToUpper();
            }

            // Seulement récupérer si la fenêtre underlyings est visible
            if (reinitTable) // _optimizerUnderlyings.Visible)
            {
                // Reinit stock list
                _oldInputs = new KeyValuePair<List<string>, string>(new List<string>(), String.Empty);

                _securityGroupList = _optimizerUnderlyings.GetAdvancedBasket(ref _listNbStocksConstraint);

                // Check stock nb coherency
                int nbStocksTotal = 0;
                for (int i = 0; i < _listNbStocksConstraint.Count; i++)
                {
                    int nbStockBasketI = 0;
                    foreach (KeyValuePair<string, int> pair in _securityGroupList)
                    {
                        if (pair.Value == i)
                        {
                            nbStockBasketI++;
                        }
                    }
                    if (_listNbStocksConstraint[i] > nbStockBasketI)
                    {
                        MessageBox.Show("Stock number constraint inconsistency problem on basket " + (i + 1) + " ; check the basket again.");
                        isOk = false;
                    }
                    nbStocksTotal += _listNbStocksConstraint[i];
                }
                isOk = int.TryParse(_textBoxConstraintsNbStocks.Text, out _nbStocks);
                if (nbStocksTotal > _nbStocks)
                {
                    MessageBox.Show("Total stock number constraints on each individual basket superior to the stock number constraint on the entire product.");
                    isOk = false;
                }
            }

            if (_securityGroupList.Count == 0)
            {
                if (_listAllDataTable != null)
                {
                    for (int counter = 0; counter < _listAllDataTable.Rows.Count; counter++)
                    {
                        DataRow row = _listAllDataTable.Rows[counter];
                        if (row[0].ToString().Trim() != String.Empty)
                        {
                            if (!underlyingList.Contains(row[0].ToString()))
                            {
                                underlyingList.Add(row[0].ToString());
                            }
                            else
                            {
                                for (int counterClean = counter; counterClean < _listAllDataTable.Rows.Count - 1; counterClean++)
                                {
                                    foreach (DataColumn col in _listAllDataTable.Columns)
                                    {
                                        _listAllDataTable.Rows[counterClean][col] = _listAllDataTable.Rows[counterClean + 1][col];
                                    }
                                }
                                _listAllDataTable.Rows.RemoveAt(_listAllDataTable.Rows.Count - 1);
                                counter--;
                            }
                        }
                    }
                }
            }
            else
            {
                if (reinitTable)
                {
                    List<string> listDuplicates = new List<string>();

                    _listAllDataTable.Rows.Clear();
                    foreach (KeyValuePair<string, int> valuePair in _securityGroupList)
                    {
                        if (!underlyingList.Contains(valuePair.Key))
                        {
                            DataRow row = _listAllDataTable.NewRow();
                            row[_colSecurity] = valuePair.Key;
                            row[_colGroup] = valuePair.Value;
                            _listAllDataTable.Rows.Add(row);
                            underlyingList.Add(valuePair.Key);
                        }
                        else
                        {
                            if (!listDuplicates.Contains(valuePair.Key))
                            {
                                listDuplicates.Add(valuePair.Key);
                            }
                        }
                    }
                    while (_listAllDataTable.Rows.Count < _minRows)
                    {
                        _listAllDataTable.Rows.Add(_listAllDataTable.NewRow());
                    }

                    // Message window if stocks have been removed due to several occurrences
                    if (listDuplicates.Count > 0)
                    {
                        string errorString = "Duplicate securities among baskets ; the following underlyings have been removed after their first occurrence.";
                        foreach (string str in listDuplicates)
                        {
                            errorString += "\n" + str;
                        }
                        MessageBox.Show(errorString);
                    }
                }
                else
                {
                    if (_listAllDataTable != null)
                    {
                        for (int counter = 0; counter < _listAllDataTable.Rows.Count; counter++)
                        {
                            DataRow row = _listAllDataTable.Rows[counter];
                            if (row[0].ToString().Trim() != String.Empty)
                            {
                                if (!underlyingList.Contains(row[0].ToString()))
                                {
                                    underlyingList.Add(row[0].ToString());
                                }
                                else
                                {
                                    for (int counterClean = counter + 1; counterClean < _listAllDataTable.Rows.Count; counterClean++)
                                    {
                                        foreach (DataColumn col in _listAllDataTable.Columns)
                                        {
                                            _listAllDataTable.Rows[counter][col] = _listAllDataTable.Rows[counter + 1][col];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

			_dataGridViewListAll.DataSource = _listAllDataTable;
            return isOk;
        }
        #endregion

        #region Data retrieval
        private bool RetrieveBasketData()
        {
            bool isDataOk = true;
			// Check stocks are ok
			if (!CheckUnderlyings(_underlyingList))
			{
				isDataOk = false;
			}
			else
			{
				// Retrieve correls and quantos
				_backgroundWorker.ReportProgress(0, "Retrieving forwards/vols ...");
				isDataOk &= RetrieveVolForwards(_underlyingList);

				// Retrieve correls and quantos
				if (isDataOk)
				{
					_backgroundWorker.ReportProgress(0, "Retrieving correls/quantos ...");
					isDataOk &= RetrieveCorrelsQuantos(_underlyingList);
				}
			}

            _lastRetrievalOk = isDataOk;
            return isDataOk;
        }

        // Get modified data from the datagrid if available
        private bool UpdateVolForwards()
        {
            bool isDataOk = false;
            try
            {
				// Parsing result holder
				double parsingResult;
                for (int i = 0; i < _vols.Length; i++)
                {
					double.TryParse(_dataGridViewListAll[2, i].Value.ToString(), out parsingResult);
					_vols[i] = parsingResult;
					double.TryParse(_dataGridViewListAll[3, i].Value.ToString(), out parsingResult);
					_skews[i] = parsingResult;
					double.TryParse(_dataGridViewListAll[4, i].Value.ToString(), out parsingResult);
					_quantos[i] = parsingResult;
					double.TryParse(_dataGridViewListAll[5, i].Value.ToString(), out parsingResult);
					_forwards[i] = parsingResult;
                }
                
                isDataOk = true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return isDataOk;
        }

		private bool CheckUnderlyings(List<string> underlyingList)
		{
			bool isDataOk = false;
			try
			{
				// Check if all underlyings are part of Sophis
				isDataOk = SophisServerManager.CheckUnderlyings(underlyingList);
			}
			catch (Exception e)
			{
				MessageBox.Show(e.Message);
			}
			return isDataOk;
		}

        private bool RetrieveVolForwards(List<string> underlyingList)
        {
            bool isDataOk = false;
            try
            {
				List<StockContainer> marketDataList;
                // Retrieve vols and forwards
				SophisServerManager.RetrieveUnderlyingVolFwd(underlyingList, _quanto, out marketDataList);

                // Convert Sophis data to optimizer data
				ConvertSophisToOptimizer(_maturity, _strike, _strikeSkewLeft, _strikeSkewRight, marketDataList);
                isDataOk = true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return isDataOk;
        }

        private bool RetrieveCorrelsQuantos(List<string> underlyingList)
        {
            bool isDataOk = false;
            try
            {
                // For a 3Y horizon
                int horizon = 3;
                List<double> horizonList = new List<double>();
                horizonList.Add(horizon);
                // Retrieve vols and forwards
                CorrelFactory tempFactory = new CorrelFactory(underlyingList, _quanto,
                    CalculationPeriod.Daily, horizonList, false);

                double[,] perfMatrix;
                Dictionary<double, CorrelationPack> correlationPackMap;
                Dictionary<double, double[]> liquidityMap;
                DataSet ds = tempFactory.StartCorrelComputations();
                tempFactory.EndCorrelComputation(ds, out perfMatrix, out correlationPackMap, out liquidityMap);

                double[,] correlationMatrix = correlationPackMap[horizon].CorrelationMatrix;
                for (int i = 0; i < _correlations.GetLength(0); i++)
                {
                    for (int j = 0; j < _correlations.GetLength(0); j++)
                    {
                        _correlations[i, j] = correlationMatrix[i, j];
                    }

                    // Ajout des quantos
                    string securityQuanto = tempFactory.SecurityList[i].Quanto;//Convert.ToString(_listAllDataTable.Rows[i][_colCurrency]);
                    // If no quanto (same currency) then set value to 0
                    // For the moment use lowercase conversion : GBP currency in Bbg is in fact returned as "GBp"
                    if (securityQuanto.ToLower() == _quanto.ToLower())
                    {
                        _quantos[i] = 0;
                    }
                    else
                    {
                        string forex = securityQuanto + _quanto;
                        // Else retrieve the appropriate correlation from the matrix
                        for (int j = 0; j < underlyingList.Count; j++)
                        {
                            if (underlyingList[j].ToLower() == forex.ToLower())
                            {
                                _quantos[i] = correlationMatrix[i, j];
                            }
                        }
                    }
                    //_quantos[i] = correlationMatrix[i, correlations.GetLength(0)];
                }

                // Uncomment to optimize on (daily - weekly) correlation spread
                //Dictionary<double, CorrelationPack> correlationPackMapW
                //    = Correlations.Calculate(perfMatrix, horizonList, underlyingList.Count, CalculationPeriod.Weekly);
                //correlationMatrix = correlationPackMapW[horizon].CorrelationMatrix;
                //for (int i = 0; i < _correlations.GetLength(0); i++)
                //{
                //    for (int j = 0; j < _correlations.GetLength(0); j++)
                //    {
                //        _correlations[i, j] -= correlationMatrix[i, j];
                //    }
                //}

                isDataOk = true;
            }
            catch (Exception e)
            {
                MessageBox.Show(e.Message);
            }
            return isDataOk;
        }

        private void ConvertSophisToOptimizer(double maturity, double strike, double strikeSkewLeft,
            double strikeSkewRight, List<StockContainer> underlyingList)
        {
			int nbSj = underlyingList.Count;

            // Data init
            _forwards = new double[nbSj];
            _vols = new double[nbSj];
            _skews = new double[nbSj];

            // Conversion
            for (int i = 0; i < nbSj; i++)
            {
                // Vols and skews
                double skew;
                _vols[i] = double.IsNaN(strikeSkewLeft) ?
					SophisServerManager.VolatilityFromMarketData(underlyingList[i], strike, maturity, out skew) :
					SophisServerManager.VolatilityFromMarketData(underlyingList[i], strike, maturity, 
                        strikeSkewLeft, strikeSkewRight, out skew);
                _skews[i] = skew;

                // Forwards
				_forwards[i] = SophisServerManager.ForwardFromMarketData(underlyingList[i], maturity);
            }
        }

		private void ConvertSophisToOptimizer(double maturity, double strike, List<StockContainer> underlying)
        {
			ConvertSophisToOptimizer(maturity, strike, double.NaN, double.NaN, underlying);
        }

        #endregion

        #region Optimization
        private void _buttonOptimize_Click(object sender, EventArgs e)
        {
            this.Enabled = false;
            if (InitOptimizationData())
            {
                _backgroundWorker.RunWorkerAsync();
            }
            else
            {
                this.Enabled = true;
            }
        }

        private bool InitOptimizationData()
        {
            bool isDataOk = false;

            // Check nb stocks constraint
            isDataOk = int.TryParse(_textBoxConstraintsNbStocks.Text, out _nbStocks);

            if (_oldInputs.Key == null)
            {
                _oldInputs = new KeyValuePair<List<string>, string>(new List<string>(), String.Empty);
            }
            isDataOk &= GetBasketUnderlyings(ref _underlyingList, false);
            if (!isDataOk || _underlyingList == null ||_nbStocks >= _underlyingList.Count)
            {
                MessageBox.Show("The number of stocks to be fixed is incorrect ; fix and run again.");
                return false;
            }
            // Récupération quanto
            _quanto = Convert.ToString(((DataRowView)_comboBoxQuanto.Items[_comboBoxQuanto.SelectedIndex])[_colValue]);

            // Save as the new input list
            _isNewData = _oldInputs.Value != _quanto;
            foreach (string underlying in _underlyingList)
            {
                _isNewData |= !_oldInputs.Key.Contains(underlying);
            }
            _oldInputs = new KeyValuePair<List<string>,string>(new List<string>(_underlyingList), _quanto);
            // Recompute only if we have a new basket
            if (_isNewData || !_lastRetrievalOk)
            {
                InputsPrecomputation(false);
            }

            #region Récupération des paramètres
            // Check maturity constraint
            isDataOk = double.TryParse(_textBoxConstraintsTenor.Text, out _maturity);
            if (!isDataOk || _maturity <= 0)
            {
                MessageBox.Show("Maturity is incorrect ; fix and run again.");
                return false;
            }

            // Check strikes constraint
            isDataOk = double.TryParse(_textBoxSensiStrike.Text, out _strike);
            isDataOk = double.TryParse(_textBoxSensiSkew1.Text, out _strikeSkewLeft);
            isDataOk = double.TryParse(_textBoxSensiSkew2.Text, out _strikeSkewRight);
            // Percent conversion
            _strike /= 100;
            _strikeSkewLeft /= 100;
            _strikeSkewRight /= 100;
            if (!isDataOk || _strike <= 0)
            {
                MessageBox.Show("Strike is incorrect ; fix and run again.");
                return false;
            }
            if (!isDataOk || _strikeSkewLeft <= 0)
            {
                MessageBox.Show("Left strike for the skew is incorrect ; fix and run again.");
                return false;
            }
            if (!isDataOk || _strikeSkewRight <= 0)
            {
                MessageBox.Show("Right strike for the skew is incorrect ; fix and run again.");
                return false;
            }
                
            // Parse the input textboxes
            isDataOk &= double.TryParse(_textBoxSensiForward.Text, out _forwardWeight);
            isDataOk &= double.TryParse(_textBoxSensiVol.Text, out _volWeight);
            isDataOk &= double.TryParse(_textBoxSensiSkew.Text, out _skewWeight);
            isDataOk &= double.TryParse(_textBoxSensiQuanto.Text, out _quantoWeight);
            isDataOk &= double.TryParse(_textBoxSensiCorrel.Text, out _correlationWeight);
            isDataOk &= double.TryParse(_textBoxSensiCovariance.Text, out _covarianceWeight);
            isDataOk &= double.TryParse(_textBoxSensiCovariance.Text, out _covarianceWeight);
            isDataOk &= double.TryParse(_textBoxSensiCovariance.Text, out _covarianceWeight);
            isDataOk &= double.TryParse(_textBoxSensiCovariance.Text, out _covarianceWeight);

            _fixedUnderlyingList = new List<int>();
            //for (int i = 0; i < _dataGridViewListAll.Rows.Count; i++)
            //{
            //    if ((int)_dataGridViewListAll.Rows[i].Cells[_colFix].Value == 1)
            //    {
            //        _fixedUnderlyingList.Add(i);
            //    }
            //}
            for (int i = 0; i < _listAllDataTable.Rows.Count; i++)
            {
                if (_listAllDataTable.Rows[i][_colFix] is int && (int)_listAllDataTable.Rows[i][_colFix] == 1)
                {
                    _fixedUnderlyingList.Add(i);
                }
            }
            _nbStocks -= _fixedUnderlyingList.Count;
            #endregion

            // Màj des params des SJ si modifiés
            if (!_isNewData)
            {
                isDataOk = UpdateVolForwards();
            }

            return isDataOk;
        }

        private bool Optimize(out int[] solution)
        {
            // Weight matrix computation and retrieval of the number of underlyings in the target basket
            double[,] weightMatrix;
            bool isOk = false;
            solution = new int[1];  // Dummy init
            try
            {
                isOk = WeightMatrixComputation(out weightMatrix);
                if (isOk)
                {
                    // Optimization
                    solution = QuadraticOptimization(weightMatrix, _nbStocks);
                }
            }
            catch (Exception ex)
            {
                ShowMessageBox("Error during optimization : " + ex.Message);                
            }
            return isOk;
        }

        private void _backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            int[] solution;
            bool result = Optimize(out solution);
            e.Result = new KeyValuePair<bool, int[]>(result, solution);
        }

        private void _backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            _toolStripProgressBar.Value = e.ProgressPercentage;
            string displayText = (string)e.UserState;
            if(displayText != String.Empty)
            {
                _toolStripStatusLabel.Text = displayText;
            }
        }

        private void _backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            KeyValuePair<bool, int[]> result = (KeyValuePair<bool, int[]>)e.Result;
            if (result.Key)
            {
                // Update result datagrid
                UpdateResultDatagrid(result.Value);
            }
            // Return to normal
            _toolStripProgressBar.Value = 0;
            _toolStripStatusLabel.Text = String.Empty;
            this.Enabled = true;
        }

        // Quadratic optimization
        private int[] QuadraticOptimization(double[,] weightMatrix, int nbStocks)
        {
            int matrixLength = weightMatrix.GetLength(0);
            int[] solution = new int[matrixLength];

            // Algo quadprog
            double[,] G = new double[matrixLength, matrixLength];
            for (int i = 0; i < matrixLength; i++)
                for (int j = 0; j < matrixLength; j++)
                    G[i, j] = i != j ? weightMatrix[i, j] : 1;
            double[] g0 = new double[matrixLength]; // poids ?
            for (int i = 0; i < matrixLength; i++) g0[i] = weightMatrix[i, i];
            int n = matrixLength;

            // Equality constraints
            double[,] CE;// = new double[matrixLength, 1];
            double[] ce0;// = new double[1]; ce0[0] = -nbStocks;
            //for (int i = 0; i < matrixLength; i++) { CE[i, 0] = 1; }
            int p;// = 1;
            RetrieveBasketConstraints(nbStocks, matrixLength, out p, out CE, out ce0);

            // Inequality constraints
            double[,] CI = new double[matrixLength, matrixLength * 2];//0, 0];//
            double[] ci0 = new double[matrixLength * 2];//0];//
            for (int i = 0; i < matrixLength; i++)
            {
                ci0[i] = 1; CI[i, i] = -1;
                ci0[i + matrixLength] = 0; CI[i, i + matrixLength] = 1;
            }
            int m = 2 * matrixLength;//0;// 

            double[] x = new double[matrixLength];
            QuadProg quadProd = new QuadProg();

            // Pre modif nb stocks
            _nbStocks += _fixedUnderlyingList.Count;

            // Algo d'optimisation
            quadProd.solve_quadprog(G, g0, n, CE, ce0, p, CI, ci0, m, ref x);

            if (FixSubbasketConstraints(ref x, ref weightMatrix))
            {
                matrixLength = weightMatrix.GetLength(0);
                x = new double[matrixLength];
                solution = new int[matrixLength];

                // Reprise
                G = new double[matrixLength, matrixLength];
                for (int i = 0; i < matrixLength; i++)
                    for (int j = 0; j < matrixLength; j++)
                        G[i, j] = i != j ? weightMatrix[i, j] : 1;
                g0 = new double[matrixLength];
                for (int i = 0; i < matrixLength; i++) g0[i] = weightMatrix[i, i];
                n = matrixLength;
                CE = new double[matrixLength, 1];
                ce0 = new double[1]; ce0[0] = -nbStocks;
                for (int i = 0; i < matrixLength; i++) { CE[i, 0] = 1; }
                p = 1;
                CI = new double[matrixLength, matrixLength * 2];
                ci0 = new double[matrixLength * 2];
                for (int i = 0; i < matrixLength; i++)
                {
                    ci0[i] = 1; CI[i, i] = -1;
                    ci0[i + matrixLength] = 0; CI[i, i + matrixLength] = 1;
                }
                m = 2 * matrixLength;
                // Reoptimisation sur la nouvelle matrice
                quadProd.solve_quadprog(G, g0, n, CE, ce0, p, CI, ci0, m, ref x);
            }            

            // Tri des valeurs par ordre croissant
            List<int> minValues = new List<int>();
            for (int i = 0; i < matrixLength; i++)
            {
                minValues.Add(-1);
                for (int j = 0; j < matrixLength; j++)
                {
                    if (!minValues.Contains(j) && (minValues[i] == -1 || x[j] < x[minValues[i]]))
                    {
                        minValues[i] = j;
                    }
                }
            }
            // Correct indices out of whack because of fixed underlyings
            List<int> indexCorrection = new List<int>();
            int indexCounter = 0;
            for (int i = 0; i < _fixedUnderlyingList.Count + matrixLength; i++)
            {
                if (!_fixedUnderlyingList.Contains(i))
                {
                    indexCorrection.Add(indexCounter);
                }
                else
                {
                    indexCounter++;
                }
            }
            for (int i = 0; i < minValues.Count; i++)
            {
                minValues[i] += indexCorrection[minValues[i]];
            }
            for (int i = 0; i < _fixedUnderlyingList.Count; i++)
            {
                minValues.Insert(0, _fixedUnderlyingList[i]);
            }

            return minValues.ToArray();
        }
        
        // Normalize outputs in case of subbasket constraints
        private bool FixSubbasketConstraints(ref double[] x, ref double[,] weightMatrix)
        {
            // Create dictionary first
            Dictionary<int, KeyValuePair<int, int>> nbFixed_nbTotalDic = new Dictionary<int, KeyValuePair<int, int>>();
            int counterStock = 0;
            double nbStocksFreeSubbasket = 0;
            int[] tempListNbStocksConstraint = new int[_listNbStocksConstraint.Count];
            _listNbStocksConstraint.CopyTo(tempListNbStocksConstraint);
            for (int listIndex = 0; listIndex < tempListNbStocksConstraint.Length; listIndex++)
            {
                int stockConstraint = tempListNbStocksConstraint[listIndex];
                int nbStocksList = 0;
                foreach (KeyValuePair<string, int> keyValuePair in _securityGroupList)
                {
                    if (keyValuePair.Value == listIndex)
                    {
                        nbStocksList++;
                    }
                }
                // Remove from fixed subbasket constraints those which a stock already fixed belongs to
                foreach (int idxFixed in _fixedUnderlyingList)
                {
                    if (idxFixed >= counterStock && idxFixed <= counterStock + nbStocksList - 1)
                    {
                        stockConstraint--;
                        tempListNbStocksConstraint[listIndex]--;
                    }
                }
                if (stockConstraint > 0)
                {
                    nbFixed_nbTotalDic.Add(listIndex,
                        new KeyValuePair<int, int>(counterStock, counterStock + nbStocksList - 1));
                }
                else
                {
                    nbStocksFreeSubbasket += nbStocksList;
                }
                counterStock += nbStocksList;
            }

            // Then, for each subset, get the k_i lowest value stocks and fix them
            List<List<int>> listMinStocks = new List<List<int>>();
            foreach (int subbasketId in nbFixed_nbTotalDic.Keys)
            {
                List<int> currentList = new List<int>();
                for (int i = 0; i < tempListNbStocksConstraint[subbasketId]; i++)
                {
                    currentList.Add(-1);
                    for (int j = nbFixed_nbTotalDic[subbasketId].Key; j <= nbFixed_nbTotalDic[subbasketId].Value; j++)
                    {
                        if (!currentList.Contains(j) && (currentList[i] == -1 || x[j] < x[currentList[i]]))
                        {
                            currentList[i] = j;
                        }
                    }
                }

                listMinStocks.Add(currentList);
            }

            // Fix mins
            List<int> newFixed = new List<int>();
            foreach (List<int> listMins in listMinStocks)
            {
                foreach (int stockIndex in listMins)
                {
                    if (!_fixedUnderlyingList.Contains(stockIndex))
                    {
                        _fixedUnderlyingList.Add(stockIndex);
                        newFixed.Add(stockIndex);
                    }
                }
            }
            int nbUnderlyings = weightMatrix.GetLength(0);

            // Remove fixed stocks
            foreach (int fixedUnderlying in newFixed)
            {
                for (int i = 0; i < nbUnderlyings; i++)
                {
                    weightMatrix[i, i] += weightMatrix[i, fixedUnderlying];
                }
            }
            List<int> unfixedUnderlying = new List<int>();
            for (int i = 0; i < nbUnderlyings; i++)
            {
                if (!newFixed.Contains(i))
                {
                    unfixedUnderlying.Add(i);
                }
            }
            nbUnderlyings = weightMatrix.GetLength(0) - newFixed.Count;
            double[,] newWeightMatrix = new double[nbUnderlyings, nbUnderlyings];
            for (int i = 0; i < nbUnderlyings; i++)
            {
                int iPrime = unfixedUnderlying[i];
                for (int j = 0; j < nbUnderlyings; j++)
                {
                    int jPrime = unfixedUnderlying[j];
                    newWeightMatrix[i, j] = weightMatrix[iPrime, jPrime];
                }
            }
            weightMatrix = newWeightMatrix;

            return true;
        }

        // Equality constraints, dependant on the basket definition
        private void RetrieveBasketConstraints(int nbStocks, int matrixLength, out int p, out double[,] CE, out double[] ce0)
        {
            // Number of equality constraints
            p = 1;
            // Dictionnaire : nbStockContraints, <FromIndex, ToIndex>
            Dictionary<int, KeyValuePair<int, int>> nbFixed_nbTotalDic = new Dictionary<int, KeyValuePair<int, int>>();
            int counterStock = 0;
            int[] tempListNbStocksConstraint = new int[_listNbStocksConstraint.Count];
            _listNbStocksConstraint.CopyTo(tempListNbStocksConstraint);
            for (int listIndex = 0; listIndex < tempListNbStocksConstraint.Length; listIndex++)
            {
                int stockConstraint = tempListNbStocksConstraint[listIndex];
                int nbStocksList = 0;
                foreach (KeyValuePair<string, int> keyValuePair in _securityGroupList)
                {
                    if (keyValuePair.Value == listIndex)
                    {
                        nbStocksList++;
                    }
                }
                // Remove from fixed subbasket constraints those which a stock already fixed belongs to
                foreach (int idxFixed in _fixedUnderlyingList)
                {
                    if (idxFixed >= counterStock && idxFixed <= counterStock + nbStocksList - 1)
                    {
                        stockConstraint--;
                        tempListNbStocksConstraint[listIndex]--;
                    }
                }
                counterStock += nbStocksList;
            }
            
            // Equality matrix definition            
            CE = new double[matrixLength, p];
            ce0 = new double[p]; ce0[0] = -nbStocks;
            for (int i = 0; i < matrixLength; i++) { CE[i, 0] = 1; }
            ce0[0] = -nbStocks;
            int pCounter = 0;
            for (int i = 0; i < matrixLength; i++)
            {
                CE[i, pCounter] = 1;
            }
            foreach (int listIndex in nbFixed_nbTotalDic.Keys)
            { 
                pCounter++;
                if (tempListNbStocksConstraint[listIndex] > 0)
                {
                    ce0[pCounter] = -tempListNbStocksConstraint[listIndex];
                    for (int i = nbFixed_nbTotalDic[listIndex].Key; i <= nbFixed_nbTotalDic[listIndex].Value; i++)
                    {
                        CE[i, pCounter] = 1;
                    }
                }
            }
        }
        #endregion

        #region Données membres
        private BasketOptimizerUnderlyings _optimizerUnderlyings;
        private double[] _forwards;
        private double[] _vols;
        private double[] _skews;
        private double[] _quantos;
        private double[,] _correlations;
        private double[,] _covariance;
        private DataTable _listAllDataTable;
        private DataTable _resultDataTable;
        private List<string> _doubleColumns;
        private List<int> _listNbStocksConstraint = new List<int>();
        private List<KeyValuePair<string,int>> _securityGroupList = new List<KeyValuePair<string,int>>();

        private static string _colSecurity = "Security";
        private static string _colQuanto = "Quanto";
        private static string _colVol = "Vol";
        private static string _colSkew = "Skew";
        private static string _colForward = "Forward";
        private static string _colValue = "Value";
        private static string _colFix = "Fix";
        private static string _colGroup = "GroupIndex";
        private static string _initQuanto = "EUR";
        private double _forwardWeight;
        private double _volWeight;
        private double _skewWeight;
        private double _quantoWeight;
        private double _correlationWeight;
        private double _covarianceWeight;
        private double _strike;
        private double _strikeSkewLeft;
        private double _strikeSkewRight;
        private double _maturity;
        private int _nbStocks;
        private string _quanto;
        private bool _isNewData;
        private KeyValuePair<List<string>, string> _oldInputs;
        private bool _lastRetrievalOk = true;
        private static int _minRows = 50;

        private List<string> _underlyingList;
        private List<int> _fixedUnderlyingList;
    
        #endregion

    }
}