﻿using System;
using RemotingInterfaces;
using System.Drawing;

namespace BBClient
{
    partial class BasketOptimizerNew
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.ToolBoxOptimisationParams = new System.Windows.Forms.GroupBox();
            this.buttonCancelLoad = new System.Windows.Forms.Button();
            this.labelProgress = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.buttonFilters = new System.Windows.Forms.Button();
            this.buttonLoadAll = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.labelListAllCount = new System.Windows.Forms.Label();
            this.dataGridViewListAll = new System.Windows.Forms.DataGridView();
            this.ColumnSecurity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnFullName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCurrency = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnCountry = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnSpot = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ColumnLiquidity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.currenciesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cCDataSet = new RemotingInterfaces.CCDataSet();
            this.currenciesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter();
            this.dataGridViewUniverse = new StructuringControls.ExcelDataGridView();
            this.SecurityCol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.FullNameColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.SpotColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CountryColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CurrencyColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.LiquidityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.VolatilityColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.labelUniverseCount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.labelDataUpdated = new System.Windows.Forms.Label();
            this.buttonOptimizerSetUp = new System.Windows.Forms.Button();
            this.buttonClearUniverse = new System.Windows.Forms.Button();
            this.buttonPaste = new System.Windows.Forms.Button();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.label3 = new System.Windows.Forms.Label();
            this.buttonLoadMarketData = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.labelUnderlyingsWithOldVol = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBoxVolDate = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ToolBoxOptimisationParams.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUniverse)).BeginInit();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // ToolBoxOptimisationParams
            // 
            this.ToolBoxOptimisationParams.Controls.Add(this.buttonCancelLoad);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelProgress);
            this.ToolBoxOptimisationParams.Controls.Add(this.label2);
            this.ToolBoxOptimisationParams.Controls.Add(this.progressBar);
            this.ToolBoxOptimisationParams.Controls.Add(this.buttonFilters);
            this.ToolBoxOptimisationParams.Controls.Add(this.buttonLoadAll);
            this.ToolBoxOptimisationParams.Controls.Add(this.label5);
            this.ToolBoxOptimisationParams.Controls.Add(this.labelListAllCount);
            this.ToolBoxOptimisationParams.Controls.Add(this.dataGridViewListAll);
            this.ToolBoxOptimisationParams.Controls.Add(this.label1);
            this.ToolBoxOptimisationParams.Dock = System.Windows.Forms.DockStyle.Top;
            this.ToolBoxOptimisationParams.Location = new System.Drawing.Point(0, 0);
            this.ToolBoxOptimisationParams.Name = "ToolBoxOptimisationParams";
            this.ToolBoxOptimisationParams.Size = new System.Drawing.Size(872, 287);
            this.ToolBoxOptimisationParams.TabIndex = 0;
            this.ToolBoxOptimisationParams.TabStop = false;
            this.ToolBoxOptimisationParams.Text = "Stock Selection and Filtering";
            // 
            // buttonCancelLoad
            // 
            this.buttonCancelLoad.Location = new System.Drawing.Point(635, 258);
            this.buttonCancelLoad.Name = "buttonCancelLoad";
            this.buttonCancelLoad.Size = new System.Drawing.Size(75, 23);
            this.buttonCancelLoad.TabIndex = 18;
            this.buttonCancelLoad.Text = "Cancel";
            this.buttonCancelLoad.UseVisualStyleBackColor = true;
            this.buttonCancelLoad.Click += new System.EventHandler(this.buttonCancelLoad_Click);
            // 
            // labelProgress
            // 
            this.labelProgress.AutoSize = true;
            this.labelProgress.BackColor = System.Drawing.Color.Transparent;
            this.labelProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProgress.Location = new System.Drawing.Point(443, 263);
            this.labelProgress.Name = "labelProgress";
            this.labelProgress.Size = new System.Drawing.Size(23, 13);
            this.labelProgress.TabIndex = 17;
            this.labelProgress.Text = "0%";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 261);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(54, 13);
            this.label2.TabIndex = 16;
            this.label2.Text = "Progress :";
            // 
            // progressBar
            // 
            this.progressBar.Location = new System.Drawing.Point(71, 258);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(499, 23);
            this.progressBar.TabIndex = 15;
            // 
            // buttonFilters
            // 
            this.buttonFilters.Location = new System.Drawing.Point(745, 161);
            this.buttonFilters.Name = "buttonFilters";
            this.buttonFilters.Size = new System.Drawing.Size(92, 71);
            this.buttonFilters.TabIndex = 14;
            this.buttonFilters.Text = "Apply Filters";
            this.buttonFilters.UseVisualStyleBackColor = true;
            this.buttonFilters.Click += new System.EventHandler(this.buttonFilters_Click);
            // 
            // buttonLoadAll
            // 
            this.buttonLoadAll.Location = new System.Drawing.Point(745, 33);
            this.buttonLoadAll.Name = "buttonLoadAll";
            this.buttonLoadAll.Size = new System.Drawing.Size(92, 71);
            this.buttonLoadAll.TabIndex = 13;
            this.buttonLoadAll.Text = "Load All Sophis Stocks";
            this.buttonLoadAll.UseVisualStyleBackColor = true;
            this.buttonLoadAll.Click += new System.EventHandler(this.buttonLoadAll_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(6, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(81, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Sophis Stocks :";
            // 
            // labelListAllCount
            // 
            this.labelListAllCount.AutoSize = true;
            this.labelListAllCount.Location = new System.Drawing.Point(68, 238);
            this.labelListAllCount.Name = "labelListAllCount";
            this.labelListAllCount.Size = new System.Drawing.Size(13, 13);
            this.labelListAllCount.TabIndex = 9;
            this.labelListAllCount.Text = "0";
            // 
            // dataGridViewListAll
            // 
            this.dataGridViewListAll.AllowUserToAddRows = false;
            this.dataGridViewListAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewListAll.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColumnSecurity,
            this.ColumnFullName,
            this.ColumnCurrency,
            this.ColumnCountry,
            this.ColumnSpot,
            this.ColumnLiquidity});
            this.dataGridViewListAll.Location = new System.Drawing.Point(6, 33);
            this.dataGridViewListAll.Name = "dataGridViewListAll";
            this.dataGridViewListAll.RowHeadersVisible = false;
            this.dataGridViewListAll.Size = new System.Drawing.Size(704, 199);
            this.dataGridViewListAll.TabIndex = 1;
            // 
            // ColumnSecurity
            // 
            this.ColumnSecurity.DataPropertyName = "Security";
            this.ColumnSecurity.HeaderText = "Security";
            this.ColumnSecurity.Name = "ColumnSecurity";
            this.ColumnSecurity.ReadOnly = true;
            // 
            // ColumnFullName
            // 
            this.ColumnFullName.DataPropertyName = "Full Name";
            this.ColumnFullName.HeaderText = "Full Name";
            this.ColumnFullName.Name = "ColumnFullName";
            this.ColumnFullName.ReadOnly = true;
            // 
            // ColumnCurrency
            // 
            this.ColumnCurrency.DataPropertyName = "Currency";
            this.ColumnCurrency.HeaderText = "Currency";
            this.ColumnCurrency.Name = "ColumnCurrency";
            this.ColumnCurrency.ReadOnly = true;
            // 
            // ColumnCountry
            // 
            this.ColumnCountry.DataPropertyName = "Country";
            this.ColumnCountry.HeaderText = "Country";
            this.ColumnCountry.Name = "ColumnCountry";
            this.ColumnCountry.ReadOnly = true;
            // 
            // ColumnSpot
            // 
            this.ColumnSpot.DataPropertyName = "Spot";
            this.ColumnSpot.HeaderText = "Spot";
            this.ColumnSpot.Name = "ColumnSpot";
            this.ColumnSpot.ReadOnly = true;
            // 
            // ColumnLiquidity
            // 
            this.ColumnLiquidity.DataPropertyName = "Liquidity";
            this.ColumnLiquidity.HeaderText = "Liquidity (average volume traded 30d)";
            this.ColumnLiquidity.Name = "ColumnLiquidity";
            this.ColumnLiquidity.ReadOnly = true;
            this.ColumnLiquidity.Width = 200;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 238);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(41, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Count :";
            // 
            // currenciesBindingSource
            // 
            this.currenciesBindingSource.DataMember = "Currencies";
            this.currenciesBindingSource.DataSource = this.cCDataSet;
            // 
            // cCDataSet
            // 
            this.cCDataSet.DataSetName = "CCDataSet";
            this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // currenciesTableAdapter
            // 
            this.currenciesTableAdapter.ClearBeforeFill = true;
            // 
            // dataGridViewUniverse
            // 
            this.dataGridViewUniverse.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUniverse.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SecurityCol,
            this.FullNameColumn,
            this.SpotColumn,
            this.CountryColumn,
            this.CurrencyColumn,
            this.LiquidityColumn,
            this.VolatilityColumn});
            this.dataGridViewUniverse.Location = new System.Drawing.Point(6, 314);
            this.dataGridViewUniverse.Name = "dataGridViewUniverse";
            this.dataGridViewUniverse.Size = new System.Drawing.Size(656, 199);
            this.dataGridViewUniverse.TabIndex = 2;
            this.dataGridViewUniverse.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUniverse_CellValueChanged);
            // 
            // SecurityCol
            // 
            this.SecurityCol.DataPropertyName = "Security";
            this.SecurityCol.HeaderText = "Security";
            this.SecurityCol.Name = "SecurityCol";
            // 
            // FullNameColumn
            // 
            this.FullNameColumn.DataPropertyName = "Full Name";
            this.FullNameColumn.HeaderText = "Full Name";
            this.FullNameColumn.Name = "FullNameColumn";
            this.FullNameColumn.ReadOnly = true;
            // 
            // SpotColumn
            // 
            this.SpotColumn.DataPropertyName = "Spot";
            this.SpotColumn.HeaderText = "Spot";
            this.SpotColumn.Name = "SpotColumn";
            this.SpotColumn.ReadOnly = true;
            // 
            // CountryColumn
            // 
            this.CountryColumn.DataPropertyName = "Country";
            this.CountryColumn.HeaderText = "Country";
            this.CountryColumn.Name = "CountryColumn";
            this.CountryColumn.ReadOnly = true;
            // 
            // CurrencyColumn
            // 
            this.CurrencyColumn.DataPropertyName = "Currency";
            this.CurrencyColumn.HeaderText = "Currency";
            this.CurrencyColumn.Name = "CurrencyColumn";
            this.CurrencyColumn.ReadOnly = true;
            // 
            // LiquidityColumn
            // 
            this.LiquidityColumn.DataPropertyName = "Liquidity";
            this.LiquidityColumn.HeaderText = "Liquidity";
            this.LiquidityColumn.Name = "LiquidityColumn";
            this.LiquidityColumn.ReadOnly = true;
            // 
            // VolatilityColumn
            // 
            this.VolatilityColumn.DataPropertyName = "Volatility";
            this.VolatilityColumn.HeaderText = "Volatility";
            this.VolatilityColumn.Name = "VolatilityColumn";
            this.VolatilityColumn.ReadOnly = true;
            // 
            // labelUniverseCount
            // 
            this.labelUniverseCount.AutoSize = true;
            this.labelUniverseCount.Location = new System.Drawing.Point(68, 524);
            this.labelUniverseCount.Name = "labelUniverseCount";
            this.labelUniverseCount.Size = new System.Drawing.Size(13, 13);
            this.labelUniverseCount.TabIndex = 11;
            this.labelUniverseCount.Text = "0";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 524);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Count :";
            // 
            // labelDataUpdated
            // 
            this.labelDataUpdated.AutoSize = true;
            this.labelDataUpdated.ForeColor = System.Drawing.Color.Red;
            this.labelDataUpdated.Location = new System.Drawing.Point(673, 298);
            this.labelDataUpdated.Name = "labelDataUpdated";
            this.labelDataUpdated.Size = new System.Drawing.Size(63, 13);
            this.labelDataUpdated.TabIndex = 13;
            this.labelDataUpdated.Text = "Not Loaded";
            // 
            // buttonOptimizerSetUp
            // 
            this.buttonOptimizerSetUp.Location = new System.Drawing.Point(555, 524);
            this.buttonOptimizerSetUp.Name = "buttonOptimizerSetUp";
            this.buttonOptimizerSetUp.Size = new System.Drawing.Size(107, 47);
            this.buttonOptimizerSetUp.TabIndex = 14;
            this.buttonOptimizerSetUp.Text = "Set-up optimization";
            this.buttonOptimizerSetUp.UseVisualStyleBackColor = true;
            this.buttonOptimizerSetUp.Click += new System.EventHandler(this.buttonOptimizerSetUp_Click);
            // 
            // buttonClearUniverse
            // 
            this.buttonClearUniverse.Location = new System.Drawing.Point(668, 481);
            this.buttonClearUniverse.Name = "buttonClearUniverse";
            this.buttonClearUniverse.Size = new System.Drawing.Size(90, 32);
            this.buttonClearUniverse.TabIndex = 15;
            this.buttonClearUniverse.Text = "Clear";
            this.buttonClearUniverse.UseVisualStyleBackColor = true;
            this.buttonClearUniverse.Click += new System.EventHandler(this.buttonClearUniverse_Click);
            // 
            // buttonPaste
            // 
            this.buttonPaste.Location = new System.Drawing.Point(9, 540);
            this.buttonPaste.Name = "buttonPaste";
            this.buttonPaste.Size = new System.Drawing.Size(93, 22);
            this.buttonPaste.TabIndex = 16;
            this.buttonPaste.Text = "Paste clipboard";
            this.buttonPaste.UseVisualStyleBackColor = true;
            this.buttonPaste.Click += new System.EventHandler(this.buttonPaste_Click);
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.WorkerSupportsCancellation = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 674);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(872, 22);
            this.statusStrip.TabIndex = 17;
            this.statusStrip.Text = "statusStrip1";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Ready";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 290);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Asset space for optimization";
            // 
            // buttonLoadMarketData
            // 
            this.buttonLoadMarketData.Location = new System.Drawing.Point(668, 314);
            this.buttonLoadMarketData.Name = "buttonLoadMarketData";
            this.buttonLoadMarketData.Size = new System.Drawing.Size(90, 34);
            this.buttonLoadMarketData.TabIndex = 20;
            this.buttonLoadMarketData.Text = "Load Market Data";
            this.buttonLoadMarketData.UseVisualStyleBackColor = true;
            this.buttonLoadMarketData.Click += new System.EventHandler(this.buttonLoadMarketData_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 565);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(208, 13);
            this.label4.TabIndex = 21;
            this.label4.Text = "Underlyings removed due to old volatility :  ";
            // 
            // labelUnderlyingsWithOldVol
            // 
            this.labelUnderlyingsWithOldVol.Location = new System.Drawing.Point(12, 590);
            this.labelUnderlyingsWithOldVol.Name = "labelUnderlyingsWithOldVol";
            this.labelUnderlyingsWithOldVol.Size = new System.Drawing.Size(650, 76);
            this.labelUnderlyingsWithOldVol.TabIndex = 22;
            this.labelUnderlyingsWithOldVol.Text = "                 ";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(673, 360);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(182, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Remove when volatility is older than :";
            // 
            // textBoxVolDate
            // 
            this.textBoxVolDate.Location = new System.Drawing.Point(676, 387);
            this.textBoxVolDate.Name = "textBoxVolDate";
            this.textBoxVolDate.Size = new System.Drawing.Size(33, 20);
            this.textBoxVolDate.TabIndex = 24;
            this.textBoxVolDate.Text = "30";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(729, 390);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "days";
            // 
            // BasketOptimizerNew
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(872, 696);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.textBoxVolDate);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.labelUnderlyingsWithOldVol);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.buttonLoadMarketData);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.buttonPaste);
            this.Controls.Add(this.buttonClearUniverse);
            this.Controls.Add(this.buttonOptimizerSetUp);
            this.Controls.Add(this.labelDataUpdated);
            this.Controls.Add(this.labelUniverseCount);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.dataGridViewUniverse);
            this.Controls.Add(this.ToolBoxOptimisationParams);
            this.Name = "BasketOptimizerNew";
            this.Text = "Basket Optimiser";
            this.ToolBoxOptimisationParams.ResumeLayout(false);
            this.ToolBoxOptimisationParams.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewListAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUniverse)).EndInit();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox ToolBoxOptimisationParams;
        private RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter bbgDescriptiveFieldsTableAdapter;
        private RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter sophisSecuritiesTableAdapter;

        private CCDataSet cCDataSet;
        private System.Windows.Forms.BindingSource currenciesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter currenciesTableAdapter;
        private System.Windows.Forms.DataGridView dataGridViewListAll;
        private StructuringControls.ExcelDataGridView dataGridViewUniverse;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label labelListAllCount;
        private System.Windows.Forms.Label labelUniverseCount;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label labelDataUpdated;
        private System.Windows.Forms.Button buttonOptimizerSetUp;
        private System.Windows.Forms.Button buttonLoadAll;
        private System.Windows.Forms.Button buttonFilters;
        private System.Windows.Forms.Button buttonClearUniverse;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSecurity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnFullName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCurrency;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCountry;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnSpot;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnLiquidity;
        private System.Windows.Forms.Button buttonPaste;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label labelProgress;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.Button buttonCancelLoad;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button buttonLoadMarketData;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label labelUnderlyingsWithOldVol;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBoxVolDate;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.DataGridViewTextBoxColumn SecurityCol;
        private System.Windows.Forms.DataGridViewTextBoxColumn FullNameColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn SpotColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountryColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CurrencyColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn LiquidityColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn VolatilityColumn;
    }
}