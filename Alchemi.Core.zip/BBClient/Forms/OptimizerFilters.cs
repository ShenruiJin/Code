﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BBClient;
using BBClient.Data;
using System.Globalization;
using CaesarApplication.Service.Strategy;

namespace BBClient.Forms
{
    public partial class OptimizerFilters : Form
    {
        public OptimizerFilters(BasketOptimizerNew BasketOpt)
        {
            InitializeComponent();
            //Save the old one
            OptimizerInput = BasketOpt;
            _strike = OptimizerInput.Strike;
            _currency = OptimizerInput.Currency;
            _maturity = OptimizerInput.Maturity;
            _filtersApplied = OptimizerInput.SomeFiltersApplied == true ? true : false;


            // Get the underlyings list
            underlyingsList = OptimizerInput.SomeFiltersApplied ? BasketOpt.underlyingsListResults : BasketOpt.underlyingsList;
            underlyingsTickers = BasketOpt.underlyingsList.Select(ul => ul.Ticker).ToList();

            // Currencies
            foreach (string currencystring in BasketOpt.currenciesList)
            {
                if (currencystring != null)
                {
                    checkedListBoxCurrencies.Items.Add(currencystring);
                }
            }

            // Countries
            foreach (string countrytring in BasketOpt.countriesList)
            {
                if (countrytring != null)
                {
                    checkedListBoxCountries.Items.Add(countrytring);
                }

            }
            GenerateSectorDictionaries();
            // Initialize the tree
            // Add industries
            foreach (string industry in IndustriesList)
            {
                treeViewSector.Nodes.Add(industry);
            }
            // Add SuperSectors
            foreach (TreeNode IndustryNode in treeViewSector.Nodes)
            {
                // Add SuperSectors
                foreach (KeyValuePair<string, string> SupersectorIndustry in SuperSectorsDictionary)
                {
                    if (SupersectorIndustry.Value == IndustryNode.Text)
                    {
                        IndustryNode.Nodes.Add(SupersectorIndustry.Key);
                    }
                }

                // Add Sectors
                foreach (TreeNode SuperSectorNode in IndustryNode.Nodes)
                {
                    foreach (KeyValuePair<string, string> SectorSuperSector in SectorsDictionary)
                    {
                        if (SectorSuperSector.Value == SuperSectorNode.Text)
                        {
                            SuperSectorNode.Nodes.Add(SectorSuperSector.Key);
                        }
                    }
                }

                // Add SubSectors
                foreach (TreeNode SuperSectorNode in IndustryNode.Nodes)
                {
                    foreach (TreeNode SectorNode in SuperSectorNode.Nodes)
                    {
                        foreach (KeyValuePair<string, string> SubSectorSector in SubSectorsDictionary)
                        {
                            if (SubSectorSector.Value == SectorNode.Text)
                            {
                                SectorNode.Nodes.Add(SubSectorSector.Key);
                            }
                        }
                    }
                }
            }

            // Allow selection with one Click
            checkedListBoxCurrencies.CheckOnClick = true;
            checkedListBoxCountries.CheckOnClick = true;
            //Volatility
            textBoxVolLowerBound.Text = "0";
            textBoxVolUpperBound.Text = "100000000000";
            //Volatility
            textBoxFwdLowerBound.Text = "0";
            textBoxFwdUpperBound.Text = "100000000000";
            //Volatility
            textBoxLiquidityLowerBound.Text = "0";
            textBoxLiquidityUpperBound.Text = "100000000000";
            //Volatility
            textBoxRatingLowerBound.Text = "0";
            textBoxRatingUpperBound.Text = "100000000000";
        }

        #region Condition classes
        public class CountryCondition
        {
            public CountryCondition(string country)
            {
                m_country = country;
                m_isInclude = true;
            }
            private string m_country;
            private bool m_isInclude;
            // Access to private members
            public string Country { get { return m_country; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }
        }
        public class SectorCondtion
        {
            public SectorCondtion(string subSector)
            {
                m_subsector = subSector;
                m_isInclude = true;
            }
            private string m_subsector;
            private bool m_isInclude;
            // Access to private members
            public string SubSector { get { return m_subsector; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }
        }
        public class VolCondition
        {
            public VolCondition(double Lbound, double Ubound)
            {
                m_Lbound = Lbound;
                m_Ubound = Ubound;
                m_isInclude = true;
            }
            private double m_Lbound;
            private double m_Ubound;
            private bool m_isInclude;

            // Access to private members
            public double LowerBound { get { return m_Lbound; } }
            public double UpperBound { get { return m_Ubound; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }
        }
        public class FwdCondition
        {
            public FwdCondition(double Lbound, double Ubound)
            {
                m_Lbound = Lbound;
                m_Ubound = Ubound;
                m_isInclude = true;
            }
            private double m_Lbound;
            private double m_Ubound;
            private bool m_isInclude;
            // Access to private members
            public double LowerBound { get { return m_Lbound; } }
            public double UpperBound { get { return m_Ubound; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }
        }
        public class CurrencyCondition
        {
            public CurrencyCondition(string ccy)
            {
                m_ccy = ccy;
                m_isInclude = true;
            }
            private string m_ccy;
            private bool m_isInclude;
            // Access to private members
            public string Currency { get { return m_ccy; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }

        }
        public class LiquidityCondition
        {
            public LiquidityCondition(double Lbound, double Ubound)
            {
                m_Lbound = Lbound;
                m_Ubound = Ubound;
            }
            private double m_Lbound;
            private double m_Ubound;
            public bool m_isInclude = true;
            // Access to private members
            public double LowerBound { get { return m_Lbound; } }
            public double UpperBound { get { return m_Ubound; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }

        }
        public class RatingCondition
        {
            public RatingCondition(double Lbound, double Ubound)
            {
                m_Lbound = Lbound;
                m_Ubound = Ubound;
                m_isInclude = true;
            }
            private double m_Lbound;
            private double m_Ubound;
            private bool m_isInclude;
            // Access to private members
            public double LowerBound { get { return m_Lbound; } }
            public double UpperBound { get { return m_Ubound; } }
            public bool isInclude { get { return m_isInclude; } set { m_isInclude = value; } }
        }

        #endregion

        #region Filtering Underlyings on Conditions Methods
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, List<CountryCondition> ConditionList)
        {
            if (ConditionList.Count == 0) return true;
            bool result = false;
            // If at least one match change the boolean
            foreach (CountryCondition condition in ConditionList)
            {
                if (underlying.Country == condition.Country)
                {
                    result = true;
                    break;
                }
            }
            if (ConditionList[0].isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, List<CurrencyCondition> ConditionList)
        {
            if (ConditionList.Count == 0) return true;
            bool result = false;
            // Change the bool if underlying matches at least one currency
            foreach (CurrencyCondition Condition in ConditionList)
            {
                if (underlying.Currency == Condition.Currency)
                {
                    result = true;
                    break;
                }
            }
            if (ConditionList[0].isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, List<SectorCondtion> ConditionList)
        {
            if (ConditionList.Count == 0) return true;
            bool result = false;
            // Change the bool if underlying matches at least one currency
            foreach (SectorCondtion Condition in ConditionList)
            {
                if (underlying.SubSector == Condition.SubSector)
                {
                    result = true;
                    break;
                }
            }
            if (ConditionList[0].isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, VolCondition Condition)
        {
            bool result;
            result = underlying.Volatility >= Condition.LowerBound
                    && underlying.Volatility <= Condition.UpperBound ? true : false;
            if (Condition.isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, FwdCondition Condition)
        {
            bool result;
            result = underlying.Forward >= Condition.LowerBound
                    && underlying.Forward <= Condition.UpperBound ? true : false;
            if (Condition.isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, LiquidityCondition Condition)
        {
            bool result;
            result = underlying.Liquidity >= Condition.LowerBound
                    && underlying.Liquidity <= Condition.UpperBound ? true : false;
            if (Condition.isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }
        private bool CheckUnderlyingOnCondition(Structures.Underlying underlying, RatingCondition Condition)
        {
            bool result;
            result = underlying.Rating >= Condition.LowerBound
                    && underlying.Rating <= Condition.UpperBound ? true : false;
            if (Condition.isInclude)
            {
                return result;
            }
            else
            {
                return !result;
            }
        }

        #endregion

        #region  Adding conditions (buttons)
        // Numerical conditions
        // Condition on volatility
        private void buttonAddVolFilter_Click(object sender, EventArgs e)
        {
            string message;
            double Lbound;
            double Ubound;
            if (!OptimizerInput.SomeFiltersApplied)
            {
                message = "You cannot apply a volatility filter. Please apply other filters first";
                MessageBox.Show(message);
                return;
            }
            bool dummy1 = double.TryParse(textBoxVolLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound);
            bool dummy2 = double.TryParse(textBoxVolUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound);


            if (_volCondition != null)
            {
                message = "A volatility filter has already been specified. Please remove it before adding a new one.";
                MessageBox.Show(message);
            }
            else if (!double.TryParse(textBoxVolLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound) ||
                    !double.TryParse(textBoxVolUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound))
            {
                message = "Please ensure that the bounds you entered are numbers";
                MessageBox.Show(message);
            }
            else if (Lbound >= Ubound)
            {
                message = "Please check your range, the lower bound cannot be higher than the upper bound.";
                MessageBox.Show(message);
            }
            else
            {
                Lbound /= 100.0;
                Ubound /= 100.0;
                _volCondition = new VolCondition(Lbound, Ubound);
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Volatility";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = "[" + Lbound + "," + Ubound + "]";
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";

            }
        }
        // Condition on forward
        private void buttonAddFwdFilter_Click(object sender, EventArgs e)
        {
            string message;
            double Lbound;
            double Ubound;
            if (!OptimizerInput.SomeFiltersApplied)
            {
                message = "You cannot apply a volatility filter. Please apply other filters first";
                MessageBox.Show(message);
                return;
            }

            bool dummy1 = double.TryParse(textBoxFwdLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound);
            bool dummy2 = double.TryParse(textBoxFwdUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound);
            if (_fwdCondition != null)
            {
                message = "A forward filter has already been specified. Please remove it before adding a new one";
                MessageBox.Show(message);
            }
            else if (!double.TryParse(textBoxFwdLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound) ||
                     !double.TryParse(textBoxFwdUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound))
            {
                message = "Please ensure that the bounds you entered are numbers";
                MessageBox.Show(message);
            }
            else if (Lbound >= Ubound)
            {
                message = "Please check your range, the lower bound cannot be higher than the upper bound";
                MessageBox.Show(message);
            }
            else
            {
                Lbound /= 100.0;
                Ubound /= 100.0;
                _fwdCondition = new FwdCondition(Lbound, Ubound);
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Forward";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = "[" + Lbound + "," + Ubound + "]";
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
            CheckIfFiltersApplied();
        }
        // Condition on liquidity
        private void buttonAddLiquidityFilter_Click(object sender, EventArgs e)
        {
            double Lbound;
            double Ubound;
            bool dummy1 = double.TryParse(textBoxLiquidityLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound);
            bool dummy2 = double.TryParse(textBoxLiquidityUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound);
            if (_liquidCondition != null)
            {
                string errorString = "A liquidity filter has already been specified. Please remove it before adding a new one";
                MessageBox.Show(errorString);
            }
            else if (!double.TryParse(textBoxLiquidityLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound) ||
                     !double.TryParse(textBoxLiquidityUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound))
            {
                string errorString = "Please ensure that the bounds you entered are numbers";
                MessageBox.Show(errorString);
            }
            else if (Lbound >= Ubound)
            {
                string errorString = "Please check your range, the lower bound cannot be higher than the upper bound";
                MessageBox.Show(errorString);
            }
            else
            {
                _liquidCondition = new LiquidityCondition(Lbound, Ubound);
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Liquidity";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = "[" + Lbound + "," + Ubound + "]";
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
            CheckIfFiltersApplied();
        }
        // Condition on rating
        private void buttonAddRatingFilter_Click(object sender, EventArgs e)
        {
            double Lbound;
            double Ubound;
            bool dummy1 = double.TryParse(textBoxFwdLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound);
            bool dummy2 = double.TryParse(textBoxFwdUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound);
            if (_ratingCondition != null)
            {
                string errorString = "A rating filter has already been specified. Please remove it before adding a new one";
                MessageBox.Show(errorString);
            }
            else if (!double.TryParse(textBoxRatingLowerBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Lbound) ||
                     !double.TryParse(textBoxRatingUpperBound.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out Ubound))
            {
                string errorString = "Please ensure that the bounds you entered are numbers";
                MessageBox.Show(errorString);
            }
            else if (Lbound >= Ubound)
            {
                string errorString = "Please check your range, the lower bound cannot be higher than the upper bound";
                MessageBox.Show(errorString);
            }
            else
            {
                _ratingCondition = new RatingCondition(Lbound, Ubound);
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Rating";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = "[" + Lbound + "," + Ubound + "]";
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
        }

        // Conditions by select
        // Condition on currency
        private void checkedListBoxCurrencies_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (checkedListBoxCurrencies.CheckedIndices.Count ==0)
            {
                CurrencyConditionsList = null;
                return;
            }
            CurrencyConditionsList = new List<CurrencyCondition>();
            // Clear the old DataGridView row if it exists
            for (int row = 0; row < dataGridViewConditions.Rows.Count; row++)
            {
                if (dataGridViewConditions.Rows[row].Cells[1].Value.ToString() == "Currency")
                {
                    dataGridViewConditions.Rows.RemoveAt(row);
                }
            }

            foreach (object itemChecked in checkedListBoxCurrencies.CheckedItems)
            {
                CurrencyConditionsList.Add(new CurrencyCondition(itemChecked.ToString()));
            }
            //If we have any currencies selected add the condition in the datagrid
            if (CurrencyConditionsList.Count > 0)
            {
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Currency";
                string cciesString = "[";
                foreach (CurrencyCondition condition in CurrencyConditionsList)
                {
                    cciesString += condition.Currency + ",";
                }
                cciesString = cciesString.Remove(cciesString.Length - 1);
                cciesString += "]";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = cciesString;
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
            CheckIfFiltersApplied();
        }

        // Condition on country
        private void checkedListBoxCountries_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(checkedListBoxCountries.CheckedIndices.Count ==0)
            {
                CountryConditionsList = null;
                return;
            }
            CountryConditionsList = new List<CountryCondition>();
            // Clear the old DataGridView row if it exists
            for (int row = 0; row < dataGridViewConditions.Rows.Count; row++)
            {
                if (dataGridViewConditions.Rows[row].Cells[1].Value.ToString() == "Country")
                {
                    dataGridViewConditions.Rows.RemoveAt(row);
                }
            }

            foreach (object itemChecked in checkedListBoxCountries.CheckedItems)
            {
                CountryConditionsList.Add(new CountryCondition(itemChecked.ToString()));
            }
            //If we have any currencies selected add the condition in the datagrid
            if (CountryConditionsList.Count > 0)
            {
                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Country";
                string countriesString = "[";
                foreach (CountryCondition condition in CountryConditionsList)
                {
                    countriesString += condition.Country + ",";
                }
                countriesString = countriesString.Remove(countriesString.Length - 1);
                countriesString += "]";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = countriesString;
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
            CheckIfFiltersApplied();
        }

        // Condition on Sector
        private void treeViewSector_NodeMouseClick(Object sender, TreeNodeMouseClickEventArgs e)
        {
            SectorConditionsList = new List<SectorCondtion>();
            bool checkedResult = e.Node.Checked;
            //Delete the old stuff on the UI as well
            foreach (DataGridViewRow row in dataGridViewConditions.Rows)
            {
                if (row.Cells[1].Value.ToString() == "Sector")
                {
                    dataGridViewConditions.Rows.Remove(row);
                }
            }
            // Apply check/uncheck to all children nodes
            // if e has children nodes (e.g. industry)
            if (e.Node.Nodes.Count > 0)
            {
                foreach (TreeNode node1 in e.Node.Nodes)
                {
                    node1.Checked = checkedResult;
                    // if node1 has children (e.g. supersector)
                    if (node1.Nodes.Count > 0)
                    {
                        foreach (TreeNode node2 in node1.Nodes)
                        {
                            node2.Checked = checkedResult;
                            // if node2 has children (e.g. sector)
                            if (node2.Nodes.Count > 0)
                            {
                                foreach (TreeNode node3 in node2.Nodes)
                                {
                                    node3.Checked = checkedResult;
                                }
                            }
                        }
                    }
                }

            }

            // Retrieve the list


            //Industry
            foreach (TreeNode node1 in treeViewSector.Nodes)
            {
                //for each Supersector
                foreach (TreeNode node2 in node1.Nodes)
                {
                    //for each Sector
                    foreach (TreeNode node3 in node2.Nodes)
                    {
                        foreach (TreeNode node4 in node3.Nodes)
                        {
                            if (node4.Checked == true)
                            {
                                SectorConditionsList.Add(new SectorCondtion(node4.Text));
                            }
                        }
                    }
                }
            }


            //If we have any subsectors selected add the condition in the datagrid
            if (SectorConditionsList.Count > 0)
            {
                foreach (DataGridViewRow row in dataGridViewConditions.Rows)
                {
                    if (row.Cells[1].Value.ToString() == "Sector")
                    {
                        dataGridViewConditions.Rows.Remove(row);
                    }
                }

                //Add to the Datagrid
                dataGridViewConditions.Rows.Add();
                int count = dataGridViewConditions.Rows.Count;
                dataGridViewConditions.Rows[count - 1].Cells[1].Value = "Sector";
                string sectorString = "[";
                foreach (SectorCondtion condition in SectorConditionsList)
                {
                    sectorString += condition.SubSector + ",";
                }
                sectorString = sectorString.Remove(sectorString.Length - 1);
                sectorString += "]";
                dataGridViewConditions.Rows[count - 1].Cells[2].Value = sectorString;
                dataGridViewConditions.Rows[count - 1].Cells[0].Value = "Include";
            }
            CheckIfFiltersApplied();
        }

        #endregion

        // Filtering of universe
        private void buttonApplyFilters_Click(object sender, EventArgs e)
        {
            string message;
            CheckIfFiltersApplied();
            if (!_filtersApplied)
            {
                message = "No filters have been applied, do you wish to return to the previous form?";
                if (MessageBox.Show(message, "No filters applied", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    BasketOptimizer = new BasketOptimizerNew(this);
                    this.Close();
                    BasketOptimizer.Show();
                    return;
                }
                else
                {
                    return;
                }
            }


            filteredUnderlyingsList = new List<Structures.Underlying>();
            bool isIncludeValue;
            // Recover the Include/Exclude Values
            foreach (DataGridViewRow row in dataGridViewConditions.Rows)
            {
                isIncludeValue = row.Cells[0].Value.ToString() == "Include" ? true : false;
                if (row.Cells[1].Value.ToString() == "Sector")
                {
                    foreach (SectorCondtion condition in SectorConditionsList)
                    {
                        condition.isInclude = isIncludeValue;
                    }
                }
                else if (row.Cells[1].Value.ToString() == "Currency")
                {
                    foreach (CurrencyCondition condition in CurrencyConditionsList)
                    {
                        condition.isInclude = isIncludeValue;
                    }
                }
                else if (row.Cells[1].Value.ToString() == "Country")
                {
                    foreach (CountryCondition condition in CountryConditionsList)
                    {
                        condition.isInclude = isIncludeValue;
                    }
                }
                else if (row.Cells[1].Value.ToString() == "Volatility")
                {
                    _volCondition.isInclude = isIncludeValue;
                }
                else if (row.Cells[1].Value.ToString() == "Forward")
                {
                    _fwdCondition.isInclude = isIncludeValue;
                }
                else if (row.Cells[1].Value.ToString() == "Liquidity")
                {
                    _liquidCondition.isInclude = isIncludeValue;
                }
                else if (row.Cells[1].Value.ToString() == "Rating")
                {
                    _ratingCondition.isInclude = isIncludeValue;
                }
            }

            #region Bloomberg data filters

            foreach (Structures.Underlying underlying in underlyingsList)
            {
                // Currency
                if (CurrencyConditionsList != null)
                {
                    if (CurrencyConditionsList.Count != 0)
                    {
                        if (!CheckUnderlyingOnCondition(underlying, CurrencyConditionsList))
                        {
                            continue;
                        }
                    }
                }
                // Country
                if (CountryConditionsList != null)
                {
                    if (CountryConditionsList.Count != 0)
                    {
                        if (!CheckUnderlyingOnCondition(underlying, CountryConditionsList))
                        {
                            continue;
                        }
                    }
                }

                // Rating Filter
                if (_ratingCondition != null)
                {
                    if (!CheckUnderlyingOnCondition(underlying, _ratingCondition))
                    {
                        continue;
                    }
                }

                // Sector Filter
                if (SectorConditionsList != null)
                {
                    if (SectorConditionsList.Count != 0)
                    {
                        if (!CheckUnderlyingOnCondition(underlying, SectorConditionsList))
                        {
                            continue;
                        }
                    }
                }

                // Liquidity Filter
                if (_liquidCondition != null)
                {
                    if (!CheckUnderlyingOnCondition(underlying, _liquidCondition))
                    {
                        continue;
                    }
                }

                // Survived to all filters: We keep he underlying so far :) !
                filteredUnderlyingsList.Add(underlying);
            }

            #endregion

            // Now Sophis data conditions
            BbgFilterUnderlyings = filteredUnderlyingsList;
            filteredUnderlyingsList = new List<Structures.Underlying>();
            underlyingsTickers = BbgFilterUnderlyings.Select(stock => stock.Ticker).ToList();

            Structures.SophisData SophisData = new Structures.SophisData(underlyingsTickers, OptimizerInput.Currency,
                                                                         OptimizerInput.Maturity, OptimizerInput.Strike);

            // Get the vol/skew if there is a condition
            if (_volCondition != null)
            {
                _volatilitiesLoading = true;
                SophisData.LoadVolsSkews();
                foreach (Structures.Underlying underlying in BbgFilterUnderlyings)
                {
                    underlying.GetVol(SophisData);
                    underlying.GetSkew(SophisData);
                }
                // Quick clean up of negative  vols
                HelperMethods.CleanNegativeVols(BbgFilterUnderlyings);
                _volatilitiesLoading = false;
            }

            // Get the forward if there is a condition
            if (_fwdCondition != null)
            {
                SophisData.LoadFwds();
                foreach (Structures.Underlying underlying in BbgFilterUnderlyings)
                {
                    underlying.GetForward(SophisData);
                }
            }

            // Apply conditions on vol, fwd
            foreach (Structures.Underlying underlying in BbgFilterUnderlyings)
            {
                //Volatility
                if (_volCondition != null)
                {

                    if (!CheckUnderlyingOnCondition(underlying, _volCondition))
                    {
                        continue;
                    }

                }

                // Forward Filter
                if (_fwdCondition != null)
                {
                    if (!CheckUnderlyingOnCondition(underlying, _fwdCondition))
                    {
                        continue;
                    }
                }

                // Survived to all filters: We keep he underlying :) !
                filteredUnderlyingsList.Add(underlying);
            }
            BasketOptimizer = new BasketOptimizerNew(this);
            this.Close();
            BasketOptimizer.Show();
        }

        // Deleting a filter
        private void dataGridViewConditions_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridViewConditions.Columns[e.ColumnIndex].Name == "DeleteColumn")
            {
                int row = e.RowIndex;
                string criterium = dataGridViewConditions.Rows[row].Cells[1].Value.ToString();
                //Delete the corresponding criterium

                if (criterium == "SubSector")
                {
                    SectorConditionsList.Clear();
                }
                else if (criterium == "Currency")
                {
                    CurrencyConditionsList.Clear();
                    for (int i = 0; i < checkedListBoxCurrencies.Items.Count; i++)
                    {
                        checkedListBoxCurrencies.SetItemChecked(i, false);
                    }
                }
                else if (criterium == "Country")
                {
                    CountryConditionsList.Clear();
                    for(int i=0; i <checkedListBoxCountries.Items.Count;i++)
                    {
                        checkedListBoxCountries.SetItemChecked(i, false);
                    }
                }
                else if (criterium == "Volatility")
                {
                    _volCondition = null;
                }
                else if (criterium == "Forward")
                {
                    _fwdCondition = null;
                }
                else if (criterium == "Liquidity")
                {
                    _liquidCondition = null;
                }
                else
                {
                    _ratingCondition = null;
                }
                // Delete the row
                dataGridViewConditions.Rows.RemoveAt(row);
            }
        }

        private void CheckIfFiltersApplied()
        {
            if (CurrencyConditionsList == null && CountryConditionsList == null && _ratingCondition == null
                && SectorConditionsList == null && _liquidCondition == null && _volCondition == null && _fwdCondition == null)
            {
                _filtersApplied = false;
                return;
            }
            else
            {
                try
                {
                    if (CurrencyConditionsList.Count == 0 && CountryConditionsList.Count == 0 && _ratingCondition == null
                        && SectorConditionsList.Count == 0 && _liquidCondition == null && _volCondition == null && _fwdCondition == null)
                    {
                        _filtersApplied = false;
                        return;
                    }
                    else
                    {
                        _filtersApplied = true;
                        return;
                    }
                }
                catch(Exception ex)
                {
                    _filtersApplied = true;
                    return;
                }
            }

        }

        #region Private

        private List<CountryCondition> CountryConditionsList;
        private List<CurrencyCondition> CurrencyConditionsList;
        private List<SectorCondtion> SectorConditionsList;
        private VolCondition _volCondition;
        private FwdCondition _fwdCondition;
        private LiquidityCondition _liquidCondition;
        private RatingCondition _ratingCondition;
        private List<Structures.Underlying> BbgFilterUnderlyings;
        private bool _filtersApplied;
        private bool _volatilitiesLoading;
        private string _currency;
        private double _maturity;
        private double _strike;

        #endregion

        #region Public
        // Public
        public string Currency { get { return _currency; } }
        public double Maturity { get { return _maturity; } }
        public double Strike{ get{ return _strike; } }
        public BasketOptimizerNew OptimizerInput;
        public BasketOptimizerNew BasketOptimizer;
        public List<Structures.Underlying> underlyingsList;
        public List<string> underlyingsTickers;
        public List<Structures.Underlying> filteredUnderlyingsList;
        public Dictionary<string, string> SubSectorsDictionary = new Dictionary<string, string>();
        public Dictionary<string, string> SectorsDictionary = new Dictionary<string, string>();
        public Dictionary<string, string> SuperSectorsDictionary = new Dictionary<string, string>();
        public List<string> IndustriesList = new List<string>();
        public bool FiltersApplied { get { return _filtersApplied; } }

        #endregion

        private void GenerateSectorDictionaries()
        {
            IndustriesList.Add("Oil & Gas");
            IndustriesList.Add("Basic Material");
            IndustriesList.Add("Industrials");
            IndustriesList.Add("Consumer Goods");
            IndustriesList.Add("Health Care");
            IndustriesList.Add("Consumer Services");
            IndustriesList.Add("Telecommunications");
            IndustriesList.Add("Utilities");
            IndustriesList.Add("Financials");
            IndustriesList.Add("Technology");


            #region SuperSectors
            SuperSectorsDictionary.Add("Oil & Gas", "Oil & Gas");
            SuperSectorsDictionary.Add("Chemicals", "Basic Material");
            SuperSectorsDictionary.Add("Basic Resources", "Basic Material");
            SuperSectorsDictionary.Add("Construction & Materials", "Industrials");
            SuperSectorsDictionary.Add("Industrial Goods & Services", "Industrials");
            SuperSectorsDictionary.Add("Automobiles & Parts", "Consumer Goods");
            SuperSectorsDictionary.Add("Food & Beverage", "Consumer Goods");
            SuperSectorsDictionary.Add("Personal & HouseHold Goods", "Consumer Goods");
            SuperSectorsDictionary.Add("Health Care", "Health Care");
            SuperSectorsDictionary.Add("Retail", "Consumer Services");
            SuperSectorsDictionary.Add("Media", "Consumer Services");
            SuperSectorsDictionary.Add("Travel & Leisure", "Consumer Services");
            SuperSectorsDictionary.Add("Telecommunications", "Telecommunications");
            SuperSectorsDictionary.Add("Utilities", "Utilities");
            SuperSectorsDictionary.Add("Banks","Financials");
            SuperSectorsDictionary.Add("Insurance", "Financials");
            SuperSectorsDictionary.Add("Real Estate", "Financials");
            SuperSectorsDictionary.Add("Financial Services", "Financials");
            SuperSectorsDictionary.Add("Technology", "Technology");

            #endregion

            #region Sectors
            SectorsDictionary.Add("Oil & Gas Producers", "Oil & Gas");
            SectorsDictionary.Add("Oil Equipment, Services & Distribution","Oil & Gas");
            SectorsDictionary.Add("Alternative Energy", "Oil & Gas");
            SectorsDictionary.Add("Chemicals", "Chemicals");
            SectorsDictionary.Add("Forestry & Paper", "Basic Resources");
            SectorsDictionary.Add("Industrial Metals & Mining", "Basic Resources");
            SectorsDictionary.Add("Mining", "Basic Resources");
            SectorsDictionary.Add("Construction & Materials", "Construction & Materials");
            SectorsDictionary.Add("Aerospace & Defense", "Industrial Goods & Services");
            SectorsDictionary.Add("General Industrials", "Industrial Goods & Services");
            SectorsDictionary.Add("Electronic & Electrical Equipment", "Industrial Goods & Services");
            SectorsDictionary.Add("Industrial Engineering", "Industrial Goods & Services");
            SectorsDictionary.Add("Industrial Transportation", "Industrial Goods & Services");
            SectorsDictionary.Add("Support Services", "Industrial Goods & Services");
            SectorsDictionary.Add("Automobiles & Parts", "Automobiles & Parts");
            SectorsDictionary.Add("Beverages", "Food & Beverage");
            SectorsDictionary.Add("Food Producers", "Food & Beverage");
            SectorsDictionary.Add("Leisure Goods", "Personal & HouseHold Goods");
            SectorsDictionary.Add("Personal Goods", "Personal & HouseHold Goods");
            SectorsDictionary.Add("Tobacco", "Personal & HouseHold Goods");
            SectorsDictionary.Add("Health Care Equipment & Services", "Health Care");
            SectorsDictionary.Add("Pharmaceuticals & Biotechnology", "Health Care");
            SectorsDictionary.Add("Food & Drug Retailers", "Retail");
            SectorsDictionary.Add("General Retailers", "Retail");
            SectorsDictionary.Add("Media", "Media");
            SectorsDictionary.Add("Travel & Leisure", "Travel & Leisure");
            SectorsDictionary.Add("Fixed Line Telecommunications", "Telecommunications");
            SectorsDictionary.Add("Mobile Telecommunications", "Telecommunications");
            SectorsDictionary.Add("Electricity", "Utilities");
            SectorsDictionary.Add("Gas, Water & Multi-utilities", "Utilities");
            SectorsDictionary.Add("Banks", "Banks");
            SectorsDictionary.Add("Nonlife Insurance", "Insurance");
            SectorsDictionary.Add("Life Insurance", "Insurance");
            SectorsDictionary.Add("Real Estate Investment & Services", "Real Estate");
            SectorsDictionary.Add("Real Estate Investment Trusts", "Real Estate");
            SectorsDictionary.Add("Financial Services", "Financial Services");
            SectorsDictionary.Add("Equity Investment Instruments", "Financial Services");
            SectorsDictionary.Add("Nonequity Investment Instruments", "Financial Services");
            SectorsDictionary.Add("Software & Computer Services", "Technology");
            SectorsDictionary.Add("Technology Hardware & Equipment", "Technology");
            #endregion


            #region Subsectors
            SubSectorsDictionary.Add("Exploration & Production", "Oil & Gas Producers");
            SubSectorsDictionary.Add("Integrated Oil & Gas", "Oil & Gas Producers");
            SubSectorsDictionary.Add("Oil Equipment & Services", "Oil Equipment, Services & Distribution");
            SubSectorsDictionary.Add("Pipelines", "Oil Equipment, Services & Distribution");
            SubSectorsDictionary.Add("Renewable Energy Equipment", "Alternative Energy");
            SubSectorsDictionary.Add("Alternative Fuels", "Alternative Energy");
            SubSectorsDictionary.Add("Commodity Chemicals", "Chemicals");
            SubSectorsDictionary.Add("Speciality Chemicals", "Chemicals");
            SubSectorsDictionary.Add("Forestry", "Forestry & Paper");
            SubSectorsDictionary.Add("Paper", "Forestry & Paper");
            SubSectorsDictionary.Add("Aluminium", "Industrial Metals & Mining");
            SubSectorsDictionary.Add("Nonferrous metals", "Industrial Metals & Mining");
            SubSectorsDictionary.Add("Iron & Steel", "Industrial Metals & Mining");
            SubSectorsDictionary.Add("Coal", "Mining");
            SubSectorsDictionary.Add("Diamonds & Gemstones", "Mining");
            SubSectorsDictionary.Add("General Mining", "Mining");
            SubSectorsDictionary.Add("Gold Mining", "Mining");
            SubSectorsDictionary.Add("Platinum & Precious Metals", "Mining");
            SubSectorsDictionary.Add("Building Materials & Fixtures", "Construction & Materials");
            SubSectorsDictionary.Add("Heavy Construction", "Construction & Materials");
            SubSectorsDictionary.Add("Aerospace", "Aerospace & Defense");
            SubSectorsDictionary.Add("Defense", "Aerospace & Defense");
            SubSectorsDictionary.Add("Containers & Packaging", "General Industrials");
            SubSectorsDictionary.Add("Diversified Industrials", "General Industrials");
            SubSectorsDictionary.Add("Electrical Components & Equipment", "Electronic & Electrical Equipment");
            SubSectorsDictionary.Add("Electronic Equipment", "Electronic & Electrical Equipment");
            SubSectorsDictionary.Add("Commercial Vehicles & Trucks", "Industrial Engineering");
            SubSectorsDictionary.Add("Industrial Machinery", "Industrial Engineering");
            SubSectorsDictionary.Add("Delivery Services", "Industrial Transportation");
            SubSectorsDictionary.Add("Marine Transportation", "Industrial Transportation");
            SubSectorsDictionary.Add("Railroads", "Industrial Transportation");
            SubSectorsDictionary.Add("Transportation Services", "Industrial Transportation");
            SubSectorsDictionary.Add("Trucking", "Industrial Transportation");
            SubSectorsDictionary.Add("Business Support Services", "Support Services");
            SubSectorsDictionary.Add("Business Training & Employment Agencies", "Support Services");
            SubSectorsDictionary.Add("Financial Administration", "Support Services");
            SubSectorsDictionary.Add("Inudstrial Suppliers", "Support Services");
            SubSectorsDictionary.Add("Waste & Disposal Services", "Support Services");
            SubSectorsDictionary.Add("Automobiles", "Automobiles & Parts");
            SubSectorsDictionary.Add("Auto Parts", "Automobiles & Parts");
            SubSectorsDictionary.Add("Tires", "Automobiles & Parts");
            SubSectorsDictionary.Add("Brewers", "Beverages");
            SubSectorsDictionary.Add("Distillers & Vinters", "Beverages");
            SubSectorsDictionary.Add("Soft Drinks", "Beverages");
            SubSectorsDictionary.Add("Farming, Fishing & Plantations", "Food Producers");
            SubSectorsDictionary.Add("Food Products", "Food Producers");
            SubSectorsDictionary.Add("Durable Household Products", "Household Goods & Home Construction");
            SubSectorsDictionary.Add("Nonurable Household Products", "Household Goods & Home Construction");
            SubSectorsDictionary.Add("Furnishings", "Household Goods & Home Construction");
            SubSectorsDictionary.Add("Home Construction", "Household Goods & Home Construction");
            SubSectorsDictionary.Add("Consumer Electronics", "Leisure Goods");
            SubSectorsDictionary.Add("Recreational Products", "Leisure Goods");
            SubSectorsDictionary.Add("Toys", "Leisure Goods");
            SubSectorsDictionary.Add("Clothing & Accessories", "Personal Goods");
            SubSectorsDictionary.Add("Footwear", "Personal Goods");
            SubSectorsDictionary.Add("Personal Products", "Personal Goods");
            SubSectorsDictionary.Add("Tobacco", "Tobacco");
            SubSectorsDictionary.Add("Health Care Providers", "Health Care Equipment & Services");
            SubSectorsDictionary.Add("Medical Equipment", "Health Care Equipment & Services");
            SubSectorsDictionary.Add("Medical Supplies", "Health Care Equipment & Services");
            SubSectorsDictionary.Add("Biotechnology", "Pharmaceuticals & Biotechnology");
            SubSectorsDictionary.Add("Pharmaceuticals", "Pharmaceuticals & Biotechnology");
            SubSectorsDictionary.Add("Drug Retailers", "Food & Drug Retailers");
            SubSectorsDictionary.Add("Food Retailers & Wholesalers", "Food & Drug Retailers");
            SubSectorsDictionary.Add("Apparel Retailers", "General Retailers");
            SubSectorsDictionary.Add("Broadline Retailers", "General Retailers");
            SubSectorsDictionary.Add("Home Improvement Retailers", "General Retailers");
            SubSectorsDictionary.Add("Specialized Consumer Retailers", "General Retailers");
            SubSectorsDictionary.Add("Specialty Retailers", "General Retailers");
            SubSectorsDictionary.Add("Broadcasting & Entertainment", "Media");
            SubSectorsDictionary.Add("Media Agencies", "Media");
            SubSectorsDictionary.Add("Publishing", "Media");
            SubSectorsDictionary.Add("Airlines", "Travel & Leisure");
            SubSectorsDictionary.Add("Gambling","Travel & Leisure");
            SubSectorsDictionary.Add("Hotels", "Travel & Leisure");
            SubSectorsDictionary.Add("Recreational Services", "Travel & Leisure");
            SubSectorsDictionary.Add("Restaurants & Bars", "Travel & Leisure");
            SubSectorsDictionary.Add("Travel & Tourism", "Travel & Leisure");
            SubSectorsDictionary.Add("Fixed Line Telecommunications", "Fixed Line Telecommunications");
            SubSectorsDictionary.Add("Mobile Telecommunications", "Mobile Telecommunications");
            SubSectorsDictionary.Add("Conventional Electricity", "Electricity");
            SubSectorsDictionary.Add("Alternative Electricity", "Electricity");
            SubSectorsDictionary.Add("Gas Distribution", "Gas, Water & Multi-utilities");
            SubSectorsDictionary.Add("Multi-utilities", "Gas, Water & Multi-utilities");
            SubSectorsDictionary.Add("Water", "Gas, Water & Multi-utilities");
            SubSectorsDictionary.Add("Banks", "Banks");
            SubSectorsDictionary.Add("Full Line Insurance", "Nonlife Insurance");
            SubSectorsDictionary.Add("Insurance Brokers", "Nonlife Insurance");
            SubSectorsDictionary.Add("Property & Casualty Insurance", "Nonlife Insurance");
            SubSectorsDictionary.Add("Reinsurance", "Nonlife Insurance");
            SubSectorsDictionary.Add("Life Insurance", "Life Insurance");
            SubSectorsDictionary.Add("Real Estate Holding & Development", "Real Estate Investment & Services");
            SubSectorsDictionary.Add("Real Estate Services", "Real Estate Investment & Services");
            SubSectorsDictionary.Add("Industrial & Office REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Retail REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Residential REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Diversified REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Specialty REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Mortgage REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Hotel & Lodging REITs", "Real Estate Investment Trusts");
            SubSectorsDictionary.Add("Asset Managers", "Financial Services");
            SubSectorsDictionary.Add("Consumer Finance", "Financial Services");
            SubSectorsDictionary.Add("Specialty Finance", "Financial Services");
            SubSectorsDictionary.Add("Investment Services", "Financial Services");
            SubSectorsDictionary.Add("Mortgage Finance", "Financial Services");
            SubSectorsDictionary.Add("Equity Investment Instruments", "Equity Investment Instruments");
            SubSectorsDictionary.Add("Nonequity Investment Instruments", "Nonequity Investment Instruments");
            SubSectorsDictionary.Add("Computer Services", "Software & Computer Services");
            SubSectorsDictionary.Add("Internet", "Software & Computer Services");
            SubSectorsDictionary.Add( "Software", "Software & Computer Services");
            SubSectorsDictionary.Add("Computer Hardware", "Technology Hardware & Equipment");
            SubSectorsDictionary.Add("Electronic Office Equipment", "Technology Hardware & Equipment");
            SubSectorsDictionary.Add("Semiconductors", "Technology Hardware & Equipment");
            SubSectorsDictionary.Add("Telecommunications Equipment", "Technology Hardware & Equipment");




            #endregion

        }
    }
}


    

