﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Estimators;

namespace BBClient
{
    public partial class CustomBumps : Form
    {
        public CustomBumps(CorrelationForm CorrelationForm)
        {
            InitializeComponent();

            _mainForm = CorrelationForm;
            FormatInputs(this);
            InitShow();
        }

        #region Init
        public void FormatInputs(Control masterCtrl)
        {
            foreach (Control ctrl in masterCtrl.Controls)
            {
                if (ctrl is TextBox)
                {
                    double bump = (ctrl == textBox11 || ctrl == textBox22 || ctrl == textBox33 || 
                        ctrl == textBox44) ? 5 : 0;
                    ((TextBox)ctrl).Text = Convert.ToString(bump);
                }
                else if (ctrl is CheckBox)
                {
                    ((CheckBox)ctrl).Checked = false;
                }
                else
                {
                    FormatInputs(ctrl);
                }
            }
        }

        public void InitShow()
        {
            //this._panel2.Enabled = false;
        }
        #endregion

        private void _buttonSetCorrels_Click(object sender, EventArgs e)
        {
            _mainForm.SetCustomCorrelBumps(GetCustomBumps());
        }

        private void _buttonGroup1_Click(object sender, EventArgs e)
        {
            SetAsGroup(0);
        }

        private void _buttonGroup2_Click(object sender, EventArgs e)
        {
            SetAsGroup(1);
        }

        private void _buttonGroup3_Click(object sender, EventArgs e)
        {
            SetAsGroup(2);
        }

        private void _buttonGroup4_Click(object sender, EventArgs e)
        {
            SetAsGroup(3);
        }

        private void SetAsGroup(int i)
        {
            _mainForm.SetAsGroup(i);
            _mainForm.SetCustomCorrelBumps(GetCustomBumps());
        }

        public List<BumpPlot> GetCustomBumps()
        {
            List<BumpPlot> bumpList = new List<BumpPlot>();
            bumpList.Add(CreateBumpPlot(textBox11, checkBox11));
            bumpList.Add(CreateBumpPlot(textBox12, checkBox12));
            bumpList.Add(CreateBumpPlot(textBox22, checkBox22));
            bumpList.Add(CreateBumpPlot(textBox13, checkBox13));
            bumpList.Add(CreateBumpPlot(textBox23, checkBox23));
            bumpList.Add(CreateBumpPlot(textBox33, checkBox33));
            bumpList.Add(CreateBumpPlot(textBox14, checkBox14));
            bumpList.Add(CreateBumpPlot(textBox24, checkBox24));
            bumpList.Add(CreateBumpPlot(textBox34, checkBox34));
            bumpList.Add(CreateBumpPlot(textBox44, checkBox44));
            return bumpList;
        }

        private BumpPlot CreateBumpPlot(TextBox txtBox, CheckBox chkBox)
        {
            bool isAbs = chkBox.Checked;
            double intensity = double.NaN;
            double.TryParse(txtBox.Text, out intensity);
            BumpPlot returnPlot = new BumpPlot();
            // In percent
            returnPlot.BumpIntensity = intensity / 100;
            returnPlot.IsAbsolute = isAbs;
            return returnPlot;
        }

        private CorrelationForm _mainForm;
    }
}