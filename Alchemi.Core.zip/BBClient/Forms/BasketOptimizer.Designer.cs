﻿using RemotingInterfaces;
namespace BBClient
{
    partial class BasketOptimizer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BasketOptimizer));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            this._groupBoxParameters = new System.Windows.Forms.GroupBox();
            this._buttonCheckBasket = new System.Windows.Forms.Button();
            this._buttonOptimize = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this._comboBoxQuanto = new System.Windows.Forms.ComboBox();
            this.currenciesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cCDataSet = new CCDataSet();
            this._labelCurr = new System.Windows.Forms.Label();
            this._textBoxConstraintsNbStocks = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this._textBoxConstraintsTenor = new System.Windows.Forms.TextBox();
            this._groupBoxSensitivities = new System.Windows.Forms.GroupBox();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this._textBoxSensiCovariance = new System.Windows.Forms.TextBox();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this._textBoxSensiQuanto = new System.Windows.Forms.TextBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this._textBoxSensiCorrel = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this._textBoxSensiForward = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this._textBoxSensiSkew = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this._textBoxSensiSkew1 = new System.Windows.Forms.TextBox();
            this._textBoxSensiSkew2 = new System.Windows.Forms.TextBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this._textBoxSensiVol = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this._textBoxSensiStrike = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this._buttonSaveSettings = new System.Windows.Forms.Button();
            this._buttonSensitivitiesInvert = new System.Windows.Forms.Button();
            this._groupBoxSensitivitiesCustom = new System.Windows.Forms.GroupBox();
            this.label17 = new System.Windows.Forms.Label();
            this._buttonSensitivityCustom2 = new System.Windows.Forms.Button();
            this._textBoxSensiCustom1 = new System.Windows.Forms.TextBox();
            this._labelSensitivityCustom2 = new System.Windows.Forms.Label();
            this._labelSensitivityCustom1 = new System.Windows.Forms.Label();
            this._textBoxSensiCustom2 = new System.Windows.Forms.TextBox();
            this._buttonSensitivityCustom1 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this._comboBoxPresets = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this._toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this._dataGridViewListAll = new StructuringControls.ExcelDataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fix = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label22 = new System.Windows.Forms.Label();
            this._dataGridViewResult = new StructuringControls.ExcelDataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Vol = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Skew = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Fwd = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label21 = new System.Windows.Forms.Label();
            this.currenciesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter();
            this._backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this._timer = new System.Windows.Forms.Timer(this.components);
            this._buttonClearBasket = new System.Windows.Forms.Button();
            this._groupBoxParameters.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
            this._groupBoxSensitivities.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel5.SuspendLayout();
            this._groupBoxSensitivitiesCustom.SuspendLayout();
            this.panel1.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this.panel2.SuspendLayout();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewListAll)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewResult)).BeginInit();
            this.SuspendLayout();
            // 
            // _groupBoxParameters
            // 
            this._groupBoxParameters.Controls.Add(this._buttonClearBasket);
            this._groupBoxParameters.Controls.Add(this._buttonCheckBasket);
            this._groupBoxParameters.Controls.Add(this._buttonOptimize);
            this._groupBoxParameters.Controls.Add(this.groupBox2);
            this._groupBoxParameters.Controls.Add(this._groupBoxSensitivities);
            this._groupBoxParameters.Dock = System.Windows.Forms.DockStyle.Top;
            this._groupBoxParameters.Location = new System.Drawing.Point(0, 0);
            this._groupBoxParameters.Name = "_groupBoxParameters";
            this._groupBoxParameters.Size = new System.Drawing.Size(616, 229);
            this._groupBoxParameters.TabIndex = 0;
            this._groupBoxParameters.TabStop = false;
            this._groupBoxParameters.Text = "Optimization parameters";
            // 
            // _buttonCheckBasket
            // 
            this._buttonCheckBasket.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._buttonCheckBasket.Location = new System.Drawing.Point(132, 126);
            this._buttonCheckBasket.Name = "_buttonCheckBasket";
            this._buttonCheckBasket.Size = new System.Drawing.Size(88, 61);
            this._buttonCheckBasket.TabIndex = 7;
            this._buttonCheckBasket.Text = "Advanced basket creation";
            this._buttonCheckBasket.UseVisualStyleBackColor = true;
            this._buttonCheckBasket.Click += new System.EventHandler(this._buttonCheckBasket_Click);
            // 
            // _buttonOptimize
            // 
            this._buttonOptimize.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this._buttonOptimize.Location = new System.Drawing.Point(6, 124);
            this._buttonOptimize.Name = "_buttonOptimize";
            this._buttonOptimize.Size = new System.Drawing.Size(120, 95);
            this._buttonOptimize.TabIndex = 6;
            this._buttonOptimize.Text = "Maximize";
            this._buttonOptimize.UseVisualStyleBackColor = true;
            this._buttonOptimize.Click += new System.EventHandler(this._buttonOptimize_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this._comboBoxQuanto);
            this.groupBox2.Controls.Add(this._labelCurr);
            this.groupBox2.Controls.Add(this._textBoxConstraintsNbStocks);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.label15);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this._textBoxConstraintsTenor);
            this.groupBox2.Location = new System.Drawing.Point(6, 19);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(215, 97);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Global parameters";
            // 
            // _comboBoxQuanto
            // 
            this._comboBoxQuanto.DataSource = this.currenciesBindingSource;
            this._comboBoxQuanto.DisplayMember = "Value";
            this._comboBoxQuanto.FormattingEnabled = true;
            this._comboBoxQuanto.Location = new System.Drawing.Point(107, 70);
            this._comboBoxQuanto.Name = "_comboBoxQuanto";
            this._comboBoxQuanto.Size = new System.Drawing.Size(96, 21);
            this._comboBoxQuanto.TabIndex = 16;
            this._comboBoxQuanto.ValueMember = "Value";
            // 
            // currenciesBindingSource
            // 
            this.currenciesBindingSource.DataMember = "Currencies";
            this.currenciesBindingSource.DataSource = this.cCDataSet;
            // 
            // cCDataSet
            // 
            this.cCDataSet.DataSetName = "CCDataSet";
            this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // _labelCurr
            // 
            this._labelCurr.AutoSize = true;
            this._labelCurr.Location = new System.Drawing.Point(46, 73);
            this._labelCurr.Name = "_labelCurr";
            this._labelCurr.Size = new System.Drawing.Size(55, 13);
            this._labelCurr.TabIndex = 17;
            this._labelCurr.Text = "Currency :";
            // 
            // _textBoxConstraintsNbStocks
            // 
            this._textBoxConstraintsNbStocks.Location = new System.Drawing.Point(108, 44);
            this._textBoxConstraintsNbStocks.Name = "_textBoxConstraintsNbStocks";
            this._textBoxConstraintsNbStocks.Size = new System.Drawing.Size(49, 20);
            this._textBoxConstraintsNbStocks.TabIndex = 13;
            this._textBoxConstraintsNbStocks.Text = "2";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 47);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(96, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Number of stocks :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(163, 21);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(40, 13);
            this.label15.TabIndex = 18;
            this.label15.Text = "Year(s)";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(61, 21);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(41, 13);
            this.label14.TabIndex = 14;
            this.label14.Text = "Tenor :";
            // 
            // _textBoxConstraintsTenor
            // 
            this._textBoxConstraintsTenor.Location = new System.Drawing.Point(108, 18);
            this._textBoxConstraintsTenor.Name = "_textBoxConstraintsTenor";
            this._textBoxConstraintsTenor.Size = new System.Drawing.Size(49, 20);
            this._textBoxConstraintsTenor.TabIndex = 15;
            this._textBoxConstraintsTenor.Text = "1";
            // 
            // _groupBoxSensitivities
            // 
            this._groupBoxSensitivities.Controls.Add(this.panel10);
            this._groupBoxSensitivities.Controls.Add(this.panel9);
            this._groupBoxSensitivities.Controls.Add(this.panel8);
            this._groupBoxSensitivities.Controls.Add(this.panel7);
            this._groupBoxSensitivities.Controls.Add(this.panel6);
            this._groupBoxSensitivities.Controls.Add(this.panel5);
            this._groupBoxSensitivities.Controls.Add(this._buttonSaveSettings);
            this._groupBoxSensitivities.Controls.Add(this._buttonSensitivitiesInvert);
            this._groupBoxSensitivities.Controls.Add(this._groupBoxSensitivitiesCustom);
            this._groupBoxSensitivities.Controls.Add(this._comboBoxPresets);
            this._groupBoxSensitivities.Controls.Add(this.label1);
            this._groupBoxSensitivities.Location = new System.Drawing.Point(226, 19);
            this._groupBoxSensitivities.Name = "_groupBoxSensitivities";
            this._groupBoxSensitivities.Size = new System.Drawing.Size(383, 206);
            this._groupBoxSensitivities.TabIndex = 2;
            this._groupBoxSensitivities.TabStop = false;
            this._groupBoxSensitivities.Text = "Sensitivities";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel10.Controls.Add(this.label16);
            this.panel10.Controls.Add(this._textBoxSensiCovariance);
            this.panel10.Location = new System.Drawing.Point(6, 174);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(145, 26);
            this.panel10.TabIndex = 37;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(1, 6);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "Covariance :";
            // 
            // _textBoxSensiCovariance
            // 
            this._textBoxSensiCovariance.Enabled = false;
            this._textBoxSensiCovariance.Location = new System.Drawing.Point(74, 3);
            this._textBoxSensiCovariance.Name = "_textBoxSensiCovariance";
            this._textBoxSensiCovariance.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiCovariance.TabIndex = 13;
            this._textBoxSensiCovariance.Text = "0";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Controls.Add(this.label6);
            this.panel9.Controls.Add(this._textBoxSensiQuanto);
            this.panel9.Location = new System.Drawing.Point(6, 149);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(145, 26);
            this.panel9.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 6);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(48, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "Quanto :";
            // 
            // _textBoxSensiQuanto
            // 
            this._textBoxSensiQuanto.Location = new System.Drawing.Point(74, 3);
            this._textBoxSensiQuanto.Name = "_textBoxSensiQuanto";
            this._textBoxSensiQuanto.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiQuanto.TabIndex = 11;
            this._textBoxSensiQuanto.Text = "0";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel8.Controls.Add(this._textBoxSensiCorrel);
            this.panel8.Controls.Add(this.label3);
            this.panel8.Location = new System.Drawing.Point(6, 124);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(145, 26);
            this.panel8.TabIndex = 35;
            // 
            // _textBoxSensiCorrel
            // 
            this._textBoxSensiCorrel.Location = new System.Drawing.Point(75, 3);
            this._textBoxSensiCorrel.Name = "_textBoxSensiCorrel";
            this._textBoxSensiCorrel.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiCorrel.TabIndex = 8;
            this._textBoxSensiCorrel.Text = "0";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(63, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Correlation :";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Controls.Add(this.label5);
            this.panel7.Controls.Add(this._textBoxSensiForward);
            this.panel7.Location = new System.Drawing.Point(6, 99);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(145, 26);
            this.panel7.TabIndex = 34;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 6);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Forward :";
            // 
            // _textBoxSensiForward
            // 
            this._textBoxSensiForward.Location = new System.Drawing.Point(75, 3);
            this._textBoxSensiForward.Name = "_textBoxSensiForward";
            this._textBoxSensiForward.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiForward.TabIndex = 9;
            this._textBoxSensiForward.Text = "0";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.WhiteSmoke;
            this.panel6.Controls.Add(this.label4);
            this.panel6.Controls.Add(this._textBoxSensiSkew);
            this.panel6.Controls.Add(this.label8);
            this.panel6.Controls.Add(this.label9);
            this.panel6.Controls.Add(this.label10);
            this.panel6.Controls.Add(this._textBoxSensiSkew1);
            this.panel6.Controls.Add(this._textBoxSensiSkew2);
            this.panel6.Location = new System.Drawing.Point(6, 74);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(364, 26);
            this.panel6.TabIndex = 33;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(40, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Skew :";
            // 
            // _textBoxSensiSkew
            // 
            this._textBoxSensiSkew.Location = new System.Drawing.Point(75, 3);
            this._textBoxSensiSkew.Name = "_textBoxSensiSkew";
            this._textBoxSensiSkew.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiSkew.TabIndex = 7;
            this._textBoxSensiSkew.Text = "0";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(245, 6);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(10, 13);
            this.label8.TabIndex = 31;
            this.label8.Text = "-";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(142, 6);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(45, 13);
            this.label9.TabIndex = 25;
            this.label9.Text = "Strikes :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(316, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(15, 13);
            this.label10.TabIndex = 30;
            this.label10.Text = "%";
            // 
            // _textBoxSensiSkew1
            // 
            this._textBoxSensiSkew1.BackColor = System.Drawing.SystemColors.Window;
            this._textBoxSensiSkew1.Location = new System.Drawing.Point(193, 3);
            this._textBoxSensiSkew1.Name = "_textBoxSensiSkew1";
            this._textBoxSensiSkew1.Size = new System.Drawing.Size(49, 20);
            this._textBoxSensiSkew1.TabIndex = 26;
            this._textBoxSensiSkew1.Text = "90";
            // 
            // _textBoxSensiSkew2
            // 
            this._textBoxSensiSkew2.BackColor = System.Drawing.SystemColors.Window;
            this._textBoxSensiSkew2.Location = new System.Drawing.Point(261, 3);
            this._textBoxSensiSkew2.Name = "_textBoxSensiSkew2";
            this._textBoxSensiSkew2.Size = new System.Drawing.Size(49, 20);
            this._textBoxSensiSkew2.TabIndex = 29;
            this._textBoxSensiSkew2.Text = "110";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.Gainsboro;
            this.panel5.Controls.Add(this.label2);
            this.panel5.Controls.Add(this._textBoxSensiVol);
            this.panel5.Controls.Add(this.label18);
            this.panel5.Controls.Add(this._textBoxSensiStrike);
            this.panel5.Controls.Add(this.label20);
            this.panel5.Location = new System.Drawing.Point(6, 49);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(364, 26);
            this.panel5.TabIndex = 32;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(41, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Vol :";
            // 
            // _textBoxSensiVol
            // 
            this._textBoxSensiVol.Location = new System.Drawing.Point(75, 3);
            this._textBoxSensiVol.Name = "_textBoxSensiVol";
            this._textBoxSensiVol.Size = new System.Drawing.Size(65, 20);
            this._textBoxSensiVol.TabIndex = 6;
            this._textBoxSensiVol.Text = "1";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(147, 6);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(40, 13);
            this.label18.TabIndex = 19;
            this.label18.Text = "Strike :";
            // 
            // _textBoxSensiStrike
            // 
            this._textBoxSensiStrike.BackColor = System.Drawing.SystemColors.Window;
            this._textBoxSensiStrike.Location = new System.Drawing.Point(193, 3);
            this._textBoxSensiStrike.Name = "_textBoxSensiStrike";
            this._textBoxSensiStrike.Size = new System.Drawing.Size(49, 20);
            this._textBoxSensiStrike.TabIndex = 20;
            this._textBoxSensiStrike.Text = "100";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(248, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(15, 13);
            this.label20.TabIndex = 21;
            this.label20.Text = "%";
            // 
            // _buttonSaveSettings
            // 
            this._buttonSaveSettings.Enabled = false;
            this._buttonSaveSettings.Location = new System.Drawing.Point(224, 22);
            this._buttonSaveSettings.Name = "_buttonSaveSettings";
            this._buttonSaveSettings.Size = new System.Drawing.Size(97, 23);
            this._buttonSaveSettings.TabIndex = 24;
            this._buttonSaveSettings.Text = "Save to presets";
            this._buttonSaveSettings.UseVisualStyleBackColor = true;
            // 
            // _buttonSensitivitiesInvert
            // 
            this._buttonSensitivitiesInvert.Enabled = false;
            this._buttonSensitivitiesInvert.Location = new System.Drawing.Point(199, 117);
            this._buttonSensitivitiesInvert.Name = "_buttonSensitivitiesInvert";
            this._buttonSensitivitiesInvert.Size = new System.Drawing.Size(117, 30);
            this._buttonSensitivitiesInvert.TabIndex = 23;
            this._buttonSensitivitiesInvert.Text = "Invert signs";
            this._buttonSensitivitiesInvert.UseVisualStyleBackColor = true;
            // 
            // _groupBoxSensitivitiesCustom
            // 
            this._groupBoxSensitivitiesCustom.Controls.Add(this.label17);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._buttonSensitivityCustom2);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._textBoxSensiCustom1);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._labelSensitivityCustom2);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._labelSensitivityCustom1);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._textBoxSensiCustom2);
            this._groupBoxSensitivitiesCustom.Controls.Add(this._buttonSensitivityCustom1);
            this._groupBoxSensitivitiesCustom.Controls.Add(this.label19);
            this._groupBoxSensitivitiesCustom.Enabled = false;
            this._groupBoxSensitivitiesCustom.Location = new System.Drawing.Point(157, 156);
            this._groupBoxSensitivitiesCustom.Name = "_groupBoxSensitivitiesCustom";
            this._groupBoxSensitivitiesCustom.Size = new System.Drawing.Size(214, 44);
            this._groupBoxSensitivitiesCustom.TabIndex = 22;
            this._groupBoxSensitivitiesCustom.TabStop = false;
            this._groupBoxSensitivitiesCustom.Text = "Custom";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(12, 25);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(57, 13);
            this.label17.TabIndex = 14;
            this.label17.Text = "Custom 1 :";
            // 
            // _buttonSensitivityCustom2
            // 
            this._buttonSensitivityCustom2.Location = new System.Drawing.Point(75, 46);
            this._buttonSensitivityCustom2.Name = "_buttonSensitivityCustom2";
            this._buttonSensitivityCustom2.Size = new System.Drawing.Size(26, 23);
            this._buttonSensitivityCustom2.TabIndex = 21;
            this._buttonSensitivityCustom2.Text = "...";
            this._buttonSensitivityCustom2.UseVisualStyleBackColor = true;
            // 
            // _textBoxSensiCustom1
            // 
            this._textBoxSensiCustom1.Location = new System.Drawing.Point(140, 22);
            this._textBoxSensiCustom1.Name = "_textBoxSensiCustom1";
            this._textBoxSensiCustom1.Size = new System.Drawing.Size(68, 20);
            this._textBoxSensiCustom1.TabIndex = 15;
            // 
            // _labelSensitivityCustom2
            // 
            this._labelSensitivityCustom2.AutoSize = true;
            this._labelSensitivityCustom2.Location = new System.Drawing.Point(137, 51);
            this._labelSensitivityCustom2.Name = "_labelSensitivityCustom2";
            this._labelSensitivityCustom2.Size = new System.Drawing.Size(31, 13);
            this._labelSensitivityCustom2.TabIndex = 20;
            this._labelSensitivityCustom2.Text = "none";
            // 
            // _labelSensitivityCustom1
            // 
            this._labelSensitivityCustom1.AutoSize = true;
            this._labelSensitivityCustom1.Location = new System.Drawing.Point(103, 25);
            this._labelSensitivityCustom1.Name = "_labelSensitivityCustom1";
            this._labelSensitivityCustom1.Size = new System.Drawing.Size(31, 13);
            this._labelSensitivityCustom1.TabIndex = 16;
            this._labelSensitivityCustom1.Text = "none";
            // 
            // _textBoxSensiCustom2
            // 
            this._textBoxSensiCustom2.Location = new System.Drawing.Point(174, 48);
            this._textBoxSensiCustom2.Name = "_textBoxSensiCustom2";
            this._textBoxSensiCustom2.Size = new System.Drawing.Size(157, 20);
            this._textBoxSensiCustom2.TabIndex = 19;
            // 
            // _buttonSensitivityCustom1
            // 
            this._buttonSensitivityCustom1.Location = new System.Drawing.Point(75, 20);
            this._buttonSensitivityCustom1.Name = "_buttonSensitivityCustom1";
            this._buttonSensitivityCustom1.Size = new System.Drawing.Size(26, 23);
            this._buttonSensitivityCustom1.TabIndex = 17;
            this._buttonSensitivityCustom1.Text = "...";
            this._buttonSensitivityCustom1.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 51);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(57, 13);
            this.label19.TabIndex = 18;
            this.label19.Text = "Custom 2 :";
            // 
            // _comboBoxPresets
            // 
            this._comboBoxPresets.Enabled = false;
            this._comboBoxPresets.FormattingEnabled = true;
            this._comboBoxPresets.Location = new System.Drawing.Point(78, 22);
            this._comboBoxPresets.Name = "_comboBoxPresets";
            this._comboBoxPresets.Size = new System.Drawing.Size(140, 21);
            this._comboBoxPresets.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Presets :";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._statusStrip);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 507);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(616, 21);
            this.panel1.TabIndex = 1;
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._toolStripProgressBar,
            this._toolStripStatusLabel});
            this._statusStrip.Location = new System.Drawing.Point(0, -1);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(616, 22);
            this._statusStrip.TabIndex = 16;
            this._statusStrip.Text = "statusStrip1";
            // 
            // _toolStripProgressBar
            // 
            this._toolStripProgressBar.Name = "_toolStripProgressBar";
            this._toolStripProgressBar.Size = new System.Drawing.Size(150, 16);
            // 
            // _toolStripStatusLabel
            // 
            this._toolStripStatusLabel.Name = "_toolStripStatusLabel";
            this._toolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.splitContainer1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 229);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(616, 278);
            this.panel2.TabIndex = 2;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this._dataGridViewListAll);
            this.splitContainer1.Panel1.Controls.Add(this.label22);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this._dataGridViewResult);
            this.splitContainer1.Panel2.Controls.Add(this.label21);
            this.splitContainer1.Size = new System.Drawing.Size(616, 278);
            this.splitContainer1.SplitterDistance = 313;
            this.splitContainer1.TabIndex = 38;
            // 
            // _dataGridViewListAll
            // 
            this._dataGridViewListAll.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.AliceBlue;
            this._dataGridViewListAll.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this._dataGridViewListAll.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this._dataGridViewListAll.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dataGridViewListAll.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.Fix,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14});
            this._dataGridViewListAll.CorrelationDataTable = null;
            this._dataGridViewListAll.DataComplete = "OK";
            this._dataGridViewListAll.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dataGridViewListAll.EmphasisColor = System.Drawing.Color.Red;
            this._dataGridViewListAll.EmphasizedCount = -2147483648;
            this._dataGridViewListAll.GroupIndexColumn = -2147483648;
            this._dataGridViewListAll.GroupList = ((System.Collections.Generic.List<System.Collections.Generic.List<int>>)(resources.GetObject("_dataGridViewListAll.GroupList")));
            this._dataGridViewListAll.HistoricalDataIncompleteColumn = -2147483648;
            this._dataGridViewListAll.IncompleteColor = System.Drawing.Color.Red;
            this._dataGridViewListAll.IsCustomGroup = false;
            this._dataGridViewListAll.IsPaintable = false;
            this._dataGridViewListAll.Location = new System.Drawing.Point(0, 18);
            this._dataGridViewListAll.Margin = new System.Windows.Forms.Padding(0);
            this._dataGridViewListAll.MissingColor = System.Drawing.Color.Red;
            this._dataGridViewListAll.MissingData = "N#A Sec";
            this._dataGridViewListAll.MissingDataReferenceColumn = -2147483648;
            this._dataGridViewListAll.Name = "_dataGridViewListAll";
            this._dataGridViewListAll.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this._dataGridViewListAll.RowHeadersVisible = false;
            this._dataGridViewListAll.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dataGridViewListAll.Size = new System.Drawing.Size(313, 260);
            this._dataGridViewListAll.TabIndex = 17;
            this._dataGridViewListAll.CellParsing += new System.Windows.Forms.DataGridViewCellParsingEventHandler(this._dataGridViewListAll_CellParsing);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Security";
            this.dataGridViewTextBoxColumn3.HeaderText = "Security";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Fix
            // 
            this.Fix.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Fix.DataPropertyName = "Fix";
            this.Fix.FalseValue = "0";
            this.Fix.HeaderText = "Fix";
            this.Fix.Name = "Fix";
            this.Fix.TrueValue = "1";
            this.Fix.Width = 26;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Vol";
            dataGridViewCellStyle2.Format = "0.00%";
            this.dataGridViewTextBoxColumn8.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTextBoxColumn8.HeaderText = "Vol";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn8.Visible = false;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Skew";
            dataGridViewCellStyle3.Format = "0.00%";
            this.dataGridViewTextBoxColumn9.DefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridViewTextBoxColumn9.HeaderText = "Skew";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn9.Visible = false;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Quanto";
            dataGridViewCellStyle4.Format = "0.00%";
            this.dataGridViewTextBoxColumn10.DefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridViewTextBoxColumn10.HeaderText = "Quanto";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn10.Visible = false;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Forward";
            dataGridViewCellStyle5.Format = "0.00%";
            this.dataGridViewTextBoxColumn15.DefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridViewTextBoxColumn15.HeaderText = "Fwd";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn15.Visible = false;
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "CRNCY";
            this.dataGridViewTextBoxColumn11.HeaderText = "Currency";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn11.Visible = false;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Liquidity";
            dataGridViewCellStyle6.Format = "#,##0";
            this.dataGridViewTextBoxColumn12.DefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridViewTextBoxColumn12.HeaderText = "Cash Liquidity";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn12.Visible = false;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "AvailableData";
            this.dataGridViewTextBoxColumn13.HeaderText = "Available Data";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn13.Visible = false;
            this.dataGridViewTextBoxColumn13.Width = 90;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "GroupIndex";
            this.dataGridViewTextBoxColumn14.HeaderText = "GroupIndex";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn14.Visible = false;
            this.dataGridViewTextBoxColumn14.Width = 5;
            // 
            // label22
            // 
            this.label22.BackColor = System.Drawing.Color.Blue;
            this.label22.Dock = System.Windows.Forms.DockStyle.Top;
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(0, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(313, 18);
            this.label22.TabIndex = 19;
            this.label22.Text = "Input basket";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // _dataGridViewResult
            // 
            this._dataGridViewResult.AllowUserToAddRows = false;
            this._dataGridViewResult.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.SeaShell;
            this._dataGridViewResult.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this._dataGridViewResult.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this._dataGridViewResult.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._dataGridViewResult.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.Vol,
            this.Skew,
            this.dataGridViewTextBoxColumn4,
            this.Fwd,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7});
            this._dataGridViewResult.CorrelationDataTable = null;
            this._dataGridViewResult.DataComplete = "OK";
            this._dataGridViewResult.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dataGridViewResult.EmphasisColor = System.Drawing.Color.Red;
            this._dataGridViewResult.EmphasizedCount = -2147483648;
            this._dataGridViewResult.GroupIndexColumn = -2147483648;
            this._dataGridViewResult.GroupList = ((System.Collections.Generic.List<System.Collections.Generic.List<int>>)(resources.GetObject("_dataGridViewResult.GroupList")));
            this._dataGridViewResult.HistoricalDataIncompleteColumn = -2147483648;
            this._dataGridViewResult.IncompleteColor = System.Drawing.Color.Red;
            this._dataGridViewResult.IsCustomGroup = false;
            this._dataGridViewResult.IsPaintable = false;
            this._dataGridViewResult.Location = new System.Drawing.Point(0, 18);
            this._dataGridViewResult.Margin = new System.Windows.Forms.Padding(0);
            this._dataGridViewResult.MissingColor = System.Drawing.Color.Red;
            this._dataGridViewResult.MissingData = "N#A Sec";
            this._dataGridViewResult.MissingDataReferenceColumn = -2147483648;
            this._dataGridViewResult.Name = "_dataGridViewResult";
            this._dataGridViewResult.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this._dataGridViewResult.RowHeadersVisible = false;
            this._dataGridViewResult.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dataGridViewResult.Size = new System.Drawing.Size(299, 260);
            this._dataGridViewResult.TabIndex = 16;
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Security";
            this.dataGridViewTextBoxColumn1.HeaderText = "Security";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // Vol
            // 
            this.Vol.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Vol.DataPropertyName = "Vol";
            dataGridViewCellStyle8.Format = "0.00%";
            this.Vol.DefaultCellStyle = dataGridViewCellStyle8;
            this.Vol.HeaderText = "Vol";
            this.Vol.Name = "Vol";
            this.Vol.ReadOnly = true;
            this.Vol.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Vol.Width = 28;
            // 
            // Skew
            // 
            this.Skew.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Skew.DataPropertyName = "Skew";
            dataGridViewCellStyle9.Format = "0.00%";
            this.Skew.DefaultCellStyle = dataGridViewCellStyle9;
            this.Skew.HeaderText = "Skew";
            this.Skew.Name = "Skew";
            this.Skew.ReadOnly = true;
            this.Skew.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Skew.Width = 40;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quanto";
            dataGridViewCellStyle10.Format = "0.00%";
            this.dataGridViewTextBoxColumn4.DefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridViewTextBoxColumn4.HeaderText = "Quanto";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.dataGridViewTextBoxColumn4.Width = 48;
            // 
            // Fwd
            // 
            this.Fwd.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
            this.Fwd.DataPropertyName = "Forward";
            dataGridViewCellStyle11.Format = "0.00%";
            this.Fwd.DefaultCellStyle = dataGridViewCellStyle11;
            this.Fwd.HeaderText = "Fwd";
            this.Fwd.Name = "Fwd";
            this.Fwd.ReadOnly = true;
            this.Fwd.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            this.Fwd.Width = 33;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "CRNCY";
            this.dataGridViewTextBoxColumn2.HeaderText = "Currency";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Liquidity";
            dataGridViewCellStyle12.Format = "#,##0";
            this.dataGridViewTextBoxColumn5.DefaultCellStyle = dataGridViewCellStyle12;
            this.dataGridViewTextBoxColumn5.HeaderText = "Cash Liquidity";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn5.Visible = false;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "AvailableData";
            this.dataGridViewTextBoxColumn6.HeaderText = "Available Data";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn6.Visible = false;
            this.dataGridViewTextBoxColumn6.Width = 90;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "GroupIndex";
            this.dataGridViewTextBoxColumn7.HeaderText = "GroupIndex";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.dataGridViewTextBoxColumn7.Visible = false;
            this.dataGridViewTextBoxColumn7.Width = 5;
            // 
            // label21
            // 
            this.label21.BackColor = System.Drawing.Color.RosyBrown;
            this.label21.Dock = System.Windows.Forms.DockStyle.Top;
            this.label21.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label21.Location = new System.Drawing.Point(0, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(299, 18);
            this.label21.TabIndex = 18;
            this.label21.Text = "Optimized basket";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // currenciesTableAdapter
            // 
            this.currenciesTableAdapter.ClearBeforeFill = true;
            // 
            // _backgroundWorker
            // 
            this._backgroundWorker.WorkerReportsProgress = true;
            this._backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this._backgroundWorker_DoWork);
            this._backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._backgroundWorker_RunWorkerCompleted);
            this._backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this._backgroundWorker_ProgressChanged);
            // 
            // _buttonClearBasket
            // 
            this._buttonClearBasket.Location = new System.Drawing.Point(132, 193);
            this._buttonClearBasket.Name = "_buttonClearBasket";
            this._buttonClearBasket.Size = new System.Drawing.Size(88, 26);
            this._buttonClearBasket.TabIndex = 8;
            this._buttonClearBasket.Text = "Clear basket";
            this._buttonClearBasket.UseVisualStyleBackColor = true;
            this._buttonClearBasket.Click += new System.EventHandler(this._buttonClearBasket_Click);
            // 
            // BasketOptimizer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 528);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this._groupBoxParameters);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "BasketOptimizer";
            this.Text = "Basket Optimizer";
            this.Load += new System.EventHandler(this.BasketOptimizer_Load);
            this._groupBoxParameters.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
            this._groupBoxSensitivities.ResumeLayout(false);
            this._groupBoxSensitivities.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this._groupBoxSensitivitiesCustom.ResumeLayout(false);
            this._groupBoxSensitivitiesCustom.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewListAll)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewResult)).EndInit();
            this.ResumeLayout(false);

}

        #endregion

        private System.Windows.Forms.GroupBox _groupBoxParameters;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.ComboBox _comboBoxPresets;
        private System.Windows.Forms.GroupBox _groupBoxSensitivities;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox _textBoxSensiQuanto;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox _textBoxSensiForward;
        private System.Windows.Forms.TextBox _textBoxSensiCorrel;
        private System.Windows.Forms.TextBox _textBoxSensiSkew;
        private System.Windows.Forms.TextBox _textBoxSensiVol;
        private System.Windows.Forms.Button _buttonCheckBasket;
        private System.Windows.Forms.Button _buttonOptimize;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox _textBoxConstraintsNbStocks;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox _textBoxConstraintsTenor;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox _comboBoxQuanto;
        private System.Windows.Forms.Label _labelCurr;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox _textBoxSensiCovariance;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.StatusStrip _statusStrip;
        private System.Windows.Forms.ToolStripProgressBar _toolStripProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel _toolStripStatusLabel;
        private System.Windows.Forms.Button _buttonSensitivityCustom1;
        private System.Windows.Forms.Label _labelSensitivityCustom1;
        private System.Windows.Forms.TextBox _textBoxSensiCustom1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button _buttonSensitivityCustom2;
        private System.Windows.Forms.Label _labelSensitivityCustom2;
        private System.Windows.Forms.TextBox _textBoxSensiCustom2;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.GroupBox _groupBoxSensitivitiesCustom;
        private CCDataSet cCDataSet;
        private System.Windows.Forms.BindingSource currenciesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter currenciesTableAdapter;
        private System.Windows.Forms.Button _buttonSaveSettings;
        private System.Windows.Forms.Button _buttonSensitivitiesInvert;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox _textBoxSensiStrike;
        private StructuringControls.ExcelDataGridView _dataGridViewResult;
        private StructuringControls.ExcelDataGridView _dataGridViewListAll;
        private System.ComponentModel.BackgroundWorker _backgroundWorker;
        private System.Windows.Forms.Timer _timer;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Vol;
        private System.Windows.Forms.DataGridViewTextBoxColumn Skew;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Fwd;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox _textBoxSensiSkew2;
        private System.Windows.Forms.TextBox _textBoxSensiSkew1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Fix;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.Button _buttonClearBasket;
    }
}