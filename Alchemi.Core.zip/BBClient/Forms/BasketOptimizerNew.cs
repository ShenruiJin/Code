﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Windows.Forms;
using MarketDataMgr.Trees;
using CaesarApplication.Service.Strategy;
using BBClient.Forms;
using BBClient.Data;
using MarketDataMgr.Trees.Ext;
using System.Linq;
using System.IO;
using System.Drawing;
using System.Text.RegularExpressions;
using System.ComponentModel;
using FuncFramework.Business;
using System.Globalization;

namespace BBClient
{
    public partial class BasketOptimizerNew : BBForm
    {
        #region Constructors
        /// <summary>
        /// Constructor called from menu bar
        /// </summary>
        /// <param name="productIndex"></param>
        /// <param name="maturity"></param>
        /// <param name="strike"></param>
        /// <param name="currency"></param>
        public BasketOptimizerNew(int productIndex, double maturity, double strike, string currency)
        {
            InitializeComponent();
            _ProcessIsRunning = true;
            _productIndex = productIndex;
            _maturity = maturity;
            _strike = strike;
            _currency = currency;
            currenciesList = MarketDataService.Currencies;
            currenciesList = currenciesList.OrderBy(ccy => ccy).ToList();
            
            _SophisStocksAreLoaded = false;
            _SomeFiltersApplied = false;
            _MinLiquidityLevel = 10000000;
            _UnderlyingsEnteredManually = false;

            this.FormClosing += new FormClosingEventHandler(BasketOptimizer_FormClosing);

            InitializeDataTables();
            InitializeDataTableSophis();
            InitializeUniverseDataTable();
            _ProcessIsRunning = false;

            // Dictionaries from csv
            FilePaths = new Dictionary<string, string>();
            FilePaths.Add("Names", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksFullName.csv");
            FilePaths.Add("Countries", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksCountry.csv");
            FilePaths.Add("Currencies", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksCurrency.csv");
            FilePaths.Add("SubSectors", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksSubSector.csv");
            FilePaths.Add("Ratings", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksRating.csv");
            FilePaths.Add("Liquidities", @"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksLiquidity.csv");

            // Get the product
            strategydatasetelement = StrategyService.CurrentStrategy.GetLeafProducts()[_productIndex];
            Product = strategydatasetelement.Clone() as FuncFramework.Business.StrategyDataSetElement;

        }

        /// <summary>
        /// Constructor for application of filters
        /// </summary>
        /// <param name="OptimFilters"></param>
        public BasketOptimizerNew(OptimizerFilters OptimFilters)
        {
            InitializeComponent();
            _ProcessIsRunning = true;
            _productIndex = OptimFilters.OptimizerInput._productIndex;
            _maturity = OptimFilters.Maturity;
            _strike = OptimFilters.Strike;
            _currency = OptimFilters.Currency;
            _UnderlyingsEnteredManually = false;
            _SophisStocksAreLoaded = true;
            _SomeFiltersApplied = OptimFilters.FiltersApplied == true ? true : false;

            
            //MarketDataTree mktTree = new MarketDataTree();
            //OverloadedMarketDataTree _tree = new OverloadedMarketDataTree(mktTree);
            currenciesList = MarketDataService.Currencies;
            _MinLiquidityLevel = 10000000;
            this.FormClosing += new FormClosingEventHandler(BasketOptimizer_FormClosing);


            //Retrieve lists of underlyings (original and filtered)
            underlyingsList = OptimFilters.OptimizerInput.underlyingsList;
            if (OptimFilters.FiltersApplied)
            {
                UnderlyingsUniverseDictionary = new Dictionary<string, Structures.Underlying>();
                foreach(Structures.Underlying Underlying in OptimFilters.filteredUnderlyingsList)
                {
                    UnderlyingsUniverseDictionary.Add(Underlying.Ticker, Underlying);
                }
                KeepLiquidUnderlyings(UnderlyingsUniverseDictionary);
                underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();
            }

            //Initialize Data Grids and add them
            InitializeDataTables();
            UpdateSophisStocksDataTable();

            // Filtered table
            if (OptimFilters.FiltersApplied)
            {
                if (underlyingsListResults.Count > 0)
                {
                    UpdateUniverseDataTable();
                }
                else
                {
                    MessageBox.Show("No stocks left after applying filters",
                                    "OverConstrained Selection", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            //Get the product
            strategydatasetelement = OptimFilters.OptimizerInput.strategydatasetelement;
            Product = strategydatasetelement.Clone() as FuncFramework.Business.StrategyDataSetElement;
            
            this.FormClosing += new FormClosingEventHandler(BasketOptimizer_FormClosing);
            _ProcessIsRunning = false;
        }

        #endregion

        #region Form Methods

        /// <summary>
        /// Initialize data tables
        /// </summary>
        public void InitializeDataTables()
        {
            _ProcessIsRunning = true;
            doubleColumns = new List<string>(new string[] { colVol, colForward, colSpot, colRating });
            listAllDataTable = new DataTable();
            listUniverseDataTable = new DataTable();
            // Add Datatable columns in correct format
            foreach (DataGridViewColumn column in dataGridViewListAll.Columns)
            {
                Type colType = doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                listAllDataTable.Columns.Add(column.DataPropertyName, colType);
            }

            foreach (DataGridViewColumn column in dataGridViewUniverse.Columns)
            {
                if (column is DataGridViewTextBoxColumn)
                {
                    Type colType = doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                    listUniverseDataTable.Columns.Add(column.DataPropertyName, colType);
                }
                else if (column is DataGridViewCheckBoxColumn)
                {
                    listUniverseDataTable.Columns.Add(column.DataPropertyName, typeof(int));
                }
            }

            // Affectation de la datatable
            dataGridViewListAll.AutoGenerateColumns = false;
            dataGridViewListAll.DataSource = listAllDataTable;
            dataGridViewUniverse.AutoGenerateColumns = false;
            dataGridViewUniverse.DataSource = listUniverseDataTable;

            // Init Gui
            //_dataGridViewListAll.GroupIndexColumn = _listAllDataTable.Columns.Count - 1;
            //_dataGridViewListAll.IsCustomGroup = true;
            _ProcessIsRunning = false;

        }

        /// <summary>
        /// Initialize the "Sophis" data table (containing all stocks when loaded)
        /// </summary>
        public void InitializeDataTableSophis()
        {
            _ProcessIsRunning = true;
            doubleColumns = new List<string>(new string[] { colVol, colForward, colSpot, colRating });
            listAllDataTable = new DataTable();
            // Add Datatable columns in correct format
            foreach (DataGridViewColumn column in dataGridViewListAll.Columns)
            {
                Type colType = doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                listAllDataTable.Columns.Add(column.DataPropertyName, colType);
            }

            // Affectation de la datatable
            dataGridViewListAll.AutoGenerateColumns = false;
            dataGridViewListAll.DataSource = listAllDataTable;

            // Init Gui
            //_dataGridViewListAll.GroupIndexColumn = _listAllDataTable.Columns.Count - 1;
            //_dataGridViewListAll.IsCustomGroup = true;
            _ProcessIsRunning = false;
        }

        /// <summary>
        /// Initialize the lower data table containing stocks for optimization
        /// </summary>
        public void InitializeUniverseDataTable()
        {
            _ProcessIsRunning = true;
            doubleColumns = new List<string>(new string[] { colVol, colForward, colSpot, colRating });
            listUniverseDataTable = new DataTable();
            // Add Datatable columns in correct format
            foreach (DataGridViewColumn column in dataGridViewUniverse.Columns)
            {
                if (column is DataGridViewTextBoxColumn)
                {
                    Type colType = doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                    listUniverseDataTable.Columns.Add(column.DataPropertyName, colType);
                }
                else if (column is DataGridViewCheckBoxColumn)
                {
                    listUniverseDataTable.Columns.Add(column.DataPropertyName, typeof(int));
                }
            }

            // Affectation de la datatable
            dataGridViewUniverse.AutoGenerateColumns = false;
            dataGridViewUniverse.DataSource = listUniverseDataTable;

            // Init Gui
            //_dataGridViewListAll.GroupIndexColumn = _listAllDataTable.Columns.Count - 1;
            //_dataGridViewListAll.IsCustomGroup = true;
            _ProcessIsRunning = false;
        }

        /// <summary>
        /// Update the "Sophis" data table
        /// </summary>
        private void UpdateSophisStocksDataTable()
        {
            if (_SophisStocksAreLoaded && underlyingsList != null && underlyingsList.Count > 0)
            {
                _ProcessIsRunning = true;
                // Update the main datatable
                foreach (Structures.Underlying underlying in underlyingsList)
                {
                    DataRow row = listAllDataTable.NewRow();
                    row[colSecurity] = underlying.Ticker;
                    row[colFullName] = underlying.Name;
                    row[colSpot] = Math.Round(underlying.Spot, 3).ToString();
                    row[colLiquidity] = Math.Round(underlying.Liquidity, 2).ToString();
                    row[colCurrency] = underlying.Currency;
                    row[colCountry] = underlying.Country;
                    listAllDataTable.Rows.Add(row);
                }
                labelListAllCount.Text = underlyingsList.Count.ToString();
                _ProcessIsRunning = false;
            }
        }

        /// <summary>
        /// Update the Stock Selection data table
        /// </summary>
        private void UpdateUniverseDataTable()
        {
            listUniverseDataTable = new DataTable();
            InitializeUniverseDataTable();
            foreach (Structures.Underlying underlying in underlyingsListResults)
            {
                DataRow row = listUniverseDataTable.NewRow();
                row[colSecurity] = underlying.Ticker;
                if(underlying.NameIsLoaded)
                {
                    row[colFullName] = underlying.Name;
                }
                if(underlying.SpotIsLoaded)
                {
                    row[colSpot] = Math.Round(underlying.Spot, 2).ToString();
                }
                if(underlying.CurrencyIsLoaded)
                {
                    row[colCurrency] = underlying.Currency;
                }
                if(underlying.CountryIsLoaded)
                {
                    row[colCountry] = underlying.Country;
                }
                if(underlying.LiquidityIsLoaded)
                {
                    row[colLiquidity] = underlying.Liquidity;
                }             
                if (underlying.VolatilityIsLoaded)
                {
                    row[colVol] = Math.Round(underlying.Volatility, 2).ToString();
                }
                listUniverseDataTable.Rows.Add(row);
            }
            labelUniverseCount.Text = underlyingsListResults.Count.ToString();
        }


        /// <summary>
        /// Update the form when a value is changed/entered (data not loaded anymore), increment counter etc;
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataGridViewUniverse_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (dataGridViewUniverse.Rows.Count - 1 > 0)
                {
                    _UnderlyingsEnteredManually = true;
                    _DataIsOKtoContinue = false;
                }

                foreach (DataGridViewRow row in dataGridViewUniverse.Rows)
                {
                    row.Cells[0].Value = row.Cells[0].Value.ToString().ToUpper();
                    labelUniverseCount.Text = (dataGridViewUniverse.Rows.Count - 1).ToString(); ;
                    labelUniverseCount.Refresh();
                }
                labelDataUpdated.Text = "Market data not loaded";
                labelDataUpdated.ForeColor = Color.Red;
            }
            catch(Exception)
            {

            }
        }

        //Get Bbg Data from a file
        public static List<StockData> GetStocksDataList(string sPath)
        {
            List<StockData> StocksDataList = new List<StockData>();
            StreamReader srReader = new StreamReader(sPath);
            string sLine = srReader.ReadLine();
            sLine = srReader.ReadLine();

            while (sLine != null)
            {
                string[] sTempData = sLine.Split(',');
                StockData stock = new StockData(sTempData[0], sTempData[1], sTempData[3]);
                sLine = srReader.ReadLine();
                StocksDataList.Add(stock);
            }
            return StocksDataList;
        }

        /// <summary>
        /// Remove illiquid underlyings from a list
        /// </summary>
        /// <param name="underlyingList"></param>
        private void KeepLiquidStocks(List<Structures.Underlying> underlyingList)
        {
            underlyingList.RemoveAll(ul => ul.Liquidity <= _MinLiquidityLevel);
        }

        /// <summary>
        /// Remove illiquid underlyings from a dictionary
        /// </summary>
        /// <param name="UnderlyingsDictionary"></param>
        private void KeepLiquidUnderlyings(Dictionary<string, Structures.Underlying> UnderlyingsDictionary)
        {
            UnderlyingsDictionary.RemoveWhere(ul => ul.Value.Liquidity < _MinLiquidityLevel);
        }

        /// <summary>
        /// Form closing
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void BasketOptimizer_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
        }

        #endregion

        #region Buttons

        /// <summary>
        /// Go to the optimization set-up (opnes the launcher form)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonOptimizerSetUp_Click(object sender, EventArgs e)
        {
            if (_ProcessIsRunning)
            {
                return;
            }
            if (!_DataIsOKtoContinue)
            {
                MessageBox.Show("Please load market data before continuing", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            // If the user didnt enter tickers manually, all good
            if (!_UnderlyingsEnteredManually)
            {
                if (underlyingsListResults == null)
                {
                    MessageBox.Show("Please Check that you have some validstocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                if (underlyingsListResults.Count == 0)
                {
                    MessageBox.Show("Please Check that you have entered some stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                else
                {
                    OptimizerLauncher Launcher = new OptimizerLauncher(this);
                    this.Hide();
                    Launcher.Show();
                }
            }

            // The user entered some tickers manually
            else
            {
                #region Get tickers, remove duplicates, record the bad ones, make the dictionary/list of underlyings
                /*
                List<string> tempTickers = new List<string>();
                failedTickers = new List<string>();
                underlyingsListResults = new List<Structures.Underlying>();
                List<string> SophisTickers = DataRetrieval.GetStocksAndIndices(DataRetrieval.GetAllSophisInstruments()).Select(stock => stock.BbgCode).Distinct().ToList();

                // Get the tickers the user entered
                foreach (DataRow row in listUniverseDataTable.Rows)
                {
                    tempTickers.Add(row[colSecurity].ToString().ToUpper());
                }


                // Check if there are duplicates (causes problems with dictionaries)
                var duplicateItems = tempTickers.GroupBy(x => x).Where(x => x.Count() > 1).Select(x => x.Key);
                List<string> DuplicatesList = duplicateItems.ToList();
                if (DuplicatesList.Count > 0)
                {
                    string duplicatesForMessage = string.Join(" , ", DuplicatesList);
                    string duplicatesFoundMessage = "The following duplicate securities were found, do you wish to proceed ? \n";

                    if (MessageBox.Show(duplicatesFoundMessage + duplicatesForMessage, "Duplicates found", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        // Clean them up to allow the user to proceed
                        tempTickers = tempTickers.Distinct().ToList();
                    }
                    else
                    {
                        return;
                    }
                }

                // Now we have distinct tickers, check if they are valid
                UnderlyingsUniverseDictionary = new Dictionary<string, Structures.Underlying>();
                underlyingsListResults = new List<Structures.Underlying>();

                foreach (string ticker in tempTickers)
                {
                    if (SophisTickers.Contains(ticker))
                    {
                        UnderlyingsUniverseDictionary.Add(ticker, new Structures.Underlying(ticker, _maturity, _strike, _currency));
                    }
                    else
                    {
                        failedTickers.Add(ticker);
                    }
                }
                underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();
                */
                #endregion

                #region Start the Optimization launcher
                
                // First check that we have some stocks
                if (underlyingsListResults == null)
                {
                    MessageBox.Show("Please check that you have some valid stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }

                if (underlyingsListResults.Count == 0)
                {
                    MessageBox.Show("Please check that you have entered some valid stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                    return;
                }
                // We are sure to have some valid stocks
                // There are some bad tickers
                if (failedTickers.Count > 0)
                {
                    string message = " The following tickers could not be retrieved : \n";
                    foreach (string failedTicker in failedTickers)
                    {
                        message += failedTicker + "\n";
                    }
                    message += "Do you wish to proceed by ignoring these securites ?";

                    // If the user proceeds (continue by ignoring the tickers)
                    if (MessageBox.Show(message, "Unfound securities", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                    {
                        OptimizerLauncher Launcher = new OptimizerLauncher(this);
                        this.Hide();
                        Launcher.Show();
                    }
                    else
                    {
                        return;
                    }
                }
                // No bad tickers
                else
                {
                    OptimizerLauncher Launcher = new OptimizerLauncher(this);
                    this.Hide();
                    Launcher.Show();
                }
            }

            #endregion
        }

        /// <summary>
        /// Load market data for the underlyings
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLoadMarketData_Click(object sender, EventArgs e)
        {
            // If something else is running stop
            if (_ProcessIsRunning)
            {
                return;
            }
            _ProcessIsRunning = true;
            // If data already loaded stop
            if (_DataIsOKtoContinue)
            {
                MessageBox.Show("Market data is already loaded", "Market Data", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                _ProcessIsRunning = false;
                return;
            }

            // Load (after some more checks)
            else
            {
                toolStripStatusLabel.Text = "Loading Market Data . . .";
                toolStripStatusLabel.ForeColor = Color.Red;

                // Make a clone of the tree (to delete if clear the basket)
                //MarketDataTree Tree = strategydatasetelement.MarketDataTree.Clone() as MarketDataTree;

                // If the user didnt enter tickers manually
                if (!_UnderlyingsEnteredManually)
                {
                    // No underlyings
                    if (underlyingsListResults == null)
                    {
                        MessageBox.Show("Please check that you have some valid stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        _ProcessIsRunning = false;
                        return;
                    }

                    if (underlyingsListResults.Count == 0)
                    {
                        MessageBox.Show("Please check that you have entered some stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        _ProcessIsRunning = false;
                        return;
                    }

                    // Some underlyings coming from the filters
                    else
                    {
                        // Check the volatilities are recent enough / exist
                        bool removed = double.TryParse(textBoxVolDate.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _oldVolDate);
                        if(!removed || _oldVolDate<=0)
                        {
                            MessageBox.Show("Please enter a valid number of days for the volatility filter", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            _ProcessIsRunning = false;
                            return;
                        }
                        
                        int quality = (int)(Math.Min(99, _oldVolDate / 10.0)); // par palier de 10
                        _oldVolDate = 1.0 + 2.0 * (quality) / 10;


                        DataRetrieval.LoadMarketData(Product.MarketDataTree.OriginalTree, UnderlyingsUniverseDictionary);

                        // Remove stocks with old vol
                        _UnderlyingsWithOldVols = new List<string>();
                        foreach (string underlying in UnderlyingsUniverseDictionary.Keys.ToList())
                        {
                            double volUpdateQualityFactor = BatchService.GetLastAssetVolatilityUpdate(underlying, Product.MarketDataTree);
                            if (volUpdateQualityFactor > _oldVolDate)
                            {
                                removed = Product.MarketDataTree.OriginalTree.Tree.RemoveSubTree(MarketDataTree.GetUnderlyingPath(underlying));
                                UnderlyingsUniverseDictionary.Remove(underlying);
                                _UnderlyingsWithOldVols.Add(underlying);
                            }
                        }
                        underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();
                        if (_UnderlyingsWithOldVols.Count > 0)
                        {
                            labelUnderlyingsWithOldVol.Text = string.Join(" , ", _UnderlyingsWithOldVols);
                        }

                        UpdateUniverseDataTable();
                        labelDataUpdated.Text = "Market data loaded";
                        labelDataUpdated.ForeColor = Color.Green;
                        toolStripStatusLabel.Text = "Ready";
                        toolStripStatusLabel.ForeColor = Color.Black;
                        _DataIsOKtoContinue = true;
                        _ProcessIsRunning = false;
                        MessageBox.Show("Market Data has finished loading", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }

                // User entered data manually
                else
                {
                    #region Get tickers, remove duplicates, record the bad ones, make the dictionary/list of underlyings

                    List<string> tempTickers = new List<string>();
                    failedTickers = new List<string>();
                    underlyingsListResults = new List<Structures.Underlying>();
                    List<string> SophisTickers = DataRetrieval.GetStocksAndIndices(DataRetrieval.GetAllSophisInstruments()).Select(stock => stock.BbgCode).Distinct().ToList();

                    // Get the tickers the user entered
                    foreach (DataRow row in listUniverseDataTable.Rows)
                    {
                        tempTickers.Add(row[colSecurity].ToString().ToUpper().Trim());
                    }


                    // Check if there are duplicates (causes problems with dictionaries)
                    var duplicateItems = tempTickers.GroupBy(x => x).Where(x => x.Count() > 1).Select(x => x.Key);
                    List<string> DuplicatesList = duplicateItems.ToList();
                    if (DuplicatesList.Count > 0)
                    {
                        string duplicatesForMessage = string.Join(" , ", DuplicatesList);
                        string duplicatesFoundMessage = "The following duplicate securities were found, do you wish to proceed ? \n";

                        if (MessageBox.Show(duplicatesFoundMessage + duplicatesForMessage, "Duplicates found", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            // Clean them up to allow the user to proceed
                            tempTickers = tempTickers.Distinct().ToList();
                        }
                        else
                        {
                            toolStripStatusLabel.Text = "Ready";
                            toolStripStatusLabel.ForeColor = Color.Black;
                            _ProcessIsRunning = false;
                            return;
                        }
                    }

                    // Now we have distinct tickers, check if they are valid
                    UnderlyingsUniverseDictionary = new Dictionary<string, Structures.Underlying>();
                    underlyingsListResults = new List<Structures.Underlying>();

                    foreach (string ticker in tempTickers)
                    {
                        if (SophisTickers.Contains(ticker))
                        {
                            UnderlyingsUniverseDictionary.Add(ticker, new Structures.Underlying(ticker, _maturity, _strike, _currency));
                        }
                        else
                        {
                            failedTickers.Add(ticker);
                        }
                    }
                    
                    underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();

                    #endregion

                    #region Load the market Data

                    // First check that we have some stocks
                    if (underlyingsListResults == null)
                    {
                        MessageBox.Show("Please check that you have some valid stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        toolStripStatusLabel.Text = "Ready";
                        toolStripStatusLabel.ForeColor = Color.Black;
                        _ProcessIsRunning = false;
                        return;
                    }

                    if (underlyingsListResults.Count == 0)
                    {
                        MessageBox.Show("Please check that you have some valid stocks to run an optimization", "Information", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        toolStripStatusLabel.Text = "Ready";
                        toolStripStatusLabel.ForeColor = Color.Black;
                        _ProcessIsRunning = false;
                        return;
                    }
                    // We are sure to have some valid stocks
                    // There are some bad tickers
                    if (failedTickers.Count > 0)
                    {
                        string message = " The following tickers could not be retrieved : \n";
                        int count = 0;
                        foreach (string failedTicker in failedTickers)
                        {
                            message += failedTicker + ", ";
                            count++;
                            if(count > 15)
                            {
                                count = 0;
                                message += "\n";

                            }
                        }
                        message += "\n";
                        message += "Do you wish to proceed by ignoring these securites ?";

                        // If the user proceeds (continue by ignoring the tickers)
                        if (MessageBox.Show(message, "Unfound securities", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                        {
                            
                            // Remove stocks with old vol
                            bool removed;
                            removed = double.TryParse(textBoxVolDate.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _oldVolDate);
                            if (!removed || _oldVolDate <= 0)
                            {
                                MessageBox.Show("Please enter a valid number of days for the volatility filter", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                _ProcessIsRunning = false;
                                return;
                            }
                            DataRetrieval.LoadMarketData(strategydatasetelement.MarketDataTree.OriginalTree, UnderlyingsUniverseDictionary);
                            int quality = (int)(Math.Min(99, _oldVolDate / 10.0)); // par palier de 10
                            _oldVolDate = 1.0 + 2.0 * (quality) / 10;
                            _UnderlyingsWithOldVols = new List<string>();
                            foreach (string underlying in UnderlyingsUniverseDictionary.Keys.ToList())
                            {
                                double volUpdateQualityFactor = BatchService.GetLastAssetVolatilityUpdate(underlying, Product.MarketDataTree);
                                if (volUpdateQualityFactor > _oldVolDate)
                                {
                                    removed = Product.MarketDataTree.OriginalTree.Tree.RemoveSubTree(MarketDataTree.GetUnderlyingPath(underlying));
                                    UnderlyingsUniverseDictionary.Remove(underlying);
                                    _UnderlyingsWithOldVols.Add(underlying);
                                }
                            }
                            underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();
                            if (_UnderlyingsWithOldVols.Count > 0)
                            {
                                labelUnderlyingsWithOldVol.Text = string.Join(" , ", _UnderlyingsWithOldVols);
                            }

                            UpdateUniverseDataTable();
                            labelDataUpdated.Text = "Market data loaded";
                            labelDataUpdated.ForeColor = Color.Green;
                            toolStripStatusLabel.Text = "Ready";
                            toolStripStatusLabel.ForeColor = Color.Black;
                            _DataIsOKtoContinue = true;
                            _ProcessIsRunning = false;
                            MessageBox.Show("Market Data has finished loading", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return;
                        }
                        else
                        {
                            toolStripStatusLabel.Text = "Ready";
                            toolStripStatusLabel.ForeColor = Color.Black;
                            _ProcessIsRunning = false;
                            return;
                        }
                    }
                    // No bad tickers
                    else
                    {
                        
                        // Remove stocks with old vol
                        bool removed;
                        removed = double.TryParse(textBoxVolDate.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _oldVolDate);
                        if (!removed || _oldVolDate <= 0)
                        {
                            MessageBox.Show("Please enter a valid number of days for the volatility filter", "Wrong Input", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            _ProcessIsRunning = false;
                            return;
                        }
                        DataRetrieval.LoadMarketData(strategydatasetelement.MarketDataTree.OriginalTree, UnderlyingsUniverseDictionary);

                        int quality = (int)(Math.Min(99, _oldVolDate / 10.0)); // par palier de 10
                        _oldVolDate = 1.0 + 2.0 * (quality) / 10;
                        _UnderlyingsWithOldVols = new List<string>();
                        foreach (string underlying in UnderlyingsUniverseDictionary.Keys.ToList())
                        {
                            double volUpdateQualityFactor = BatchService.GetLastAssetVolatilityUpdate(underlying, Product.MarketDataTree);
                            if (volUpdateQualityFactor > _oldVolDate)
                            {
                                removed = Product.MarketDataTree.OriginalTree.Tree.RemoveSubTree(MarketDataTree.GetUnderlyingPath(underlying));
                                UnderlyingsUniverseDictionary.Remove(underlying);
                                _UnderlyingsWithOldVols.Add(underlying);
                            }
                        }
                        underlyingsListResults = UnderlyingsUniverseDictionary.Values.ToList();

                        if (_UnderlyingsWithOldVols.Count > 0)
                        {
                            labelUnderlyingsWithOldVol.Text = string.Join(" , ", _UnderlyingsWithOldVols);
                        }

                        UpdateUniverseDataTable();
                        labelDataUpdated.Text = "Market data loaded";
                        labelDataUpdated.ForeColor = Color.Green;
                        toolStripStatusLabel.Text = "Ready";
                        toolStripStatusLabel.ForeColor = Color.Black;
                        _DataIsOKtoContinue = true;
                        _ProcessIsRunning = false;
                        MessageBox.Show("Market Data has finished loading", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return;
                    }
                }
                #endregion

            }

        }

        /// <summary>
        /// Load all Sophis stocks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonLoadAll_Click(object sender, EventArgs e)
        {
            if (!_SophisStocksAreLoaded && _ProcessIsRunning  == false)
            {
                #region via BBgQuery 
                /*


                InitializeDataTableSophis();
                underlyingsList = new List<Structures.Underlying>();
                underlyingsTickers = new List<string>();

                // Retrieve all Sophis stocks & Indices, and tickers
                StocksList = new List<MarketData.Instrument>();
                StocksList = DataRetrieval.GetStocks(DataRetrieval.GetAllSophisInstruments());

                //Clean it (only what is on BBg)
                underlyingsTickers = DataRetrieval.FilterBbgStocks(StocksList);

                // Get the Bbg data for the clean stocks
                DataRetrieval.GetBloombergDataViaQueries(underlyingsTickers, ref StocksDataFullNames, ref StocksDataCurrencies,
                                                                             ref StocksDataCountries, ref StocksDataRatings,
                                                                             ref StocksDataLiquidities, ref StocksDataSubSectors);
                // Make list of underlyings (clean-up with Bbg dictionaries)
                underlyingsList = HelperMethods.MakeUnderlyingListFromTickers(underlyingsTickers, m_maturity, m_strike, m_currency,
                                                                              StocksDataFullNames, StocksDataCountries,
                                                                              StocksDataCurrencies, StocksDataRatings,
                                                                              StocksDataLiquidities, StocksDataSubSectors);
                */
                #endregion


                #region via CSV

                _ProcessIsRunning =  true;

                InitializeDataTableSophis();
                toolStripStatusLabel.Text = "Loading Stocks . . .";
                toolStripStatusLabel.ForeColor = Color.Red;
                //underlyingsList = new List<Structures.Underlying>();
                //underlyingsTickers = new List<string>();

                // Retrieve all Sophis stocks
                //DataTable table = cCDataSet.SophisSecurities;
                // TODO: This line of code loads data into the 'cCDataSet.BbgDescriptiveFields' table. You can move, or remove it, as needed.
                //this.bbgDescriptiveFieldsTableAdapter.Fill(this.cCDataSet.BbgDescriptiveFields);
                // TODO: This line of code loads data into the 'cCDataSet.SophisSecurities' table. You can move, or remove it, as needed.
                //this.sophisSecuritiesTableAdapter.Fill(this.cCDataSet.SophisSecurities);

                //StocksList = new List<MarketData.Instrument>();
                //StocksList = DataRetrieval.GetStocks(DataRetrieval.GetAllSophisInstruments());

                // Get the Bbg liquidities and use them to remove bad stocks(using ticker not liquidity level)
                //StockDataList = GetStocksDataList(@"C:\DevCaesar\projects\BBClient\StocksLiquidity.csv");
                //underlyingsTickers = StocksList.Select(stock => stock.BbgCode).Distinct().ToList();
                //underlyingsTickers = DataRetrieval.CleanBbgStocks(underlyingsTickers, StockDataList);
                // Get the Bbg data for the clean stocks            
                //BloombergData = new Structures.BbgData(underlyingsTickers, this.FilePaths);

                // Update the currencies
                //currenciesList = BloombergData.DataCurrencies.Values.Distinct().ToList();

                // Get the FX rates (needed for liquidity levels)
                //StocksDataFXrates = DataRetrieval.GetFXrates(currenciesList);
                //BloombergData.DataFX = StocksDataFXrates;

                // Make the list of underlyings and remove ETFs
                //underlyingsList = HelperMethods.MakeUnderlyingList(underlyingsTickers, _maturity, _strike, _currency, BloombergData);
                //underlyingsList.RemoveWhere(ul => ul.Name.Contains("ETF")).ToList();
                //underlyingsTickers.RemoveWhere(ul => ul.Contains("ETF"));
                //underlyingsTickers = underlyingsList.Select(ul => ul.Ticker).ToList();

                //SophisData = new Structures.SophisData(underlyingsTickers, _currency, _maturity, _strike);
                //SophisData.LoadSpots();
                backgroundWorker.RunWorkerAsync();
                //underlyingsTickers = SophisData.UnderlyingSpotsDictionary.Keys.ToList();
                // Some stocks may have been lost (no spot) make the new tickers
                //underlyingsList = HelperMethods.MakeUnderlyingList(underlyingsTickers, _maturity, _strike, _currency, BloombergData);


                //_SophisStocksAreLoaded = true;
                //foreach (Structures.Underlying underlying in underlyingsList)
                //{
                //    underlying.GetSpot(SophisData);
                //}
                // Remove those which do not satisfy the liquidity requirement
                //KeepLiquidStocks(ref underlyingsList);

                #endregion

                // Update the main datatable
                //underlyingsList = underlyingsList.OrderBy(ul => ul.Ticker).ToList();
                //underlyingsTickers = underlyingsList.Select(ul => ul.Ticker).ToList();
                //UpdateSophisStocksDataTable();

                //BasketOptimizationProcessIsRunning = false;

            }
            else
            {
                MessageBox.Show("Sophis stocks are already loaded", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }

        }

        /// <summary>
        /// Apply filters to the Sophis stocks (open the optimizer filters form)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonFilters_Click(object sender, EventArgs e)
        {
            // BasketOptimizerNew.Hide();
            if (_SophisStocksAreLoaded && !_ProcessIsRunning)
            {
                //countriesList = HelperMethods.GetCountriesList(underlyingsList);
                countriesList = underlyingsList.Select(stock => stock.Country).Distinct().ToList();
                countriesList.Sort();
                currenciesList = underlyingsList.Select(stock => stock.Currency).Distinct().ToList();
                OptimizerFilters OptimizerFilters = new OptimizerFilters(this);
                OptimizerFilters.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Please load Sophis stocks before applying filters.", "Missing stocks", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Clear the universe datagrid
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonClearUniverse_Click(object sender, EventArgs e)
        {
            string message = "Are you sure you wish to clear the underlyings? All previously downloaded stocks and associated data will be erased.";
            if (MessageBox.Show(message, "Clear Baskets", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                _ProcessIsRunning  = true;
                // Clear Datagrid and initialize again
                listUniverseDataTable = new DataTable();
                InitializeUniverseDataTable();

                labelDataUpdated.Text = "Market data not loaded";
                labelDataUpdated.ForeColor = Color.Red;
                labelUniverseCount.Text = "0";
                _UnderlyingsEnteredManually = false;
                _ProcessIsRunning = false;
                _SomeFiltersApplied = false;
                _DataIsOKtoContinue = false;
                underlyingsListResults = null;
            }
        }

        /// <summary>
        /// Paste from the clipboard
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonPaste_Click(object sender, EventArgs e)
        {
            try
            {
                _ProcessIsRunning = true;
                // Clear the basket from the old stuff
                // Clear Datagrid and initialize again
                listUniverseDataTable = new DataTable();
                InitializeUniverseDataTable();

                _SomeFiltersApplied = false;
                underlyingsListResults = null;

                char[] rowSplitter = { '\r', '\n' };
                char[] columnSplitter = { '\t' };

                //Get the text from clipboard (return if there is nothing)
                IDataObject dataInClipboard = Clipboard.GetDataObject();
                if (dataInClipboard == null)
                {
                    return;
                }

                string stringInClipboard = (string)dataInClipboard.GetData(DataFormats.Text);

                //split it into lines
                string[] rowsInClipboard = stringInClipboard.Split(rowSplitter, StringSplitOptions.RemoveEmptyEntries);
                // loop through the lines, split them into cells and place the values in the corresponding cell.
                for (int iRow = 0; iRow < rowsInClipboard.Length; iRow++)
                {
                    //split row into cell values
                    string[] valuesInRow = rowsInClipboard[iRow].Split(columnSplitter);
                    if (valuesInRow.Length > 1)
                    {
                        MessageBox.Show("Only one column allowed", "Wrong clipboard format", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                }
                foreach (string underlying in rowsInClipboard)
                {
                    DataRow row = listUniverseDataTable.NewRow();
                    row[colSecurity] = underlying.ToUpper();
                    listUniverseDataTable.Rows.Add(row);
                }
                labelUniverseCount.Text = rowsInClipboard.Length.ToString();
                labelDataUpdated.Text = "Market data not loaded";
                labelDataUpdated.ForeColor = Color.Red;
                _DataIsOKtoContinue = false;
                _UnderlyingsEnteredManually = true;
                _ProcessIsRunning = false;
            }
            catch(Exception ex)
            {
                MessageBox.Show("No copied data in the clipboard", "Empty Clipboard", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            
        }

        /// <summary>
        /// Cancel the loading of stocks
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void buttonCancelLoad_Click(object sender, EventArgs e)
        {
            if (backgroundWorker.IsBusy)
            {
                backgroundWorker.CancelAsync();
                toolStripStatusLabel.Text = "Ready";
                _ProcessIsRunning = false;
                _SophisStocksAreLoaded = false;
            }
        }
        
        #endregion
        
        #region Private members

        private List<string> BadTickers;
        private List<string> _UnderlyingsWithOldVols;
        private List<string> underlyingsTickers;
        private List<string> underlyingsCurrencies;
        private List<string> underlyingsCountries;
        private List<double> underlyingsRatings;
        private List<string> underlyingsSubSectors;
        private List<string> doubleColumns;
        private List<string> failedTickers;
        private double _strike;
        private double _maturity;
        private double _oldVolDate;
        private DateTime _strikeDate;
        private Structures.SophisData SophisData;
        private Structures.BbgData BloombergData;
        private string _currency;
        private double liquidityMin;
        private OptimizerFilters optimizerFilters;
        private bool _SophisStocksAreLoaded;
        private bool _SomeFiltersApplied;
        private bool _UnderlyingsEnteredManually;
        private bool _DataIsOKtoContinue;
        private bool _SpotsAreLoaded;
        private bool _ProcessIsRunning;
        private DataTable listAllDataTable;

        private string colSecurity = "Security";
        private string colVol = "Volatility";
        private string colSpot = "Spot";
        private string colRating = "Rating";
        private string colForward = "Forward";
        private string colCountry = "Country";
        private string colCurrency = "Currency";
        private string colLiquidity = "Liquidity";
        private string colSubSector = "Subsector";
        private string colFullName = "Full Name";
        private double _MinLiquidityLevel;
        private int _productIndex;

        #endregion

        #region Public members

        public Dictionary<string, Structures.Underlying> UnderlyingsUniverseDictionary;
        public List<string> currenciesList;
        public List<string> countriesList;
        public bool ProcessIsRunning;
        public List<Structures.Underlying> underlyingsList;
        public List<Structures.Underlying> underlyingsListResults;
        List<MarketData.Instrument> StocksList;
        public StrategyDataSetElement Product;
        public StrategyDataSetElement strategydatasetelement;

        public class StockData
        {
            public StockData(string field, string ticker, string value)
            {
                m_field = field;
                m_ticker = ticker;
                m_value = value;
            }

            private string m_field;
            private string m_ticker;
            private string m_value;

            public string Field { get { return m_field; } }
            public string Ticker { get { return m_ticker; } }
            public string Value { get { return m_value; } }

        }
        public List<StockData> StockDataList;
        #endregion

        #region Dictionaries

        public Dictionary<string, string> StocksDataFullNames;
        public Dictionary<string, string> StocksDataCountries;
        public Dictionary<string, string> StocksDataCurrencies;
        public Dictionary<string, string> StocksDataSubSectors;
        public Dictionary<string, double> StocksDataRatings;
        public Dictionary<string, double> StocksDataSpot;
        public Dictionary<string, double> StocksDataLiquidities;
        public Dictionary<string, double> StocksDataFXrates;
        public Dictionary<string, string> FilePaths;
        public MarketDataTree currentDataTree;
        public DataTable listUniverseDataTable;
        
        #endregion

        #region Public Accessors

        public double Maturity { get { return _maturity; } }
        public double Strike { get { return _strike; } }
        public string Currency { get { return _currency; } }
        public bool SomeFiltersApplied { get { return _SomeFiltersApplied; } }
        public int ProductIndex { get { return _productIndex; } }

        public object CrossoverProbTextbox { get; private set; }

        #endregion

        #region Background worker: Load all Sophis Stocks

        /// <summary>
        /// "Do work" method, where stocks and data are loaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            if (!backgroundWorker.CancellationPending)
            {
                underlyingsList = new List<Structures.Underlying>();
                underlyingsTickers = new List<string>();
                StocksList = new List<MarketData.Instrument>();

                //Load all stocks keep liquid ones
                StocksList = DataRetrieval.GetStocks(DataRetrieval.GetAllSophisInstruments());


                StockDataList = GetStocksDataList(@"K:\ED_ExcelTools\Parameters\Caesar\BasketOptimizer\StocksLiquidity.csv");

                // Get the Bloomberg data from the tickers
                underlyingsTickers = StocksList.Select(stock => stock.BbgCode).Distinct().ToList();
                underlyingsTickers = DataRetrieval.CleanBbgStocks(underlyingsTickers, StockDataList);
                BloombergData = new Structures.BbgData(underlyingsTickers, this.FilePaths);

                // Get a list of the currencies
                currenciesList = BloombergData.DataCurrencies.Values.Distinct().ToList();

                // If cancel requested stop here
                if (backgroundWorker.CancellationPending)
                {
                    e.Cancel = true;
                    return;
                }

                // Get spot FX rates (used to compute liquidity) and put it in the Bloomberg data
                StocksDataFXrates = DataRetrieval.GetFXrates(currenciesList, backgroundWorker, e);
                BloombergData.DataFX = StocksDataFXrates;

                //Remove ETFs
                underlyingsTickers.RemoveWhere(ul => ul.Contains("ETF"));

                // Make a Sophis Data object and load spots
                SophisData = new Structures.SophisData(underlyingsTickers, _currency, _maturity, _strike);
                SophisData.LoadSpots(backgroundWorker, e);

                // Cancel if requested
                if(e.Cancel == true)
                {
                    return;
                }
            }
            
        }

        /// <summary>
        /// Keeps track of the loading progress
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            progressBar.Value = e.ProgressPercentage;
            labelProgress.Text = progressBar.Value.ToString() + "%";
        }

        /// <summary>
        /// Executed when do work is finished i.e. stocks are loaded
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            
            if(e.Cancelled)
            {
                progressBar.Value = 0;
                labelProgress.Text = progressBar.Value.ToString() + "%";
                _SophisStocksAreLoaded = false;
                _ProcessIsRunning = false;
                toolStripStatusLabel.Text = "Ready";
                toolStripStatusLabel.ForeColor = Color.Black;
                return;
            }
            else if (e.Error != null)
            {
                progressBar.Value = 0;
                _SophisStocksAreLoaded = false;
                _ProcessIsRunning = false;
                toolStripStatusLabel.Text = "Ready";
                toolStripStatusLabel.ForeColor = Color.Black;
                MessageBox.Show("Error. Details: " + (e.Error as Exception).ToString());
            }
            else
            {
                _SophisStocksAreLoaded = true;
                toolStripStatusLabel.Text = "Ready";
                toolStripStatusLabel.ForeColor = Color.Green;
                progressBar.Value = 100;
                labelProgress.Text = progressBar.Value.ToString() + "%";
                underlyingsTickers = SophisData.UnderlyingSpotsDictionary.Keys.ToList();
                // Some stocks may have been lost (no spot) make the new tickers
                underlyingsList = HelperMethods.MakeUnderlyingList(underlyingsTickers, _maturity, _strike, _currency, BloombergData);


                //_SophisStocksAreLoaded = true;
                foreach (Structures.Underlying underlying in underlyingsList)
                {
                    underlying.GetSpot(SophisData);
                }
                // Remove those which do not satisfy the liquidity requirement
                KeepLiquidStocks(underlyingsList);


                // Update the main datatable
                underlyingsList = underlyingsList.OrderBy(ul => ul.Ticker).ToList();
                underlyingsTickers = underlyingsList.Select(ul => ul.Ticker).ToList();
                UpdateSophisStocksDataTable();

                toolStripStatusLabel.Text = "Ready";
                _ProcessIsRunning = false;
            }
            
        }
                
        #endregion

        
    }
}


