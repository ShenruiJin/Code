﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BBClient.Data;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.EdaProto;
using FuncFramework.Configuration;
using PricingBase.Product;
using Pricing.Engine;
using CaesarApplication.Service.Strategy;
using FuncFramework.Business.RiskAnalysis;
using FuncFramework.Business.RiskAnalysis.StandardMeta;
using MarketDataMgr.Trees;

namespace BBClient.Forms
{
    public partial class OptimizerLauncher : BBForm
    {
        readonly Dictionary<string, Structures.BasketOfUnderlyings> _pricingCache = new Dictionary<string, Structures.BasketOfUnderlyings>();
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="BasketOpt"></param>
        public OptimizerLauncher(BasketOptimizerNew BasketOpt)
        {
            InitializeComponent();
            BasketOptimizerForm = BasketOpt;
            Product = BasketOptimizerForm.Product;
            labelHeader.Text += Product.Product.Name;
            if (labelHeader.Text.Contains("(Copy)"))
            {
                labelHeader.Text = labelHeader.Text.Replace("(Copy)", "");
            }
            labelUniverseSize.Text = BasketOptimizerForm.UnderlyingsUniverseDictionary.Count.ToString();
            _optimRunning = false;
            //Default values
            _repriceFinalPop = false;
            _nbGenerations = 20;
            _popSize = 100;
            _pCrossover = 70.0;
            _pMutation = 1.0;
            _replacementPercent = 50.0;
            _pWinTournament = 70.0;
            _nbSimulations = 5000;
            rnd = new Random(5);

            // Population size and number of generations
            if (BasketOpt.underlyingsListResults.Count >= 30)
            {
                _popSize = 50;
                _nbGenerations = 30;
            }
            if (BasketOpt.underlyingsListResults.Count >= 60)
            {
                _popSize = 50;
                _nbGenerations = 40;
            }
            if (BasketOpt.underlyingsListResults.Count >= 100)
            {
                _popSize = 80;
                _nbGenerations = 60;
            }

            // Default Selection of ComboBoxes
            comboBoxSortBasis.SelectedIndex = 0;
            comboBoxStockModel.SelectedIndex = 2;
            comboBoxRateModel.SelectedIndex = 0;
            combBoxOptimGoal.SelectedIndex = 0;

            comboBoxSelectionMethod.SelectedIndex = 2;
            comboBoxCrossoverMethod.SelectedIndex = 0;
            comboBoxReinsertionMethod.SelectedIndex = 0;



            // Populate textboxes
            nbGenerationsTextBox.Text = _nbGenerations.ToString();
            CrossoverProbTextbox.Text = _pCrossover.ToString();
            MutationProbTextbox.Text = _pMutation.ToString();
            ReplacementPercentTextbox.Text = _replacementPercent.ToString();
            textBoxPopulationSize.Text = _popSize.ToString();
            TournamentWinPercentTextBox.Text = _pWinTournament.ToString();
            textBoxSimulations.Text = _nbSimulations.ToString();

            // Asset space
            UnderlyingsUniverse = new Dictionary<string, Structures.Underlying>();
            UnderlyingsUniverse = BasketOpt.UnderlyingsUniverseDictionary;

            labelNgenerations.Text = _nbGenerations.ToString();
            labelBestBasketComposition.Text = "";

        }

        #region Private members

        //private int _productIndex;
        private int _nbGenerations;
        private int _nbSimulations;
        private int _nbSimulationsFinalReprice;
        private int _basketSize;
        private int _popSize;
        private bool _repriceFinalPop;
        private bool _optimRunning;
        private double _pCrossover;
        private double _pMutation;
        private double _pWinTournament;
        private double _replacementPercent;
        private string _productName;
        private OptimizationGoal _optimGoal;
        private SortType _sortBasis;
        private Dictionary<string, Structures.Underlying> UnderlyingsUniverse;
        private Structures.PopulationOfBaskets InitialPopulation;
        private StockModelType _stockModel;
        private RateModelType _rateModel;
        private Structures.PricingSettingsForBasket _PricingSettings;
        private Structures.PricingSettingsForBasket _PricingSettingsForFinalIteration;
        private SelectionMethodDelegate _SelectionMethod;
        private ReinsertionMethodDelegate _ReinsertionMethod;
        private CrossoverMethodDelegate _CrossoverMethod;
        private GeneticLibrary.GeneticAlgorithm Algorithm;
        private BasketOptimizerNew BasketOptimizerForm;
        private List<string> _UnderlyingsWithOldVols;
        private FuncFramework.Business.StrategyDataSetElement Product;

        #endregion

        #region Public members and accessors

        public GeneticLibrary.GAparameters AlgorithmParameters;
        public double _pricingFunction;
        public Random rnd;
        public Structures.PricingSettingsForBasket PricingSettings { get { return _PricingSettings; } }

        #endregion




        /// <summary>
        /// Load market data (now done in the previous BBform BasketOptimizerNew)
        /// </summary>
        /// <param name="tree"></param>
        private void LoadMarketData(MarketDataTree tree)
        {
            var strategydatasetelement = CaesarApplication.Service.Strategy.StrategyService.CurrentStrategy.GetLeafProducts()[0];
            //var product = strategydatasetelement.Product;
            //var bp = product.GetPricingProduct(false, strategydatasetelement.MarketDataTree);
            List<Structures.Underlying> UnderlyingUniverseList = UnderlyingsUniverse.Values.ToList();
            List<string> UnderlyingsTickers = UnderlyingsUniverse.Keys.ToList();
            PricingBase.Product.CsInfoContainer.Basket b = new PricingBase.Product.CsInfoContainer.Basket();

            b.Resize(UnderlyingUniverseList.Count);
            // Add underlyings to the basket
            for (int i = 0; i < UnderlyingUniverseList.Count; i++)
            {
                b.ModelName[i] = UnderlyingsTickers[i];
                b.Weight[UnderlyingsTickers[i]] = 1.0 / UnderlyingUniverseList.Count;

                //((FuncFramework.Business.Product.StandardProduct.GenericProduct)bp).MarketDataTree.OriginalTree.Tree.AddSubTree("marketData" + MarketDataTree.PathDelimiter + "underlying", b.ModelName[i]);

            }



            // On load le tree
            MarketDataService.LoadMarketData(UnderlyingsTickers, UnderlyingUniverseList[0].BaseCurrency, tree, true);
            //MarketDataService.LoadMarketData(((FuncFramework.Business.Product.StandardProduct.GenericProduct)bp).MarketDataTree.OriginalTree, String.Empty);
        }


        #region Background Worker for Genetic Algorithm

        private void backgroundWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - Start optimization...");
            // Get an initial population, evaluate and sort it
            if (AlgorithmParameters.OptimizationGoal == OptimizationGoal.Maximize)
            {
                InitialPopulation = HelperMethods.GetInitialPopulation(UnderlyingsUniverse, ref AlgorithmParameters, PricingSettings, GeneticLibrary.FitnessIsPremium);
            }
            else
            {
                InitialPopulation = HelperMethods.GetInitialPopulation(UnderlyingsUniverse, ref AlgorithmParameters, PricingSettings, GeneticLibrary.FitnessForMinimization);
            }
            if (backgroundWorker.CancellationPending)
            {
                e.Cancel = true;
                return;
            }
            Structures.BasketSensi bs = new Structures.BasketSensi(Product, InitialPopulation.BasketsList[1], (MonteCarloConfiguration)Product.Configuration);

            //bs.Meta();
            double delta = bs.GetDelta(PricingSettings, Product, InitialPopulation.BasketsList[1], InitialPopulation.BasketsList[1]._maturity);
            LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - Sensi div = : " + delta);
            double vega = bs.GetVega(PricingSettings, Product, InitialPopulation.BasketsList[1], (MonteCarloConfiguration)Product.Configuration);
            LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - Vega = : " + vega);
            double cega= bs.GetCega(PricingSettings, Product, InitialPopulation.BasketsList[1]);
            //LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - Cega = : " + cega);

            /* double volref = MarketDataService.GetSyntheticVolatility(InitialPopulation.BasketsList[0].UnderlyingsTickers, Enumerable.Repeat(1.0, InitialPopulation.BasketsList[0].UnderlyingsTickers.Count).ToList(), InitialPopulation.BasketsList[0]._strike, DateTime.Today.AddDays(InitialPopulation.BasketsList[0]._maturity));
              double forwardref= Structures.BasketOfUnderlyings.GetSyntheticForward(InitialPopulation.BasketsList[0].UnderlyingsTickers, DateTime.Today.AddDays(InitialPopulation.BasketsList[0]._maturity));
              double correlref= Structures.BasketOfUnderlyings.GetSyntheticCorrel(InitialPopulation.BasketsList[0].UnderlyingsTickers, DateTime.Today.AddDays(InitialPopulation.BasketsList[0]._maturity));
              Structures.BasketRef basketRef = new Structures.BasketRef(delta,vega,0.0,volref,forwardref,correlref);*/


            LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - InitialPopulation");
            InitialPopulation.Evaluate(_pricingCache, Product, backgroundWorker, e, false, delta, vega, cega);
            InitialPopulation.SortPopulation();
            LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - NextGeneration");
            // Start the algorithm
            Algorithm = new GeneticLibrary.GeneticAlgorithm(InitialPopulation, AlgorithmParameters, _SelectionMethod, _CrossoverMethod, _ReinsertionMethod, _PricingSettingsForFinalIteration, _repriceFinalPop);
            Algorithm.Evolve(_pricingCache, Product, backgroundWorker, e, delta, vega, cega);
            e.Result = Algorithm;

        }


        private void backgroundWorker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {

            progressBar.Value = e.ProgressPercentage;
            GeneticLibrary.GeneticAlgorithm algo = (GeneticLibrary.GeneticAlgorithm)e.UserState;
            labelGenerationCounter.Text = algo.AlgorithmStatistics.GenerationsCounter.ToString();
            labelBestBasketComposition.Text = algo.AlgorithmStatistics.BestBasketEver.GetComposition();
            labelBestBasketPremium.Text = (algo.AlgorithmStatistics.BestBasketEver.Premium * 100).ToString("0.00") + "%";
            labelBestBasketGeneration.Text = algo.AlgorithmStatistics.BestBasketGeneration.ToString();
            labelProgress.Text = progressBar.Value.ToString() + "%";
            if (algo.AlgorithmStatistics.BestBasketGeneration == algo.AlgorithmStatistics.GenerationsCounter)
            {
                labelBestBasketComposition.ForeColor = Color.Green;
                labelBestBasketGeneration.ForeColor = Color.Green;
            }
            else
            {
                labelBestBasketComposition.ForeColor = Color.Black;
                labelBestBasketGeneration.ForeColor = Color.Black;
            }


        }

        private void backgroundWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            if (e.Cancelled)
            {
                MessageBox.Show("The optimization process has been cancelled");
                foreach (Control ctl in GAparamsGroupBox.Controls)
                {
                    ctl.Enabled = true;
                }
                foreach (Control ctl in OptimisationSimulationParams.Controls)
                {
                    ctl.Enabled = true;
                }
                foreach (Control ctl in GAprogressGroupBox.Controls)
                {
                    ctl.Enabled = false;
                }
                buttonGoBack.Enabled = true;
                buttonViewResults.Enabled = true;
                StartButton.Enabled = true;
                _optimRunning = false;
            }
            else if (e.Error != null)
            {
                MessageBox.Show("Error. Details: " + (e.Error as Exception).ToString());
                foreach (Control ctl in GAparamsGroupBox.Controls)
                {
                    ctl.Enabled = true;
                }
                foreach (Control ctl in OptimisationSimulationParams.Controls)
                {
                    ctl.Enabled = true;
                }
                foreach (Control ctl in GAprogressGroupBox.Controls)
                {
                    ctl.Enabled = false;
                }
                buttonGoBack.Enabled = true;
                StartButton.Enabled = true;
                _optimRunning = false;
            }
            else
            {
                LoggingService.Info(typeof(OptimizerLauncher), "[Basket Optimizer] - End optimization...");
                MessageBox.Show("The basket optimization finished running", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                GeneticLibrary.GeneticAlgorithm algo = (GeneticLibrary.GeneticAlgorithm)e.Result;
                OptimizationResults OptimResults = new OptimizationResults(algo);
                this.Hide();
                OptimResults.Show();
            }

        }

        #endregion


        #region Buttons and form methods

        // Start the optimization
        private void StartButton_Click(object sender, EventArgs e)
        {
            // Quick check for the basket size
            if (textBoxBasketSize.Text == String.Empty ||
               !int.TryParse(textBoxBasketSize.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _basketSize))
            {
                string errorString = "Please enter a basket size that is an integer";
                MessageBox.Show(errorString);
                return;
            }

            // Check that basket is not too big
            // Quick check for the basket size
            int.TryParse(textBoxBasketSize.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _basketSize);
            if (_basketSize > UnderlyingsUniverse.Count)
            {
                string errorString = "Your basket size is too big, please decrease it or specify a larger asset space.";
                MessageBox.Show(errorString);
                return;
            }

            if (_optimRunning)
            {
                string errorString = "The optimization process has already started.";
                MessageBox.Show(errorString);
                return;
            }

            _optimRunning = true;
            buttonGoBack.Enabled = false;
            buttonViewResults.Enabled = false;

            foreach (Control ctl in GAparamsGroupBox.Controls)
            {
                ctl.Enabled = false;
            }
            foreach (Control ctl in OptimisationSimulationParams.Controls)
            {
                ctl.Enabled = false;
            }
            foreach (Control ctl in GAprogressGroupBox.Controls)
            {
                ctl.Enabled = true;
            }

            #region Read and Check Parameters

            bool dummyBool;
            string paramsErrorString = "Please check that your parameters are valid";

            dummyBool = int.TryParse(textBoxBasketSize.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _basketSize);
            if (!dummyBool || _basketSize <= 0)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = int.TryParse(nbGenerationsTextBox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _nbGenerations);
            if (!dummyBool || _nbGenerations <= 0)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = int.TryParse(textBoxPopulationSize.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _popSize);
            if (!dummyBool || _popSize <= 0)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = int.TryParse(textBoxSimulations.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _nbSimulations);
            if (!dummyBool || _nbSimulations <= 0)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = int.TryParse(textBoxRepriceFinalSimulations.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _nbSimulationsFinalReprice);
            if (!dummyBool || _nbSimulationsFinalReprice < 0)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = double.TryParse(CrossoverProbTextbox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _pCrossover);
            if (!dummyBool || _pCrossover < 0 || _pCrossover > 100)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = double.TryParse(MutationProbTextbox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _pMutation);
            if (!dummyBool || _pMutation < 0 || _pMutation > 100)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = double.TryParse(ReplacementPercentTextbox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _replacementPercent);
            if (!dummyBool || _replacementPercent < 0 || _replacementPercent > 100)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }
            dummyBool = double.TryParse(TournamentWinPercentTextBox.Text, NumberStyles.Any, CultureInfo.InvariantCulture, out _pWinTournament);
            if (!dummyBool || _pWinTournament < 0 || _pWinTournament > 100)
            {
                MessageBox.Show(paramsErrorString);
                return;
            }

            _repriceFinalPop = checkBoxRepriceFinalPop.Checked;

            _pCrossover /= 100.0;
            _pMutation /= 100.0;
            _replacementPercent /= 100.0;
            _pWinTournament /= 100.0;
            _optimGoal = combBoxOptimGoal.SelectedIndex == 0 ? OptimizationGoal.Minimize : OptimizationGoal.Maximize;
            _sortBasis = comboBoxSortBasis.SelectedIndex == 0 ? SortType.Raw : SortType.Scaled;

            #endregion

            this.labelBestBasketPremium.Text = "0.00%";
            labelBestBasketComposition.Text = "";
            progressBar.Value = 0;
            labelProgress.Text = "0%";
            labelGenerationCounter.Text = "0";
            labelBestBasketGeneration.Text = "0";



            #region Read GA Methods
            //Selection
            if (comboBoxSelectionMethod.SelectedIndex == 0)
            {
                _SelectionMethod = GeneticLibrary.RouletteSelectionByFitness;
            }
            else if (comboBoxSelectionMethod.SelectedIndex == 1)
            {
                _SelectionMethod = GeneticLibrary.RouletteSelectionByRank;
            }
            else if (comboBoxSelectionMethod.SelectedIndex == 2)
            {
                _SelectionMethod = GeneticLibrary.SelectionByTournament;
            }
            else
            {
                _SelectionMethod = GeneticLibrary.Elitism;
            }
            //Crossover
            if (comboBoxCrossoverMethod.SelectedIndex == 0)
            {
                _CrossoverMethod = GeneticLibrary.CrossoverSinglePointProbable;
            }
            else
            {
                _CrossoverMethod = GeneticLibrary.CrossoverSinglePointCertain;
            }
            //Reinsertion
            if (comboBoxReinsertionMethod.SelectedIndex == 0)
            {
                _ReinsertionMethod = GeneticLibrary.Eugenics;
            }
            else
            {
                _ReinsertionMethod = GeneticLibrary.GenerationalReplacement;
            }

            #endregion

            // Parameters of Genetic algorithm
            AlgorithmParameters = new GeneticLibrary.GAparameters(_optimGoal, _sortBasis, _nbGenerations, _popSize, _basketSize,
                                                                  _pCrossover, _pMutation, _pWinTournament, _replacementPercent, rnd);
            // Pricing settings
            #region Stock Model
            if (comboBoxStockModel.SelectedIndex == 0)
            {
                _stockModel = StockModelType.BlackScholes;
            }
            else if (comboBoxStockModel.SelectedIndex == 1)
            {
                _stockModel = StockModelType.Copula;
            }
            else if (comboBoxStockModel.SelectedIndex == 2)
            {
                _stockModel = StockModelType.LocalVolatility;
            }
            else if (comboBoxStockModel.SelectedIndex == 3)
            {
                _stockModel = StockModelType.PSkew;
            }
            else if (comboBoxStockModel.SelectedIndex == 4)
            {
                _stockModel = StockModelType.LocalStochasticVolatility;
            }
            else if (comboBoxStockModel.SelectedIndex == 5)
            {
                _stockModel = StockModelType.LocalVolatilityIFC;
            }
            else if (comboBoxStockModel.SelectedIndex == 6)
            {
                _stockModel = StockModelType.LocalVolatilityBuehler;
            }
            else
            {
                _stockModel = StockModelType.Bates;
            }
            #endregion

            #region Rate Model
            if (comboBoxRateModel.SelectedIndex == 0)
            {
                _rateModel = RateModelType.Deterministic;
            }
            else if (comboBoxRateModel.SelectedIndex == 1)
            {
                _rateModel = RateModelType.NoStoDriftHJM;
            }
            else if (comboBoxRateModel.SelectedIndex == 2)
            {
                _rateModel = RateModelType.HJM;
            }
            else if (comboBoxRateModel.SelectedIndex == 3)
            {
                _rateModel = RateModelType.HJM_CMS10Y;
            }
            else
            {
                _rateModel = RateModelType.HJM_Replic;
            }
            #endregion


            _PricingSettings = new Structures.PricingSettingsForBasket(_nbSimulations, _stockModel, _rateModel);
            _PricingSettingsForFinalIteration = new Structures.PricingSettingsForBasket(_nbSimulationsFinalReprice, _PricingSettings.StockModel, _PricingSettings.RateModel);

            labelNgenerations.Text = AlgorithmParameters.nGenerations.ToString();
            backgroundWorker.RunWorkerAsync();

        }
        private void checkBoxRepriceFinalPop_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBoxRepriceFinalPop.Checked)
            {
                labelSimulationsFinalPop.Enabled = true;
                textBoxRepriceFinalSimulations.Enabled = true;
            }
            else
            {
                labelSimulationsFinalPop.Enabled = false;
                textBoxRepriceFinalSimulations.Enabled = false;
            }
        }

        private void GAoptionsCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (GAoptionsCheckBox.Checked)
            {
                // Enable everything
                foreach (Control ctrl in GAparamsGroupBox.Controls)
                {
                    ctrl.Enabled = true;
                }
            }
            else
            {
                // Disable everything
                foreach (Control ctrl in GAparamsGroupBox.Controls)
                {
                    ctrl.Enabled = false;
                }
            }
        }

        private void buttonGoBack_Click(object sender, EventArgs e)
        {
            this.Dispose();
            BasketOptimizerForm.Show();
        }

        private void buttonStopOptim_Click(object sender, EventArgs e)
        {
            if (_optimRunning && backgroundWorker.IsBusy)
            {
                backgroundWorker.CancelAsync();
            }
        }

        private void buttonViewResults_Click(object sender, EventArgs e)
        {
            OptimizationResults OptimResults = new OptimizationResults(Algorithm);
            this.Hide();
            OptimResults.Show();
        }

        #endregion
    }
}
