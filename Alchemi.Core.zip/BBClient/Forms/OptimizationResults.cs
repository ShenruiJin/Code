﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BBClient.Data;
using System.Windows.Forms;

namespace BBClient.Forms
{
    public partial class OptimizationResults : Form
    {
        public OptimizationResults(GeneticLibrary.GeneticAlgorithm GenAlgo)
        {
            InitializeComponent();
            Algorithm = GenAlgo;
            Algorithm.CurrentPopulation.SortPopulation(true);
            if(Algorithm.AlgorithmWasCancelled)
            {
                labelAlgoState.Text = "Algorithm was cancelled in generation " 
                                    + Algorithm.AlgorithmStatistics.GenerationsCounter.ToString();

                labelAlgoState.ForeColor = Color.Red;
            }
            else
            {
                labelAlgoState.Text = "Algorithm finished";
                labelAlgoState.ForeColor = Color.Green;
            }
            doubleColumns = new List<string>(new string[] { colVol, colForward, colSpot, colRating });
            comboBoxSelectedBasket.SelectedIndex = 0;
            numericUpDownSelectedIndividual.Value = 1;
            DisplayBasket(Algorithm.AlgorithmStatistics.BestBasketEver);
            labelPremium.Text = (Algorithm.AlgorithmStatistics.BestBasketEver.Premium * 100.0).ToString("0.00");
            numericUpDownSelectedIndividual.Minimum = 1;
            numericUpDownSelectedIndividual.Maximum = GenAlgo.CurrentPopulation.Size;
            labelGenerations.Text = GenAlgo.AlgorithmStatistics.GenerationsCounter.ToString();
            labelCrossovers.Text = GenAlgo.AlgorithmStatistics.NumberOfCrossovers.ToString();
            labelMutations.Text = GenAlgo.AlgorithmStatistics.NumberOfMutations.ToString();
            labelBestBasketGeneration.Text = GenAlgo.AlgorithmStatistics.BestBasketGeneration.ToString();
            
        }

        private void numericUpDownSelectedIndividual_ValueChanged(object sender, EventArgs e)
        {
            int index = (int)numericUpDownSelectedIndividual.Value - 1;
            Structures.BasketOfUnderlyings SelectedBasketToShow = Algorithm.CurrentPopulation.BasketsList[index];
            DisplayBasket(SelectedBasketToShow);
        }

        private void InitializeDataTable()
        {
            BasketDataTable = new DataTable();
            // Affectation de la datatable
            dataGridViewBasket.AutoGenerateColumns = false;
            dataGridViewBasket.DataSource = BasketDataTable;
            foreach (DataGridViewColumn column in dataGridViewBasket.Columns)
            {
                if (column is DataGridViewTextBoxColumn)
                {
                    Type colType = doubleColumns.Contains(column.DataPropertyName) ? typeof(double) : typeof(string);
                    BasketDataTable.Columns.Add(column.DataPropertyName, colType);
                }
                else if (column is DataGridViewCheckBoxColumn)
                {
                    BasketDataTable.Columns.Add(column.DataPropertyName, typeof(int));
                }
            }
        }

        private void DisplayBasket(Structures.BasketOfUnderlyings SelectedBasketToShow)
        {
            InitializeDataTable();
            SelectedBasketToShow.RefreshTickers();
            foreach (string underlying in SelectedBasketToShow.UnderlyingsTickers)
            {
                DataRow row = BasketDataTable.NewRow();
                row[colSecurity] = underlying;
                BasketDataTable.Rows.Add(row);
            }
            labelPremium.Text = (SelectedBasketToShow.Premium * 100.0).ToString("0.00");
        }
        private void comboBoxSelectedBasket_SelectedIndexChanged(object sender, EventArgs e)
        {
            Structures.BasketOfUnderlyings SelectedBasketToShow;
            //Structures.PopulationOfBaskets PopulationSelected;
            int index;
            if (comboBoxSelectedBasket.SelectedIndex == 0)
            {
                labelViewPopulationMember.Enabled = false;
                numericUpDownSelectedIndividual.Enabled = false;
                SelectedBasketToShow = Algorithm.AlgorithmStatistics.BestBasketEver;

            }
            else if (comboBoxSelectedBasket.SelectedIndex == 1)
            {
                SelectedBasketToShow = Algorithm.AlgorithmStatistics.WorstBasketEver;
            }
            else
            {
                labelViewPopulationMember.Enabled = true;
                numericUpDownSelectedIndividual.Enabled = true;
                index = (int)numericUpDownSelectedIndividual.Value;
                SelectedBasketToShow = Algorithm.CurrentPopulation.BasketsList[index - 1];
            }

            DisplayBasket(SelectedBasketToShow);

        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    


        #region Private

        private GeneticLibrary.GeneticAlgorithm Algorithm;
        private DataTable BasketDataTable;
        private string colSecurity = "Security";
        private string colVol = "Volatility";
        private string colSpot = "Spot";
        private string colRating = "Rating";
        private string colForward = "Forward";
        private string colCountry = "Country";
        private string colCurrency = "Currency";
        private string colLiquidity = "Liquidity";
        private string colSubSector = "Subsector";
        private string colFullName = "Full Name";
        private string colFix = "Fix";
        private List<string> doubleColumns;



        #endregion

}


}
