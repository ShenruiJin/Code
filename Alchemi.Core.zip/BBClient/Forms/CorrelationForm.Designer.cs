﻿using RemotingInterfaces;
namespace BBClient
{
    partial class CorrelationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            // In case déploiement raté
            if(System.IO.File.Exists("C:\\Program Files\\Where is my CC\\RunWhereIsMyCC.exe"))
            {
               // System.Windows.Forms.Application.CommonAppDataPath
                System.IO.File.Delete("C:\\Program Files\\Where is my CC\\RunWhereIsMyCC.exe");
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CorrelationForm));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            this._comboBoxQuanto = new System.Windows.Forms.ComboBox();
            this.currenciesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cCDataSet = new RemotingInterfaces.CCDataSet();
            this._labelCurr = new System.Windows.Forms.Label();
            this._topPanel = new System.Windows.Forms.Panel();
            this._groupBoxRhoHorizon = new System.Windows.Forms.GroupBox();
            this._dataGridViewRho = new System.Windows.Forms.DataGridView();
            this.Y1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Y5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._groupBoxDisplay = new System.Windows.Forms.GroupBox();
            this._floorCB = new System.Windows.Forms.CheckBox();
            this._buttonPrint = new System.Windows.Forms.Button();
            this._comboBoxQtoCmpo = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this._buttonGraphAnalysis = new System.Windows.Forms.Button();
            this._comboBoxFrequency = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this._buttonCopy = new System.Windows.Forms.Button();
            this._comboBoxProvs = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this._labelHorizon = new System.Windows.Forms.Label();
            this._comboBoxCorrelHorizon = new System.Windows.Forms.ComboBox();
            this.maturitiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._groupBoxOptimizer = new System.Windows.Forms.GroupBox();
            this._buttonOptimize = new System.Windows.Forms.Button();
            this._groupBoxMain = new System.Windows.Forms.GroupBox();
            this._buttonCalculate = new System.Windows.Forms.Button();
            this._menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sendToServerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyMatrixToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clearSelectionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.loadFromIndexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dataAnalysisToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.graphicalEvolutionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutWhereIsMyCCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.dataManagementToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this._statusStrip = new System.Windows.Forms.StatusStrip();
            this._toolStripProgressBar = new System.Windows.Forms.ToolStripProgressBar();
            this._toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this._panelDG = new System.Windows.Forms.Panel();
            this._dataGridViewNonCorrel = new StructuringControls.ExcelDataGridView();
            this.Security = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CRNCY = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quanto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Liquidity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.AvailableData = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.GroupIndex = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.currenciesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter();
            this.maturitiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.MaturitiesTableAdapter();
            this._backgroundWorkerCalculations = new System.ComponentModel.BackgroundWorker();
            this._timer = new System.Windows.Forms.Timer(this.components);
            this.sophisSecuritiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.sophisSecuritiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter();
            this.indicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.indicesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.IndicesTableAdapter();
            this.forexFactorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.forexFactorsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.ForexFactorsTableAdapter();
            this._printDialog = new System.Windows.Forms.PrintDialog();
            this._printDocument = new System.Drawing.Printing.PrintDocument();
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
            this._topPanel.SuspendLayout();
            this._groupBoxRhoHorizon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewRho)).BeginInit();
            this._groupBoxDisplay.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maturitiesBindingSource)).BeginInit();
            this._groupBoxOptimizer.SuspendLayout();
            this._groupBoxMain.SuspendLayout();
            this._menuStrip.SuspendLayout();
            this._statusStrip.SuspendLayout();
            this._panelDG.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewNonCorrel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.forexFactorsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // _comboBoxQuanto
            // 
            this._comboBoxQuanto.DataSource = this.currenciesBindingSource;
            this._comboBoxQuanto.DisplayMember = "Value";
            this._comboBoxQuanto.FormattingEnabled = true;
            this._comboBoxQuanto.Location = new System.Drawing.Point(66, 22);
            this._comboBoxQuanto.Name = "_comboBoxQuanto";
            this._comboBoxQuanto.Size = new System.Drawing.Size(88, 21);
            this._comboBoxQuanto.TabIndex = 11;
            this._comboBoxQuanto.ValueMember = "Value";
            // 
            // currenciesBindingSource
            // 
            this.currenciesBindingSource.DataMember = "Currencies";
            this.currenciesBindingSource.DataSource = this.cCDataSet;
            // 
            // cCDataSet
            // 
            this.cCDataSet.DataSetName = "CCDataSet";
            this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // _labelCurr
            // 
            this._labelCurr.AutoSize = true;
            this._labelCurr.Location = new System.Drawing.Point(12, 25);
            this._labelCurr.Name = "_labelCurr";
            this._labelCurr.Size = new System.Drawing.Size(48, 13);
            this._labelCurr.TabIndex = 12;
            this._labelCurr.Text = "Quanto :";
            // 
            // _topPanel
            // 
            this._topPanel.Controls.Add(this._groupBoxRhoHorizon);
            this._topPanel.Controls.Add(this._groupBoxDisplay);
            this._topPanel.Controls.Add(this._groupBoxOptimizer);
            this._topPanel.Controls.Add(this._groupBoxMain);
            this._topPanel.Controls.Add(this._menuStrip);
            this._topPanel.Dock = System.Windows.Forms.DockStyle.Top;
            this._topPanel.Location = new System.Drawing.Point(0, 0);
            this._topPanel.Name = "_topPanel";
            this._topPanel.Size = new System.Drawing.Size(1017, 117);
            this._topPanel.TabIndex = 13;
            // 
            // _groupBoxRhoHorizon
            // 
            this._groupBoxRhoHorizon.Controls.Add(this._dataGridViewRho);
            this._groupBoxRhoHorizon.Dock = System.Windows.Forms.DockStyle.Fill;
            this._groupBoxRhoHorizon.Location = new System.Drawing.Point(562, 0);
            this._groupBoxRhoHorizon.Name = "_groupBoxRhoHorizon";
            this._groupBoxRhoHorizon.Size = new System.Drawing.Size(455, 117);
            this._groupBoxRhoHorizon.TabIndex = 16;
            this._groupBoxRhoHorizon.TabStop = false;
            this._groupBoxRhoHorizon.Text = "Rhos";
            // 
            // _dataGridViewRho
            // 
            this._dataGridViewRho.AllowUserToAddRows = false;
            this._dataGridViewRho.AllowUserToDeleteRows = false;
            this._dataGridViewRho.AllowUserToResizeColumns = false;
            this._dataGridViewRho.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.Honeydew;
            this._dataGridViewRho.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this._dataGridViewRho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this._dataGridViewRho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            this._dataGridViewRho.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Y1,
            this.Y2,
            this.Y3,
            this.Y4,
            this.Y5});
            this._dataGridViewRho.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dataGridViewRho.Location = new System.Drawing.Point(3, 16);
            this._dataGridViewRho.Name = "_dataGridViewRho";
            this._dataGridViewRho.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this._dataGridViewRho.Size = new System.Drawing.Size(449, 98);
            this._dataGridViewRho.TabIndex = 15;
            // 
            // Y1
            // 
            dataGridViewCellStyle2.Format = "0.00%";
            this.Y1.DefaultCellStyle = dataGridViewCellStyle2;
            this.Y1.HeaderText = "1Y";
            this.Y1.Name = "Y1";
            this.Y1.ReadOnly = true;
            // 
            // Y2
            // 
            dataGridViewCellStyle3.Format = "0.00%";
            this.Y2.DefaultCellStyle = dataGridViewCellStyle3;
            this.Y2.HeaderText = "2Y";
            this.Y2.Name = "Y2";
            this.Y2.ReadOnly = true;
            // 
            // Y3
            // 
            dataGridViewCellStyle4.Format = "0.00%";
            this.Y3.DefaultCellStyle = dataGridViewCellStyle4;
            this.Y3.HeaderText = "3Y";
            this.Y3.Name = "Y3";
            this.Y3.ReadOnly = true;
            // 
            // Y4
            // 
            dataGridViewCellStyle5.Format = "0.00%";
            this.Y4.DefaultCellStyle = dataGridViewCellStyle5;
            this.Y4.HeaderText = "4Y";
            this.Y4.Name = "Y4";
            this.Y4.ReadOnly = true;
            // 
            // Y5
            // 
            dataGridViewCellStyle6.Format = "0.00%";
            this.Y5.DefaultCellStyle = dataGridViewCellStyle6;
            this.Y5.HeaderText = "5Y";
            this.Y5.Name = "Y5";
            this.Y5.ReadOnly = true;
            // 
            // _groupBoxDisplay
            // 
            this._groupBoxDisplay.Controls.Add(this._floorCB);
            this._groupBoxDisplay.Controls.Add(this._buttonPrint);
            this._groupBoxDisplay.Controls.Add(this._comboBoxQtoCmpo);
            this._groupBoxDisplay.Controls.Add(this.label3);
            this._groupBoxDisplay.Controls.Add(this._buttonGraphAnalysis);
            this._groupBoxDisplay.Controls.Add(this._comboBoxFrequency);
            this._groupBoxDisplay.Controls.Add(this.label2);
            this._groupBoxDisplay.Controls.Add(this._buttonCopy);
            this._groupBoxDisplay.Controls.Add(this._comboBoxProvs);
            this._groupBoxDisplay.Controls.Add(this.label1);
            this._groupBoxDisplay.Controls.Add(this._labelHorizon);
            this._groupBoxDisplay.Controls.Add(this._comboBoxCorrelHorizon);
            this._groupBoxDisplay.Dock = System.Windows.Forms.DockStyle.Left;
            this._groupBoxDisplay.Location = new System.Drawing.Point(163, 0);
            this._groupBoxDisplay.Name = "_groupBoxDisplay";
            this._groupBoxDisplay.Size = new System.Drawing.Size(399, 117);
            this._groupBoxDisplay.TabIndex = 21;
            this._groupBoxDisplay.TabStop = false;
            this._groupBoxDisplay.Text = "Display as ...";
            // 
            // _floorCB
            // 
            this._floorCB.AutoSize = true;
            this._floorCB.Checked = true;
            this._floorCB.CheckState = System.Windows.Forms.CheckState.Checked;
            this._floorCB.Location = new System.Drawing.Point(302, 22);
            this._floorCB.Name = "_floorCB";
            this._floorCB.Size = new System.Drawing.Size(95, 30);
            this._floorCB.TabIndex = 25;
            this._floorCB.Text = "Floor with \nmarked values";
            this._floorCB.UseVisualStyleBackColor = true;
            this._floorCB.CheckedChanged += new System.EventHandler(this._floorCB_CheckedChanged);
            // 
            // _buttonPrint
            // 
            this._buttonPrint.Location = new System.Drawing.Point(324, 82);
            this._buttonPrint.Name = "_buttonPrint";
            this._buttonPrint.Size = new System.Drawing.Size(67, 27);
            this._buttonPrint.TabIndex = 24;
            this._buttonPrint.Text = "&Print";
            this._buttonPrint.UseVisualStyleBackColor = true;
            this._buttonPrint.Click += new System.EventHandler(this._buttonPrint_Click);
            // 
            // _comboBoxQtoCmpo
            // 
            this._comboBoxQtoCmpo.FormattingEnabled = true;
            this._comboBoxQtoCmpo.Items.AddRange(new object[] {
            "Quanto",
            "Compo"});
            this._comboBoxQtoCmpo.Location = new System.Drawing.Point(230, 53);
            this._comboBoxQtoCmpo.Name = "_comboBoxQtoCmpo";
            this._comboBoxQtoCmpo.Size = new System.Drawing.Size(66, 21);
            this._comboBoxQtoCmpo.TabIndex = 23;
            this._comboBoxQtoCmpo.SelectedIndexChanged += new System.EventHandler(this._comboBoxQtoCmpo_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(162, 56);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(62, 13);
            this.label3.TabIndex = 22;
            this.label3.Text = "Qto/Cmpo :";
            // 
            // _buttonGraphAnalysis
            // 
            this._buttonGraphAnalysis.Location = new System.Drawing.Point(96, 82);
            this._buttonGraphAnalysis.Name = "_buttonGraphAnalysis";
            this._buttonGraphAnalysis.Size = new System.Drawing.Size(138, 27);
            this._buttonGraphAnalysis.TabIndex = 21;
            this._buttonGraphAnalysis.Text = "&Graph Evolution (Ctrl+G)";
            this._buttonGraphAnalysis.UseVisualStyleBackColor = true;
            this._buttonGraphAnalysis.Click += new System.EventHandler(this._buttonGraphAnalysis_Click);
            // 
            // _comboBoxFrequency
            // 
            this._comboBoxFrequency.FormattingEnabled = true;
            this._comboBoxFrequency.Items.AddRange(new object[] {
            "Weekly",
            "Daily",
            "Monthly"});
            this._comboBoxFrequency.Location = new System.Drawing.Point(230, 26);
            this._comboBoxFrequency.Name = "_comboBoxFrequency";
            this._comboBoxFrequency.Size = new System.Drawing.Size(66, 21);
            this._comboBoxFrequency.TabIndex = 20;
            this._comboBoxFrequency.SelectedIndexChanged += new System.EventHandler(this._comboBoxFrequency_SelectedIndexChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(161, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "Frequency :";
            // 
            // _buttonCopy
            // 
            this._buttonCopy.Location = new System.Drawing.Point(240, 82);
            this._buttonCopy.Name = "_buttonCopy";
            this._buttonCopy.Size = new System.Drawing.Size(78, 27);
            this._buttonCopy.TabIndex = 18;
            this._buttonCopy.Text = "Copy &Matrix";
            this._buttonCopy.UseVisualStyleBackColor = true;
            this._buttonCopy.Click += new System.EventHandler(this._buttonCopy_Click);
            // 
            // _comboBoxProvs
            // 
            this._comboBoxProvs.FormattingEnabled = true;
            this._comboBoxProvs.Items.AddRange(new object[] {
            "None",
            "Lambda prod",
            "Custom ..."});
            this._comboBoxProvs.Location = new System.Drawing.Point(65, 52);
            this._comboBoxProvs.Name = "_comboBoxProvs";
            this._comboBoxProvs.Size = new System.Drawing.Size(86, 21);
            this._comboBoxProvs.TabIndex = 17;
            this._comboBoxProvs.SelectionChangeCommitted += new System.EventHandler(this._comboBoxProvs_SelectionChangeCommitted);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(19, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 16;
            this.label1.Text = "Provs :";
            // 
            // _labelHorizon
            // 
            this._labelHorizon.AutoSize = true;
            this._labelHorizon.Location = new System.Drawing.Point(10, 28);
            this._labelHorizon.Name = "_labelHorizon";
            this._labelHorizon.Size = new System.Drawing.Size(49, 13);
            this._labelHorizon.TabIndex = 15;
            this._labelHorizon.Text = "Horizon :";
            // 
            // _comboBoxCorrelHorizon
            // 
            this._comboBoxCorrelHorizon.DataSource = this.maturitiesBindingSource;
            this._comboBoxCorrelHorizon.DisplayMember = "Name";
            this._comboBoxCorrelHorizon.FormattingEnabled = true;
            this._comboBoxCorrelHorizon.Location = new System.Drawing.Point(65, 25);
            this._comboBoxCorrelHorizon.Name = "_comboBoxCorrelHorizon";
            this._comboBoxCorrelHorizon.Size = new System.Drawing.Size(86, 21);
            this._comboBoxCorrelHorizon.TabIndex = 14;
            this._comboBoxCorrelHorizon.ValueMember = "Value";
            this._comboBoxCorrelHorizon.SelectionChangeCommitted += new System.EventHandler(this._comboBoxCorrelHorizon_SelectionChangeCommitted);
            // 
            // maturitiesBindingSource
            // 
            this.maturitiesBindingSource.DataMember = "Maturities";
            this.maturitiesBindingSource.DataSource = this.cCDataSet;
            // 
            // _groupBoxOptimizer
            // 
            this._groupBoxOptimizer.Controls.Add(this._buttonOptimize);
            this._groupBoxOptimizer.Dock = System.Windows.Forms.DockStyle.Left;
            this._groupBoxOptimizer.Location = new System.Drawing.Point(163, 0);
            this._groupBoxOptimizer.Name = "_groupBoxOptimizer";
            this._groupBoxOptimizer.Size = new System.Drawing.Size(0, 117);
            this._groupBoxOptimizer.TabIndex = 22;
            this._groupBoxOptimizer.TabStop = false;
            this._groupBoxOptimizer.Text = "Optimizer";
            // 
            // _buttonOptimize
            // 
            this._buttonOptimize.Location = new System.Drawing.Point(6, 28);
            this._buttonOptimize.Name = "_buttonOptimize";
            this._buttonOptimize.Size = new System.Drawing.Size(72, 68);
            this._buttonOptimize.TabIndex = 13;
            this._buttonOptimize.Text = "Launch Optimizer";
            this._buttonOptimize.UseVisualStyleBackColor = true;
            this._buttonOptimize.Click += new System.EventHandler(this._buttonOptimize_Click);
            // 
            // _groupBoxMain
            // 
            this._groupBoxMain.Controls.Add(this._comboBoxQuanto);
            this._groupBoxMain.Controls.Add(this._labelCurr);
            this._groupBoxMain.Controls.Add(this._buttonCalculate);
            this._groupBoxMain.Dock = System.Windows.Forms.DockStyle.Left;
            this._groupBoxMain.Location = new System.Drawing.Point(0, 0);
            this._groupBoxMain.Name = "_groupBoxMain";
            this._groupBoxMain.Size = new System.Drawing.Size(163, 117);
            this._groupBoxMain.TabIndex = 20;
            this._groupBoxMain.TabStop = false;
            this._groupBoxMain.Text = "Parameters";
            // 
            // _buttonCalculate
            // 
            this._buttonCalculate.Location = new System.Drawing.Point(15, 52);
            this._buttonCalculate.Name = "_buttonCalculate";
            this._buttonCalculate.Size = new System.Drawing.Size(139, 49);
            this._buttonCalculate.TabIndex = 13;
            this._buttonCalculate.Text = "&Retrieve Data (Ctrl+R)";
            this._buttonCalculate.Click += new System.EventHandler(this._buttonCalculate_Click);
            // 
            // _menuStrip
            // 
            this._menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.editToolStripMenuItem,
            this.dataAnalysisToolStripMenuItem,
            this.optionsToolStripMenuItem});
            this._menuStrip.Location = new System.Drawing.Point(0, 0);
            this._menuStrip.Name = "_menuStrip";
            this._menuStrip.Size = new System.Drawing.Size(904, 24);
            this._menuStrip.TabIndex = 18;
            this._menuStrip.Text = "menuStrip1";
            this._menuStrip.Visible = false;
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.sendToServerToolStripMenuItem,
            this.toolStripSeparator2,
            this.printToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // sendToServerToolStripMenuItem
            // 
            this.sendToServerToolStripMenuItem.Name = "sendToServerToolStripMenuItem";
            this.sendToServerToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.R)));
            this.sendToServerToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.sendToServerToolStripMenuItem.Text = "Retrieve Correls";
            this.sendToServerToolStripMenuItem.Click += new System.EventHandler(this.sendToServerToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(194, 6);
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.P)));
            this.printToolStripMenuItem.Size = new System.Drawing.Size(197, 22);
            this.printToolStripMenuItem.Text = "Print ...";
            this.printToolStripMenuItem.Click += new System.EventHandler(this.printToolStripMenuItem_Click);
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyMatrixToolStripMenuItem,
            this.clearSelectionToolStripMenuItem,
            this.toolStripSeparator4,
            this.loadFromIndexToolStripMenuItem});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyMatrixToolStripMenuItem
            // 
            this.copyMatrixToolStripMenuItem.Name = "copyMatrixToolStripMenuItem";
            this.copyMatrixToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.M)));
            this.copyMatrixToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.copyMatrixToolStripMenuItem.Text = "Copy Matrix";
            this.copyMatrixToolStripMenuItem.Click += new System.EventHandler(this.copyMatrixToolStripMenuItem_Click);
            // 
            // clearSelectionToolStripMenuItem
            // 
            this.clearSelectionToolStripMenuItem.Name = "clearSelectionToolStripMenuItem";
            this.clearSelectionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.K)));
            this.clearSelectionToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.clearSelectionToolStripMenuItem.Text = "Clear Securities";
            this.clearSelectionToolStripMenuItem.Click += new System.EventHandler(this.clearSelectionToolStripMenuItem_Click);
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(212, 6);
            // 
            // loadFromIndexToolStripMenuItem
            // 
            this.loadFromIndexToolStripMenuItem.Enabled = false;
            this.loadFromIndexToolStripMenuItem.Name = "loadFromIndexToolStripMenuItem";
            this.loadFromIndexToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.O)));
            this.loadFromIndexToolStripMenuItem.Size = new System.Drawing.Size(215, 22);
            this.loadFromIndexToolStripMenuItem.Text = "Load from index ...";
            this.loadFromIndexToolStripMenuItem.Click += new System.EventHandler(this.loadFromIndexToolStripMenuItem_Click);
            // 
            // dataAnalysisToolStripMenuItem
            // 
            this.dataAnalysisToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.graphicalEvolutionToolStripMenuItem});
            this.dataAnalysisToolStripMenuItem.Name = "dataAnalysisToolStripMenuItem";
            this.dataAnalysisToolStripMenuItem.Size = new System.Drawing.Size(89, 20);
            this.dataAnalysisToolStripMenuItem.Text = "Data Analysis";
            // 
            // graphicalEvolutionToolStripMenuItem
            // 
            this.graphicalEvolutionToolStripMenuItem.Name = "graphicalEvolutionToolStripMenuItem";
            this.graphicalEvolutionToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.G)));
            this.graphicalEvolutionToolStripMenuItem.Size = new System.Drawing.Size(219, 22);
            this.graphicalEvolutionToolStripMenuItem.Text = "Graphical Evolution";
            this.graphicalEvolutionToolStripMenuItem.Click += new System.EventHandler(this.graphicalEvolutionToolStripMenuItem_Click);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutWhereIsMyCCToolStripMenuItem,
            this.toolStripSeparator3,
            this.dataManagementToolStripMenuItem,
            this.toolStripSeparator1,
            this.settingsToolStripMenuItem});
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(61, 20);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // aboutWhereIsMyCCToolStripMenuItem
            // 
            this.aboutWhereIsMyCCToolStripMenuItem.Name = "aboutWhereIsMyCCToolStripMenuItem";
            this.aboutWhereIsMyCCToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.aboutWhereIsMyCCToolStripMenuItem.Text = "About Where is my CC ...";
            this.aboutWhereIsMyCCToolStripMenuItem.Click += new System.EventHandler(this.aboutWhereIsMyCCToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(211, 6);
            // 
            // dataManagementToolStripMenuItem
            // 
            this.dataManagementToolStripMenuItem.Name = "dataManagementToolStripMenuItem";
            this.dataManagementToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.D)));
            this.dataManagementToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.dataManagementToolStripMenuItem.Text = "Data Management";
            this.dataManagementToolStripMenuItem.Click += new System.EventHandler(this.dataManagementToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(211, 6);
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.Enabled = false;
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.S)));
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(214, 22);
            this.settingsToolStripMenuItem.Text = "Settings ...";
            this.settingsToolStripMenuItem.Click += new System.EventHandler(this.settingsToolStripMenuItem_Click);
            // 
            // _statusStrip
            // 
            this._statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this._toolStripProgressBar,
            this._toolStripStatusLabel});
            this._statusStrip.Location = new System.Drawing.Point(0, 547);
            this._statusStrip.Name = "_statusStrip";
            this._statusStrip.Size = new System.Drawing.Size(1017, 22);
            this._statusStrip.TabIndex = 15;
            this._statusStrip.Text = "statusStrip1";
            // 
            // _toolStripProgressBar
            // 
            this._toolStripProgressBar.Name = "_toolStripProgressBar";
            this._toolStripProgressBar.Size = new System.Drawing.Size(150, 16);
            // 
            // _toolStripStatusLabel
            // 
            this._toolStripStatusLabel.Name = "_toolStripStatusLabel";
            this._toolStripStatusLabel.Size = new System.Drawing.Size(0, 17);
            // 
            // _panelDG
            // 
            this._panelDG.Controls.Add(this._dataGridViewNonCorrel);
            this._panelDG.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelDG.Location = new System.Drawing.Point(0, 117);
            this._panelDG.Name = "_panelDG";
            this._panelDG.Size = new System.Drawing.Size(1017, 430);
            this._panelDG.TabIndex = 16;
            // 
            // _dataGridViewNonCorrel
            // 
            this._dataGridViewNonCorrel.AllowUserToAddRows = false;
            this._dataGridViewNonCorrel.AllowUserToDeleteRows = false;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.AliceBlue;
            this._dataGridViewNonCorrel.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle7;
            this._dataGridViewNonCorrel.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this._dataGridViewNonCorrel.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this._dataGridViewNonCorrel.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Security,
            this.CRNCY,
            this.Description,
            this.Quanto,
            this.Liquidity,
            this.AvailableData,
            this.GroupIndex});
            this._dataGridViewNonCorrel.CorrelationDataTable = null;
            this._dataGridViewNonCorrel.DataComplete = "OK";
            this._dataGridViewNonCorrel.Dock = System.Windows.Forms.DockStyle.Fill;
            this._dataGridViewNonCorrel.EmphasisColor = System.Drawing.Color.Red;
            this._dataGridViewNonCorrel.EmphasizedCount = -2147483648;
            this._dataGridViewNonCorrel.GroupIndexColumn = -2147483648;
            this._dataGridViewNonCorrel.GroupList = ((System.Collections.Generic.List<System.Collections.Generic.List<int>>)(resources.GetObject("_dataGridViewNonCorrel.GroupList")));
            this._dataGridViewNonCorrel.HistoricalDataIncompleteColumn = -2147483648;
            this._dataGridViewNonCorrel.IncompleteColor = System.Drawing.Color.Red;
            this._dataGridViewNonCorrel.IsCustomGroup = false;
            this._dataGridViewNonCorrel.IsPaintable = false;
            this._dataGridViewNonCorrel.Location = new System.Drawing.Point(0, 0);
            this._dataGridViewNonCorrel.Margin = new System.Windows.Forms.Padding(0);
            this._dataGridViewNonCorrel.MissingColor = System.Drawing.Color.Red;
            this._dataGridViewNonCorrel.MissingData = "N#A Sec";
            this._dataGridViewNonCorrel.MissingDataReferenceColumn = -2147483648;
            this._dataGridViewNonCorrel.Name = "_dataGridViewNonCorrel";
            this._dataGridViewNonCorrel.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this._dataGridViewNonCorrel.RowHeadersVisible = false;
            this._dataGridViewNonCorrel.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._dataGridViewNonCorrel.Size = new System.Drawing.Size(1017, 430);
            this._dataGridViewNonCorrel.TabIndex = 14;
            this._dataGridViewNonCorrel.ColumnHeaderMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this._dataGridViewNonCorrel_ColumnHeaderMouseClick);
            // 
            // Security
            // 
            this.Security.DataPropertyName = "Security";
            this.Security.Frozen = true;
            this.Security.HeaderText = "Security";
            this.Security.Name = "Security";
            this.Security.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // CRNCY
            // 
            this.CRNCY.DataPropertyName = "CRNCY";
            this.CRNCY.Frozen = true;
            this.CRNCY.HeaderText = "Currency";
            this.CRNCY.Name = "CRNCY";
            this.CRNCY.ReadOnly = true;
            this.CRNCY.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // Description
            // 
            this.Description.DataPropertyName = "NAME";
            this.Description.Frozen = true;
            this.Description.HeaderText = "Description";
            this.Description.Name = "Description";
            this.Description.ReadOnly = true;
            this.Description.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // Quanto
            // 
            this.Quanto.DataPropertyName = "Quanto";
            dataGridViewCellStyle8.Format = "0.00%";
            this.Quanto.DefaultCellStyle = dataGridViewCellStyle8;
            this.Quanto.HeaderText = "Quanto";
            this.Quanto.Name = "Quanto";
            this.Quanto.ReadOnly = true;
            this.Quanto.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // Liquidity
            // 
            this.Liquidity.DataPropertyName = "Liquidity";
            dataGridViewCellStyle9.Format = "#,##0";
            this.Liquidity.DefaultCellStyle = dataGridViewCellStyle9;
            this.Liquidity.HeaderText = "Cash Liquidity";
            this.Liquidity.Name = "Liquidity";
            this.Liquidity.ReadOnly = true;
            this.Liquidity.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            // 
            // AvailableData
            // 
            this.AvailableData.DataPropertyName = "AvailableData";
            this.AvailableData.HeaderText = "Available Data";
            this.AvailableData.Name = "AvailableData";
            this.AvailableData.ReadOnly = true;
            this.AvailableData.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.AvailableData.Width = 90;
            // 
            // GroupIndex
            // 
            this.GroupIndex.DataPropertyName = "GroupIndex";
            this.GroupIndex.HeaderText = "GroupIndex";
            this.GroupIndex.Name = "GroupIndex";
            this.GroupIndex.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Programmatic;
            this.GroupIndex.Visible = false;
            this.GroupIndex.Width = 5;
            // 
            // currenciesTableAdapter
            // 
            this.currenciesTableAdapter.ClearBeforeFill = true;
            // 
            // maturitiesTableAdapter
            // 
            this.maturitiesTableAdapter.ClearBeforeFill = true;
            // 
            // _backgroundWorkerCalculations
            // 
            this._backgroundWorkerCalculations.WorkerReportsProgress = true;
            this._backgroundWorkerCalculations.WorkerSupportsCancellation = true;
            this._backgroundWorkerCalculations.DoWork += new System.ComponentModel.DoWorkEventHandler(this._backgroundWorkerCalculations_DoWork);
            this._backgroundWorkerCalculations.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this._backgroundWorkerCalculations_RunWorkerCompleted);
            // 
            // _timer
            // 
            this._timer.Tick += new System.EventHandler(this._timer_Tick);
            // 
            // sophisSecuritiesBindingSource
            // 
            this.sophisSecuritiesBindingSource.DataMember = "SophisSecurities";
            this.sophisSecuritiesBindingSource.DataSource = this.cCDataSet;
            // 
            // sophisSecuritiesTableAdapter
            // 
            this.sophisSecuritiesTableAdapter.ClearBeforeFill = true;
            // 
            // indicesBindingSource
            // 
            this.indicesBindingSource.DataMember = "Indices";
            this.indicesBindingSource.DataSource = this.cCDataSet;
            // 
            // indicesTableAdapter
            // 
            this.indicesTableAdapter.ClearBeforeFill = true;
            // 
            // forexFactorsBindingSource
            // 
            this.forexFactorsBindingSource.DataMember = "ForexFactors";
            this.forexFactorsBindingSource.DataSource = this.cCDataSet;
            // 
            // forexFactorsTableAdapter
            // 
            this.forexFactorsTableAdapter.ClearBeforeFill = true;
            // 
            // _printDialog
            // 
            this._printDialog.UseEXDialog = true;
            // 
            // _printDocument
            // 
            this._printDocument.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this._printDocument_PrintPage);
            // 
            // CorrelationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1017, 569);
            this.Controls.Add(this._panelDG);
            this.Controls.Add(this._statusStrip);
            this.Controls.Add(this._topPanel);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "CorrelationForm";
            this.Text = "Correlation Client";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.CorrelationForm_FormClosing);
            this.Shown += new System.EventHandler(this.CorrelationForm_Shown);
            ((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
            this._topPanel.ResumeLayout(false);
            this._topPanel.PerformLayout();
            this._groupBoxRhoHorizon.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewRho)).EndInit();
            this._groupBoxDisplay.ResumeLayout(false);
            this._groupBoxDisplay.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.maturitiesBindingSource)).EndInit();
            this._groupBoxOptimizer.ResumeLayout(false);
            this._groupBoxMain.ResumeLayout(false);
            this._groupBoxMain.PerformLayout();
            this._menuStrip.ResumeLayout(false);
            this._menuStrip.PerformLayout();
            this._statusStrip.ResumeLayout(false);
            this._statusStrip.PerformLayout();
            this._panelDG.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._dataGridViewNonCorrel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.forexFactorsBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox _comboBoxQuanto;
        private System.Windows.Forms.Label _labelCurr;
        private System.Windows.Forms.Panel _topPanel;
        private StructuringControls.ExcelDataGridView _dataGridViewNonCorrel;
        private System.Windows.Forms.StatusStrip _statusStrip;
        private System.Windows.Forms.ToolStripProgressBar _toolStripProgressBar;
        private System.Windows.Forms.ToolStripStatusLabel _toolStripStatusLabel;
        private System.Windows.Forms.Panel _panelDG;
        private System.Windows.Forms.ToolTip _toolTip;
        private System.Windows.Forms.Button _buttonCalculate;
        private System.Windows.Forms.ComboBox _comboBoxCorrelHorizon;
        private System.Windows.Forms.GroupBox _groupBoxRhoHorizon;
        private System.Windows.Forms.DataGridView _dataGridViewRho;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Y5;
        private System.Windows.Forms.MenuStrip _menuStrip;
		private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.GroupBox _groupBoxDisplay;
        private System.Windows.Forms.ComboBox _comboBoxProvs;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label _labelHorizon;
        private System.Windows.Forms.GroupBox _groupBoxMain;
        private System.Windows.Forms.Button _buttonCopy;
        private System.Windows.Forms.ToolStripMenuItem dataManagementToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private CCDataSet cCDataSet;
        private System.Windows.Forms.BindingSource currenciesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter currenciesTableAdapter;
        private System.Windows.Forms.BindingSource maturitiesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.MaturitiesTableAdapter maturitiesTableAdapter;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyMatrixToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem clearSelectionToolStripMenuItem;
        private System.ComponentModel.BackgroundWorker _backgroundWorkerCalculations;
        private System.Windows.Forms.Timer _timer;
        private System.Windows.Forms.ToolStripMenuItem sendToServerToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem aboutWhereIsMyCCToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem dataAnalysisToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem graphicalEvolutionToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn Security;
        private System.Windows.Forms.DataGridViewTextBoxColumn CRNCY;
        private System.Windows.Forms.DataGridViewTextBoxColumn Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quanto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Liquidity;
        private System.Windows.Forms.DataGridViewTextBoxColumn AvailableData;
        private System.Windows.Forms.DataGridViewTextBoxColumn GroupIndex;
        private System.Windows.Forms.GroupBox _groupBoxOptimizer;
        private System.Windows.Forms.Button _buttonOptimize;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripMenuItem loadFromIndexToolStripMenuItem;
        private System.Windows.Forms.ComboBox _comboBoxFrequency;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button _buttonGraphAnalysis;
        private System.Windows.Forms.BindingSource sophisSecuritiesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter sophisSecuritiesTableAdapter;
        private System.Windows.Forms.BindingSource indicesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.IndicesTableAdapter indicesTableAdapter;
        private System.Windows.Forms.BindingSource forexFactorsBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.ForexFactorsTableAdapter forexFactorsTableAdapter;
        private System.Windows.Forms.PrintDialog _printDialog;
        private System.Drawing.Printing.PrintDocument _printDocument;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ComboBox _comboBoxQtoCmpo;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button _buttonPrint;
        private System.Windows.Forms.CheckBox _floorCB;
    }
}