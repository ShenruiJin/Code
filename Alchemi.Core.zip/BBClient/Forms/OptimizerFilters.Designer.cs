﻿using System;
using System.Windows.Forms;

namespace BBClient.Forms
{
    partial class OptimizerFilters
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(OptimizerFilters));
            this.buttonApplyFilters = new System.Windows.Forms.Button();
            this.groupBoxFilters = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.treeViewSector = new System.Windows.Forms.TreeView();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.checkedListBoxCurrencies = new System.Windows.Forms.CheckedListBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.checkedListBoxCountries = new System.Windows.Forms.CheckedListBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.textBoxVolUpperBound = new System.Windows.Forms.TextBox();
            this.textBoxVolLowerBound = new System.Windows.Forms.TextBox();
            this.buttonAddVolFilter = new System.Windows.Forms.Button();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBoxFwdUpperBound = new System.Windows.Forms.TextBox();
            this.textBoxFwdLowerBound = new System.Windows.Forms.TextBox();
            this.buttonAddFwdFilter = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.textBoxLiquidityUpperBound = new System.Windows.Forms.TextBox();
            this.textBoxLiquidityLowerBound = new System.Windows.Forms.TextBox();
            this.buttonAddLiquidityFilter = new System.Windows.Forms.Button();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.textBoxRatingUpperBound = new System.Windows.Forms.TextBox();
            this.textBoxRatingLowerBound = new System.Windows.Forms.TextBox();
            this.buttonAddRatingFilter = new System.Windows.Forms.Button();
            this.dataGridViewConditions = new StructuringControls.ExcelDataGridView();
            this.IncludeExcludeColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.CriteriumColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ValueColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DeleteColumn = new System.Windows.Forms.DataGridViewButtonColumn();
            this.groupBoxFilters.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewConditions)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonApplyFilters
            // 
            this.buttonApplyFilters.Location = new System.Drawing.Point(555, 528);
            this.buttonApplyFilters.Name = "buttonApplyFilters";
            this.buttonApplyFilters.Size = new System.Drawing.Size(201, 66);
            this.buttonApplyFilters.TabIndex = 1;
            this.buttonApplyFilters.Text = "Apply filters";
            this.buttonApplyFilters.UseVisualStyleBackColor = true;
            this.buttonApplyFilters.Click += new System.EventHandler(this.buttonApplyFilters_Click);
            // 
            // groupBoxFilters
            // 
            this.groupBoxFilters.Controls.Add(this.label1);
            this.groupBoxFilters.Controls.Add(this.tabControl1);
            this.groupBoxFilters.Location = new System.Drawing.Point(12, 12);
            this.groupBoxFilters.Name = "groupBoxFilters";
            this.groupBoxFilters.Size = new System.Drawing.Size(744, 390);
            this.groupBoxFilters.TabIndex = 2;
            this.groupBoxFilters.TabStop = false;
            this.groupBoxFilters.Text = "Conditional Filtering";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(7, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(49, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Filter by :";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage8);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(6, 32);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(650, 352);
            this.tabControl1.TabIndex = 9;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.treeViewSector);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(642, 326);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Sector";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // treeViewSector
            // 
            this.treeViewSector.CheckBoxes = true;
            this.treeViewSector.Location = new System.Drawing.Point(6, 6);
            this.treeViewSector.Name = "treeViewSector";
            this.treeViewSector.Size = new System.Drawing.Size(630, 320);
            this.treeViewSector.TabIndex = 0;
            this.treeViewSector.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.treeViewSector_NodeMouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.checkedListBoxCurrencies);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(642, 326);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Currency";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // checkedListBoxCurrencies
            // 
            this.checkedListBoxCurrencies.FormattingEnabled = true;
            this.checkedListBoxCurrencies.Location = new System.Drawing.Point(6, 6);
            this.checkedListBoxCurrencies.Name = "checkedListBoxCurrencies";
            this.checkedListBoxCurrencies.Size = new System.Drawing.Size(630, 199);
            this.checkedListBoxCurrencies.TabIndex = 0;
            this.checkedListBoxCurrencies.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxCurrencies_SelectedIndexChanged);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.checkedListBoxCountries);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(642, 326);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Country";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // checkedListBoxCountries
            // 
            this.checkedListBoxCountries.FormattingEnabled = true;
            this.checkedListBoxCountries.Location = new System.Drawing.Point(6, 6);
            this.checkedListBoxCountries.Name = "checkedListBoxCountries";
            this.checkedListBoxCountries.Size = new System.Drawing.Size(630, 199);
            this.checkedListBoxCountries.TabIndex = 1;
            this.checkedListBoxCountries.SelectedIndexChanged += new System.EventHandler(this.checkedListBoxCountries_SelectedIndexChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.label3);
            this.tabPage4.Controls.Add(this.label2);
            this.tabPage4.Controls.Add(this.textBoxVolUpperBound);
            this.tabPage4.Controls.Add(this.textBoxVolLowerBound);
            this.tabPage4.Controls.Add(this.buttonAddVolFilter);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(642, 326);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Volatility";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(249, 19);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(15, 13);
            this.label7.TabIndex = 9;
            this.label7.Text = "%";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(167, 20);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 8;
            this.label6.Text = "<";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(116, 19);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(45, 13);
            this.label5.TabIndex = 7;
            this.label5.Text = "Volatility";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(97, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(13, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "<";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(76, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(15, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "%";
            // 
            // textBoxVolUpperBound
            // 
            this.textBoxVolUpperBound.Location = new System.Drawing.Point(186, 16);
            this.textBoxVolUpperBound.Name = "textBoxVolUpperBound";
            this.textBoxVolUpperBound.Size = new System.Drawing.Size(58, 20);
            this.textBoxVolUpperBound.TabIndex = 4;
            // 
            // textBoxVolLowerBound
            // 
            this.textBoxVolLowerBound.Location = new System.Drawing.Point(13, 16);
            this.textBoxVolLowerBound.Name = "textBoxVolLowerBound";
            this.textBoxVolLowerBound.Size = new System.Drawing.Size(58, 20);
            this.textBoxVolLowerBound.TabIndex = 3;
            // 
            // buttonAddVolFilter
            // 
            this.buttonAddVolFilter.Location = new System.Drawing.Point(539, 184);
            this.buttonAddVolFilter.Name = "buttonAddVolFilter";
            this.buttonAddVolFilter.Size = new System.Drawing.Size(100, 24);
            this.buttonAddVolFilter.TabIndex = 2;
            this.buttonAddVolFilter.Text = "Add condition";
            this.buttonAddVolFilter.UseVisualStyleBackColor = true;
            this.buttonAddVolFilter.Click += new System.EventHandler(this.buttonAddVolFilter_Click);
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.label8);
            this.tabPage5.Controls.Add(this.label11);
            this.tabPage5.Controls.Add(this.label12);
            this.tabPage5.Controls.Add(this.label13);
            this.tabPage5.Controls.Add(this.label14);
            this.tabPage5.Controls.Add(this.textBoxFwdUpperBound);
            this.tabPage5.Controls.Add(this.textBoxFwdLowerBound);
            this.tabPage5.Controls.Add(this.buttonAddFwdFilter);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(642, 326);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "Forward";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(249, 20);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(15, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "%";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(167, 20);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(13, 13);
            this.label11.TabIndex = 13;
            this.label11.Text = "<";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(116, 20);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(45, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Forward";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(97, 20);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(13, 13);
            this.label13.TabIndex = 11;
            this.label13.Text = "<";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(76, 20);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 13);
            this.label14.TabIndex = 10;
            this.label14.Text = "%";
            // 
            // textBoxFwdUpperBound
            // 
            this.textBoxFwdUpperBound.Location = new System.Drawing.Point(186, 16);
            this.textBoxFwdUpperBound.Name = "textBoxFwdUpperBound";
            this.textBoxFwdUpperBound.Size = new System.Drawing.Size(58, 20);
            this.textBoxFwdUpperBound.TabIndex = 6;
            // 
            // textBoxFwdLowerBound
            // 
            this.textBoxFwdLowerBound.Location = new System.Drawing.Point(13, 16);
            this.textBoxFwdLowerBound.Name = "textBoxFwdLowerBound";
            this.textBoxFwdLowerBound.Size = new System.Drawing.Size(58, 20);
            this.textBoxFwdLowerBound.TabIndex = 5;
            // 
            // buttonAddFwdFilter
            // 
            this.buttonAddFwdFilter.Location = new System.Drawing.Point(539, 184);
            this.buttonAddFwdFilter.Name = "buttonAddFwdFilter";
            this.buttonAddFwdFilter.Size = new System.Drawing.Size(100, 24);
            this.buttonAddFwdFilter.TabIndex = 2;
            this.buttonAddFwdFilter.Text = "Add condition";
            this.buttonAddFwdFilter.UseVisualStyleBackColor = true;
            this.buttonAddFwdFilter.Click += new System.EventHandler(this.buttonAddFwdFilter_Click);
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.label16);
            this.tabPage8.Controls.Add(this.label17);
            this.tabPage8.Controls.Add(this.label18);
            this.tabPage8.Controls.Add(this.textBoxLiquidityUpperBound);
            this.tabPage8.Controls.Add(this.textBoxLiquidityLowerBound);
            this.tabPage8.Controls.Add(this.buttonAddLiquidityFilter);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(642, 326);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Liquidity";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(204, 18);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(13, 13);
            this.label16.TabIndex = 18;
            this.label16.Text = "<";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(153, 19);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(45, 13);
            this.label17.TabIndex = 17;
            this.label17.Text = "Liquidity";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(134, 19);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(13, 13);
            this.label18.TabIndex = 16;
            this.label18.Text = "<";
            // 
            // textBoxLiquidityUpperBound
            // 
            this.textBoxLiquidityUpperBound.Location = new System.Drawing.Point(234, 15);
            this.textBoxLiquidityUpperBound.Name = "textBoxLiquidityUpperBound";
            this.textBoxLiquidityUpperBound.Size = new System.Drawing.Size(115, 20);
            this.textBoxLiquidityUpperBound.TabIndex = 6;
            // 
            // textBoxLiquidityLowerBound
            // 
            this.textBoxLiquidityLowerBound.Location = new System.Drawing.Point(13, 16);
            this.textBoxLiquidityLowerBound.Name = "textBoxLiquidityLowerBound";
            this.textBoxLiquidityLowerBound.Size = new System.Drawing.Size(115, 20);
            this.textBoxLiquidityLowerBound.TabIndex = 5;
            // 
            // buttonAddLiquidityFilter
            // 
            this.buttonAddLiquidityFilter.Location = new System.Drawing.Point(542, 185);
            this.buttonAddLiquidityFilter.Name = "buttonAddLiquidityFilter";
            this.buttonAddLiquidityFilter.Size = new System.Drawing.Size(97, 23);
            this.buttonAddLiquidityFilter.TabIndex = 19;
            this.buttonAddLiquidityFilter.Text = "Add condition";
            this.buttonAddLiquidityFilter.Click += new System.EventHandler(this.buttonAddLiquidityFilter_Click);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.label21);
            this.tabPage9.Controls.Add(this.label22);
            this.tabPage9.Controls.Add(this.label23);
            this.tabPage9.Controls.Add(this.textBoxRatingUpperBound);
            this.tabPage9.Controls.Add(this.textBoxRatingLowerBound);
            this.tabPage9.Controls.Add(this.buttonAddRatingFilter);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Size = new System.Drawing.Size(642, 326);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "Concensus Rating";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(160, 13);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(13, 13);
            this.label21.TabIndex = 23;
            this.label21.Text = "<";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(109, 13);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(38, 13);
            this.label22.TabIndex = 22;
            this.label22.Text = "Rating";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(90, 13);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(13, 13);
            this.label23.TabIndex = 21;
            this.label23.Text = "<";
            // 
            // textBoxRatingUpperBound
            // 
            this.textBoxRatingUpperBound.Location = new System.Drawing.Point(187, 10);
            this.textBoxRatingUpperBound.Name = "textBoxRatingUpperBound";
            this.textBoxRatingUpperBound.Size = new System.Drawing.Size(49, 20);
            this.textBoxRatingUpperBound.TabIndex = 6;
            // 
            // textBoxRatingLowerBound
            // 
            this.textBoxRatingLowerBound.Location = new System.Drawing.Point(13, 10);
            this.textBoxRatingLowerBound.Name = "textBoxRatingLowerBound";
            this.textBoxRatingLowerBound.Size = new System.Drawing.Size(58, 20);
            this.textBoxRatingLowerBound.TabIndex = 5;
            // 
            // buttonAddRatingFilter
            // 
            this.buttonAddRatingFilter.Location = new System.Drawing.Point(539, 184);
            this.buttonAddRatingFilter.Name = "buttonAddRatingFilter";
            this.buttonAddRatingFilter.Size = new System.Drawing.Size(100, 24);
            this.buttonAddRatingFilter.TabIndex = 2;
            this.buttonAddRatingFilter.Text = "Add condition";
            this.buttonAddRatingFilter.UseVisualStyleBackColor = true;
            this.buttonAddRatingFilter.Click += new System.EventHandler(this.buttonAddRatingFilter_Click);
            // 
            // dataGridViewConditions
            // 
            this.dataGridViewConditions.AllowUserToAddRows = false;
            this.dataGridViewConditions.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewConditions.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IncludeExcludeColumn,
            this.CriteriumColumn,
            this.ValueColumn,
            this.DeleteColumn});
            this.dataGridViewConditions.CorrelationDataTable = null;
            this.dataGridViewConditions.DataComplete = "OK";
            this.dataGridViewConditions.EmphasisColor = System.Drawing.Color.Red;
            this.dataGridViewConditions.EmphasizedCount = -2147483648;
            this.dataGridViewConditions.GroupIndexColumn = -2147483648;
            this.dataGridViewConditions.GroupList = ((System.Collections.Generic.List<System.Collections.Generic.List<int>>)(resources.GetObject("dataGridViewConditions.GroupList")));
            this.dataGridViewConditions.HistoricalDataIncompleteColumn = -2147483648;
            this.dataGridViewConditions.IncompleteColor = System.Drawing.Color.Red;
            this.dataGridViewConditions.IsCustomGroup = false;
            this.dataGridViewConditions.IsPaintable = false;
            this.dataGridViewConditions.Location = new System.Drawing.Point(12, 405);
            this.dataGridViewConditions.Margin = new System.Windows.Forms.Padding(0);
            this.dataGridViewConditions.MissingColor = System.Drawing.Color.Red;
            this.dataGridViewConditions.MissingData = "#N/A Sec";
            this.dataGridViewConditions.MissingDataReferenceColumn = -2147483648;
            this.dataGridViewConditions.Name = "dataGridViewConditions";
            this.dataGridViewConditions.RowHeadersVisible = false;
            this.dataGridViewConditions.Size = new System.Drawing.Size(516, 189);
            this.dataGridViewConditions.TabIndex = 3;
            this.dataGridViewConditions.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewConditions_CellContentClick);
            // 
            // IncludeExcludeColumn
            // 
            this.IncludeExcludeColumn.DataPropertyName = "IncludeExclude";
            this.IncludeExcludeColumn.HeaderText = "Include/Exclude";
            this.IncludeExcludeColumn.Items.AddRange(new object[] {
            "Include",
            "Exclude"});
            this.IncludeExcludeColumn.Name = "IncludeExcludeColumn";
            this.IncludeExcludeColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.IncludeExcludeColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // CriteriumColumn
            // 
            this.CriteriumColumn.HeaderText = "Criterium";
            this.CriteriumColumn.Name = "CriteriumColumn";
            this.CriteriumColumn.ReadOnly = true;
            // 
            // ValueColumn
            // 
            this.ValueColumn.HeaderText = "Value";
            this.ValueColumn.Name = "ValueColumn";
            this.ValueColumn.ReadOnly = true;
            this.ValueColumn.Width = 200;
            // 
            // DeleteColumn
            // 
            this.DeleteColumn.HeaderText = "Delete";
            this.DeleteColumn.Name = "DeleteColumn";
            this.DeleteColumn.Text = "Delete";
            this.DeleteColumn.UseColumnTextForButtonValue = true;
            // 
            // OptimizerFilters
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 627);
            this.Controls.Add(this.dataGridViewConditions);
            this.Controls.Add(this.groupBoxFilters);
            this.Controls.Add(this.buttonApplyFilters);
            this.Name = "OptimizerFilters";
            this.Text = "Conditional Filters";
            this.groupBoxFilters.ResumeLayout(false);
            this.groupBoxFilters.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.tabPage8.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewConditions)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button buttonApplyFilters;
        private System.Windows.Forms.GroupBox groupBoxFilters;
        private StructuringControls.ExcelDataGridView dataGridViewConditions;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TreeView treeViewSector;
        private System.Windows.Forms.CheckedListBox checkedListBoxCurrencies;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button buttonAddVolFilter;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.Button buttonAddFwdFilter;
        private System.Windows.Forms.TabPage tabPage8;
        private System.Windows.Forms.Button buttonAddLiquidityFilter;
        private System.Windows.Forms.TabPage tabPage9;
        private System.Windows.Forms.Button buttonAddRatingFilter;
        private System.Windows.Forms.TextBox textBoxVolUpperBound;
        private System.Windows.Forms.TextBox textBoxVolLowerBound;
        private System.Windows.Forms.TextBox textBoxFwdUpperBound;
        private System.Windows.Forms.TextBox textBoxFwdLowerBound;
        private System.Windows.Forms.TextBox textBoxLiquidityUpperBound;
        private System.Windows.Forms.TextBox textBoxLiquidityLowerBound;
        private System.Windows.Forms.TextBox textBoxRatingUpperBound;
        private System.Windows.Forms.TextBox textBoxRatingLowerBound;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridViewComboBoxColumn IncludeExcludeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn CriteriumColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn ValueColumn;
        private System.Windows.Forms.DataGridViewButtonColumn DeleteColumn;
        private CheckedListBox checkedListBoxCountries;
        private EventHandler treeViewSectors_TreeNodeCheckChanged;
    }
}