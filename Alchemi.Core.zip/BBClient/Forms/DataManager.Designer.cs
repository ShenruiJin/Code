﻿using RemotingInterfaces;
namespace BBClient
{
    partial class DataManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DataManager));
			this._groupBoxCurrencies = new System.Windows.Forms.GroupBox();
			this._dataGridViewCurrencies = new System.Windows.Forms.DataGridView();
			this.valueDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.currenciesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.cCDataSet = new CCDataSet();
			this._groupBoxIndices = new System.Windows.Forms.GroupBox();
			this._dataGridViewIndices = new System.Windows.Forms.DataGridView();
			this.valueDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.indicesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this._buttonCancel = new System.Windows.Forms.Button();
			this._groupBoxMaturities = new System.Windows.Forms.GroupBox();
			this._dataGridViewMaturities = new System.Windows.Forms.DataGridView();
			this.nameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.valueDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.maturitiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this._buttonAccept = new System.Windows.Forms.Button();
			this._groupBoxPreviousClose = new System.Windows.Forms.GroupBox();
			this._dataGridViewUsePrevious = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.asiansBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this._groupBoxCommodities = new System.Windows.Forms.GroupBox();
			this._dataGridViewCommodities = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.commoditiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.Security = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.sophisSecuritiesBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this._dataGridViewDescriptiveFields = new System.Windows.Forms.DataGridView();
			this.fieldDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.typeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.helpDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.bbgDescriptiveFieldsBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.dataGridView3 = new StructuringControls.CopyPasteGridView();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.regressionBindingSource = new System.Windows.Forms.BindingSource(this.components);
			this.groupBox3 = new System.Windows.Forms.GroupBox();
			this.dataGridView2 = new System.Windows.Forms.DataGridView();
			this.forexDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.factorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.forexFactorsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.currenciesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter();
            this.indicesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.IndicesTableAdapter();
            this.maturitiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.MaturitiesTableAdapter();
            this.asiansTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.AsiansTableAdapter();
            this.commoditiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.CommoditiesTableAdapter();
            this.bbgDescriptiveFieldsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter();
            this.sophisSecuritiesTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter();
            this.forexFactorsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.ForexFactorsTableAdapter();
            this.regressionsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.RegressionsTableAdapter();
			this._groupBoxCurrencies.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewCurrencies)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
			this._groupBoxIndices.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewIndices)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.indicesBindingSource)).BeginInit();
			this._groupBoxMaturities.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewMaturities)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.maturitiesBindingSource)).BeginInit();
			this._groupBoxPreviousClose.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewUsePrevious)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.asiansBindingSource)).BeginInit();
			this._groupBoxCommodities.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewCommodities)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.commoditiesBindingSource)).BeginInit();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).BeginInit();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewDescriptiveFields)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.bbgDescriptiveFieldsBindingSource)).BeginInit();
			this.tabPage3.SuspendLayout();
			this.groupBox4.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.regressionBindingSource)).BeginInit();
			this.groupBox3.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.forexFactorsBindingSource)).BeginInit();
			this.SuspendLayout();
			// 
			// _groupBoxCurrencies
			// 
			this._groupBoxCurrencies.Controls.Add(this._dataGridViewCurrencies);
			this._groupBoxCurrencies.Location = new System.Drawing.Point(6, 15);
			this._groupBoxCurrencies.Name = "_groupBoxCurrencies";
			this._groupBoxCurrencies.Size = new System.Drawing.Size(126, 259);
			this._groupBoxCurrencies.TabIndex = 0;
			this._groupBoxCurrencies.TabStop = false;
			this._groupBoxCurrencies.Text = "Currencies";
			// 
			// _dataGridViewCurrencies
			// 
			this._dataGridViewCurrencies.AutoGenerateColumns = false;
			this._dataGridViewCurrencies.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewCurrencies.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.valueDataGridViewTextBoxColumn});
			this._dataGridViewCurrencies.DataSource = this.currenciesBindingSource;
			this._dataGridViewCurrencies.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewCurrencies.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewCurrencies.Name = "_dataGridViewCurrencies";
			this._dataGridViewCurrencies.Size = new System.Drawing.Size(120, 240);
			this._dataGridViewCurrencies.TabIndex = 0;
			// 
			// valueDataGridViewTextBoxColumn
			// 
			this.valueDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.valueDataGridViewTextBoxColumn.DataPropertyName = "Value";
			this.valueDataGridViewTextBoxColumn.HeaderText = "Value";
			this.valueDataGridViewTextBoxColumn.Name = "valueDataGridViewTextBoxColumn";
			// 
			// currenciesBindingSource
			// 
			this.currenciesBindingSource.DataMember = "Currencies";
			this.currenciesBindingSource.DataSource = this.cCDataSet;
			// 
			// cCDataSet
			// 
			this.cCDataSet.DataSetName = "CCDataSet";
			this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
			// 
			// _groupBoxIndices
			// 
			this._groupBoxIndices.Controls.Add(this._dataGridViewIndices);
			this._groupBoxIndices.Location = new System.Drawing.Point(138, 15);
			this._groupBoxIndices.Name = "_groupBoxIndices";
			this._groupBoxIndices.Size = new System.Drawing.Size(152, 259);
			this._groupBoxIndices.TabIndex = 1;
			this._groupBoxIndices.TabStop = false;
			this._groupBoxIndices.Text = "Indices";
			// 
			// _dataGridViewIndices
			// 
			this._dataGridViewIndices.AutoGenerateColumns = false;
			this._dataGridViewIndices.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewIndices.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.valueDataGridViewTextBoxColumn1});
			this._dataGridViewIndices.DataSource = this.indicesBindingSource;
			this._dataGridViewIndices.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewIndices.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewIndices.Name = "_dataGridViewIndices";
			this._dataGridViewIndices.Size = new System.Drawing.Size(146, 240);
			this._dataGridViewIndices.TabIndex = 1;
			// 
			// valueDataGridViewTextBoxColumn1
			// 
			this.valueDataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.valueDataGridViewTextBoxColumn1.DataPropertyName = "Value";
			this.valueDataGridViewTextBoxColumn1.HeaderText = "Value";
			this.valueDataGridViewTextBoxColumn1.Name = "valueDataGridViewTextBoxColumn1";
			// 
			// indicesBindingSource
			// 
			this.indicesBindingSource.DataMember = "Indices";
			this.indicesBindingSource.DataSource = this.cCDataSet;
			// 
			// _buttonCancel
			// 
			this._buttonCancel.Location = new System.Drawing.Point(371, 579);
			this._buttonCancel.Name = "_buttonCancel";
			this._buttonCancel.Size = new System.Drawing.Size(89, 23);
			this._buttonCancel.TabIndex = 2;
			this._buttonCancel.Text = "Cancel";
			this._buttonCancel.UseVisualStyleBackColor = true;
			this._buttonCancel.Click += new System.EventHandler(this._buttonClose_Click);
			// 
			// _groupBoxMaturities
			// 
			this._groupBoxMaturities.Controls.Add(this._dataGridViewMaturities);
			this._groupBoxMaturities.Location = new System.Drawing.Point(9, 285);
			this._groupBoxMaturities.Name = "_groupBoxMaturities";
			this._groupBoxMaturities.Size = new System.Drawing.Size(219, 259);
			this._groupBoxMaturities.TabIndex = 3;
			this._groupBoxMaturities.TabStop = false;
			this._groupBoxMaturities.Text = "Maturities";
			// 
			// _dataGridViewMaturities
			// 
			this._dataGridViewMaturities.AutoGenerateColumns = false;
			this._dataGridViewMaturities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewMaturities.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.nameDataGridViewTextBoxColumn,
            this.valueDataGridViewTextBoxColumn2});
			this._dataGridViewMaturities.DataSource = this.maturitiesBindingSource;
			this._dataGridViewMaturities.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewMaturities.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewMaturities.Name = "_dataGridViewMaturities";
			this._dataGridViewMaturities.Size = new System.Drawing.Size(213, 240);
			this._dataGridViewMaturities.TabIndex = 1;
			// 
			// nameDataGridViewTextBoxColumn
			// 
			this.nameDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.nameDataGridViewTextBoxColumn.DataPropertyName = "Name";
			this.nameDataGridViewTextBoxColumn.HeaderText = "Name";
			this.nameDataGridViewTextBoxColumn.Name = "nameDataGridViewTextBoxColumn";
			// 
			// valueDataGridViewTextBoxColumn2
			// 
			this.valueDataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.valueDataGridViewTextBoxColumn2.DataPropertyName = "Value";
			this.valueDataGridViewTextBoxColumn2.HeaderText = "Value";
			this.valueDataGridViewTextBoxColumn2.Name = "valueDataGridViewTextBoxColumn2";
			// 
			// maturitiesBindingSource
			// 
			this.maturitiesBindingSource.DataMember = "Maturities";
			this.maturitiesBindingSource.DataSource = this.cCDataSet;
			// 
			// _buttonAccept
			// 
			this._buttonAccept.Location = new System.Drawing.Point(276, 579);
			this._buttonAccept.Name = "_buttonAccept";
			this._buttonAccept.Size = new System.Drawing.Size(89, 23);
			this._buttonAccept.TabIndex = 4;
			this._buttonAccept.Text = "Accept";
			this._buttonAccept.UseVisualStyleBackColor = true;
			this._buttonAccept.Click += new System.EventHandler(this._buttonAccept_Click);
			// 
			// _groupBoxPreviousClose
			// 
			this._groupBoxPreviousClose.Controls.Add(this._dataGridViewUsePrevious);
			this._groupBoxPreviousClose.Location = new System.Drawing.Point(234, 285);
			this._groupBoxPreviousClose.Name = "_groupBoxPreviousClose";
			this._groupBoxPreviousClose.Size = new System.Drawing.Size(209, 259);
			this._groupBoxPreviousClose.TabIndex = 4;
			this._groupBoxPreviousClose.TabStop = false;
			this._groupBoxPreviousClose.Text = "Previous close if containing ...";
			// 
			// _dataGridViewUsePrevious
			// 
			this._dataGridViewUsePrevious.AutoGenerateColumns = false;
			this._dataGridViewUsePrevious.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewUsePrevious.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn2});
			this._dataGridViewUsePrevious.DataSource = this.asiansBindingSource;
			this._dataGridViewUsePrevious.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewUsePrevious.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewUsePrevious.Name = "_dataGridViewUsePrevious";
			this._dataGridViewUsePrevious.Size = new System.Drawing.Size(203, 240);
			this._dataGridViewUsePrevious.TabIndex = 1;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn2.DataPropertyName = "Value";
			this.dataGridViewTextBoxColumn2.HeaderText = "Value";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			// 
			// asiansBindingSource
			// 
			this.asiansBindingSource.DataMember = "Asians";
			this.asiansBindingSource.DataSource = this.cCDataSet;
			// 
			// _groupBoxCommodities
			// 
			this._groupBoxCommodities.Controls.Add(this._dataGridViewCommodities);
			this._groupBoxCommodities.Location = new System.Drawing.Point(296, 15);
			this._groupBoxCommodities.Name = "_groupBoxCommodities";
			this._groupBoxCommodities.Size = new System.Drawing.Size(150, 259);
			this._groupBoxCommodities.TabIndex = 5;
			this._groupBoxCommodities.TabStop = false;
			this._groupBoxCommodities.Text = "Commodities";
			// 
			// _dataGridViewCommodities
			// 
			this._dataGridViewCommodities.AutoGenerateColumns = false;
			this._dataGridViewCommodities.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewCommodities.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
			this._dataGridViewCommodities.DataSource = this.commoditiesBindingSource;
			this._dataGridViewCommodities.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewCommodities.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewCommodities.Name = "_dataGridViewCommodities";
			this._dataGridViewCommodities.Size = new System.Drawing.Size(144, 240);
			this._dataGridViewCommodities.TabIndex = 1;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn1.DataPropertyName = "Value";
			this.dataGridViewTextBoxColumn1.HeaderText = "Value";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			// 
			// commoditiesBindingSource
			// 
			this.commoditiesBindingSource.DataMember = "Commodities";
			this.commoditiesBindingSource.DataSource = this.cCDataSet;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Controls.Add(this.tabPage3);
			this.tabControl1.Location = new System.Drawing.Point(2, 1);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(462, 572);
			this.tabControl1.TabIndex = 6;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this._groupBoxCurrencies);
			this.tabPage1.Controls.Add(this._groupBoxCommodities);
			this.tabPage1.Controls.Add(this._groupBoxIndices);
			this.tabPage1.Controls.Add(this._groupBoxPreviousClose);
			this.tabPage1.Controls.Add(this._groupBoxMaturities);
			this.tabPage1.Location = new System.Drawing.Point(4, 22);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(454, 546);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "Market data";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.groupBox2);
			this.tabPage2.Controls.Add(this.groupBox1);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(454, 546);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Basket creation";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.dataGridView1);
			this.groupBox2.Location = new System.Drawing.Point(7, 265);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(219, 275);
			this.groupBox2.TabIndex = 7;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Sophis stocks";
			// 
			// dataGridView1
			// 
			this.dataGridView1.AutoGenerateColumns = false;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Security,
            this.dataGridViewTextBoxColumn5});
			this.dataGridView1.DataSource = this.sophisSecuritiesBindingSource;
			this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView1.Location = new System.Drawing.Point(3, 16);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.Size = new System.Drawing.Size(213, 256);
			this.dataGridView1.TabIndex = 2;
			// 
			// Security
			// 
			this.Security.DataPropertyName = "Security";
			this.Security.HeaderText = "Security";
			this.Security.Name = "Security";
			// 
			// dataGridViewTextBoxColumn5
			// 
			this.dataGridViewTextBoxColumn5.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn5.DataPropertyName = "Type";
			this.dataGridViewTextBoxColumn5.HeaderText = "Type";
			this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
			// 
			// sophisSecuritiesBindingSource
			// 
			this.sophisSecuritiesBindingSource.DataMember = "SophisSecurities";
			this.sophisSecuritiesBindingSource.DataSource = this.cCDataSet;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this._dataGridViewDescriptiveFields);
			this.groupBox1.Location = new System.Drawing.Point(7, 9);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(440, 250);
			this.groupBox1.TabIndex = 6;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Descriptive fields";
			// 
			// _dataGridViewDescriptiveFields
			// 
			this._dataGridViewDescriptiveFields.AutoGenerateColumns = false;
			this._dataGridViewDescriptiveFields.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this._dataGridViewDescriptiveFields.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.fieldDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.typeDataGridViewTextBoxColumn,
            this.helpDataGridViewTextBoxColumn});
			this._dataGridViewDescriptiveFields.DataSource = this.bbgDescriptiveFieldsBindingSource;
			this._dataGridViewDescriptiveFields.Dock = System.Windows.Forms.DockStyle.Fill;
			this._dataGridViewDescriptiveFields.Location = new System.Drawing.Point(3, 16);
			this._dataGridViewDescriptiveFields.Name = "_dataGridViewDescriptiveFields";
			this._dataGridViewDescriptiveFields.Size = new System.Drawing.Size(434, 231);
			this._dataGridViewDescriptiveFields.TabIndex = 2;
			// 
			// fieldDataGridViewTextBoxColumn
			// 
			this.fieldDataGridViewTextBoxColumn.DataPropertyName = "Field";
			this.fieldDataGridViewTextBoxColumn.HeaderText = "Field";
			this.fieldDataGridViewTextBoxColumn.Name = "fieldDataGridViewTextBoxColumn";
			// 
			// descriptionDataGridViewTextBoxColumn
			// 
			this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
			this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
			this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
			// 
			// typeDataGridViewTextBoxColumn
			// 
			this.typeDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells;
			this.typeDataGridViewTextBoxColumn.DataPropertyName = "Type";
			this.typeDataGridViewTextBoxColumn.HeaderText = "Type";
			this.typeDataGridViewTextBoxColumn.Name = "typeDataGridViewTextBoxColumn";
			this.typeDataGridViewTextBoxColumn.Width = 56;
			// 
			// helpDataGridViewTextBoxColumn
			// 
			this.helpDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.helpDataGridViewTextBoxColumn.DataPropertyName = "Help";
			this.helpDataGridViewTextBoxColumn.HeaderText = "Help";
			this.helpDataGridViewTextBoxColumn.Name = "helpDataGridViewTextBoxColumn";
			// 
			// bbgDescriptiveFieldsBindingSource
			// 
			this.bbgDescriptiveFieldsBindingSource.DataMember = "BbgDescriptiveFields";
			this.bbgDescriptiveFieldsBindingSource.DataSource = this.cCDataSet;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.groupBox4);
			this.tabPage3.Controls.Add(this.groupBox3);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Size = new System.Drawing.Size(454, 546);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Additional Bbg data";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.dataGridView3);
			this.groupBox4.Location = new System.Drawing.Point(213, 6);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(234, 527);
			this.groupBox4.TabIndex = 8;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Regression factors";
			// 
			// dataGridView3
			// 
			this.dataGridView3.AutoGenerateColumns = false;
			this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4});
			this.dataGridView3.DataSource = this.regressionBindingSource;
			this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView3.Location = new System.Drawing.Point(3, 16);
			this.dataGridView3.Name = "dataGridView3";
			this.dataGridView3.Size = new System.Drawing.Size(228, 508);
			this.dataGridView3.TabIndex = 2;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn3.DataPropertyName = "Value";
			this.dataGridViewTextBoxColumn3.HeaderText = "Ticker";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			// 
			// dataGridViewTextBoxColumn4
			// 
			this.dataGridViewTextBoxColumn4.DataPropertyName = "Factor";
			this.dataGridViewTextBoxColumn4.HeaderText = "Factor";
			this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
			// 
			// regressionBindingSource
			// 
			this.regressionBindingSource.DataMember = "Regressions";
			this.regressionBindingSource.DataSource = this.cCDataSet;
			// 
			// groupBox3
			// 
			this.groupBox3.Controls.Add(this.dataGridView2);
			this.groupBox3.Location = new System.Drawing.Point(6, 6);
			this.groupBox3.Name = "groupBox3";
			this.groupBox3.Size = new System.Drawing.Size(191, 527);
			this.groupBox3.TabIndex = 7;
			this.groupBox3.TabStop = false;
			this.groupBox3.Text = "Descriptive fields";
			// 
			// dataGridView2
			// 
			this.dataGridView2.AutoGenerateColumns = false;
			this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
			this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.forexDataGridViewTextBoxColumn,
            this.factorDataGridViewTextBoxColumn});
			this.dataGridView2.DataSource = this.forexFactorsBindingSource;
			this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView2.Location = new System.Drawing.Point(3, 16);
			this.dataGridView2.Name = "dataGridView2";
			this.dataGridView2.Size = new System.Drawing.Size(185, 508);
			this.dataGridView2.TabIndex = 2;
			// 
			// forexDataGridViewTextBoxColumn
			// 
			this.forexDataGridViewTextBoxColumn.DataPropertyName = "Forex";
			this.forexDataGridViewTextBoxColumn.HeaderText = "Forex";
			this.forexDataGridViewTextBoxColumn.Name = "forexDataGridViewTextBoxColumn";
			this.forexDataGridViewTextBoxColumn.Width = 60;
			// 
			// factorDataGridViewTextBoxColumn
			// 
			this.factorDataGridViewTextBoxColumn.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.factorDataGridViewTextBoxColumn.DataPropertyName = "Factor";
			this.factorDataGridViewTextBoxColumn.HeaderText = "Factor";
			this.factorDataGridViewTextBoxColumn.Name = "factorDataGridViewTextBoxColumn";
			// 
			// forexFactorsBindingSource
			// 
			this.forexFactorsBindingSource.DataMember = "ForexFactors";
			this.forexFactorsBindingSource.DataSource = this.cCDataSet;
			// 
			// currenciesTableAdapter
			// 
			this.currenciesTableAdapter.ClearBeforeFill = true;
			// 
			// indicesTableAdapter
			// 
			this.indicesTableAdapter.ClearBeforeFill = true;
			// 
			// maturitiesTableAdapter
			// 
			this.maturitiesTableAdapter.ClearBeforeFill = true;
			// 
			// asiansTableAdapter
			// 
			this.asiansTableAdapter.ClearBeforeFill = true;
			// 
			// commoditiesTableAdapter
			// 
			this.commoditiesTableAdapter.ClearBeforeFill = true;
			// 
			// bbgDescriptiveFieldsTableAdapter
			// 
			this.bbgDescriptiveFieldsTableAdapter.ClearBeforeFill = true;
			// 
			// sophisSecuritiesTableAdapter
			// 
			this.sophisSecuritiesTableAdapter.ClearBeforeFill = true;
			// 
			// forexFactorsTableAdapter
			// 
			this.forexFactorsTableAdapter.ClearBeforeFill = true;
			// 
			// regressionsTableAdapter
			// 
			this.regressionsTableAdapter.ClearBeforeFill = true;
			// 
			// DataManager
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(465, 612);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this._buttonAccept);
			this.Controls.Add(this._buttonCancel);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "DataManager";
			this.Text = "Data Management";
			this.Load += new System.EventHandler(this.DataManager_Load);
			this.Layout += new System.Windows.Forms.LayoutEventHandler(this.DataManager_Layout);
			this._groupBoxCurrencies.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewCurrencies)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.currenciesBindingSource)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
			this._groupBoxIndices.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewIndices)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.indicesBindingSource)).EndInit();
			this._groupBoxMaturities.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewMaturities)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.maturitiesBindingSource)).EndInit();
			this._groupBoxPreviousClose.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewUsePrevious)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.asiansBindingSource)).EndInit();
			this._groupBoxCommodities.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewCommodities)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.commoditiesBindingSource)).EndInit();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.groupBox2.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.sophisSecuritiesBindingSource)).EndInit();
			this.groupBox1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this._dataGridViewDescriptiveFields)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.bbgDescriptiveFieldsBindingSource)).EndInit();
			this.tabPage3.ResumeLayout(false);
			this.groupBox4.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.regressionBindingSource)).EndInit();
			this.groupBox3.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.forexFactorsBindingSource)).EndInit();
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox _groupBoxCurrencies;
        private System.Windows.Forms.GroupBox _groupBoxIndices;
        private System.Windows.Forms.Button _buttonCancel;
        private System.Windows.Forms.GroupBox _groupBoxMaturities;
        private System.Windows.Forms.DataGridView _dataGridViewCurrencies;
        private System.Windows.Forms.DataGridView _dataGridViewIndices;
        private System.Windows.Forms.DataGridView _dataGridViewMaturities;
        private System.Windows.Forms.Button _buttonAccept;
        private CCDataSet cCDataSet;
        private System.Windows.Forms.BindingSource currenciesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.CurrenciesTableAdapter currenciesTableAdapter;
        private System.Windows.Forms.BindingSource indicesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.IndicesTableAdapter indicesTableAdapter;
        private System.Windows.Forms.BindingSource maturitiesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.MaturitiesTableAdapter maturitiesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn valueDataGridViewTextBoxColumn2;
        private System.Windows.Forms.GroupBox _groupBoxPreviousClose;
        private System.Windows.Forms.DataGridView _dataGridViewUsePrevious;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.BindingSource asiansBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.AsiansTableAdapter asiansTableAdapter;
        private System.Windows.Forms.GroupBox _groupBoxCommodities;
        private System.Windows.Forms.DataGridView _dataGridViewCommodities;
        private System.Windows.Forms.BindingSource commoditiesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.CommoditiesTableAdapter commoditiesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.DataGridView _dataGridViewDescriptiveFields;
        private System.Windows.Forms.BindingSource bbgDescriptiveFieldsBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter bbgDescriptiveFieldsTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn fieldDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn typeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn helpDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource sophisSecuritiesBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.SophisSecuritiesTableAdapter sophisSecuritiesTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn Security;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingSource forexFactorsBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.ForexFactorsTableAdapter forexFactorsTableAdapter;
		private System.Windows.Forms.GroupBox groupBox4;
		private StructuringControls.CopyPasteGridView dataGridView3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
		private System.Windows.Forms.BindingSource regressionBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.RegressionsTableAdapter regressionsTableAdapter;
		private System.Windows.Forms.DataGridViewTextBoxColumn forexDataGridViewTextBoxColumn;
		private System.Windows.Forms.DataGridViewTextBoxColumn factorDataGridViewTextBoxColumn;
    }
}