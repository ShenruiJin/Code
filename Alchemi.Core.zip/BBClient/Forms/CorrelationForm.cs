﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using BbgProcesser;
using Estimators;
using StructuringControls;
using RemotingInterfaces;

namespace BBClient
{
    public partial class CorrelationForm : BBForm
    {
		public CorrelationForm()
        {
            InitializeComponent();
		}

		public void InitializeCorrelationForm()
		{
			if (!_isInit)
			{
				// Retrieve data from the DB
				RetrieveData();

				#region Init DB
				// DB
				//System.IO.TextReader tr = new System.IO.StreamReader("C:\\listeSSJacents.txt");
				//string str = tr.ReadToEnd();
				//tr.Close();
				//foreach (string s in str.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
				//{
				//    string eq = s.Remove(s.IndexOf(" Equity"));
				//    eq = eq.Replace("VCL ", String.Empty);
				//    DataRow row = cCDataSet.SophisSecurities.NewRow();
				//    row[1] = eq; row[2] = "Equity";
				//    cCDataSet.SophisSecurities.Rows.Add(row);
				//}
				//List<string> curList = new List<string>();
				//foreach (DataRow rowInd in cCDataSet.Currencies.Rows)
				//{
				//    curList.Add(rowInd[1].ToString());
				//}
				//List<string> curList2 = new List<string>(curList);
				//Dictionary<string, double> curClose = new Dictionary<string, double>();
				//foreach (string s1 in curList)
				//    foreach (string s2 in curList2)
				//        if (s1 != s2)
				//            curClose.Add(s1 + s2, 0);
				//BbgQuery query = new BbgQuery();
				//query.IsStatic = false;
				//foreach (string key in curClose.Keys)
				//    query.SecuritiesList.Add(key);
				//query.FieldsList.Add("LAST_PRICE");
				//query.StartDate = DateTime.Today.AddDays(-2);
				//query.EndDate = DateTime.Today.AddDays(-1);
				//DataSet ds = Remoter.Send(query);
				//foreach (DataRow row in ds.Tables[1].Rows)
				//{
				//    string key = row["Security"].ToString().Remove(row["Security"].ToString().IndexOf(" "));
				//    double price = Convert.ToDouble(row["LAST_PRICE"].ToString());
				//    curClose[key] = price;
				//}
				//Dictionary<string, double> pbDic = new Dictionary<string, double>();
				//List<string> nanCur = new List<string>();
				//foreach (string s1 in curList)
				//    foreach (string s2 in curList2)
				//    {
				//        if (s1 != s2)
				//        {
				//            double price1 = curClose[s1 + s2];
				//            double price2 = curClose[s2 + s1];
				//            if (Math.Abs(price1 * price2 - 1) > 0.01)
				//            {
				//                if (!pbDic.ContainsKey(s1 + s2) && !pbDic.ContainsKey(s2 + s1))
				//                    pbDic.Add(s1 + s2, price1 * price2);
				//            }
				//            if (double.IsNaN(price1))
				//            {
				//                nanCur.Add(s1 + s2);
				//            }
				//        }
				//    }
				//System.IO.TextWriter tr = new System.IO.StreamWriter("C:\\nonpar.txt");
				//foreach (string key in pbDic.Keys)
				//{
				//    tr.WriteLine(key + ";" + pbDic[key]);

				//    DataRow row = cCDataSet.ForexFactors.NewRow();
				//    row[1] = key; row[2] = (int)Math.Round(pbDic[key]);
				//    cCDataSet.ForexFactors.Rows.Add(row);
				//}
				//tr.Close();
				//tr = new System.IO.StreamWriter("C:\\nancur.txt");
				//foreach (string key in nanCur)
				//    tr.WriteLine(key);
				//tr.Close();
				//sophisSecuritiesTableAdapter.Update(cCDataSet.SophisSecurities);
				//forexFactorsTableAdapter.Update(cCDataSet.ForexFactors);

				/*System.IO.TextReader tr = new System.IO.StreamReader("C:\\listeSSJacents.txt");
				List<string> missingSecurities = new List<string>();
				string str = tr.ReadToEnd();
				tr.Close();
				List<string> allsecs = new List<string>();
				foreach (DataRow row in cCDataSet.SophisSecurities.Rows)
				{
					allsecs.Add(row["Security"].ToString());
				}
				foreach (string s in str.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries))
				{
					string eq = s.Remove(s.IndexOf(" Equity"));
					eq = eq.Replace("VCL ", String.Empty);
					if (!allsecs.Contains(eq))
					{
						missingSecurities.Add(eq);
					}
				}
				foreach (string msec in missingSecurities)
				{
					DataRow row = cCDataSet.SophisSecurities.NewRow();
					row[1] = msec; row[2] = "Equity";
					cCDataSet.SophisSecurities.Rows.Add(row);
				}
				sophisSecuritiesTableAdapter.Update(cCDataSet.SophisSecurities);*/
				#endregion

				_isInit = true;
			}

			// Init custom GUI
			InitGui();
		}

		public void InitializeCorrelationFormFromEvent(List<string> stockList, string currency, double maturity)
		{
			InitializeCorrelationForm();

			// Set default parameters in case
			if (currency != String.Empty)
			{            
				// Init quantos
				for (int counterQuanto = 0; counterQuanto < cCDataSet.Currencies.Rows.Count; counterQuanto++)
				{
					if (Convert.ToString(cCDataSet.Currencies.Rows[counterQuanto][_colValue]) == currency)
					{
						_comboBoxQuanto.SelectedIndex = counterQuanto;
					}
				}
			}

			_requestedStockList = stockList;
			_productMaturity = maturity;
        }

        private void Calculate()
        {
            // Disable data entry
            EnableDataEntry(false);
            _toolStripStatusLabel.Text = "Retrieving data from Bloomberg ...";
            _timer.Start();
			if (!_backgroundWorkerCalculations.IsBusy)
			{
				_backgroundWorkerCalculations.RunWorkerAsync();
			}
        }

        #region Data retrieval and correlations computation
        // Data retrieval running on the background thread
        private KeyValuePair<CorrelFactory, DataSet> LaunchCalculations(BackgroundWorker worker)
        {
            try
            {
                // Add the requested securities
                _securityList = new List<string>();
                for (int counter = 0; counter < this._dataGridViewNonCorrel.Rows.Count; counter++)
                {
                    object sjValue = this._dataGridViewNonCorrel[_colSecurity, counter].Value;
                    if (sjValue != null)
                    {
                        string underlying = sjValue.ToString().ToUpper();
                        if (underlying.Trim() != string.Empty && !_securityList.Contains(underlying))
                        {
                            _securityList.Add(underlying);
                        }
                    }
                }

                // Invoke needs to be used since we're trying to access the main thread from another thread
                RetrieveObject tempDeleg = delegate() { return ((DataRowView)_comboBoxQuanto.Items[_comboBoxQuanto.SelectedIndex])[_colValue]; };
                string quantoCurrency = Convert.ToString(this.Invoke(tempDeleg));

                _correlFactory = new CorrelFactory(_securityList, quantoCurrency,
                    _calcPeriod, _horizonList, true);
                // Default to quanto
                _correlFactory.QuantoType = QuantoType.Quanto;
				_correlFactory.ProductMaturity = _productMaturity;

                KeyValuePair<CorrelFactory, DataSet> returnPair = new KeyValuePair<CorrelFactory, DataSet>(
                    _correlFactory, _correlFactory.StartCorrelComputations());

                // Update datatables
                CheckStaticReply(_correlFactory);

                return returnPair;
            }
            catch (Exception ex)
            {
                ShowMessageBox(ex.Message);
            }
            return new KeyValuePair<CorrelFactory,DataSet>();
        }

        // Correl computation and Ihm update once data retrieval is finished
        private void FinishComputations(RunWorkerCompletedEventArgs e)
        {
            // If data retrieval completed successfully
            if (((KeyValuePair<CorrelFactory, DataSet>)e.Result).Value != null &&
                ((DataSet)((KeyValuePair<CorrelFactory, DataSet>)e.Result).Value).Tables.Count > 0)
            {
                DataSet histoDataDs = ((KeyValuePair<CorrelFactory, DataSet>)e.Result).Value;
                _correlFactory.EndCorrelComputation(histoDataDs, out _perfMatrix, 
                    out _correlationPackMap, out _liquidityMap);

                // Analyse des données
                int maxDays = (int)(_horizonList[_horizonList.Count - 1] * 252);
                int[] listAvailableData = Correlations.GetAvailableData(_perfMatrix, maxDays);
                _nbNonQuantoSecurities = _correlFactory.SecurityList.Count;
                for (int counterSj = 0; counterSj < _nbNonQuantoSecurities; counterSj++)
                {
                    int nbDaysAvailable = listAvailableData[counterSj];
                    double nbYears = (double)nbDaysAvailable / 252;
                    _correlationDataTable.Rows[counterSj][_colAvailableData] = nbDaysAvailable >= maxDays ? "OK" : nbYears.ToString("0.00") + " Y";
                    _correlationDataTable.Rows[counterSj][_colGroupIndex] = 0;
                }
                _dataGridViewNonCorrel.CorrelationDataTable = _correlationDataTable;
            }
            else
            {
                _correlationPackMap = new Dictionary<double, CorrelationPack>();
            }
            // Update Ihm
            this.InitDatagrids(false);
            this.UpdateDataGridRho();

            // Finally, update the main datagridview
            if (_correlationDataTable.Rows.Count > 0)
            {
                _dataGridViewNonCorrel.DataSource = _correlationDataTable;
            }
        }
        #endregion

        #region Datagrid update

        private bool CheckStaticReply(CorrelFactory factory)
        {
            bool noMissingData = true;
            // Copy of the datatable for temporary manipulation
            DataTable tempCorrelationDataTable = _correlationDataTable.Copy();

            // Init rows in the datatable
            tempCorrelationDataTable.Rows.Clear();
            int nbSecurities = _securityList.Count;
            if (nbSecurities != 0)
            {
                try
                {
					// Update the static data columns in the datagrid
                    foreach (SecurityDescription desc in factory.SecurityList)
                    {
                        string security = desc.Security;
                        // Add the security anyway
                        tempCorrelationDataTable.Rows.Add(new object[] { security });

                        string companyDescription = desc.Description;
                        string country = desc.Country;
                        string currency = desc.Quanto;
                        if (companyDescription == _missingData)
                        {
                            noMissingData = false;
                        }
                        tempCorrelationDataTable.Rows[tempCorrelationDataTable.Rows.Count - 1][BbgField.Currency] = currency;
                        tempCorrelationDataTable.Rows[tempCorrelationDataTable.Rows.Count - 1][BbgField.Name] = companyDescription;
                    }

                    // If inferior to the minimum number of rows, fill the remaining with empty values
                    while (tempCorrelationDataTable.Rows.Count < _minRows)
                    {
                        tempCorrelationDataTable.Rows.Add(new object[] { String.Empty });
                    }
                    // Commit the changes
                    _correlationDataTable = tempCorrelationDataTable;
                }
                catch (Exception ex)
                {
                    ShowMessageBox("Error while checking the static reply : " + ex.Message);
                    noMissingData = false;
                }
            }

            // Initialize the custom groups
            for (int groupIndex = 0; groupIndex < _correlationGroups.Count; groupIndex++)
            {
                _correlationGroups[groupIndex].Clear();
            }
            for (int i = 0; i < _nbNonQuantoSecurities; i++)
            {
                _correlationGroups[0].Add(i);
            }
            return noMissingData;
        }

        List<BumpPlot> _activeBumps = null;
        private void UpdateDataGridCorrelsHisto(bool refreshColumns)
        {
            try
            {
                _dataGridViewNonCorrel.DataSource = null;
                double key = _horizonList[_comboBoxCorrelHorizon.SelectedIndex];
                // If we have already retrieved a correlation map
                if (_correlationPackMap.ContainsKey(key))
                {
                    CorrelationPack corPack = _correlationPackMap[key];
                    // Retrieve the provisioned correls
                    List<int> groupIndexList = new List<int>();
                    for (int counterSj = 0; counterSj < _nbNonQuantoSecurities; counterSj++)
                    {
                        groupIndexList.Add(int.Parse(_correlationDataTable.Rows[counterSj][_colGroupIndex].ToString()));
                    }
                    double[,] correlationMatrix = Correlations.GetProvdCorrels(corPack,
                        GetProvisioningType(), _activeBumps, _correlationGroups);
                    double[,] correlationMatrixNoProvs = Correlations.GetProvdCorrels(corPack,
                        ProvisioningType.None, _activeBumps, _correlationGroups);
                    double[] liquidityMatrix = _liquidityMap[key];

                    int nbSecurities = _nbNonQuantoSecurities;

                    if (refreshColumns)
                    {
                        // Delete non static columns in both the datatable and the datagridview to be sure
                        for (int nbColumn = _dataGridViewNonCorrel.ColumnCount - 1; nbColumn >= _nbStaticColumns; nbColumn--)
                        {
                            _correlationDataTable.Columns.Remove(_dataGridViewNonCorrel.Columns[nbColumn].DataPropertyName);
                            _dataGridViewNonCorrel.Columns.Remove(_dataGridViewNonCorrel.Columns[nbColumn]);
                        }

                        // Add a column for each underlying
                        for (int indexAdditionalColumn = 0; indexAdditionalColumn < nbSecurities; indexAdditionalColumn++)
                        {
                            string columnName = _securityList[indexAdditionalColumn];
                            _dataGridViewNonCorrel.Columns.Add(columnName, columnName);
                            _dataGridViewNonCorrel.Columns[indexAdditionalColumn + _nbStaticColumns].DefaultCellStyle.Format = "0.00%";
                            _dataGridViewNonCorrel.Columns[indexAdditionalColumn + _nbStaticColumns].ReadOnly = true;
                            _dataGridViewNonCorrel.Columns[indexAdditionalColumn + _nbStaticColumns].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                            _dataGridViewNonCorrel.Columns[indexAdditionalColumn + _nbStaticColumns].DataPropertyName = columnName;
                            _dataGridViewNonCorrel.Columns[indexAdditionalColumn + _nbStaticColumns].SortMode = DataGridViewColumnSortMode.Programmatic;
                            _correlationDataTable.Columns.Add(columnName, typeof(double));
                        }
                    }

                    if (_floorCB.Checked)
                    {
                        double[,] flooredCorrelationMatrix = new double[nbSecurities, nbSecurities];

                        List<string> udls = _securityList;


                        for (int i = 0; i < nbSecurities; i++)
                        {
                            for (int j = 0; j < nbSecurities; j++)
                            {
                                flooredCorrelationMatrix[i, j] = Math.Max(CaesarApplication.Service.Strategy.MarketDataService.GetCorrelation(_securityList[i],
                                    _securityList[j], key), correlationMatrix[i, j]);
                                if (double.IsNaN(flooredCorrelationMatrix[i, j]))
                                {
                                    flooredCorrelationMatrix[i, j] = correlationMatrix[i, j];
                                }
                            }
                        }
                        correlationMatrix = flooredCorrelationMatrix;
                    }

                    // Databinding avec la datatable
                    string selectedQuanto = Convert.ToString(((DataRowView)_comboBoxQuanto.Items[_comboBoxQuanto.SelectedIndex])[_colValue]);
                    for (int i = 0; i < nbSecurities; i++)
                    {
                        for (int j = 0; j < nbSecurities; j++)
                        {
                            _correlationDataTable.Rows[i][j + _nbStaticColumns] = correlationMatrix[i, j];
                        }

                        // Ajout des quantos
                        string securityQuanto = Convert.ToString(_correlationDataTable.Rows[i][_colCurrency]);
                        // If no quanto (same currency) then set value to 0
                        // For the moment use uppercase conversion : GBP currency in Bbg is in fact returned as "GBp"
                        if (securityQuanto.ToUpper() == selectedQuanto.ToUpper())
                        {
                            _correlationDataTable.Rows[i][_colQuanto] = 0;
                        }
                        else
                        {
                            string forex = securityQuanto + selectedQuanto;
                            // Else retrieve the appropriate correlation from the matrix
                            for (int j = 0; j < _securityList.Count; j++)
                            {
                                if (_securityList[j].ToLower() == forex.ToLower())
                                {
                                    _correlationDataTable.Rows[i][_colQuanto] = correlationMatrixNoProvs[i, j];
                                }
                            }
                        }

                        // Ajout des liquidités
                        _correlationDataTable.Rows[i][_colLiquidity] = liquidityMatrix[i];
                    }
                    
                    // Màj datatable de tri
                    this.SortDataGrid(true);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating the main datagrid : " + ex.Message);
            }
        }

        private void UpdateDataGridRho()
        {
            try
            {
                int currCol = 0;
				foreach (double horizon in _horizonList)
				{
                    if (_correlationPackMap.ContainsKey(horizon))
                    {
                        CorrelationPack corPack = _correlationPackMap[horizon];
                        _dataGridViewRho[currCol, 0].Value = corPack.Rho;
                        _dataGridViewRho[currCol, 1].Value = corPack.Provs;
                        _dataGridViewRho[currCol, 2].Value = corPack.Rho + (1 - corPack.Rho) * corPack.Provs;
                        currCol++;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error while updating the rho datagrid : " + ex.Message);
            }
        }
        #endregion

        #region Database interaction

        private void RetrieveData()
        {
            try
            {
                // TODO: This line of code loads data into the 'cCDataSet.SophisSecurities' table. You can move, or remove it, as needed.
                this.sophisSecuritiesTableAdapter.Fill(this.cCDataSet.SophisSecurities);
                // TODO: This line of code loads data into the 'cCDataSet.Indices' table. You can move, or remove it, as needed.
                this.indicesTableAdapter.Fill(this.cCDataSet.Indices);
                // TODO: This line of code loads data into the 'cCDataSet.ForexFactors' table. You can move, or remove it, as needed.
                this.forexFactorsTableAdapter.Fill(this.cCDataSet.ForexFactors);

                // TODO: This line of code loads data into the 'cCDataSet.Maturities' table. You can move, or remove it, as needed.
                this.maturitiesTableAdapter.Fill(this.cCDataSet.Maturities);
                // TODO: This line of code loads data into the 'cCDataSet.Currencies' table. You can move, or remove it, as needed.
                this.currenciesTableAdapter.Fill(this.cCDataSet.Currencies);

                // Retrieve the list of asian securities from the DB
                _previousDaySecurities = new List<string>();
                RemotingInterfaces.CCDataSetTableAdapters.AsiansTableAdapter asianAdapter = new RemotingInterfaces.CCDataSetTableAdapters.AsiansTableAdapter();
                asianAdapter.Fill(this.cCDataSet.Asians);
                foreach (DataRow row in cCDataSet.Asians.Rows)
                {
                    string asianValue = Convert.ToString(row[_colValue]);
                    if (!_previousDaySecurities.Contains(asianValue))
                    {
                        _previousDaySecurities.Add(asianValue);
                    }
                }
                CorrelFactory.PreviousDaySecurities = _previousDaySecurities;
                // Retrieve the list of forex factors
                foreach (DataRow row in cCDataSet.ForexFactors.Rows)
                {
                    string key = row[1].ToString();
                    if (!CorrelFactory.ForexFactors.ContainsKey(key))
                    {
                        double factor = Convert.ToDouble(row[2].ToString());
                        CorrelFactory.ForexFactors.Add(key, factor);
                    }
                }
            }
            catch (Exception ex)
            {   
				CaesarApplication.Service.Message.MessageService.ShowError(ex);
            }
        }
        #endregion

        #region Gui Helpers and events

        private void _buttonCalculate_Click(object sender, EventArgs e)
        {
            this.Calculate();
        }

        // Init datagrids, comboboxes, ...
        private void InitGui()
        {
            _clientSettingsDlg = new ClientSettings();
            _customBumpPalette = new CustomBumps(this);
            _dataManagerDlg = new DataManager();
            _correlationPackMap = new Dictionary<double, CorrelationPack>();
			_perfMatrix = null;
            _liquidityMap = new Dictionary<double, double[]>();
            _securityList = new List<string>();
            _correlationGroups = new List<List<int>>();
            _calcPeriod = CalculationPeriod.Weekly;
            for (int i = 0; i < 4; i++)
            {
                _correlationGroups.Add(new List<int>());
            }

            // Creation and initialization of the data table
			_dataGridViewNonCorrel.DataSource = null;
            _dataGridViewNonCorrel.RowCount = _minRows;
            _dataGridViewNonCorrel.AutoGenerateColumns = false;
            _dataGridViewNonCorrel.MissingData = _missingData;
            _dataGridViewNonCorrel.MissingDataReferenceColumn = _dataGridViewNonCorrel.Columns[_colCurrency].Index;
            _dataGridViewNonCorrel.HistoricalDataIncompleteColumn = 5;
            _dataGridViewNonCorrel.GroupIndexColumn = 6;
            _correlationDataTable = new DataTable();
            foreach (DataGridViewTextBoxColumn column in _dataGridViewNonCorrel.Columns)
            {
                _correlationDataTable.Columns.Add(column.DataPropertyName);
                if (column.DataPropertyName == _colLiquidity || column.DataPropertyName == _colQuanto)
                {
                    _correlationDataTable.Columns[_correlationDataTable.Columns.Count - 1].DataType = typeof(double);
                }
            }
            _dataGridViewNonCorrel.CorrelationDataTable = _correlationDataTable;
            // Initialize the correl horizons
            _horizonList = new List<double>();
            foreach(DataRow row in cCDataSet.Maturities.Rows)
            {
                _horizonList.Add(Convert.ToDouble(row[_colValue]));
            }

            // Init quantos
            for (int counterQuanto = 0; counterQuanto < cCDataSet.Currencies.Rows.Count; counterQuanto++)
            {
                if (Convert.ToString(cCDataSet.Currencies.Rows[counterQuanto][_colValue]) == _initQuanto)
                {
                    _comboBoxQuanto.SelectedIndex = counterQuanto;
                }
            }

			// Init horizon
			for (int counterHorizon = 0; counterHorizon < cCDataSet.Maturities.Rows.Count; counterHorizon++)
			{
				if (Convert.ToString(cCDataSet.Maturities.Rows[counterHorizon][_colValue]) == "3")
				{
					_comboBoxCorrelHorizon.SelectedIndex = counterHorizon;
				}
			}

            // Focus on the datagridview
            _dataGridViewNonCorrel.Select();
			
            // Branchement évènement sur data management
            _dataManagerDlg.UpdateDBList += new EventHandler(_dataManagerDlg_UpdateDBList);
        }

        private void InitDatagrids(bool refreshRhoColumns)
        {
            // Set the combo boxes to their defaut values
			for (int counterHorizon = 0; counterHorizon < cCDataSet.Maturities.Rows.Count; counterHorizon++)
			{
				if (Convert.ToString(cCDataSet.Maturities.Rows[counterHorizon][_colValue]) == "3")
				{
					_comboBoxCorrelHorizon.SelectedIndex = counterHorizon;
				}
			}
            if (_comboBoxProvs.SelectedIndex != 1)
            {
                // Hack code, vive le développement rapide
                _customBumpPalette.Hide();
                _dataGridViewNonCorrel.IsCustomGroup = false;
                _comboBoxProvs.SelectedIndex = 1;
            }
            if (_comboBoxFrequency.SelectedIndex != 0)
            {
                _comboBoxFrequency.SelectedIndex = 0;
            }
            if (_comboBoxQtoCmpo.SelectedIndex != 0)
            {
                _comboBoxQtoCmpo.SelectedIndex = 0;
            }
            _sortOrder = SortOrder.None;
            this.UpdateDataGridCorrelsHisto(true);

			// Add or remove the columns to/from the rho datagrid
			int nbColToAdd = _horizonList.Count - _dataGridViewRho.Columns.Count;
			if (nbColToAdd > 0)
			{
				for (int addCounter = nbColToAdd; addCounter > 0; addCounter--)
				{
					DataGridViewColumn col = _dataGridViewRho.Columns[0].Clone() as DataGridViewColumn;
					_dataGridViewRho.Columns.Add(col);
				}
			}
			else if(nbColToAdd < 0)
			{
				for (int deleteCounter = nbColToAdd; deleteCounter < 0; deleteCounter++)
				{
					_dataGridViewRho.Columns.Remove(_dataGridViewRho.Columns[0]);
				}
			}
            // Add three rows to the rho datagrid
            _dataGridViewRho.Rows.Clear();
            _dataGridViewRho.RowCount = 3;
			// Update datacolumns name
			for (int i = 0; i < _horizonList.Count; i++)
			{
				foreach (DataRow row in maturitiesTableAdapter.GetData().Select("Value = '" + _horizonList[i] + "'"))
				{
					_dataGridViewRho.Columns[i].HeaderText = Convert.ToString(row["Name"]);
				}
			}
			_dataGridViewRho.Invalidate();

            for (int i = 0; i < _dataGridViewRho.RowCount; i++)
            {
                _dataGridViewRho.Rows[i].Height = 24;
            }
			// Moyen (encore une fois) très sale pour forcer le réaffichage du datagrid
			// qui sinon affiche des colonnes de taille énorme (?)
			if (refreshRhoColumns)
			{
				this.Width += 1;
			}

            _dataGridViewRho.Rows[0].HeaderCell.Value = "Rho";
            _dataGridViewRho.Rows[1].HeaderCell.Value = "Lambda";
            _dataGridViewRho.Rows[2].HeaderCell.Value = "Rho&Lambda";
            _dataGridViewRho.Rows[0].Cells[0].Selected = false;
        }

        private void _comboBoxCorrelHorizon_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (_comboBoxCorrelHorizon.SelectedIndex >= 0)
            {
                if (_comboBoxProvs.SelectedIndex == _comboBoxProvs.Items.Count - 1)
                {
                    _activeBumps = _customBumpPalette.GetCustomBumps();
                }
                else
                {
                    _activeBumps = null;
                }
                UpdateDataGridCorrelsHisto(false);
            }
        }


        private void _comboBoxFrequency_SelectedIndexChanged(object sender, EventArgs e)
        {
            CalculationPeriod calcPer = CalculationPeriod.Weekly;
            switch(_comboBoxFrequency.SelectedIndex)
            {
                case 1:
                    calcPer = CalculationPeriod.Daily;
                    break;
                case 2:
                    calcPer = CalculationPeriod.Monthly;
                    break;
                default:
                    break;
            }
            if (_perfMatrix != null)
            {
                _correlFactory.CalcPeriod = calcPer;
                // Update correlations
                _correlationPackMap = _correlFactory.FastCorrelationComputation(_perfMatrix);

                if (_comboBoxProvs.SelectedIndex == _comboBoxProvs.Items.Count - 1)
                {
                    _activeBumps = _customBumpPalette.GetCustomBumps();
                }
                else
                {
                    _activeBumps = null;
                }
                UpdateDataGridCorrelsHisto(false);
                UpdateDataGridRho();
            }
        }


        private void _comboBoxQtoCmpo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_correlFactory != null)
            {
                _correlFactory.QuantoType = QuantoType.Quanto;
                switch (_comboBoxQtoCmpo.SelectedIndex)
                {
                    case 1:
                        _correlFactory.QuantoType = QuantoType.Compo;
                        break;
                    default:
                        break;
                }
                if (_perfMatrix != null)
                {
                    _correlationPackMap = _correlFactory.FastCorrelationComputation(_perfMatrix);
                    if (_comboBoxProvs.SelectedIndex == _comboBoxProvs.Items.Count - 1)
                    {
                        _activeBumps = _customBumpPalette.GetCustomBumps();
                    }
                    else
                    {
                        _activeBumps = null;
                    }
                    UpdateDataGridCorrelsHisto(false);
                    UpdateDataGridRho();
                }
            }
        }

        private void _comboBoxProvs_SelectionChangeCommitted(object sender, EventArgs e)
        {
            if (_comboBoxProvs.SelectedIndex >= 0)
            {
                if (_comboBoxProvs.SelectedIndex == _comboBoxProvs.Items.Count - 1)
                {
                    _customBumpPalette.Show();
                    _dataGridViewNonCorrel.IsCustomGroup = true;
                    _dataGridViewNonCorrel.GroupList = _correlationGroups;
                    _activeBumps = _customBumpPalette.GetCustomBumps();
                }
                else
                {
                    _customBumpPalette.Hide();
                    _dataGridViewNonCorrel.IsCustomGroup = false;
                    _activeBumps = null;
                }
                UpdateDataGridCorrelsHisto(false);
            }
        }

        private void _dataGridViewNonCorrel_ColumnHeaderMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            // Sort if the datasource has been specified
            if (_dataGridViewNonCorrel.DataSource != null)
            {
                // Update the glyph and the sorting direction
                int colIndex = e.ColumnIndex;
                SortOrder oldOrder = _dataGridViewNonCorrel.Columns[colIndex].HeaderCell.SortGlyphDirection;
                SortOrder newOrder = oldOrder == SortOrder.Ascending ? SortOrder.Descending :
                    oldOrder == SortOrder.Descending ? SortOrder.None : SortOrder.Ascending;

                // Sort the datagrid
                _sortColumnIndex = colIndex;
                _sortOrder = newOrder;
                this.SortDataGrid(false);
            }
        }

        private void SortDataGrid(bool isRefresh)
        {
            SortOrder newOrder = _sortOrder;
            int colIndex = _sortColumnIndex;

            // We cycle through sorting in that order : ascending -> descending -> none
            // If no sorting, we retrieve the original order back
            if (newOrder == SortOrder.None)
            {
                _dataGridViewNonCorrel.DataSource = _correlationDataTable;
            }
            // Else we sort according to the required order
            else
            {
                // Sort the new datatable itself
                int orderModifier = _dataGridViewNonCorrel.Columns[colIndex].HeaderCell.SortGlyphDirection == SortOrder.Ascending ? 1 : -1;
                if (isRefresh)
                {
                    orderModifier *= -1;
                }
                _sortableCorrelationDataTable = _correlationDataTable.Copy();
                List<int> newSortingOrder = new List<int>();

                #region Custom sort
                // Custom sort for doubles
                if (_sortableCorrelationDataTable.Columns[colIndex].DataType == typeof(double))
                {
                    List<IntDoublePoint> sortElementList = new List<IntDoublePoint>();
                    for (int rowCounter = 0; rowCounter < _sortableCorrelationDataTable.Rows.Count; rowCounter++)
                    {
                        double number;
                        if (!double.TryParse(Convert.ToString(_sortableCorrelationDataTable.Rows[rowCounter][colIndex]), out number))
                        {
                            number = double.NaN;
                        }
                        IntDoublePoint point = new IntDoublePoint();
                        point.Double = number; point.Int = rowCounter;
                        sortElementList.Add(point);
                    }
                    sortElementList.Sort(delegate(IntDoublePoint x, IntDoublePoint y)
                    {
                        return orderModifier * (double.IsNaN(x.Double) && double.IsNaN(y.Double) ?
                            0 : double.IsNaN(x.Double) ? orderModifier : double.IsNaN(y.Double) ?
                            -orderModifier : Comparer<double>.Default.Compare(x.Double, y.Double));
                    });
                    foreach (IntDoublePoint pt in sortElementList)
                    {
                        newSortingOrder.Add(pt.Int);
                    }
                }
                // Custom sort for strings                
                else if (_sortableCorrelationDataTable.Columns[colIndex].DataType == typeof(string))
                {
                    List<IntStringPoint> sortElementList = new List<IntStringPoint>();
                    for (int rowCounter = 0; rowCounter < _sortableCorrelationDataTable.Rows.Count; rowCounter++)
                    {
                        IntStringPoint point = new IntStringPoint();
                        point.String = Convert.ToString(_sortableCorrelationDataTable.Rows[rowCounter][colIndex]); point.Int = rowCounter;
                        sortElementList.Add(point);
                    }
                    sortElementList.Sort(delegate(IntStringPoint x, IntStringPoint y)
                    {
                        return orderModifier * (x.String == String.Empty && x.String == String.Empty ?
                            0 : x.String == String.Empty ? orderModifier : y.String == String.Empty ?
                        -orderModifier : Comparer<string>.Default.Compare(x.String, y.String));
                    });
                    foreach (IntStringPoint pt in sortElementList)
                    {
                        newSortingOrder.Add(pt.Int);
                    }
                }
                #endregion

                // Rearrange the row order of the datatable
                _sortableCorrelationDataTable.Rows.Clear();
                foreach (int rowIndex in newSortingOrder)
                {
                    _sortableCorrelationDataTable.Rows.Add(_correlationDataTable.Rows[rowIndex].ItemArray);
                }
                _dataGridViewNonCorrel.DataSource = _sortableCorrelationDataTable;
            }
            _dataGridViewNonCorrel.Columns[_sortColumnIndex].HeaderCell.SortGlyphDirection = newOrder;
        }

        // Return the type of provisioning selected in the respective combo box
        private ProvisioningType GetProvisioningType()
        {
            int indexProv = _comboBoxProvs.SelectedIndex;
            ProvisioningType prov = ProvisioningType.Partial;
            switch(indexProv)
            {
                case 0:
                    prov = ProvisioningType.None;
                    break;
                case 2:
                    prov = ProvisioningType.Custom;
                    break;
					/*
                    prov = ProvisioningType.Partial;
                case 3:
                    prov = ProvisioningType.Indice;
                    break;
                case 4:
                    break;*/
                default:
                    break;
            }
            return prov;
        }
        
        // Copy to the clipboard the correl part of the datagridview
        private void _buttonCopy_Click(object sender, EventArgs e)
        {
            CopyCorrelationMatrix();
        }

		// Print the displayed matrix
		private void _buttonPrint_Click(object sender, EventArgs e)
		{
			PrintDisplayedMatrix();
		}

		private void PrintDisplayedMatrix()
		{
			// Attach the PrintDialog to the PrintDocument Object
			_printDialog.Document = this._printDocument;
			// Show the Print Dialog before printing
			if (_printDialog.ShowDialog() == DialogResult.OK)
			{
				_printDocument.DocumentName = "Correlation client";
				_printDocument.PrinterSettings = _printDialog.PrinterSettings;
				_printDocument.DefaultPageSettings = _printDialog.PrinterSettings.DefaultPageSettings;
				_printDocument.DefaultPageSettings.Margins = new System.Drawing.Printing.Margins(40, 40, 40, 40);

				_dataGridViewPrinter = new DataGridViewPrinter(_dataGridViewNonCorrel, _printDocument,
					"Correlations", new Font("Tahoma", 18, FontStyle.Bold, GraphicsUnit.Point), Color.Black);

				this._printDocument.Print(); // Print the Form
			}
		}

        // Used by both the button and the relevant menu item
        private void CopyCorrelationMatrix()
        {
            // Unselect
            foreach (DataGridViewCell cell in _dataGridViewNonCorrel.SelectedCells)
            {
                cell.Selected = false;
            }

            // Select the correl submatrix
            for (int col = _nbStaticColumns; col < _dataGridViewNonCorrel.Columns.Count; col++)
            {
                for (int row = 0; row < _nbNonQuantoSecurities; row++)
                {
                    _dataGridViewNonCorrel[col, row].Selected = true;
                }
            }

            // Copy to clipboard
            if (_dataGridViewNonCorrel.GetCellCount(DataGridViewElementStates.Selected) > 0)
            {
                Clipboard.SetDataObject(_dataGridViewNonCorrel.GetClipboardContent());
            }
        }
        #endregion

        #region Background worker

		private void CorrelationForm_Shown(object sender, EventArgs e)
		{
			this.InitDatagrids(true);

			// Automatic retrieval of the requested list of stocks on display
			if (_requestedStockList != null)
			{
				ClearSecuritiesList();
				// Update security cells for each stock in the list
				int row = 0;
				foreach (string stock in _requestedStockList)
				{
					while (row >= _dataGridViewNonCorrel.RowCount)
					{
						_dataGridViewNonCorrel.RowCount++;
					}
					_dataGridViewNonCorrel[_colSecurity, row].Value = stock.Contains(" ") ? stock : stock.Replace("/", String.Empty);
					row++;
				}
				this.Calculate();
			}
		}


        private void _backgroundWorkerCalculations_DoWork(object sender, DoWorkEventArgs e)
        {
            e.Result = LaunchCalculations(_backgroundWorkerCalculations);
        }

        private void _backgroundWorkerCalculations_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            // On error
            if (e.Error != null)
            {
                MessageBox.Show("Request failed to complete successfully ; " +
                    "check that server is still up and parameters for the request are correct.\n\n\nError description:\n" + e.Error.Message);
                _toolStripStatusLabel.Text = "Failed to compute correlations";
            }
            else
            {
                _toolStripStatusLabel.Text = "Computing correlations ...";
                FinishComputations(e);
                _toolStripStatusLabel.Text = e.Result == null ? "Failed to compute correlations" : String.Empty;
            }

            // Restore the Ihm to default
            _timer.Stop();
            _toolStripProgressBar.Value = 0;
            EnableDataEntry(true);
        }

        // Enable/disable data entry when calculating
        private void EnableDataEntry(bool isEnabled)
        {
            _dataGridViewNonCorrel.Enabled = isEnabled;
            _groupBoxDisplay.Enabled = isEnabled;
            _groupBoxMain.Enabled = isEnabled;
            _groupBoxRhoHorizon.Enabled = isEnabled;
            sendToServerToolStripMenuItem.Enabled = isEnabled;
            editToolStripMenuItem.Enabled = isEnabled;
        }

        // Timer event : update the progress bar
        private void _timer_Tick(object sender, EventArgs e)
        {
            _toolStripProgressBar.Value = (_toolStripProgressBar.Value + 5) % 100;
        }

        private void _dataManagerDlg_UpdateDBList(object sender, EventArgs e)
        {
            RetrieveData();
        }
        #endregion

        #region Menu item handlers
        // Exit the application
        private void quitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
		{
        }

        private void dataManagementToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!_dataManagerDlg.Visible)
            {
                if (_dataManagerDlg.IsDisposed)
                {
                    _dataManagerDlg = new DataManager();
                }
                _dataManagerDlg.Show();
            }
        }

        private void copyMatrixToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CopyCorrelationMatrix();
        }

        // Clear the entire list of securities
        private void clearSelectionToolStripMenuItem_Click(object sender, EventArgs e)
        {
			ClearSecuritiesList();
		}

		private void ClearSecuritiesList()
		{
            // Clear the security cell for each row
            for (int i = 0; i < _dataGridViewNonCorrel.RowCount; i++)
            {
                _dataGridViewNonCorrel[_colSecurity, i].Value = String.Empty;
            }

            // Clear the datatable too
            // If inferior to the minimum number of rows, fill the remaining with empty values
            _correlationDataTable.Rows.Clear();
            for (int nbColumn = _dataGridViewNonCorrel.ColumnCount - 1; nbColumn >= _nbStaticColumns; nbColumn--)
            {
                _correlationDataTable.Columns.Remove(_dataGridViewNonCorrel.Columns[nbColumn].DataPropertyName);
                _dataGridViewNonCorrel.Columns.Remove(_dataGridViewNonCorrel.Columns[nbColumn]);
            }
            while (_correlationDataTable.Rows.Count < _minRows)
            {
                _correlationDataTable.Rows.Add(new object[] { String.Empty });
            }
            this.UpdateDataGridRho();

            // Focus on the first cell in the datagrid to enable immediate typing/pasting
            _dataGridViewNonCorrel.Select();
            _dataGridViewNonCorrel.CurrentCell = _dataGridViewNonCorrel[0, 0];
        }

        // Menu shortcut
        private void sendToServerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Calculate();
        }

        private void aboutWhereIsMyCCToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Where is my CC\n\nCurrent version 1.0.0.\n\nLast update : December 2nd, 2008");
        }

        private void graphicalEvolutionToolStripMenuItem_Click(object sender, EventArgs e)
        {
			if (_perfMatrix != null && _correlFactory != null)
			{
				new GraphicalAnalysis(_perfMatrix, _correlFactory).Show();
			}
			else
			{
				MessageBox.Show("Please run a correlation calculation first.");
			}
        }

        private void _buttonOptimize_Click(object sender, EventArgs e)
        {

        }

        private void _buttonGraphAnalysis_Click(object sender, EventArgs e)
        {
            graphicalEvolutionToolStripMenuItem_Click(sender, e);
        }

        private void loadFromIndexToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void printToolStripMenuItem_Click(object sender, EventArgs e)
        {
			PrintDisplayedMatrix();
		}

        private void _printDocument_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            if (_dataGridViewPrinter.DrawDataGridView(e.Graphics))
            {
                e.HasMorePages = true;
            }
		}

		private void CorrelationForm_FormClosing(object sender, FormClosingEventArgs e)
		{
			// Hide the form if not computing anything
			if (!_backgroundWorkerCalculations.IsBusy)
			{
				this.Hide();
			}
			// Hide the custom window if still visible
			_customBumpPalette.Hide();
			e.Cancel = true;
		}
        #endregion

        #region Const and variables
        private ClientSettings _clientSettingsDlg;
        private DataManager _dataManagerDlg;
        private CustomBumps _customBumpPalette;
        private DataGridViewPrinter _dataGridViewPrinter;
        private CorrelFactory _correlFactory;

        private static string _colSecurity = "Security";
        private static string _colCurrency = "CRNCY";
        private static string _colLiquidity = "Liquidity";
        private static string _colAvailableData = "AvailableData";
        private static string _colGroupIndex = "GroupIndex";
        private static string _colQuanto = "Quanto";
        private static string _colValue = "Value";
        private string _initQuanto = "EUR";
        private static string _missingData = "#N/A Sec";
        private static int _nbStaticColumns = 7;
        private static int _minRows = 50;
        private int _sortColumnIndex;
        private SortOrder _sortOrder;
        private int _nbNonQuantoSecurities;
        private CalculationPeriod _calcPeriod;
        private Dictionary<double, CorrelationPack> _correlationPackMap;
        private Dictionary<double, double[]> _liquidityMap;
        private List<double> _horizonList;
        private List<string> _securityList;
        private List<string> _previousDaySecurities;
        private DataTable _correlationDataTable;
        private DataTable _sortableCorrelationDataTable;
        private double[,] _perfMatrix;
		private bool _isInit = false;
		private List<string> _requestedStockList;
		private double _productMaturity = double.NaN;
		private delegate void MsgShowDelegate(string str);


		public Dictionary<KeyValuePair<string, string>, double> CorrelationUpdateResult
		{
			get
			{
				Dictionary<KeyValuePair<string, string>, double> correlationUpdateResult = new Dictionary<KeyValuePair<string, string>, double>();
				try
				{
					for (int i = 1; i < _requestedStockList.Count; i++)
					{
						string stockI = _requestedStockList[i];
						for (int j = 0; j < i; j++)
						{
							string stockJ = _requestedStockList[j];
							correlationUpdateResult.Add(
								new KeyValuePair<string, string>(stockI, stockJ),
								Convert.ToDouble(_correlationDataTable.Rows[i][j + _nbStaticColumns]));
						}
					}
				}
				catch (Exception ex)
				{
					MessageBox.Show("Correlation update could not be completed.\n" + ex.Message, "Calculation error");
				}

				return correlationUpdateResult;
			}
		}
        #endregion

        private void _floorCB_CheckedChanged(object sender, EventArgs e)
        {
            UpdateDataGridCorrelsHisto(false);
        }

    }
}