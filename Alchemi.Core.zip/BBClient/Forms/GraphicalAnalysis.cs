﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Text;
using System.Windows.Forms;
using ZedGraph;
using Estimators;
using BbgProcesser;
using System.Globalization;

namespace BBClient
{
    public partial class GraphicalAnalysis : Form
    {
        public GraphicalAnalysis(double[,] perfMatrix, CorrelFactory correlFactory)
        {
            InitializeComponent();

            _perfMatrix = perfMatrix;
            _correlFactory = correlFactory;
        }

        #region Events

        private void GraphicalAnalysis_Load(object sender, EventArgs e)
        {
            // Setup the graph
            CreateGraph();

            // Size the control to fill the form with a margin
            SetSize();
        }

        private void GraphicalAnalysis_Resize(object sender, EventArgs e)
        {
            SetSize();
        }
        #endregion

        private void SetSize()
        {
            _zedGraphControl.Location = new Point(10, 10);
            // Leave a small margin around the outside of the control
            _zedGraphControl.Size = new Size(ClientRectangle.Width - 20,
                                    ClientRectangle.Height - 20);
        }

        private void CreateGraph()
        {
            // Setup display parameters
            double stepsPerYear = 5;
            List<Color> colorList = new List<Color>();
            colorList.Add(Color.Red);
            colorList.Add(Color.Orange);
            colorList.Add(Color.PaleGreen);
            colorList.Add(Color.DodgerBlue);
            colorList.Add(Color.DarkOrchid);
            colorList.Add(Color.Brown);

            // get a reference to the GraphPane
            GraphPane myPane = _zedGraphControl.GraphPane;

            // Set the Titles
            myPane.Title.Text = "Temporal evolution of the rho, ";
            switch (_correlFactory.CalcPeriod)
            {
                case CalculationPeriod.Daily:
                    myPane.Title.Text += "daily";
                    break;
                case CalculationPeriod.Weekly:
                    myPane.Title.Text += "weekly";
                    break;
                case CalculationPeriod.Monthly:
                    myPane.Title.Text += "monthly";
                    break;
                default:
                    break;
            }
            myPane.Title.Text += " frequency";
            myPane.XAxis.Title.Text = "Year";
            myPane.YAxis.Title.Text = "Rho";
            myPane.XAxis.Type = AxisType.Date;

            // Add gridlines to the plot, and make them gray
            myPane.XAxis.MajorGrid.IsVisible = true;
            myPane.YAxis.MajorGrid.IsVisible = true;
            myPane.XAxis.MajorGrid.Color = Color.LightGray;
            myPane.YAxis.MajorGrid.Color = Color.LightGray;

            // Add a background gradient fill to the axis frame
            myPane.Chart.Fill = new Fill(Color.White, Color.LightGoldenrodYellow, -45F);

            // Make up the data arrays based on the correlation matrix
            Dictionary<double, PointPairList> listPointPairList = new Dictionary<double, PointPairList>();
            foreach (double horizon in _correlFactory.HorizonList)
            {
                listPointPairList.Add(horizon, new PointPairList());
            }

			double maxHorizon = 0;
			// Retrieve the max horizon to be used for graphical analysis
			for (int i = 0; i < _correlFactory.HorizonList.Count; i++)
			{
				double currentHorizon = _correlFactory.HorizonList[i];
				if (currentHorizon > maxHorizon)
					maxHorizon = currentHorizon;
			}
            for (double i = 0; i < maxHorizon * stepsPerYear; i++)
            {
                DateTime currentDate = DateTime.Today.AddDays((int)(-i / stepsPerYear * 365));
                double x = (double)new XDate(currentDate);
                int dayStart = i == 0 ? _perfMatrix.GetLength(1) : Converter.NumberDaysFromYears(DateTime.Today, 2 * maxHorizon - i / stepsPerYear) + 4;
                int daysEnd =  Converter.NumberDaysFromYears(DateTime.Today, maxHorizon - i/stepsPerYear) + 1;

                double[,] tempDailyPerfs = new double[_perfMatrix.GetLength(0), dayStart - daysEnd];
                for (int fillCounter = 0; fillCounter < _perfMatrix.GetLength(0); fillCounter++)
                {
                    for (int startIndex = daysEnd; startIndex < dayStart; startIndex++)
                    {
                        tempDailyPerfs[fillCounter, startIndex - daysEnd] = _perfMatrix[fillCounter, startIndex];
                    }
                }
                Dictionary<double, CorrelationPack> corrPack = _correlFactory.FastCorrelationComputation(tempDailyPerfs);
                foreach (double horizon in _correlFactory.HorizonList)
                {
                    listPointPairList[horizon].Add(x, corrPack[horizon].Rho);
                }
            }

            // Generate a curve for each list
            int colorIndex = 0;
            foreach (double horizon in _correlFactory.HorizonList)
            {
                colorIndex = colorIndex % colorList.Count;
                LineItem myCurve = myPane.AddCurve(horizon + "Y",
                    listPointPairList[horizon], colorList[colorIndex], SymbolType.None);
                myCurve.Line.IsAntiAlias = true;
                //myCurve.Line.IsSmooth = true;
                //myCurve.Line.SmoothTension = 0.4F;
                colorIndex++;
            }

            // Set min and max scales
            myPane.XAxis.Scale.Max = (double)new XDate(DateTime.Today);
            myPane.XAxis.Scale.Min = (double)new XDate(DateTime.Today.AddDays((int)(-maxHorizon * 365)));

            // Tell ZedGraph to refigure the axes since the data have changed
            _zedGraphControl.AxisChange();
        }

        #region Variables
        private double[,] _perfMatrix;
        //private List<double> _horizonList;
        //private int _nbNonQuantoSecurities;
        //private CalculationPeriod _calcPeriod;
        private CorrelFactory _correlFactory;
        #endregion

        private void _button_Click(object sender, EventArgs e)
        {
            if (_saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                GraphPane myPane = _zedGraphControl.GraphPane;
                if (myPane.CurveList.Count > 0)
                {
                    TextWriter writer = new StreamWriter(_saveFileDialog.FileName);
                    string line = string.Empty;
                    foreach (double horizon in _correlFactory.HorizonList)
                    {
                        line += ";" + horizon.ToString(CultureInfo.InvariantCulture.NumberFormat) + "Y";
                    }
                    writer.WriteLine(line);
                    for (int ppIndex = myPane.CurveList[0].Points.Count - 1; ppIndex >= 0; ppIndex--)
                    {
                        line = Convert.ToString(myPane.CurveList[0][ppIndex].X.ToString(CultureInfo.InvariantCulture.NumberFormat));
                        for (int nbCurve = 0; nbCurve < myPane.CurveList.Count; nbCurve++)
                        {
                            line += ";" + myPane.CurveList[nbCurve][ppIndex].Y.ToString(CultureInfo.InvariantCulture.NumberFormat);
                        }
                        writer.WriteLine(line);
                    }
                    writer.Close();
                }
            }            
        }
    }
}