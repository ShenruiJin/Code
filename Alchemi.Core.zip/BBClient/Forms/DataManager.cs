﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using CaesarApplication.Service.Connection;

namespace BBClient
{
    public partial class DataManager : Form
    {
        // Màj main form
        public event EventHandler UpdateDBList;
 
        public DataManager()
        {
            InitializeComponent();
        }

        private void DataManager_Load(object sender, EventArgs e)
        {
			// TODO: This line of code loads data into the 'cCDataSet.Regressions' table. You can move, or remove it, as needed.
			this.regressionsTableAdapter.Fill(this.cCDataSet.Regressions);
            // TODO: This line of code loads data into the 'cCDataSet.ForexFactors' table. You can move, or remove it, as needed.
            this.forexFactorsTableAdapter.Fill(this.cCDataSet.ForexFactors);
            // TODO: This line of code loads data into the 'cCDataSet.SophisSecurities' table. You can move, or remove it, as needed.
            this.sophisSecuritiesTableAdapter.Fill(this.cCDataSet.SophisSecurities);
            // TODO: This line of code loads data into the 'cCDataSet.BbgDescriptiveFields' table. You can move, or remove it, as needed.
            this.bbgDescriptiveFieldsTableAdapter.Fill(this.cCDataSet.BbgDescriptiveFields);
            // TODO: This line of code loads data into the 'cCDataSet.Commodities' table. You can move, or remove it, as needed.
            this.commoditiesTableAdapter.Fill(this.cCDataSet.Commodities);
            // TODO: This line of code loads data into the 'cCDataSet.Asians' table. You can move, or remove it, as needed.
            this.asiansTableAdapter.Fill(this.cCDataSet.Asians);
            // TODO: This line of code loads data into the 'cCDataSet.Maturities' table. You can move, or remove it, as needed.
            this.maturitiesTableAdapter.Fill(this.cCDataSet.Maturities);
            // TODO: This line of code loads data into the 'cCDataSet.Indices' table. You can move, or remove it, as needed.
            this.indicesTableAdapter.Fill(this.cCDataSet.Indices);
            // TODO: This line of code loads data into the 'cCDataSet.Currencies' table. You can move, or remove it, as needed.
            this.currenciesTableAdapter.Fill(this.cCDataSet.Currencies);
            // TODO: This line of code loads data into the 'cCDataSet.Indices' table. You can move, or remove it, as needed.
            this.indicesTableAdapter.Fill(this.cCDataSet.Indices);
        }

        private void _buttonClose_Click(object sender, EventArgs e)
        {
            this.Close();
            //this.Hide();
        }

        private void _buttonAccept_Click(object sender, EventArgs e)
        {
            // Commit changes
            currenciesTableAdapter.Update(cCDataSet.Currencies);
            commoditiesTableAdapter.Update(cCDataSet.Commodities);
            indicesTableAdapter.Update(cCDataSet.Indices);
            maturitiesTableAdapter.Update(cCDataSet.Maturities);
            asiansTableAdapter.Update(cCDataSet.Asians);
            bbgDescriptiveFieldsTableAdapter.Update(cCDataSet.BbgDescriptiveFields);
            sophisSecuritiesTableAdapter.Update(cCDataSet.SophisSecurities);
            forexFactorsTableAdapter.Update(cCDataSet.ForexFactors);
			regressionsTableAdapter.Update(cCDataSet.Regressions);
            cCDataSet.AcceptChanges();

            // Force the server to update its internal data with the new data
            // Temporary catch while the server base has not been updated
            try
            {
                Remoter.ReinitializeData();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Please restart your server to get the latest version.\n" + ex.Message);
            }

            this.Close();

            if (UpdateDBList != null)
            {
                UpdateDBList(this, new EventArgs());
            }
        }

        private void DataManager_Layout(object sender, LayoutEventArgs e)
        {

        }
    }
}