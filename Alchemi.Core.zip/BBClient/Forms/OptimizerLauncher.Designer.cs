﻿using System.Drawing;

namespace BBClient.Forms
{
    partial class OptimizerLauncher
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.backgroundWorker = new System.ComponentModel.BackgroundWorker();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.buttonGoBack = new System.Windows.Forms.Button();
            this.labelHeader = new System.Windows.Forms.Label();
            this.GAprogressGroupBox = new System.Windows.Forms.GroupBox();
            this.labelBestBasketGeneration = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.buttonStopOptim = new System.Windows.Forms.Button();
            this.labelProgress = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.labelBestBasketPremium = new System.Windows.Forms.Label();
            this.StartButton = new System.Windows.Forms.Button();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.label18 = new System.Windows.Forms.Label();
            this.labelBestBasketComposition = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.labelNgenerations = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.labelGenerationCounter = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.GAoptionsCheckBox = new System.Windows.Forms.CheckBox();
            this.GAparamsGroupBox = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBoxReinsertionMethod = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBoxCrossoverMethod = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBoxSelectionMethod = new System.Windows.Forms.ComboBox();
            this.comboBoxSortBasis = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.TournamentWinPercentTextBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.textBoxPopulationSize = new System.Windows.Forms.TextBox();
            this.labelPopulationSize = new System.Windows.Forms.Label();
            this.ReplacementPercentSignLabel = new System.Windows.Forms.Label();
            this.MutationpercentSignLabel = new System.Windows.Forms.Label();
            this.CrossoverPercentSignLabel = new System.Windows.Forms.Label();
            this.ReplacementPercentTextbox = new System.Windows.Forms.TextBox();
            this.MutationProbTextbox = new System.Windows.Forms.TextBox();
            this.CrossoverProbTextbox = new System.Windows.Forms.TextBox();
            this.ReplacementPercentLabel = new System.Windows.Forms.Label();
            this.MutationProbLabel = new System.Windows.Forms.Label();
            this.nbGenerationsTextBox = new System.Windows.Forms.TextBox();
            this.CrossoverProbLabel = new System.Windows.Forms.Label();
            this.NbGenerationsLabel = new System.Windows.Forms.Label();
            this.OptimisationSimulationParams = new System.Windows.Forms.GroupBox();
            this.labelUniverseSize = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.textBoxRepriceFinalSimulations = new System.Windows.Forms.TextBox();
            this.labelSimulationsFinalPop = new System.Windows.Forms.Label();
            this.checkBoxRepriceFinalPop = new System.Windows.Forms.CheckBox();
            this.combBoxOptimGoal = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.textBoxBasketSize = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBoxSimulations = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBoxRateModel = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.comboBoxStockModel = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.buttonViewResults = new System.Windows.Forms.Button();
            this.GAprogressGroupBox.SuspendLayout();
            this.GAparamsGroupBox.SuspendLayout();
            this.OptimisationSimulationParams.SuspendLayout();
            this.SuspendLayout();
            // 
            // backgroundWorker
            // 
            this.backgroundWorker.WorkerReportsProgress = true;
            this.backgroundWorker.WorkerSupportsCancellation = true;
            this.backgroundWorker.DoWork += new System.ComponentModel.DoWorkEventHandler(this.backgroundWorker_DoWork);
            this.backgroundWorker.ProgressChanged += new System.ComponentModel.ProgressChangedEventHandler(this.backgroundWorker_ProgressChanged);
            this.backgroundWorker.RunWorkerCompleted += new System.ComponentModel.RunWorkerCompletedEventHandler(this.backgroundWorker_RunWorkerCompleted);
            // 
            // statusStrip
            // 
            this.statusStrip.Location = new System.Drawing.Point(0, 694);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(742, 22);
            this.statusStrip.TabIndex = 15;
            this.statusStrip.Text = "statusStrip1";
            // 
            // buttonGoBack
            // 
            this.buttonGoBack.Location = new System.Drawing.Point(16, 645);
            this.buttonGoBack.Name = "buttonGoBack";
            this.buttonGoBack.Size = new System.Drawing.Size(85, 46);
            this.buttonGoBack.TabIndex = 14;
            this.buttonGoBack.Text = "Back";
            this.buttonGoBack.UseVisualStyleBackColor = true;
            this.buttonGoBack.Click += new System.EventHandler(this.buttonGoBack_Click);
            // 
            // labelHeader
            // 
            this.labelHeader.AutoSize = true;
            this.labelHeader.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHeader.Location = new System.Drawing.Point(21, 18);
            this.labelHeader.Name = "labelHeader";
            this.labelHeader.Size = new System.Drawing.Size(237, 24);
            this.labelHeader.TabIndex = 13;
            this.labelHeader.Text = "Optimization set-up for : ";
            // 
            // GAprogressGroupBox
            // 
            this.GAprogressGroupBox.Controls.Add(this.labelBestBasketGeneration);
            this.GAprogressGroupBox.Controls.Add(this.label17);
            this.GAprogressGroupBox.Controls.Add(this.buttonStopOptim);
            this.GAprogressGroupBox.Controls.Add(this.labelProgress);
            this.GAprogressGroupBox.Controls.Add(this.label12);
            this.GAprogressGroupBox.Controls.Add(this.labelBestBasketPremium);
            this.GAprogressGroupBox.Controls.Add(this.StartButton);
            this.GAprogressGroupBox.Controls.Add(this.progressBar);
            this.GAprogressGroupBox.Controls.Add(this.label18);
            this.GAprogressGroupBox.Controls.Add(this.labelBestBasketComposition);
            this.GAprogressGroupBox.Controls.Add(this.label16);
            this.GAprogressGroupBox.Controls.Add(this.labelNgenerations);
            this.GAprogressGroupBox.Controls.Add(this.label14);
            this.GAprogressGroupBox.Controls.Add(this.labelGenerationCounter);
            this.GAprogressGroupBox.Controls.Add(this.label11);
            this.GAprogressGroupBox.Location = new System.Drawing.Point(16, 460);
            this.GAprogressGroupBox.Name = "GAprogressGroupBox";
            this.GAprogressGroupBox.Size = new System.Drawing.Size(708, 179);
            this.GAprogressGroupBox.TabIndex = 12;
            this.GAprogressGroupBox.TabStop = false;
            this.GAprogressGroupBox.Text = "Algorithm progress";
            // 
            // labelBestBasketGeneration
            // 
            this.labelBestBasketGeneration.AutoSize = true;
            this.labelBestBasketGeneration.Enabled = false;
            this.labelBestBasketGeneration.Location = new System.Drawing.Point(200, 63);
            this.labelBestBasketGeneration.Name = "labelBestBasketGeneration";
            this.labelBestBasketGeneration.Size = new System.Drawing.Size(13, 13);
            this.labelBestBasketGeneration.TabIndex = 17;
            this.labelBestBasketGeneration.Text = "0";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Enabled = false;
            this.label17.Location = new System.Drawing.Point(96, 63);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(98, 13);
            this.label17.TabIndex = 16;
            this.label17.Text = "found in generation";
            // 
            // buttonStopOptim
            // 
            this.buttonStopOptim.Location = new System.Drawing.Point(650, 147);
            this.buttonStopOptim.Name = "buttonStopOptim";
            this.buttonStopOptim.Size = new System.Drawing.Size(52, 25);
            this.buttonStopOptim.TabIndex = 15;
            this.buttonStopOptim.Text = "Stop";
            this.buttonStopOptim.UseVisualStyleBackColor = true;
            this.buttonStopOptim.Click += new System.EventHandler(this.buttonStopOptim_Click);
            // 
            // labelProgress
            // 
            this.labelProgress.AutoSize = true;
            this.labelProgress.BackColor = System.Drawing.Color.Transparent;
            this.labelProgress.Enabled = false;
            this.labelProgress.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelProgress.Location = new System.Drawing.Point(389, 120);
            this.labelProgress.Name = "labelProgress";
            this.labelProgress.Size = new System.Drawing.Size(23, 13);
            this.labelProgress.TabIndex = 13;
            this.labelProgress.Text = "0%";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Enabled = false;
            this.label12.Location = new System.Drawing.Point(6, 112);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 13);
            this.label12.TabIndex = 12;
            this.label12.Text = "Progress :";
            // 
            // labelBestBasketPremium
            // 
            this.labelBestBasketPremium.AutoSize = true;
            this.labelBestBasketPremium.Enabled = false;
            this.labelBestBasketPremium.Location = new System.Drawing.Point(96, 85);
            this.labelBestBasketPremium.Name = "labelBestBasketPremium";
            this.labelBestBasketPremium.Size = new System.Drawing.Size(36, 13);
            this.labelBestBasketPremium.TabIndex = 7;
            this.labelBestBasketPremium.Text = "0.00%";
            // 
            // StartButton
            // 
            this.StartButton.Location = new System.Drawing.Point(628, 19);
            this.StartButton.Name = "StartButton";
            this.StartButton.Size = new System.Drawing.Size(74, 57);
            this.StartButton.TabIndex = 10;
            this.StartButton.Text = "Start Optimization";
            this.StartButton.UseVisualStyleBackColor = true;
            this.StartButton.Click += new System.EventHandler(this.StartButton_Click);
            // 
            // progressBar
            // 
            this.progressBar.Enabled = false;
            this.progressBar.Location = new System.Drawing.Point(99, 112);
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(603, 29);
            this.progressBar.TabIndex = 11;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Enabled = false;
            this.label18.Location = new System.Drawing.Point(6, 85);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(53, 13);
            this.label18.TabIndex = 6;
            this.label18.Text = "Premium :";
            // 
            // labelBestBasketComposition
            // 
            this.labelBestBasketComposition.Enabled = false;
            this.labelBestBasketComposition.ForeColor = System.Drawing.Color.Green;
            this.labelBestBasketComposition.Location = new System.Drawing.Point(96, 41);
            this.labelBestBasketComposition.Name = "labelBestBasketComposition";
            this.labelBestBasketComposition.Size = new System.Drawing.Size(526, 22);
            this.labelBestBasketComposition.TabIndex = 5;
            this.labelBestBasketComposition.Text = "   ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Enabled = false;
            this.label16.Location = new System.Drawing.Point(6, 41);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 4;
            this.label16.Text = "Best basket :";
            // 
            // labelNgenerations
            // 
            this.labelNgenerations.AutoSize = true;
            this.labelNgenerations.Enabled = false;
            this.labelNgenerations.Location = new System.Drawing.Point(168, 19);
            this.labelNgenerations.Name = "labelNgenerations";
            this.labelNgenerations.Size = new System.Drawing.Size(31, 13);
            this.labelNgenerations.TabIndex = 3;
            this.labelNgenerations.Text = "1000";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Enabled = false;
            this.label14.Location = new System.Drawing.Point(135, 19);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(16, 13);
            this.label14.TabIndex = 2;
            this.label14.Text = "of";
            // 
            // labelGenerationCounter
            // 
            this.labelGenerationCounter.AutoSize = true;
            this.labelGenerationCounter.Enabled = false;
            this.labelGenerationCounter.Location = new System.Drawing.Point(96, 19);
            this.labelGenerationCounter.Name = "labelGenerationCounter";
            this.labelGenerationCounter.Size = new System.Drawing.Size(13, 13);
            this.labelGenerationCounter.TabIndex = 1;
            this.labelGenerationCounter.Text = "0";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Enabled = false;
            this.label11.Location = new System.Drawing.Point(6, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(59, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Generation";
            // 
            // GAoptionsCheckBox
            // 
            this.GAoptionsCheckBox.AutoSize = true;
            this.GAoptionsCheckBox.Location = new System.Drawing.Point(16, 221);
            this.GAoptionsCheckBox.Name = "GAoptionsCheckBox";
            this.GAoptionsCheckBox.Size = new System.Drawing.Size(203, 17);
            this.GAoptionsCheckBox.TabIndex = 9;
            this.GAoptionsCheckBox.Text = "Custom Genetic Algorithm Parameters";
            this.GAoptionsCheckBox.UseVisualStyleBackColor = true;
            this.GAoptionsCheckBox.CheckedChanged += new System.EventHandler(this.GAoptionsCheckBox_CheckedChanged);
            // 
            // GAparamsGroupBox
            // 
            this.GAparamsGroupBox.Controls.Add(this.label10);
            this.GAparamsGroupBox.Controls.Add(this.comboBoxReinsertionMethod);
            this.GAparamsGroupBox.Controls.Add(this.label9);
            this.GAparamsGroupBox.Controls.Add(this.comboBoxCrossoverMethod);
            this.GAparamsGroupBox.Controls.Add(this.label8);
            this.GAparamsGroupBox.Controls.Add(this.comboBoxSelectionMethod);
            this.GAparamsGroupBox.Controls.Add(this.comboBoxSortBasis);
            this.GAparamsGroupBox.Controls.Add(this.label7);
            this.GAparamsGroupBox.Controls.Add(this.label6);
            this.GAparamsGroupBox.Controls.Add(this.TournamentWinPercentTextBox);
            this.GAparamsGroupBox.Controls.Add(this.label5);
            this.GAparamsGroupBox.Controls.Add(this.textBoxPopulationSize);
            this.GAparamsGroupBox.Controls.Add(this.labelPopulationSize);
            this.GAparamsGroupBox.Controls.Add(this.ReplacementPercentSignLabel);
            this.GAparamsGroupBox.Controls.Add(this.MutationpercentSignLabel);
            this.GAparamsGroupBox.Controls.Add(this.CrossoverPercentSignLabel);
            this.GAparamsGroupBox.Controls.Add(this.ReplacementPercentTextbox);
            this.GAparamsGroupBox.Controls.Add(this.MutationProbTextbox);
            this.GAparamsGroupBox.Controls.Add(this.CrossoverProbTextbox);
            this.GAparamsGroupBox.Controls.Add(this.ReplacementPercentLabel);
            this.GAparamsGroupBox.Controls.Add(this.MutationProbLabel);
            this.GAparamsGroupBox.Controls.Add(this.nbGenerationsTextBox);
            this.GAparamsGroupBox.Controls.Add(this.CrossoverProbLabel);
            this.GAparamsGroupBox.Controls.Add(this.NbGenerationsLabel);
            this.GAparamsGroupBox.Location = new System.Drawing.Point(16, 244);
            this.GAparamsGroupBox.Name = "GAparamsGroupBox";
            this.GAparamsGroupBox.Size = new System.Drawing.Size(708, 210);
            this.GAparamsGroupBox.TabIndex = 8;
            this.GAparamsGroupBox.TabStop = false;
            this.GAparamsGroupBox.Text = " ";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Enabled = false;
            this.label10.Location = new System.Drawing.Point(326, 116);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(104, 13);
            this.label10.TabIndex = 29;
            this.label10.Text = "Reinsertion method :";
            // 
            // comboBoxReinsertionMethod
            // 
            this.comboBoxReinsertionMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxReinsertionMethod.Enabled = false;
            this.comboBoxReinsertionMethod.FormattingEnabled = true;
            this.comboBoxReinsertionMethod.Items.AddRange(new object[] {
            "eugenics (best survive)",
            "generational"});
            this.comboBoxReinsertionMethod.Location = new System.Drawing.Point(436, 108);
            this.comboBoxReinsertionMethod.Name = "comboBoxReinsertionMethod";
            this.comboBoxReinsertionMethod.Size = new System.Drawing.Size(241, 21);
            this.comboBoxReinsertionMethod.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Enabled = false;
            this.label9.Location = new System.Drawing.Point(326, 88);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(98, 13);
            this.label9.TabIndex = 27;
            this.label9.Text = "Crossover method :";
            // 
            // comboBoxCrossoverMethod
            // 
            this.comboBoxCrossoverMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxCrossoverMethod.Enabled = false;
            this.comboBoxCrossoverMethod.FormattingEnabled = true;
            this.comboBoxCrossoverMethod.Items.AddRange(new object[] {
            "single-point crossover (with probability)",
            "single-point crossover (without probability)"});
            this.comboBoxCrossoverMethod.Location = new System.Drawing.Point(436, 80);
            this.comboBoxCrossoverMethod.Name = "comboBoxCrossoverMethod";
            this.comboBoxCrossoverMethod.Size = new System.Drawing.Size(241, 21);
            this.comboBoxCrossoverMethod.TabIndex = 26;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Enabled = false;
            this.label8.Location = new System.Drawing.Point(326, 58);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(95, 13);
            this.label8.TabIndex = 25;
            this.label8.Text = "Selection method :";
            // 
            // comboBoxSelectionMethod
            // 
            this.comboBoxSelectionMethod.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSelectionMethod.Enabled = false;
            this.comboBoxSelectionMethod.FormattingEnabled = true;
            this.comboBoxSelectionMethod.Items.AddRange(new object[] {
            "roulette by premium",
            "roulette by rank",
            "tournament",
            "elitism (select the best)"});
            this.comboBoxSelectionMethod.Location = new System.Drawing.Point(436, 50);
            this.comboBoxSelectionMethod.Name = "comboBoxSelectionMethod";
            this.comboBoxSelectionMethod.Size = new System.Drawing.Size(241, 21);
            this.comboBoxSelectionMethod.TabIndex = 24;
            // 
            // comboBoxSortBasis
            // 
            this.comboBoxSortBasis.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxSortBasis.Enabled = false;
            this.comboBoxSortBasis.FormattingEnabled = true;
            this.comboBoxSortBasis.Items.AddRange(new object[] {
            "Objective scores (prices)",
            "Fitness scores"});
            this.comboBoxSortBasis.Location = new System.Drawing.Point(436, 20);
            this.comboBoxSortBasis.Name = "comboBoxSortBasis";
            this.comboBoxSortBasis.Size = new System.Drawing.Size(241, 21);
            this.comboBoxSortBasis.TabIndex = 12;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Enabled = false;
            this.label7.Location = new System.Drawing.Point(326, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 13);
            this.label7.TabIndex = 23;
            this.label7.Text = "Sort Basis :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Enabled = false;
            this.label6.Location = new System.Drawing.Point(228, 147);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(15, 13);
            this.label6.TabIndex = 22;
            this.label6.Text = "%";
            // 
            // TournamentWinPercentTextBox
            // 
            this.TournamentWinPercentTextBox.Enabled = false;
            this.TournamentWinPercentTextBox.Location = new System.Drawing.Point(172, 143);
            this.TournamentWinPercentTextBox.Name = "TournamentWinPercentTextBox";
            this.TournamentWinPercentTextBox.Size = new System.Drawing.Size(50, 20);
            this.TournamentWinPercentTextBox.TabIndex = 21;
            this.TournamentWinPercentTextBox.Text = "70";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Enabled = false;
            this.label5.Location = new System.Drawing.Point(21, 147);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(139, 13);
            this.label5.TabIndex = 20;
            this.label5.Text = "Tournament win probability :";
            // 
            // textBoxPopulationSize
            // 
            this.textBoxPopulationSize.Enabled = false;
            this.textBoxPopulationSize.Location = new System.Drawing.Point(171, 56);
            this.textBoxPopulationSize.Name = "textBoxPopulationSize";
            this.textBoxPopulationSize.Size = new System.Drawing.Size(50, 20);
            this.textBoxPopulationSize.TabIndex = 19;
            this.textBoxPopulationSize.Text = "10";
            // 
            // labelPopulationSize
            // 
            this.labelPopulationSize.AutoSize = true;
            this.labelPopulationSize.Enabled = false;
            this.labelPopulationSize.Location = new System.Drawing.Point(21, 56);
            this.labelPopulationSize.Name = "labelPopulationSize";
            this.labelPopulationSize.Size = new System.Drawing.Size(78, 13);
            this.labelPopulationSize.TabIndex = 18;
            this.labelPopulationSize.Text = "Population size";
            // 
            // ReplacementPercentSignLabel
            // 
            this.ReplacementPercentSignLabel.AutoSize = true;
            this.ReplacementPercentSignLabel.Enabled = false;
            this.ReplacementPercentSignLabel.Location = new System.Drawing.Point(228, 174);
            this.ReplacementPercentSignLabel.Name = "ReplacementPercentSignLabel";
            this.ReplacementPercentSignLabel.Size = new System.Drawing.Size(15, 13);
            this.ReplacementPercentSignLabel.TabIndex = 17;
            this.ReplacementPercentSignLabel.Text = "%";
            // 
            // MutationpercentSignLabel
            // 
            this.MutationpercentSignLabel.AutoSize = true;
            this.MutationpercentSignLabel.Enabled = false;
            this.MutationpercentSignLabel.Location = new System.Drawing.Point(227, 120);
            this.MutationpercentSignLabel.Name = "MutationpercentSignLabel";
            this.MutationpercentSignLabel.Size = new System.Drawing.Size(15, 13);
            this.MutationpercentSignLabel.TabIndex = 16;
            this.MutationpercentSignLabel.Text = "%";
            // 
            // CrossoverPercentSignLabel
            // 
            this.CrossoverPercentSignLabel.AutoSize = true;
            this.CrossoverPercentSignLabel.Enabled = false;
            this.CrossoverPercentSignLabel.Location = new System.Drawing.Point(227, 87);
            this.CrossoverPercentSignLabel.Name = "CrossoverPercentSignLabel";
            this.CrossoverPercentSignLabel.Size = new System.Drawing.Size(15, 13);
            this.CrossoverPercentSignLabel.TabIndex = 15;
            this.CrossoverPercentSignLabel.Text = "%";
            // 
            // ReplacementPercentTextbox
            // 
            this.ReplacementPercentTextbox.Enabled = false;
            this.ReplacementPercentTextbox.Location = new System.Drawing.Point(172, 171);
            this.ReplacementPercentTextbox.Name = "ReplacementPercentTextbox";
            this.ReplacementPercentTextbox.Size = new System.Drawing.Size(50, 20);
            this.ReplacementPercentTextbox.TabIndex = 13;
            this.ReplacementPercentTextbox.Text = "50";
            // 
            // MutationProbTextbox
            // 
            this.MutationProbTextbox.Enabled = false;
            this.MutationProbTextbox.Location = new System.Drawing.Point(171, 117);
            this.MutationProbTextbox.Name = "MutationProbTextbox";
            this.MutationProbTextbox.Size = new System.Drawing.Size(50, 20);
            this.MutationProbTextbox.TabIndex = 12;
            this.MutationProbTextbox.Text = "1";
            // 
            // CrossoverProbTextbox
            // 
            this.CrossoverProbTextbox.Enabled = false;
            this.CrossoverProbTextbox.Location = new System.Drawing.Point(171, 87);
            this.CrossoverProbTextbox.Name = "CrossoverProbTextbox";
            this.CrossoverProbTextbox.Size = new System.Drawing.Size(50, 20);
            this.CrossoverProbTextbox.TabIndex = 11;
            this.CrossoverProbTextbox.Text = "70";
            // 
            // ReplacementPercentLabel
            // 
            this.ReplacementPercentLabel.AutoSize = true;
            this.ReplacementPercentLabel.Enabled = false;
            this.ReplacementPercentLabel.Location = new System.Drawing.Point(22, 174);
            this.ReplacementPercentLabel.Name = "ReplacementPercentLabel";
            this.ReplacementPercentLabel.Size = new System.Drawing.Size(133, 13);
            this.ReplacementPercentLabel.TabIndex = 9;
            this.ReplacementPercentLabel.Text = "Replacement percentage :";
            // 
            // MutationProbLabel
            // 
            this.MutationProbLabel.AutoSize = true;
            this.MutationProbLabel.Enabled = false;
            this.MutationProbLabel.Location = new System.Drawing.Point(21, 117);
            this.MutationProbLabel.Name = "MutationProbLabel";
            this.MutationProbLabel.Size = new System.Drawing.Size(104, 13);
            this.MutationProbLabel.TabIndex = 8;
            this.MutationProbLabel.Text = "Mutation probability :";
            // 
            // nbGenerationsTextBox
            // 
            this.nbGenerationsTextBox.Enabled = false;
            this.nbGenerationsTextBox.Location = new System.Drawing.Point(172, 26);
            this.nbGenerationsTextBox.Name = "nbGenerationsTextBox";
            this.nbGenerationsTextBox.Size = new System.Drawing.Size(50, 20);
            this.nbGenerationsTextBox.TabIndex = 7;
            this.nbGenerationsTextBox.Text = "20";
            // 
            // CrossoverProbLabel
            // 
            this.CrossoverProbLabel.AutoSize = true;
            this.CrossoverProbLabel.Enabled = false;
            this.CrossoverProbLabel.Location = new System.Drawing.Point(21, 87);
            this.CrossoverProbLabel.Name = "CrossoverProbLabel";
            this.CrossoverProbLabel.Size = new System.Drawing.Size(110, 13);
            this.CrossoverProbLabel.TabIndex = 6;
            this.CrossoverProbLabel.Text = "Crossover probability :";
            // 
            // NbGenerationsLabel
            // 
            this.NbGenerationsLabel.AutoSize = true;
            this.NbGenerationsLabel.Enabled = false;
            this.NbGenerationsLabel.Location = new System.Drawing.Point(22, 26);
            this.NbGenerationsLabel.Name = "NbGenerationsLabel";
            this.NbGenerationsLabel.Size = new System.Drawing.Size(120, 13);
            this.NbGenerationsLabel.TabIndex = 2;
            this.NbGenerationsLabel.Text = "Number of generations :";
            // 
            // OptimisationSimulationParams
            // 
            this.OptimisationSimulationParams.Controls.Add(this.labelUniverseSize);
            this.OptimisationSimulationParams.Controls.Add(this.label15);
            this.OptimisationSimulationParams.Controls.Add(this.textBoxRepriceFinalSimulations);
            this.OptimisationSimulationParams.Controls.Add(this.labelSimulationsFinalPop);
            this.OptimisationSimulationParams.Controls.Add(this.checkBoxRepriceFinalPop);
            this.OptimisationSimulationParams.Controls.Add(this.combBoxOptimGoal);
            this.OptimisationSimulationParams.Controls.Add(this.label1);
            this.OptimisationSimulationParams.Controls.Add(this.textBoxBasketSize);
            this.OptimisationSimulationParams.Controls.Add(this.label13);
            this.OptimisationSimulationParams.Controls.Add(this.textBoxSimulations);
            this.OptimisationSimulationParams.Controls.Add(this.label4);
            this.OptimisationSimulationParams.Controls.Add(this.comboBoxRateModel);
            this.OptimisationSimulationParams.Controls.Add(this.label3);
            this.OptimisationSimulationParams.Controls.Add(this.comboBoxStockModel);
            this.OptimisationSimulationParams.Controls.Add(this.label2);
            this.OptimisationSimulationParams.Location = new System.Drawing.Point(16, 45);
            this.OptimisationSimulationParams.Name = "OptimisationSimulationParams";
            this.OptimisationSimulationParams.Size = new System.Drawing.Size(530, 158);
            this.OptimisationSimulationParams.TabIndex = 1;
            this.OptimisationSimulationParams.TabStop = false;
            this.OptimisationSimulationParams.Text = " ";
            // 
            // labelUniverseSize
            // 
            this.labelUniverseSize.AutoSize = true;
            this.labelUniverseSize.Location = new System.Drawing.Point(306, 22);
            this.labelUniverseSize.Name = "labelUniverseSize";
            this.labelUniverseSize.Size = new System.Drawing.Size(13, 13);
            this.labelUniverseSize.TabIndex = 16;
            this.labelUniverseSize.Text = "0";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(265, 22);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(27, 13);
            this.label15.TabIndex = 15;
            this.label15.Text = "from";
            // 
            // textBoxRepriceFinalSimulations
            // 
            this.textBoxRepriceFinalSimulations.Enabled = false;
            this.textBoxRepriceFinalSimulations.Location = new System.Drawing.Point(368, 118);
            this.textBoxRepriceFinalSimulations.Name = "textBoxRepriceFinalSimulations";
            this.textBoxRepriceFinalSimulations.Size = new System.Drawing.Size(124, 20);
            this.textBoxRepriceFinalSimulations.TabIndex = 14;
            this.textBoxRepriceFinalSimulations.Text = "30000";
            // 
            // labelSimulationsFinalPop
            // 
            this.labelSimulationsFinalPop.AutoSize = true;
            this.labelSimulationsFinalPop.Enabled = false;
            this.labelSimulationsFinalPop.Location = new System.Drawing.Point(267, 118);
            this.labelSimulationsFinalPop.Name = "labelSimulationsFinalPop";
            this.labelSimulationsFinalPop.Size = new System.Drawing.Size(66, 13);
            this.labelSimulationsFinalPop.TabIndex = 13;
            this.labelSimulationsFinalPop.Text = "Simulations :";
            // 
            // checkBoxRepriceFinalPop
            // 
            this.checkBoxRepriceFinalPop.AutoSize = true;
            this.checkBoxRepriceFinalPop.Location = new System.Drawing.Point(270, 91);
            this.checkBoxRepriceFinalPop.Name = "checkBoxRepriceFinalPop";
            this.checkBoxRepriceFinalPop.Size = new System.Drawing.Size(137, 17);
            this.checkBoxRepriceFinalPop.TabIndex = 12;
            this.checkBoxRepriceFinalPop.Text = "Reprice final population";
            this.checkBoxRepriceFinalPop.UseVisualStyleBackColor = true;
            this.checkBoxRepriceFinalPop.CheckedChanged += new System.EventHandler(this.checkBoxRepriceFinalPop_CheckedChanged);
            // 
            // combBoxOptimGoal
            // 
            this.combBoxOptimGoal.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combBoxOptimGoal.FormattingEnabled = true;
            this.combBoxOptimGoal.Items.AddRange(new object[] {
            "Mimimize",
            "Maximize"});
            this.combBoxOptimGoal.Location = new System.Drawing.Point(368, 64);
            this.combBoxOptimGoal.Name = "combBoxOptimGoal";
            this.combBoxOptimGoal.Size = new System.Drawing.Size(124, 21);
            this.combBoxOptimGoal.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(267, 67);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(95, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Optimization Goal :";
            // 
            // textBoxBasketSize
            // 
            this.textBoxBasketSize.Location = new System.Drawing.Point(110, 19);
            this.textBoxBasketSize.Name = "textBoxBasketSize";
            this.textBoxBasketSize.Size = new System.Drawing.Size(124, 20);
            this.textBoxBasketSize.TabIndex = 9;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(22, 22);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(69, 13);
            this.label13.TabIndex = 8;
            this.label13.Text = "Basket Size :";
            // 
            // textBoxSimulations
            // 
            this.textBoxSimulations.Location = new System.Drawing.Point(110, 111);
            this.textBoxSimulations.Name = "textBoxSimulations";
            this.textBoxSimulations.Size = new System.Drawing.Size(124, 20);
            this.textBoxSimulations.TabIndex = 7;
            this.textBoxSimulations.Text = "5000";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 114);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Simulations :";
            // 
            // comboBoxRateModel
            // 
            this.comboBoxRateModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxRateModel.FormattingEnabled = true;
            this.comboBoxRateModel.Items.AddRange(new object[] {
            "Deterministic",
            "No Stochastic Drift HJM",
            "HJM",
            "HJM CMS 10Y",
            "HJM Replic"});
            this.comboBoxRateModel.Location = new System.Drawing.Point(110, 84);
            this.comboBoxRateModel.Name = "comboBoxRateModel";
            this.comboBoxRateModel.Size = new System.Drawing.Size(124, 21);
            this.comboBoxRateModel.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Rate Model :";
            // 
            // comboBoxStockModel
            // 
            this.comboBoxStockModel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxStockModel.FormattingEnabled = true;
            this.comboBoxStockModel.Items.AddRange(new object[] {
            "Black-Scholes",
            "Copula",
            "Local Volatility",
            "PSkew",
            "Local Stochastic Volatility",
            "Local Volatility IFC",
            "Local Volatility Buehler",
            "Bates"});
            this.comboBoxStockModel.Location = new System.Drawing.Point(110, 52);
            this.comboBoxStockModel.Name = "comboBoxStockModel";
            this.comboBoxStockModel.Size = new System.Drawing.Size(124, 21);
            this.comboBoxStockModel.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Stock Model :";
            // 
            // buttonViewResults
            // 
            this.buttonViewResults.Enabled = false;
            this.buttonViewResults.Location = new System.Drawing.Point(639, 645);
            this.buttonViewResults.Name = "buttonViewResults";
            this.buttonViewResults.Size = new System.Drawing.Size(85, 46);
            this.buttonViewResults.TabIndex = 16;
            this.buttonViewResults.Text = "View Results";
            this.buttonViewResults.UseVisualStyleBackColor = true;
            this.buttonViewResults.Click += new System.EventHandler(this.buttonViewResults_Click);
            // 
            // OptimizerLauncher
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 716);
            this.Controls.Add(this.buttonViewResults);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.buttonGoBack);
            this.Controls.Add(this.labelHeader);
            this.Controls.Add(this.GAprogressGroupBox);
            this.Controls.Add(this.GAoptionsCheckBox);
            this.Controls.Add(this.GAparamsGroupBox);
            this.Controls.Add(this.OptimisationSimulationParams);
            this.Name = "OptimizerLauncher";
            this.Text = "OptimizerLauncher";
            this.GAprogressGroupBox.ResumeLayout(false);
            this.GAprogressGroupBox.PerformLayout();
            this.GAparamsGroupBox.ResumeLayout(false);
            this.GAparamsGroupBox.PerformLayout();
            this.OptimisationSimulationParams.ResumeLayout(false);
            this.OptimisationSimulationParams.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox OptimisationSimulationParams;
        private System.Windows.Forms.TextBox textBoxSimulations;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBoxRateModel;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBoxStockModel;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox GAparamsGroupBox;
        private System.Windows.Forms.TextBox nbGenerationsTextBox;
        private System.Windows.Forms.Label CrossoverProbLabel;
        private System.Windows.Forms.Label NbGenerationsLabel;
        private System.Windows.Forms.CheckBox GAoptionsCheckBox;
        private System.Windows.Forms.Label ReplacementPercentSignLabel;
        private System.Windows.Forms.Label MutationpercentSignLabel;
        private System.Windows.Forms.Label CrossoverPercentSignLabel;
        private System.Windows.Forms.TextBox ReplacementPercentTextbox;
        private System.Windows.Forms.TextBox MutationProbTextbox;
        private System.Windows.Forms.TextBox CrossoverProbTextbox;
        private System.Windows.Forms.Label ReplacementPercentLabel;
        private System.Windows.Forms.Label MutationProbLabel;
        private System.Windows.Forms.TextBox textBoxBasketSize;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ComboBox combBoxOptimGoal;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button StartButton;
        private System.Windows.Forms.TextBox textBoxPopulationSize;
        private System.Windows.Forms.Label labelPopulationSize;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TournamentWinPercentTextBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBoxSortBasis;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBoxSelectionMethod;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBoxReinsertionMethod;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBoxCrossoverMethod;
        private System.ComponentModel.BackgroundWorker backgroundWorker;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.GroupBox GAprogressGroupBox;
        private System.Windows.Forms.Label labelBestBasketPremium;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label labelBestBasketComposition;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label labelNgenerations;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label labelGenerationCounter;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label labelProgress;
        private System.Windows.Forms.CheckBox checkBoxRepriceFinalPop;
        private System.Windows.Forms.TextBox textBoxRepriceFinalSimulations;
        private System.Windows.Forms.Label labelSimulationsFinalPop;
        private System.Windows.Forms.Label labelHeader;
        private System.Windows.Forms.Button buttonGoBack;
        private System.Windows.Forms.Label labelUniverseSize;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button buttonStopOptim;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label labelBestBasketGeneration;
        private System.Windows.Forms.Button buttonViewResults;
    }
}