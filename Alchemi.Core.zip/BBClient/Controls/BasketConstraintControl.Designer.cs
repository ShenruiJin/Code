﻿using RemotingInterfaces;
namespace BBClient
{
    partial class BasketConstraintControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this._comboBoxMnemonics = new System.Windows.Forms.ComboBox();
            this.bbgFieldsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cCDataSet = new CCDataSet();
            this.mnemonicsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this._comboBoxEquality = new System.Windows.Forms.ComboBox();
            this._textBoxValue = new System.Windows.Forms.TextBox();
            this._toolTip = new System.Windows.Forms.ToolTip(this.components);
            this._buttonRemove = new System.Windows.Forms.Button();
            this.bbgDescriptiveFieldsTableAdapter = new RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.bbgFieldsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.mnemonicsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // _comboBoxMnemonics
            // 
            this._comboBoxMnemonics.DataSource = this.bbgFieldsBindingSource;
            this._comboBoxMnemonics.DisplayMember = "Description";
            this._comboBoxMnemonics.FormattingEnabled = true;
            this._comboBoxMnemonics.Location = new System.Drawing.Point(3, 3);
            this._comboBoxMnemonics.Name = "_comboBoxMnemonics";
            this._comboBoxMnemonics.Size = new System.Drawing.Size(190, 21);
            this._comboBoxMnemonics.TabIndex = 0;
            this._comboBoxMnemonics.ValueMember = "Field";
            this._comboBoxMnemonics.SelectedIndexChanged += new System.EventHandler(this._comboBoxMnemonics_SelectedIndexChanged);
            // 
            // bbgFieldsBindingSource
            // 
            this.bbgFieldsBindingSource.DataMember = "BbgDescriptiveFields";
            this.bbgFieldsBindingSource.DataSource = this.cCDataSet;
            // 
            // cCDataSet
            // 
            this.cCDataSet.DataSetName = "CCDataSet";
            this.cCDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // mnemonicsBindingSource
            // 
            this.mnemonicsBindingSource.DataMember = "Mnemonics";
            this.mnemonicsBindingSource.DataSource = this.cCDataSet;
            // 
            // _comboBoxEquality
            // 
            this._comboBoxEquality.FormattingEnabled = true;
            this._comboBoxEquality.Location = new System.Drawing.Point(199, 3);
            this._comboBoxEquality.Name = "_comboBoxEquality";
            this._comboBoxEquality.Size = new System.Drawing.Size(50, 21);
            this._comboBoxEquality.TabIndex = 1;
            this._comboBoxEquality.SelectedIndexChanged += new System.EventHandler(this._comboBoxEquality_SelectedIndexChanged);
            // 
            // _textBoxValue
            // 
            this._textBoxValue.Location = new System.Drawing.Point(255, 3);
            this._textBoxValue.Name = "_textBoxValue";
            this._textBoxValue.Size = new System.Drawing.Size(191, 20);
            this._textBoxValue.TabIndex = 2;
            this._toolTip.SetToolTip(this._textBoxValue, "_toolTip");
            // 
            // _toolTip
            // 
            this._toolTip.AutoPopDelay = 2000;
            this._toolTip.InitialDelay = 100;
            this._toolTip.ReshowDelay = 100;
            // 
            // _buttonRemove
            // 
            this._buttonRemove.Location = new System.Drawing.Point(452, 1);
            this._buttonRemove.Name = "_buttonRemove";
            this._buttonRemove.Size = new System.Drawing.Size(61, 23);
            this._buttonRemove.TabIndex = 3;
            this._buttonRemove.Text = "Remove";
            this._buttonRemove.UseVisualStyleBackColor = true;
            this._buttonRemove.Click += new System.EventHandler(this._buttonRemove_Click);
            // 
            // bbgDescriptiveFieldsTableAdapter
            // 
            this.bbgDescriptiveFieldsTableAdapter.ClearBeforeFill = true;
            // 
            // BasketConstraintControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._buttonRemove);
            this.Controls.Add(this._textBoxValue);
            this.Controls.Add(this._comboBoxEquality);
            this.Controls.Add(this._comboBoxMnemonics);
            this.Name = "BasketConstraintControl";
            this.Size = new System.Drawing.Size(517, 27);
            ((System.ComponentModel.ISupportInitialize)(this.bbgFieldsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cCDataSet)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox _comboBoxMnemonics;
        private System.Windows.Forms.ComboBox _comboBoxEquality;
        private System.Windows.Forms.TextBox _textBoxValue;
        private System.Windows.Forms.ToolTip _toolTip;
        private System.Windows.Forms.Button _buttonRemove;
        private System.Windows.Forms.BindingSource mnemonicsBindingSource;
        private CCDataSet cCDataSet;
        private System.Windows.Forms.BindingSource bbgFieldsBindingSource;
        private RemotingInterfaces.CCDataSetTableAdapters.BbgDescriptiveFieldsTableAdapter bbgDescriptiveFieldsTableAdapter;
    }
}
