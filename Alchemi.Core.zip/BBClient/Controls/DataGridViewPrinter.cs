﻿using System;
using System.Text;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Data;
using System.Windows.Forms;

namespace StructuringControls
{
    public class DataGridViewPrinter
    {
        struct DocumentTitle
        {
            public string Text;
            public Font Font;
            public Color Color;
 
            public DocumentTitle(string text, Font font, Color color)
            {
                this.Text = text;
                this.Font = font;
                this.Color = color;
            }
        }
 
        struct DocumentMetrics
        {
            public int Width;
            public int Height;
            public int LeftMargin;
            public int RightMargin;
            public int TopMargin;
            public int BottomMargin;
 
            public int PrintableWidth {
                get { return (this.Width - this.LeftMargin - this.RightMargin); }
            }
            public int PrintableHeight {
                get { return (this.Height - this.TopMargin - this.BottomMargin); }
            }
 
            public DocumentMetrics(int width, int height, int leftMargin, int rightMargin, int topMargin, int bottomMargin)
            {
                this.Width = width;
                this.Height = height;
                this.LeftMargin = leftMargin;
                this.RightMargin = rightMargin;
                this.TopMargin = topMargin;
                this.BottomMargin = bottomMargin;
            }
        }
 
 
        const float SpacingAfterHeader = 20.0f;
        const float HorizontalCellPadding = 5.0f;
        const float VerticalCellPadding = 5.0f;
 
        readonly DataGridView DgvSource;
        readonly PrintDocument PrintDocTarget;
        readonly DocumentTitle DocTitle;
        readonly DocumentMetrics DocMetrics;
        readonly Font DefaultCellFont;
        readonly Pen CellBorderPen;
        readonly StringFormat DefaultStringFormat;
 
 
        Graphics _graphics;
        int _currentRow;
        int _pageIdx; // 1-based page number would be _pageIdx + 1
        float _currentX;
        float _currentY;
        float _columnHeaderRowHeight;
        float[] _rowHeights;
        float[] _columnWidths;
        float _printedWidthOfDGV;
        float _rowHeaderColumnWidth;
        // Maintain a generic list to hold start/stop points for the column printing
        // This will be used for wrapping in situations where the DataGridView will not fit on a single page
        List<int[]> _columnRanges;
        List<float> _pageWidths;
 
 
        public DataGridViewPrinter(DataGridView dgv, PrintDocument printDoc, string titleText, Font titleFont, Color titleColor)
        {
            DgvSource = dgv;
            PrintDocTarget = printDoc;
            DocTitle = new DocumentTitle(titleText, titleFont, titleColor);
            CellBorderPen = new Pen(DgvSource.GridColor, 1);
 
            DefaultStringFormat = new StringFormat();
            DefaultStringFormat.Trimming = StringTrimming.Word;
            DefaultStringFormat.FormatFlags = StringFormatFlags.NoWrap | StringFormatFlags.LineLimit | StringFormatFlags.NoClip;
            DefaultStringFormat.Alignment = StringAlignment.Far;
 
            DefaultCellFont = DgvSource.ColumnHeadersDefaultCellStyle.Font;
            if (DefaultCellFont == null) // If there is no special HeaderFont style, then use the default DataGridView font style
                DefaultCellFont = DgvSource.DefaultCellStyle.Font;
 
            Margins margins = PrintDocTarget.DefaultPageSettings.Margins;
            DocMetrics = new DocumentMetrics(0, 0, margins.Left, margins.Right, margins.Top, margins.Bottom);
            if (!PrintDocTarget.DefaultPageSettings.Landscape) {
                DocMetrics.Width = PrintDocTarget.DefaultPageSettings.PaperSize.Width;
                DocMetrics.Height = PrintDocTarget.DefaultPageSettings.PaperSize.Height;
            } else {
                DocMetrics.Height = PrintDocTarget.DefaultPageSettings.PaperSize.Width;
                DocMetrics.Width = PrintDocTarget.DefaultPageSettings.PaperSize.Height;
            }
 
            ResetDocument();
        }
 
        void ResetDocument()
        {
            _pageIdx = 0;
            _currentRow = 0;
            _rowHeights = new float[DgvSource.Rows.Count];
            _columnWidths = new float[DgvSource.Columns.Count];
            _columnRanges = new List<int[]>();
            _pageWidths = new List<float>();
        }
 
        Font UseDefaultFontIfNull(Font fontToTry)
        {
            return (fontToTry == null ? DefaultCellFont : fontToTry);
        }
        SolidBrush SolidBrushFromForeColor(Color foreColor)
        {
            if (foreColor.IsEmpty)
                foreColor = DgvSource.DefaultCellStyle.ForeColor;
            return (new SolidBrush(foreColor));
        }
        SolidBrush SolidBrushFromBackColor(Color backColor)
        {
            if (backColor.IsEmpty)
                backColor = DgvSource.DefaultCellStyle.BackColor;
            return (new SolidBrush(backColor));
        }
        StringAlignment ContentAlignmentToStringAlignment(DataGridViewContentAlignment contentAlignment)
        {
            string stringRep = contentAlignment.ToString();
 
            if (stringRep.Contains("Right"))
                return (StringAlignment.Far);
 
            if (stringRep.Contains("Center"))
                return (StringAlignment.Center);
 
            return (StringAlignment.Near);
        }
        StringFormat NewStringFormatWithAlignment(DataGridViewContentAlignment contentAlignment)
        {
            StringFormat cellFormat = DefaultStringFormat.Clone() as StringFormat;
            cellFormat.Alignment = ContentAlignmentToStringAlignment(contentAlignment);
            return (cellFormat);
        }
        RectangleF GetPaddedCellBounds(float width, float height)
        {
            // retruns a region at the current X,Y where cell text can be drawn
            // takes cell padding into account when creating the region
            return (new RectangleF(_currentX + HorizontalCellPadding, _currentY + VerticalCellPadding, width - 2 * HorizontalCellPadding, height - 2 * VerticalCellPadding));
        }
 
        void CalculateTableDimensions()
        {
            // COLUMN OF ROW HEADERS
            for (int rowIdx = 0; rowIdx < DgvSource.Rows.Count; ++rowIdx) {
                DataGridViewCell rowHeader = DgvSource.Rows[rowIdx].HeaderCell;
                Font headerFont = UseDefaultFontIfNull(rowHeader.Style.Font);
                SizeF cellMetrics = _graphics.MeasureString(rowHeader.EditedFormattedValue.ToString(), headerFont);
                _rowHeaderColumnWidth = Math.Max(_rowHeaderColumnWidth, cellMetrics.Width);
                _rowHeights[rowIdx] = cellMetrics.Height + 2 * VerticalCellPadding;  // padding
            }
            _rowHeaderColumnWidth += 2 * HorizontalCellPadding;  // padding
            _printedWidthOfDGV += _rowHeaderColumnWidth;
 
            // EVERY OTHER COLUMN
            for (int columnIdx = 0; columnIdx < DgvSource.Columns.Count; ++columnIdx) {
                DataGridViewColumn column = DgvSource.Columns[columnIdx];
 
                Font headerFont = UseDefaultFontIfNull(column.HeaderCell.Style.Font);
                SizeF cellMetrics = _graphics.MeasureString(column.HeaderText, headerFont);
                _columnHeaderRowHeight = cellMetrics.Height + 2 * VerticalCellPadding;  // padding
                float columnWidth = cellMetrics.Width;
 
                for (int rowIdx = 0; rowIdx < DgvSource.Rows.Count; ++rowIdx) {
                    DataGridViewCell cell = DgvSource.Rows[rowIdx].Cells[columnIdx];
                    Font cellFont = UseDefaultFontIfNull(cell.Style.Font);
                    cellMetrics = _graphics.MeasureString(cell.EditedFormattedValue.ToString(), cellFont);
                    float cellHeight = cellMetrics.Height + 2 * VerticalCellPadding;  // padding
                    _rowHeights[rowIdx] = Math.Max(_rowHeights[rowIdx], cellHeight);
                    columnWidth = Math.Max(columnWidth, cellMetrics.Width);
                }
 
                columnWidth += 2 * HorizontalCellPadding;  // padding
                _columnWidths[columnIdx] = columnWidth;
                if (column.Visible)
                    _printedWidthOfDGV += columnWidth;
            }
        }
        void BreakDocumentIntoPages()
        {
            if (_printedWidthOfDGV <= DocMetrics.PrintableWidth) {
                // All columns can fit on one page
                _pageWidths.Add(_printedWidthOfDGV);
                _columnRanges.Add(new int[] { 0, DgvSource.Columns.Count });
                return;
            }
 
            // We need to break the grid up into multiple pages
            float widthOnThisPage = _rowHeaderColumnWidth;  // row header goes on every page
            int startColumnOnThisPage = 0;
 
            for (int columnIdx = 0; columnIdx < DgvSource.Columns.Count; ++columnIdx) {
                if (!DgvSource.Columns[columnIdx].Visible)
                    continue;
 
                float columnWidth = _columnWidths[columnIdx];
 
                if (widthOnThisPage + columnWidth <= DocMetrics.PrintableWidth) {
                    // This column will fit
                    widthOnThisPage += columnWidth;
                    continue;
                }
 
                // This column will not fit. Save this column print range and start the next
                _columnRanges.Add(new int[] { startColumnOnThisPage, columnIdx });
                _pageWidths.Add(widthOnThisPage);
                startColumnOnThisPage = columnIdx;
                widthOnThisPage = columnWidth;
            }
 
            _columnRanges.Add(new int[] { startColumnOnThisPage, DgvSource.Columns.Count });
            _pageWidths.Add(widthOnThisPage);
        }
        void PrepareDocumentForPrinting()
        {
            CalculateTableDimensions();
            BreakDocumentIntoPages();
        }
 
        void PrintPageNumber(int pageNumber)
        {
            string pageString = "Page " + pageNumber.ToString();
 
            Font stringFont = new Font("Tahoma", 8, FontStyle.Regular, GraphicsUnit.Point);
            SizeF stringMetrics = _graphics.MeasureString(pageString, stringFont);
            RectangleF stringRectangle = new RectangleF(DocMetrics.LeftMargin, _currentY, DocMetrics.PrintableWidth, stringMetrics.Height);
            _graphics.DrawString(pageString, stringFont, new SolidBrush(Color.Black), stringRectangle, DefaultStringFormat);
 
            _currentY += stringMetrics.Height + SpacingAfterHeader / 2;
        }
        void PrintTitle()
        {
            SizeF stringMetrics = _graphics.MeasureString(DocTitle.Text, DocTitle.Font);
            RectangleF titleRectangle = new RectangleF(DocMetrics.LeftMargin, _currentY, DocMetrics.PrintableWidth, stringMetrics.Height);
            StringFormat titleFormat = NewStringFormatWithAlignment(DataGridViewContentAlignment.MiddleCenter);
 
            _graphics.DrawString(DocTitle.Text, DocTitle.Font, new SolidBrush(DocTitle.Color), titleRectangle, titleFormat);
 
            _currentY += stringMetrics.Height + SpacingAfterHeader;
        }
        void DrawTableHeader()
        {
            _currentX = DocMetrics.LeftMargin + (DocMetrics.PrintableWidth - _pageWidths[_pageIdx]) * 0.5F;
 
            SolidBrush headerForeBrush = SolidBrushFromForeColor(DgvSource.ColumnHeadersDefaultCellStyle.ForeColor);
            SolidBrush headerBackBrush = SolidBrushFromBackColor(DgvSource.ColumnHeadersDefaultCellStyle.BackColor);
            Font headerFont = UseDefaultFontIfNull(DgvSource.ColumnHeadersDefaultCellStyle.Font);
            RectangleF headerBounds = new RectangleF(_currentX, _currentY, _pageWidths[_pageIdx], _columnHeaderRowHeight);
 
            _graphics.FillRectangle(headerBackBrush, headerBounds);
 
            // Draw the empty cell in the top left of every grid
            if (DgvSource.RowHeadersBorderStyle != DataGridViewHeaderBorderStyle.None)
                _graphics.DrawRectangle(CellBorderPen, _currentX, _currentY, _rowHeaderColumnWidth, _columnHeaderRowHeight);
            _currentX += _rowHeaderColumnWidth;
 
            for (int columnIdx = _columnRanges[_pageIdx][0]; columnIdx < _columnRanges[_pageIdx][1]; ++columnIdx) {
                if (!DgvSource.Columns[columnIdx].Visible)
                    continue;
 
                float columnWidth = _columnWidths[columnIdx];
 
                StringFormat cellFormat = NewStringFormatWithAlignment(DgvSource.ColumnHeadersDefaultCellStyle.Alignment);
 
                RectangleF cellBoundsText = GetPaddedCellBounds(columnWidth, _columnHeaderRowHeight);
                _graphics.DrawString(DgvSource.Columns[columnIdx].HeaderText, headerFont, headerForeBrush, cellBoundsText, cellFormat);
 
                // Drawing the cell bounds
                if (DgvSource.RowHeadersBorderStyle != DataGridViewHeaderBorderStyle.None) // Draw the cell border only if the HeaderBorderStyle is not None
                    _graphics.DrawRectangle(CellBorderPen, _currentX, _currentY, columnWidth, _columnHeaderRowHeight);
 
                _currentX += columnWidth;
            }
        }
        void DrawStaticPageElements()
        {
            _currentY = DocMetrics.TopMargin;
 
            PrintPageNumber(_pageIdx + 1);
            PrintTitle();
            DrawTableHeader();
 
            _currentY += _columnHeaderRowHeight;
        }
 
        void DrawRowHeader()
        {
            DataGridViewCell headerCell = DgvSource.Rows[_currentRow].HeaderCell;
            DataGridViewCellStyle headerStyle = headerCell.Style;
            Font cellFont = UseDefaultFontIfNull(headerStyle.Font);
            SolidBrush rowForeBrush = SolidBrushFromForeColor(headerStyle.ForeColor);
 
            StringFormat cellFormat = NewStringFormatWithAlignment(headerStyle.Alignment);
 
            // Printing the cell text
            RectangleF cellBoundsText = GetPaddedCellBounds(_rowHeaderColumnWidth, _rowHeights[_currentRow]);
            _graphics.DrawString(headerCell.EditedFormattedValue.ToString(), cellFont, rowForeBrush, cellBoundsText, cellFormat);
 
            // Drawing the cell bounds            
            if (DgvSource.CellBorderStyle != DataGridViewCellBorderStyle.None) // Draw the cell border only if the CellBorderStyle is not None
                _graphics.DrawRectangle(CellBorderPen, _currentX, _currentY, _rowHeaderColumnWidth, _rowHeights[_currentRow]);
        }
        void DrawCellContents(int columnIdx, float rowHeight)
        {
            DataGridViewCell cell = DgvSource.Rows[_currentRow].Cells[columnIdx];
            float columnWidth = _columnWidths[columnIdx];
            Font cellFont = UseDefaultFontIfNull(cell.Style.Font);
            SolidBrush cellForeBrush = SolidBrushFromForeColor(cell.Style.ForeColor);
 
            DataGridViewContentAlignment alignment = cell.Style.Alignment;
            if (alignment == DataGridViewContentAlignment.NotSet) {
                alignment = DgvSource.Columns[columnIdx].CellTemplate.Style.Alignment;
                if (alignment == DataGridViewContentAlignment.NotSet)
                    alignment = DgvSource.Columns[columnIdx].DefaultCellStyle.Alignment;
            }
            StringFormat cellFormat = NewStringFormatWithAlignment(alignment);
 
            // Printing the cell text
            RectangleF cellBoundsText = GetPaddedCellBounds(columnWidth, rowHeight);
            _graphics.DrawString(cell.EditedFormattedValue.ToString(), cellFont, cellForeBrush, cellBoundsText, cellFormat);
 
            // Drawing the cell bounds
            if (DgvSource.CellBorderStyle != DataGridViewCellBorderStyle.None)
                _graphics.DrawRectangle(CellBorderPen, _currentX, _currentY, columnWidth, rowHeight);
        }
        void DrawRowContents()
        {
            DataGridViewRow row = DgvSource.Rows[_currentRow];
            float rowHeight = _rowHeights[_currentRow];
            RectangleF rowBounds = new RectangleF(_currentX, _currentY, _pageWidths[_pageIdx], rowHeight);
 
            SolidBrush rowBackBrush;
            if (!row.DefaultCellStyle.BackColor.IsEmpty)
                rowBackBrush = new SolidBrush(row.DefaultCellStyle.BackColor);
            else if (_currentRow % 2 == 0)
                rowBackBrush = new SolidBrush(DgvSource.DefaultCellStyle.BackColor);
            else
                rowBackBrush = new SolidBrush(DgvSource.AlternatingRowsDefaultCellStyle.BackColor);
 
            // Filling the back of the CurrentRow
            _graphics.FillRectangle(rowBackBrush, rowBounds);
 
            // Printing each visible cell of the CurrentRow                
            for (int columnIdx = _columnRanges[_pageIdx][0]; columnIdx < _columnRanges[_pageIdx][1]; ++columnIdx) {
                if (!DgvSource.Columns[columnIdx].Visible)
                    continue;
 
                DrawCellContents(columnIdx, rowHeight);
                _currentX += _columnWidths[columnIdx];
            }
        }
        bool DrawOnePage()
        { // return value:   true => more to print   false => everything has been printed
 
            int startingRow = _currentRow;
 
            // Printing each visible cell
            for ( ; _currentRow < DgvSource.Rows.Count; ++_currentRow) {
                if (!DgvSource.Rows[_currentRow].Visible)
                    continue;
 
                // If there is no more space left on the page,
                // the next call will pick up here
                if (_currentY > DocMetrics.PrintableHeight)
                    return (true);
 
                _currentX = DocMetrics.LeftMargin + (DocMetrics.PrintableWidth - _pageWidths[_pageIdx]) / 2.0F;
 
                DrawRowHeader();
                _currentX += _rowHeaderColumnWidth;
 
                DrawRowContents();
                _currentY += _rowHeights[_currentRow];
            }
 
            // If we need to print more columns for the same set of rows,
            // we'll need to start at the same row as before
            _currentRow = startingRow;
 
            // return 'true' only if there are more columns to print for the same
            // rows we printed here
            ++_pageIdx;
            return (false); //_pageIdx < _columnRanges.Count);       
        }
 
 
 
 
        // The method that calls all other functions
        public bool DrawDataGridView(Graphics g)
        {
            bool morePagesToPrint = false;
 
            _graphics = g;
 
            try {
                if (_pageIdx == 0)
                    PrepareDocumentForPrinting();
                DrawStaticPageElements();
                morePagesToPrint = DrawOnePage();
                ++_pageIdx;
            } catch (Exception ex) {
#if DEBUG
                Console.WriteLine("Exception in DrawDataGridViewPrinter: " + ex.ToString());
#endif
                MessageBox.Show("Printing failed: " + ex.Message, "Where is my CC", MessageBoxButtons.OK, MessageBoxIcon.Error);
 
                return (false);
            } finally {
                if (!morePagesToPrint)
                    ResetDocument();
            }
 
            return (morePagesToPrint);
        }
    }
}