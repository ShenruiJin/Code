﻿namespace BBClient
{
    partial class BasketDefinition
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            this._groupBoxParameters = new System.Windows.Forms.GroupBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this._panelBasketDefinitions = new System.Windows.Forms.Panel();
            this._panelConstraintsSet = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this._checkBoxStockConstraint = new System.Windows.Forms.CheckBox();
            this._textBoxConstraint = new System.Windows.Forms.TextBox();
            this._buttonAddSubBasket = new System.Windows.Forms.Button();
            this._buttonPreview = new System.Windows.Forms.Button();
            this._panelUnderlyingsUnion = new System.Windows.Forms.Panel();
            this._copyPasteGridViewUnderlyings = new StructuringControls.ExcelDataGridView();
            this._buttonClearCustomList = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this._groupBoxParameters.SuspendLayout();
            this.panel2.SuspendLayout();
            this._panelBasketDefinitions.SuspendLayout();
            this.panel1.SuspendLayout();
            this._panelUnderlyingsUnion.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this._copyPasteGridViewUnderlyings)).BeginInit();
            this.SuspendLayout();
            // 
            // _groupBoxParameters
            // 
            this._groupBoxParameters.Controls.Add(this.panel2);
            this._groupBoxParameters.Dock = System.Windows.Forms.DockStyle.Fill;
            this._groupBoxParameters.Location = new System.Drawing.Point(0, 0);
            this._groupBoxParameters.Name = "_groupBoxParameters";
            this._groupBoxParameters.Size = new System.Drawing.Size(728, 396);
            this._groupBoxParameters.TabIndex = 4;
            this._groupBoxParameters.TabStop = false;
            this._groupBoxParameters.Text = "Basket constraints";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this._panelBasketDefinitions);
            this.panel2.Controls.Add(this._panelUnderlyingsUnion);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(3, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(722, 377);
            this.panel2.TabIndex = 6;
            // 
            // _panelBasketDefinitions
            // 
            this._panelBasketDefinitions.AutoScroll = true;
            this._panelBasketDefinitions.Controls.Add(this._panelConstraintsSet);
            this._panelBasketDefinitions.Controls.Add(this.panel1);
            this._panelBasketDefinitions.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelBasketDefinitions.Location = new System.Drawing.Point(151, 0);
            this._panelBasketDefinitions.Name = "_panelBasketDefinitions";
            this._panelBasketDefinitions.Size = new System.Drawing.Size(571, 377);
            this._panelBasketDefinitions.TabIndex = 7;
            // 
            // _panelConstraintsSet
            // 
            this._panelConstraintsSet.AutoScroll = true;
            this._panelConstraintsSet.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelConstraintsSet.Location = new System.Drawing.Point(0, 34);
            this._panelConstraintsSet.Name = "_panelConstraintsSet";
            this._panelConstraintsSet.Size = new System.Drawing.Size(571, 343);
            this._panelConstraintsSet.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._checkBoxStockConstraint);
            this.panel1.Controls.Add(this._textBoxConstraint);
            this.panel1.Controls.Add(this._buttonAddSubBasket);
            this.panel1.Controls.Add(this._buttonPreview);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(571, 34);
            this.panel1.TabIndex = 5;
            // 
            // _checkBoxStockConstraint
            // 
            this._checkBoxStockConstraint.AutoSize = true;
            this._checkBoxStockConstraint.Location = new System.Drawing.Point(30, 6);
            this._checkBoxStockConstraint.Name = "_checkBoxStockConstraint";
            this._checkBoxStockConstraint.Size = new System.Drawing.Size(143, 17);
            this._checkBoxStockConstraint.TabIndex = 7;
            this._checkBoxStockConstraint.Text = "Has nb stocks constraint";
            this._checkBoxStockConstraint.UseVisualStyleBackColor = true;
            this._checkBoxStockConstraint.CheckedChanged += new System.EventHandler(this._checkBoxStockConstraint_CheckedChanged);
            // 
            // _textBoxConstraint
            // 
            this._textBoxConstraint.Enabled = false;
            this._textBoxConstraint.Location = new System.Drawing.Point(174, 4);
            this._textBoxConstraint.Name = "_textBoxConstraint";
            this._textBoxConstraint.Size = new System.Drawing.Size(100, 20);
            this._textBoxConstraint.TabIndex = 6;
            this._textBoxConstraint.Text = "3";
            // 
            // _buttonAddSubBasket
            // 
            this._buttonAddSubBasket.Location = new System.Drawing.Point(314, 0);
            this._buttonAddSubBasket.Name = "_buttonAddSubBasket";
            this._buttonAddSubBasket.Size = new System.Drawing.Size(100, 23);
            this._buttonAddSubBasket.TabIndex = 4;
            this._buttonAddSubBasket.Text = "Add subbasket";
            this._buttonAddSubBasket.UseVisualStyleBackColor = true;
            this._buttonAddSubBasket.Click += new System.EventHandler(this._buttonAddSubBasket_Click);
            // 
            // _buttonPreview
            // 
            this._buttonPreview.Location = new System.Drawing.Point(457, 0);
            this._buttonPreview.Name = "_buttonPreview";
            this._buttonPreview.Size = new System.Drawing.Size(111, 23);
            this._buttonPreview.TabIndex = 0;
            this._buttonPreview.Text = "Preview Basket";
            this._buttonPreview.UseVisualStyleBackColor = true;
            this._buttonPreview.Click += new System.EventHandler(this._buttonPreview_Click);
            // 
            // _panelUnderlyingsUnion
            // 
            this._panelUnderlyingsUnion.Controls.Add(this._copyPasteGridViewUnderlyings);
            this._panelUnderlyingsUnion.Controls.Add(this._buttonClearCustomList);
            this._panelUnderlyingsUnion.Dock = System.Windows.Forms.DockStyle.Left;
            this._panelUnderlyingsUnion.Location = new System.Drawing.Point(0, 0);
            this._panelUnderlyingsUnion.Name = "_panelUnderlyingsUnion";
            this._panelUnderlyingsUnion.Size = new System.Drawing.Size(151, 377);
            this._panelUnderlyingsUnion.TabIndex = 10;
            // 
            // _copyPasteGridViewUnderlyings
            // 
            this._copyPasteGridViewUnderlyings.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LemonChiffon;
            this._copyPasteGridViewUnderlyings.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this._copyPasteGridViewUnderlyings.ClipboardCopyMode = System.Windows.Forms.DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
            this._copyPasteGridViewUnderlyings.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this._copyPasteGridViewUnderlyings.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1});
            this._copyPasteGridViewUnderlyings.Dock = System.Windows.Forms.DockStyle.Fill;
            this._copyPasteGridViewUnderlyings.Location = new System.Drawing.Point(0, 23);
            this._copyPasteGridViewUnderlyings.Name = "_copyPasteGridViewUnderlyings";
            this._copyPasteGridViewUnderlyings.RowHeadersVisible = false;
            this._copyPasteGridViewUnderlyings.Size = new System.Drawing.Size(151, 354);
            this._copyPasteGridViewUnderlyings.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this._copyPasteGridViewUnderlyings.TabIndex = 6;
            // 
            // _buttonClearCustomList
            // 
            this._buttonClearCustomList.Dock = System.Windows.Forms.DockStyle.Top;
            this._buttonClearCustomList.Location = new System.Drawing.Point(0, 0);
            this._buttonClearCustomList.Name = "_buttonClearCustomList";
            this._buttonClearCustomList.Size = new System.Drawing.Size(151, 23);
            this._buttonClearCustomList.TabIndex = 7;
            this._buttonClearCustomList.Text = "Clear list";
            this._buttonClearCustomList.UseVisualStyleBackColor = true;
            this._buttonClearCustomList.Click += new System.EventHandler(this._buttonClearCustomList_Click);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
            this.dataGridViewTextBoxColumn1.HeaderText = "Free basket";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // BasketDefinition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._groupBoxParameters);
            this.Name = "BasketDefinition";
            this.Size = new System.Drawing.Size(728, 396);
            this._groupBoxParameters.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this._panelBasketDefinitions.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this._panelUnderlyingsUnion.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this._copyPasteGridViewUnderlyings)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox _groupBoxParameters;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel _panelBasketDefinitions;
        private System.Windows.Forms.Button _buttonAddSubBasket;
        private System.Windows.Forms.Button _buttonPreview;
        private System.Windows.Forms.Panel _panelUnderlyingsUnion;
        private StructuringControls.ExcelDataGridView _copyPasteGridViewUnderlyings;
        private System.Windows.Forms.Button _buttonClearCustomList;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel _panelConstraintsSet;
        private System.Windows.Forms.CheckBox _checkBoxStockConstraint;
        private System.Windows.Forms.TextBox _textBoxConstraint;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;

    }
}
