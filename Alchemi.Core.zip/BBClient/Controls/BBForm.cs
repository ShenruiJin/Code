using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace BBClient
{
    public partial class BBForm : Form
    {
        public BBForm()
        {
            InitializeComponent();
        }

        // Multithread delegate to retrieve data
        protected delegate object RetrieveObject();

        protected delegate void TransmitStringDelegate(string msg);
        protected void ShowMessageBox(string message)
        {
            TransmitStringDelegate del = delegate(string msg)
            {
                MessageBox.Show(msg);
            };
            this.Invoke(del, new object[] { message });
        }

    }
}

