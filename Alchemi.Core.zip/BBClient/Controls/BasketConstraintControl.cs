﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace BBClient
{
    public partial class BasketConstraintControl : UserControl
    {
        public event ControlEventHandler Removed;

        public BasketConstraintControl()
        {
            InitializeComponent();

            // Retrieve data from the DB
            RetrieveData();

            _comboBoxMnemonics_SelectedIndexChanged(this, new EventArgs());
        }

		public void SetConstraint(string constraintName, string value)
		{
			for(int index = 0; index < _comboBoxMnemonics.Items.Count; index++)
			{
				if (((DataRowView)_comboBoxMnemonics.Items[index]).Row["Field"].ToString() == constraintName)
				{
					_comboBoxMnemonics.SelectedIndex = index;
					_textBoxValue.Text = value;
					return;
				}
			}
		}

		public string GetConstraint()
        {
            bool isString = ((DataRowView)_comboBoxMnemonics.SelectedItem).Row["Type"].ToString() == "string";
            // Return empty if no input
            if (_textBoxValue.Text.Trim() == String.Empty)
            {
                return String.Empty;
            }
			string selectedValue = Convert.ToString(_comboBoxEquality.SelectedValue);
			bool isIn = selectedValue == "IN" || selectedValue == "NOT IN";
            string paramString = String.Empty;
            if (isIn)
            {
                paramString += "(";
                foreach (string str in _textBoxValue.Text.Split(','))
                {
                    paramString += "'" + str.Trim() + "',";
                }
                paramString = paramString.Remove(paramString.Length - 1);
                paramString += ")";
            }
            else
            {
                paramString = isString ? "'" + _textBoxValue.Text + "'" : _textBoxValue.Text;
            }
            return Convert.ToString(_comboBoxMnemonics.SelectedValue) + " " +
                Convert.ToString(_comboBoxEquality.SelectedValue) + " " + paramString;
        }

        private void _comboBoxEquality_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Void for the moment
        }

        private void _comboBoxMnemonics_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (_comboBoxMnemonics.SelectedItem != null)
            {
                UpdateComboEquality(((DataRowView)_comboBoxMnemonics.SelectedItem).Row["Type"].ToString());
                _toolTip.SetToolTip(_textBoxValue, ((DataRowView)_comboBoxMnemonics.SelectedItem).Row["Help"].ToString());
            }
        }

        private void _buttonRemove_Click(object sender, EventArgs e)
        {
            if (Removed != null)
            {
                Removed(this, new ControlEventArgs(this));
            }
        }

        private void UpdateComboEquality(string type)
        {
            List<string> equalityList = new List<string>();
            switch (type)
            {
                    // Type texte
                case "string":
                    equalityList.Add("IN");
                    equalityList.Add("NOT IN");
                    break;

                    // Type numérique
                default:
                    equalityList.Add(">");
                    equalityList.Add("=");
                    equalityList.Add("<");
                    break;
            }
            _comboBoxEquality.DataSource = equalityList;
        }

        private string _helpText = String.Empty;

        #region Database interaction

        private void RetrieveData()
        {
            // TODO: This line of code loads data into the 'cCDataSet.Maturities' table. You can move, or remove it, as needed.
            this.bbgDescriptiveFieldsTableAdapter.Fill(this.cCDataSet.BbgDescriptiveFields);
        }
        #endregion
    }
}
