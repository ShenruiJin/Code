﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace BBClient
{
    public partial class BasketDefinition : UserControl
    {
        public BasketDefinition() : this(null)
        {
        }

		public BasketDefinition(BasketOptimizerUnderlyings bou)
		{
			InitializeComponent();
			AddNewBasket(true);
			_bou = bou;
			_copyPasteGridViewUnderlyings.RowCount = 50;
		}

        public event EventHandler PreviewBasket;

        // Main function : returns the list of stocks, if they're fixed or not
        // and an optional constraint on their number
		public BasketDefinitionComposition GetComposition()
		{
			DataTable descriptiveData = _bou.GetDescriptiveBbgData();

			// Once we have the descriptions, we can create subsets for each subbasket
			List<KeyValuePair<SetLogic, List<string>>> subsets = new List<KeyValuePair<SetLogic, List<string>>>();
			subsets.Add(new KeyValuePair<SetLogic, List<string>>(SetLogic.Union, GetInputBasket()));
			for (int i = _panelConstraintsSet.Controls.Count - 1; i >= 0; i--)
			{
				BasketConstraintsSetControl ctrl = _panelConstraintsSet.Controls[i] as BasketConstraintsSetControl;
				KeyValuePair<SetLogic, string> constraint = ctrl.GetDefinition();
				if (constraint.Value != String.Empty)
				{
					DataRow[] drArray = descriptiveData.Select(constraint.Value, "Security ASC");
					List<string> subbasketUnderlyings = new List<string>();
					foreach (DataRow row in drArray)
					{
						string underlying = Convert.ToString(row["Security"]);
						// Remove the ticker part from the name
						//underlying = underlying.Remove(underlying.LastIndexOf(" "));
						subbasketUnderlyings.Add(underlying);
					}

					subsets.Add(new KeyValuePair<SetLogic, List<string>>(constraint.Key, subbasketUnderlyings));
				}
			}

			// We can then use set logic to create the baskets
			List<string> underlyingList = subsets[0].Value;
			for (int i = 1; i < subsets.Count; i++)
			{
				switch (subsets[i].Key)
				{
					// Union : simple add
					case SetLogic.Union:
						foreach (string ul in subsets[i].Value)
						{
							if (!underlyingList.Contains(ul))
							{
								underlyingList.Add(ul);
							}
						}
						break;

					// Intersection
					case SetLogic.Intersection:
						for (int counter = underlyingList.Count - 1; counter >= 0; counter--)
						{
							if (!subsets[i].Value.Contains(underlyingList[counter]))
							{
								underlyingList.Remove(underlyingList[counter]);
							}
						}
						break;


					case SetLogic.Minus:
						for (int counter = underlyingList.Count - 1; counter >= 0; counter--)
						{
							if (subsets[i].Value.Contains(underlyingList[counter]))
							{
								underlyingList.Remove(underlyingList[counter]);
							}
						}
						break;


					case SetLogic.InverseMinus:
						for (int counter = subsets[i].Value.Count - 1; counter >= 0; counter--)
						{
							if (underlyingList.Contains(subsets[i].Value[counter]))
							{
								subsets[i].Value.Remove(subsets[i].Value[counter]);
							}
						}
						underlyingList = subsets[i].Value;
						break;

					default:
						break;
				}
			}

			// Return basket definition
			BasketDefinitionComposition defComposition = new BasketDefinitionComposition();
			int nbStocks = 0;
			int.TryParse(_textBoxConstraint.Text, out nbStocks);
			defComposition.NbStocks = _checkBoxStockConstraint.Checked ? nbStocks : 0;
			defComposition.UnderlyingList = underlyingList;

			return defComposition;
		}

        private List<string> GetInputBasket()
        {
            List<string> inputBasket = new List<string>();
            for(int i = 0; i < _copyPasteGridViewUnderlyings.RowCount; i++)
            {
                string underlying = Convert.ToString(_copyPasteGridViewUnderlyings[0, i].Value);
                if (underlying.Trim() != String.Empty)
                {
                    inputBasket.Add(underlying.ToUpper());
                }
            }
            return inputBasket;
        }

        // Fire an event to the BOU form for display
        private void _buttonPreview_Click(object sender, EventArgs e)
        {
            if (_bou != null && PreviewBasket != null)
            {
                PreviewBasket(this, new EventArgs());
            }
        }

        private void _buttonAddSubBasket_Click(object sender, EventArgs e)
        {
            AddNewBasket(false);
        }
		
		private void AddNewBasket(bool isDefault)
        {
            BasketConstraintsSetControl ctrl = new BasketConstraintsSetControl(_ctrlCounter + 1, isDefault);
            int nbControls = _panelConstraintsSet.Controls.Count;
            ctrl.Location = new Point(0, nbControls * (ctrl.Height + _margeControlesTop));
            _panelConstraintsSet.Controls.Add(ctrl);
            _panelConstraintsSet.Controls.SetChildIndex(ctrl, 0);
            ctrl.Dock = DockStyle.Top;
            ctrl.Removed += new ControlEventHandler(ctrl_OnRemove);
            _ctrlCounter++;
        }

        // Basket removal
        void ctrl_OnRemove(object sender, ControlEventArgs e)
        {
            BasketConstraintsSetControl ctrl = sender as BasketConstraintsSetControl;
            int indexCtrl = _panelConstraintsSet.Controls.IndexOf(ctrl);
            int yOffset = ctrl.Height + _margeControlesTop;
            // Remove from the panel and move the others up
            _panelConstraintsSet.Controls.Remove(ctrl);
            for (int ctrlCounter = indexCtrl; ctrlCounter < _panelConstraintsSet.Controls.Count; ctrlCounter++)
            {
                _panelConstraintsSet.Controls[ctrlCounter].Location =
                    new Point(0, _panelConstraintsSet.Controls[ctrlCounter].Location.Y - yOffset);
            }
        }

        private void InitGui()
        {
            // Creation and initialization of the data table
            //_dataGridViewStocks.RowCount = _minRows;
            _copyPasteGridViewUnderlyings.RowCount = _minRows;
        }

        private void _buttonClearCustomList_Click(object sender, EventArgs e)
        {
            // Clear the security cell for each row
            for (int i = 0; i < _copyPasteGridViewUnderlyings.RowCount; i++)
            {
                _copyPasteGridViewUnderlyings[0, i].Value = String.Empty;
            }

            // Focus on the first cell in the datagrid to enable immediate typing/pasting
            _copyPasteGridViewUnderlyings.Select();
            _copyPasteGridViewUnderlyings.CurrentCell = _copyPasteGridViewUnderlyings[0, 0];
        }
        private void _checkBoxStockConstraint_CheckedChanged(object sender, EventArgs e)
        {
            _textBoxConstraint.Enabled = _checkBoxStockConstraint.Checked;
        }

        private int _margeControlesTop = 35;
        private int _minRows = 50;
        private int _ctrlCounter = 0;
        private BasketOptimizerUnderlyings _bou;
    }

    public struct BasketDefinitionComposition
    {
        public List<string> UnderlyingList;
        public int NbStocks;
    }
}
