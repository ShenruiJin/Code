﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Windows.Forms;
using System.Text;

namespace StructuringControls
{
    public class CopyPasteGridView : DataGridView
    {
		#region Paste and clear
		// La copie vers Excel est implémentée de base
		// Il ne reste plus qu'à s'occuper de coller
		// Surcharge de la prise en compte de la touche Suppr aussi,
		// Seulement pour les colonnes non-readonly
		protected override void OnKeyDown(KeyEventArgs e)
		{
			this.CellKeyDownHandler(this, e);
			base.OnKeyDown(e);
		}

		// Bug when pasting Excel columns : the standard behavior keeps getting called even though KeyDown has been overloaded
		// We have to take care of /t's ourselves
		protected override void OnCellValueChanged(DataGridViewCellEventArgs e)
		{
			base.OnCellValueChanged(e);
			if (e.ColumnIndex < this.ColumnCount && e.RowIndex < this.RowCount
				&& e.ColumnIndex >= 0 && e.RowIndex >= 0)
			{
				string tabCheckValue = Convert.ToString(this[e.ColumnIndex, e.RowIndex].Value);
				if (tabCheckValue.Contains("\t"))
				{
					this[e.ColumnIndex, e.RowIndex].Value = tabCheckValue.Split('\t')[0];
				}
			}
		}

		protected override void OnEditingControlShowing(DataGridViewEditingControlShowingEventArgs e)
		{
			KeyEventHandler KeyDownDelegate = new KeyEventHandler(CellKeyDownHandler);
			e.Control.KeyDown -= KeyDownDelegate;
			e.Control.KeyDown += KeyDownDelegate;

			base.OnEditingControlShowing(e);
		}

		protected void CellKeyDownHandler(object sender, KeyEventArgs e)
		{
			if (e.Control && e.KeyCode == Keys.V)
			{
				string s = Clipboard.GetText();
				string[] lines = s.Replace("\r\n \r", String.Empty).Split('\n');
				for (int counter = 0; counter < lines.Length; counter++)
				{
					lines[counter] = lines[counter].Replace("\r", String.Empty);
				}
				int row = this.CurrentCell.RowIndex;
				int col = this.CurrentCell.ColumnIndex;

				if (this.DataSource is DataTable)
				{
					DataTable table = (DataTable)this.DataSource;
					table.Rows.Clear();

					int rowCount = Math.Max(this.RowCount, 50);
					// Add to the first column
					foreach (string line in lines)
					{
						if (row < rowCount && line.Length > 0)
						{
							DataRow tableRow = table.NewRow();
							tableRow[0] = line;
							table.Rows.Add(tableRow);
						}
					}
					while (rowCount > this.RowCount)
					{
						table.Rows.Add(table.NewRow());
					}
				}
				else
				{
					this.DataSource = null;
					this.RowCount = Math.Max(this.RowCount, 50);
					while (lines.Length + row > this.RowCount)
					{
						this.Rows.Add();
					}
					foreach (string line in lines)
					{
						if (row < this.RowCount)
						{
							if (line.Length > 0)
							{
								string[] cells = line.Split('\t');
								for (int i = 0; i < cells.GetLength(0); ++i)
								{
									if (col + i < this.ColumnCount)
									{
										this[col + i, row].Value =
											Convert.ChangeType(cells[i], this[col + i, row].ValueType);
									}
									else
									{
										break;
									}
								}
								row++;
							}
						}
						else
						{
							break;
						}
					}
				}
			}
			else if (e.KeyCode == Keys.Delete && !this.CurrentCell.ReadOnly)
			{
				this.CurrentCell.Value = String.Empty;
			}
		}

		#endregion
    }

    public class ExcelDataGridView : CopyPasteGridView
    {
        #region Anti flicker
        // Anti-flicker pour éviter les refresh inutiles
        private const int WM_SETREDRAW = 0x000B;
        private const int WM_USER = 0x400;
        private const int EM_GETEVENTMASK = (WM_USER + 59);
        private const int EM_SETEVENTMASK = (WM_USER + 69);

        [DllImport("user32", CharSet = CharSet.Auto)]
        private extern static IntPtr SendMessage(IntPtr hWnd, int msg, int wParam, IntPtr lParam);

        private IntPtr _eventMask = IntPtr.Zero;
        public void Freeze()
        {
            _eventMask = IntPtr.Zero;
            // Stop redrawing:
            SendMessage(this.Handle, WM_SETREDRAW, 0, IntPtr.Zero);
            // Stop sending events
            //_eventMask = SendMessage(this.Handle, EM_GETEVENTMASK, 0, IntPtr.Zero);
        }

        public void Unfreeze()
        {
            // Turn on events
            //SendMessage(this.Handle, EM_SETEVENTMASK, 0, _eventMask);
            // Turn on redrawing
            SendMessage(this.Handle, WM_SETREDRAW, 1, IntPtr.Zero);
        }

        private bool _isPaintable;

        public bool IsPaintable
        {
            get { return _isPaintable; }
            set { _isPaintable = value; }
        }

        #endregion

        #region Paint rows : missing ticker, incomplete history, correlation groups
        private string _missingData = "#N/A Sec";
        private string _dataComplete = "OK";
        private int _missingDataReferenceColumn = int.MinValue;//1;
        private int _historicalDataIncompleteColumn = int.MinValue;//5;
        private int _groupIndexColumn = int.MinValue;//6;
        private bool _isCustomGroup = false;
        private int _emphasizedCount = int.MinValue;
        private DataTable _correlationDataTable;
        private List<List<int>> _groupList = new List<List<int>>();
        // Colors
        private Color _emphasisColor = Color.Red;
        private Color _incompleteColor = Color.Red;
        private Color _missingColor = Color.Red;

        public DataTable CorrelationDataTable
        {
            get { return _correlationDataTable; }
            set { _correlationDataTable = value; }
        }
        public string DataComplete
        {
            get { return _dataComplete; }
            set { _dataComplete = value; }
        }
        public List<List<int>> GroupList
        {
            get { return _groupList; }
            set { _groupList = value; }
        }
        public bool IsCustomGroup
        {
            get { return _isCustomGroup; }
            set { _isCustomGroup = value; }
        }
        public int HistoricalDataIncompleteColumn
        {
            get { return _historicalDataIncompleteColumn; }
            set { _historicalDataIncompleteColumn = value; }
        }
        public int GroupIndexColumn
        {
            get { return _groupIndexColumn; }
            set { _groupIndexColumn = value; }
        }
        public int MissingDataReferenceColumn
        {
            get { return _missingDataReferenceColumn; }
            set { _missingDataReferenceColumn = value; }
        }
        public string MissingData
        {
            get { return _missingData; }
            set { _missingData = value; }
        }
        public int EmphasizedCount
        {
            get { return _emphasizedCount; }
            set { _emphasizedCount = value; }
        }
        public Color MissingColor
        {
            get { return _missingColor; }
            set { _missingColor = value; }
        }
        public Color EmphasisColor
        {
            get { return _emphasisColor; }
            set { _emphasisColor = value; }
        }
        public Color IncompleteColor
        {
            get { return _incompleteColor; }
            set { _incompleteColor = value; }
        }

        protected override void OnCellFormatting(DataGridViewCellFormattingEventArgs e)
        {
            string histoDataCol = (this.ColumnCount > HistoricalDataIncompleteColumn && HistoricalDataIncompleteColumn >= 0)
                ? Convert.ToString(this[HistoricalDataIncompleteColumn, e.RowIndex].Value) : String.Empty;
            // Emphasis on
            if (EmphasizedCount != int.MinValue && e.RowIndex < EmphasizedCount)
            {
                e.CellStyle.BackColor = EmphasisColor; //: this.DefaultCellStyle.BackColor;
            }
            // Missing data
            else if ((this.ColumnCount > MissingDataReferenceColumn && MissingDataReferenceColumn >= 0) &&
                Convert.ToString(this[MissingDataReferenceColumn, e.RowIndex].Value) == MissingData)
            {
                e.CellStyle.BackColor = MissingColor;
            }
            // Historical data incomplete
            else if (histoDataCol != String.Empty && histoDataCol != DataComplete)
            {
                e.CellStyle.BackColor = IncompleteColor;
            }
            else
            {
                e.CellStyle.BackColor = (e.RowIndex % 2 == 1) ?
                    this.AlternatingRowsDefaultCellStyle.BackColor : this.DefaultCellStyle.BackColor;
            }

            // If grouping
            if (IsCustomGroup && GroupList.Count > 0 && e.Value != null && e.Value.ToString().Trim() != String.Empty)
            {
                e.CellStyle.BackColor = GetColorFromIndex(GetColorIndex(e.RowIndex));
            }
            // Pour BO
            else if (IsCustomGroup && e.Value != null && (e.Value.ToString().Trim() != String.Empty ||
                (this.Columns[e.ColumnIndex] is DataGridViewCheckBoxColumn && 
                this[0, e.RowIndex].Value.ToString().Trim() != String.Empty)))
            {
                int idx = 0;
                if(!int.TryParse(Convert.ToString(this[GroupIndexColumn, e.RowIndex].Value), out idx))
                {
                    idx = 0;
                }
                e.CellStyle.BackColor = GetColorFromIndex(idx);
            }

            base.OnCellFormatting(e);
        }

        private int GetColorIndex(int rowIndex)
        {
            int idx = 0;
            // Retrieve the group index of the requested row
            for (int i = 0; i < CorrelationDataTable.Rows.Count; i++)
            {
                if (Convert.ToString(CorrelationDataTable.Rows[i][0]) == Convert.ToString(this[0, rowIndex].Value))
                {
                    idx = int.Parse(CorrelationDataTable.Rows[i][GroupIndexColumn].ToString());
                    break;
                }
            }
            return idx;
        }
        private Color GetColorFromIndex(int idx)
        {
            Color returnColor = this.DefaultCellStyle.BackColor;
            switch(idx)
            {
                case 0:
                    returnColor = Color.Coral;
                    break;
                case 1:
                    returnColor = Color.Khaki;
                    break;
                case 2:
                    returnColor = Color.LightBlue;
                    break;
                case 3:
                    returnColor = Color.LightGreen;
                    break;
                default:
                    returnColor = Color.Black;
                    break;
            }
            return returnColor;
        }

        #endregion
    }
}
