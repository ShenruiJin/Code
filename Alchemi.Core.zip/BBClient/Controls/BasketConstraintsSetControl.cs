﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;

namespace BBClient
{
    public partial class BasketConstraintsSetControl : UserControl
    {
        public event ControlEventHandler Removed;
        public BasketConstraintsSetControl() : this(1)
        {
		}
		public BasketConstraintsSetControl(int i) : this(i, false)
		{
		}
        public BasketConstraintsSetControl(int i, bool isDefault)
        {
            InitializeComponent();
            _groupBox.Text = "Basket " + i;
			InitDefaultConstraints();

            _comboBoxSet.SelectedIndex = 0;
        }

		private void InitDefaultConstraints()
		{
			// Ajout des valeurs par défaut : type Equity + liquidité > 0
			AddNewConstraint("MARKET_SECTOR_DES", "Equity");

			AddNewConstraint("AVG_DAILY_VALUE_TRADED_3M", "0");
		}

        public KeyValuePair<SetLogic, string> GetDefinition()
        {
            SetLogic logic = (SetLogic)_comboBoxSet.SelectedIndex;
            string constraint = String.Empty;
            foreach (BasketConstraintControl ctrl in _panelConstraints.Controls)
            {
                string ctrlConstraint = ctrl.GetConstraint();
                if (ctrlConstraint != String.Empty)
                {
                    if (constraint != String.Empty)
                    {
                        constraint += " AND ";
                    }
                    constraint += ctrlConstraint;
                }
            }

            return new KeyValuePair<SetLogic, string>(logic, constraint);
        }

        private void _buttonAddConst_Click(object sender, EventArgs e)
        {
            AddNewConstraint();
        }

		private BasketConstraintControl AddNewConstraint()
        {
            BasketConstraintControl ctrl = new BasketConstraintControl();
            int nbControls = _panelConstraints.Controls.Count;
            ctrl.Location = new Point(0, nbControls * (ctrl.Height + margeControles));
            _panelConstraints.Controls.Add(ctrl);
            ctrl.Removed += new ControlEventHandler(ctrl_OnRemove);
            this.Height += ctrl.Height + margeControles;
			return ctrl;
        }

		private void AddNewConstraint(string defaultField, string defaultValue)
		{
			AddNewConstraint().SetConstraint(defaultField, defaultValue);
		}

        // Constraint removal
        void ctrl_OnRemove(object sender, ControlEventArgs e)
        {
            BasketConstraintControl ctrl = sender as BasketConstraintControl;
            int indexCtrl = _panelConstraints.Controls.IndexOf(ctrl);
            int yOffset = ctrl.Height + margeControles;
            // Remove from the panel and move the others up
            _panelConstraints.Controls.Remove(ctrl);
            for (int ctrlCounter = indexCtrl; ctrlCounter < _panelConstraints.Controls.Count; ctrlCounter++)
            {
                _panelConstraints.Controls[ctrlCounter].Location = 
                    new Point(0, _panelConstraints.Controls[ctrlCounter].Location.Y - yOffset);
            }

            this.Height -= yOffset;
        }

        private int margeControles = 3;

        private void _buttonRemove_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to remove the entire subbasket ?", "Removal confirmation", 
                MessageBoxButtons.OKCancel) == DialogResult.OK)
            {
                if (Removed != null)
                {
                    Removed(this, new ControlEventArgs(this));
                }
            }
        }
    }

    public enum SetLogic
    {
        Union,
        Intersection,
        Minus,
        InverseMinus
    }
}
