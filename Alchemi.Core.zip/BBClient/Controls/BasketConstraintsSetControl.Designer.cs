﻿namespace BBClient
{
    partial class BasketConstraintsSetControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this._groupBox = new System.Windows.Forms.GroupBox();
            this._panelConstraints = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this._buttonRemove = new System.Windows.Forms.Button();
            this._buttonAddConst = new System.Windows.Forms.Button();
            this._comboBoxSet = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this._groupBox.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // _groupBox
            // 
            this._groupBox.Controls.Add(this._panelConstraints);
            this._groupBox.Controls.Add(this.panel1);
            this._groupBox.Dock = System.Windows.Forms.DockStyle.Fill;
            this._groupBox.Location = new System.Drawing.Point(58, 0);
            this._groupBox.Name = "_groupBox";
            this._groupBox.Size = new System.Drawing.Size(520, 51);
            this._groupBox.TabIndex = 1;
            this._groupBox.TabStop = false;
            this._groupBox.Text = "Basket constraints";
            // 
            // _panelConstraints
            // 
            this._panelConstraints.Dock = System.Windows.Forms.DockStyle.Fill;
            this._panelConstraints.Location = new System.Drawing.Point(3, 16);
            this._panelConstraints.Name = "_panelConstraints";
            this._panelConstraints.Size = new System.Drawing.Size(514, 3);
            this._panelConstraints.TabIndex = 2;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this._buttonRemove);
            this.panel1.Controls.Add(this._buttonAddConst);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(3, 19);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(514, 29);
            this.panel1.TabIndex = 1;
            // 
            // _buttonRemove
            // 
            this._buttonRemove.Location = new System.Drawing.Point(392, 3);
            this._buttonRemove.Name = "_buttonRemove";
            this._buttonRemove.Size = new System.Drawing.Size(116, 23);
            this._buttonRemove.TabIndex = 1;
            this._buttonRemove.Text = "Remove subbasket";
            this._buttonRemove.UseVisualStyleBackColor = true;
            this._buttonRemove.Click += new System.EventHandler(this._buttonRemove_Click);
            // 
            // _buttonAddConst
            // 
            this._buttonAddConst.Location = new System.Drawing.Point(3, 3);
            this._buttonAddConst.Name = "_buttonAddConst";
            this._buttonAddConst.Size = new System.Drawing.Size(90, 23);
            this._buttonAddConst.TabIndex = 0;
            this._buttonAddConst.Text = "Add constraint";
            this._buttonAddConst.UseVisualStyleBackColor = true;
            this._buttonAddConst.Click += new System.EventHandler(this._buttonAddConst_Click);
            // 
            // _comboBoxSet
            // 
            this._comboBoxSet.FormattingEnabled = true;
            this._comboBoxSet.Items.AddRange(new object[] {
            "∪",
            "∩",
            "\\",
            "/"});
            this._comboBoxSet.Location = new System.Drawing.Point(11, 24);
            this._comboBoxSet.Name = "_comboBoxSet";
            this._comboBoxSet.Size = new System.Drawing.Size(41, 21);
            this._comboBoxSet.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this._comboBoxSet);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(58, 51);
            this.panel2.TabIndex = 3;
            // 
            // BasketConstraintsSetControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this._groupBox);
            this.Controls.Add(this.panel2);
            this.Name = "BasketConstraintsSetControl";
            this.Size = new System.Drawing.Size(578, 51);
            this._groupBox.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox _groupBox;
        private System.Windows.Forms.Panel _panelConstraints;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button _buttonAddConst;
        private System.Windows.Forms.Button _buttonRemove;
        private System.Windows.Forms.ComboBox _comboBoxSet;
        private System.Windows.Forms.Panel panel2;
    }
}
