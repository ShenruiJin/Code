﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemotingInterfaces
{
    [Serializable]
    public static class BbgField
    {
        public static string Name = "NAME";

        public static string Country = "COUNTRY";

        public static string Currency = "CRNCY";

        public static string CompanyDescription = "CIE_DES_BULK";

        public static string ClosePrice = "LAST_PRICE";

        public static string Volume = "VOLUME";

        public static string DayToDayPerf = "CHG_PCT_1D";
	}

	[Serializable]
    public static class BbgConstants
	{
		public static string DateColumn = "UtcDate";

		public static string SecuritiesTable = "Securities";

		public static string SecurityColumn = "Security";
    }
}
