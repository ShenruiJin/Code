﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace RemotingInterfaces
{
    public interface IRemoteBbg
    {
		void Connection(string name);
		void Disconnection(string name);

		DataSet Send(BbgQuery query);

        string GetServerVersion();

        void ReinitializeData();
    }
}
