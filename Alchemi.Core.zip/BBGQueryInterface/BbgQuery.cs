﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemotingInterfaces
{
    [Serializable]
    public class BbgQuery
    {
        public BbgQuery()
        {
            IsStatic = false;
            SecuritiesList = new List<string>();
            FieldsList = new List<string>();
            Currencies = new List<string>();
            StartDate = DateTime.Now;
            EndDate = DateTime.Now;
            Periodicity = BbgPeriodicity.Daily;
            FillOption = BbgNonTradingDayFillOption.All_Calendar_Days;
            FillMethod = BbgNonTradingDayFillMethod.Previous_Value;
        }

        public bool IsStatic { get; set;}
        public List<string> SecuritiesList { get; set;}
        public List<string> FieldsList { get; set;}
        public DateTime StartDate { get; set;}
        public DateTime EndDate { get; set;}
        public List<string> Currencies { get; set;}
        public BbgPeriodicity Periodicity { get; set; }
        public BbgNonTradingDayFillOption FillOption { get; set; }
        public BbgNonTradingDayFillMethod FillMethod { get; set; }
       
    }
}
