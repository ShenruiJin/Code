﻿namespace RemotingInterfaces {
    
    
    public partial class CCDataSet {
    }
}
