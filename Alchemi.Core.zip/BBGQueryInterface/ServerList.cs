﻿using System;
using System.Collections.Generic;
using System.Text;
using RemotingInterfaces.CCDataSetTableAdapters;
using System.Data;
using System.Collections;

namespace RemotingInterfaces
{
    /// <summary>
    /// Gere une liste de serveur sur le reseau
    /// </summary>
    public class ServerList
    {
        CCDataSet _servers = new CCDataSet();
        BbgServerIpTableAdapter _serverAdapter = new BbgServerIpTableAdapter();

        /// <summary>
        /// Constructeur : Charge la liste des IP
        /// </summary>
        private ServerList()
        {
            _serverAdapter.Fill(_servers.BbgServerIp);
        }

        /// <summary>
        /// Ajoute un server
        /// </summary>
        /// <param name="ip"></param>
        private void AddIP(string ip)
        {
            // check si l'ip existe et update si necessaire
            DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
            DataRow[] rows = dtIP.Select("Ip = '" + ip + "'");
            // il est deja là ?
            if (rows.Length > 0)
                return;
            // sinon on l'ajoute
            DataRow row = dtIP.NewRow();
            row["Ip"] = ip;
            dtIP.Rows.Add(row);
            // transfert
            _serverAdapter.Update(_servers.BbgServerIp);
            // valide 
            _servers.BbgServerIp.AcceptChanges();
        }

        /// <summary>
        /// Elimine un server
        /// </summary>
        /// <param name="ip"></param>
        private void RemoveIP(string ip)
        {
            // check si l'ip existe et update si necessaire
            DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
            DataRow[] rows = dtIP.Select("Ip = '" + ip + "'");
            // il est deja là ?
            if (rows.Length > 0)
            {
                foreach(DataRow row in rows)
                    row.Delete();
                // transfert
                _serverAdapter.Update(_servers.BbgServerIp);
                // valide 
                _servers.BbgServerIp.AcceptChanges();
            }
        }

        /// <summary>
        /// Retourne la lu=iste de serveur potentielement actif
        /// </summary>
        private List<string> ServersIP
        {
            get
            {
                DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
                List<string> ret = new List<string>();
                foreach(DataRow row in dtIP.Rows)
                {
                    ret.Add(row["Ip"].ToString());
                }
                return ret;
            }
        }

        /// <summary>
        /// Retourne une nouvelle collection a chaque acces pour etre a jour des update des copains
        /// </summary>
        private static ServerList singleton
        {
            get
            {
                return new ServerList();
            }
        }

        /// <summary>
        /// Ajoute un server
        /// </summary>
        /// <param name="ip"></param>
        public static void Add(string ip)
        {
            try
            {
                singleton.AddIP(ip);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Elimine un server
        /// </summary>
        /// <param name="ip"></param>
        public static void Remove(string ip)
        {
            try
            {
                singleton.RemoveIP(ip);
            }
            catch
            {
            }
        }

        /// <summary>
        /// Retourne la lu=iste de serveur potentielement actif
        /// </summary>
        public static List<string> Servers
        {
            get
            {
                try
                {
                    return singleton.ServersIP;
                }
                catch
                {
                    return new List<string>();
                }
            }
        }
    }
}
