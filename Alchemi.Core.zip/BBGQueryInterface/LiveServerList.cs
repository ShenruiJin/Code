﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using RemotingInterfaces.CCDataSetTableAdapters;
using System.Data;
using System.Collections;
using NetMQ;
using System.Threading.Tasks;
using System.Threading;
using Newtonsoft.Json;
using System.Collections.Concurrent;
using NetMQ.Sockets;

namespace RemotingInterfaces
{
    /// <summary>
    /// Gere une liste de serveur sur le reseau
    /// </summary>
    public class LiveServerList
    {
        //// netmq discovery & context
        NetMQContext context = NetMQContext.Create();
        CancellationTokenSource cancel = null;
        object context_lock = new object();

        NetMQBeacon discoveryListener = null;

        private static string _legacyListeningAddress;

        public static void Advertise(string address)
        {
            lock (singleton.context_lock)
            {
                _legacyListeningAddress = address;
                if (singleton.discoveryListener != null)
                {
                    singleton.discoveryListener.Dispose();
                    singleton.cancel.Cancel();
                }
                singleton.cancel = new CancellationTokenSource();
                NetMQBeacon listener = new NetMQBeacon(singleton.context);
                listener.Configure(9999);
                singleton.discoveryListener = listener;
                var token = singleton.cancel.Token;
                new Task(() =>
                {
                    //// take everything
                    listener.Subscribe("PEERLIST:");
                    while (!token.IsCancellationRequested)
                    {
                        string peer;
                        string data = listener.ReceiveString(out peer);

                        Task.Factory.StartNew(() => OneAdv(peer, data));
                    }
                }, TaskCreationOptions.LongRunning).Start(TaskScheduler.Default);
            }
        }

        /// <summary>
        /// simple serverdiscovery, has a beacon that emits UDP broadcasts, will be pinged back by server instances
        /// </summary>
        public class ServerDiscovery : IDisposable
        {
            public ConcurrentDictionary<string, Peer> Servers { get; private set; }
            NetMQSocket router;
            NetMQBeacon speaker;

            public ServerDiscovery()
            {
                Servers = new ConcurrentDictionary<string, Peer>();

                router = singleton.context.CreateRouterSocket();
                //router = singleton.context.CreateResponseSocket();

                int bound = router.BindRandomPort("tcp://localhost");
                speaker = new NetMQBeacon(singleton.context);

                speaker.Configure(9999);
                Peer thisPeer = new Peer()
                {
                    RouterAddress = "tcp://" + speaker.Hostname + ":" + bound
                };
                speaker.Publish("PEERLIST:" + JsonConvert.SerializeObject(new[] { thisPeer }), new TimeSpan(0, 0, 10));

                Task.Factory.StartNew(Receive);
            }

            private void Receive()
            {
                string peers = router.ReceiveString();
                peers = peers.Split(new[] { ':' }, 2).Skip(1).FirstOrDefault();

            }


            public void Dispose()
            {
                speaker.Dispose();
                router.Dispose();
            }
        }
        public static ServerDiscovery StartDiscovery()
        {
            return new ServerDiscovery();
        }

        public class Peer
        {
            public string Username { get; set; }
            public string RouterAddress { get; set; }
            public string LegacyRemoting { get; set; }
        }


        private static void OneAdv(string peer, string data)
        {
            try
            {
                var peerObject = JsonConvert.DeserializeObject<Peer[]>(data.Split(new[] { ':' }, 2).Skip(1).FirstOrDefault());
                var reply = new[] { new Peer() { LegacyRemoting = _legacyListeningAddress, Username = Environment.UserName } };
                using (var dealer = singleton.context.CreateDealerSocket())
                {
                    EventWaitHandle ewh = new EventWaitHandle(false, EventResetMode.ManualReset);
                    dealer.SendReady += (object sender, NetMQSocketEventArgs e) =>
                    {
                        ewh.Set();
                    };

                    dealer.Connect(peerObject.First().RouterAddress);

                    dealer.SendMore(string.Empty);
                    dealer.Send(JsonConvert.SerializeObject(reply));
                }
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("ServerList").Warn("Error while responding to beacon", e);
            }
        }

        /// <summary>
        /// Constructeur : Charge la liste des IP
        /// </summary>
        private LiveServerList()
        {
            //   _serverAdapter.Fill(_servers.BbgServerIp);
        }

        ///// <summary>
        ///// Ajoute un server
        ///// </summary>
        ///// <param name="ip"></param>
        //private void AddIP(string ip)
        //{
        //    // check si l'ip existe et update si necessaire
        //    DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
        //    DataRow[] rows = dtIP.Select("Ip = '" + ip + "'");
        //    // il est deja là ?
        //    if (rows.Length > 0)
        //        return;
        //    // sinon on l'ajoute
        //    DataRow row = dtIP.NewRow();
        //    row["Ip"] = ip;
        //    dtIP.Rows.Add(row);
        //    // transfert
        //    _serverAdapter.Update(_servers.BbgServerIp);
        //    // valide 
        //    _servers.BbgServerIp.AcceptChanges();
        //}

        ///// <summary>
        ///// Elimine un server
        ///// </summary>
        ///// <param name="ip"></param>
        //private void RemoveIP(string ip)
        //{
        //    // check si l'ip existe et update si necessaire
        //    DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
        //    DataRow[] rows = dtIP.Select("Ip = '" + ip + "'");
        //    // il est deja là ?
        //    if (rows.Length > 0)
        //    {
        //        foreach(DataRow row in rows)
        //            row.Delete();
        //        // transfert
        //        _serverAdapter.Update(_servers.BbgServerIp);
        //        // valide 
        //        _servers.BbgServerIp.AcceptChanges();
        //    }
        //}

        ///// <summary>
        ///// Retourne la lu=iste de serveur potentielement actif
        ///// </summary>
        //private List<string> ServersIP
        //{
        //    get
        //    {
        //        DataTable dtIP = _servers.BbgServerIp.DataSet.Tables[_servers.BbgServerIp.TableName];
        //        List<string> ret = new List<string>();
        //        foreach(DataRow row in dtIP.Rows)
        //        {
        //            ret.Add(row["Ip"].ToString());
        //        }
        //        return ret;
        //    }
        //}

        /// <summary>
        /// Retourne une nouvelle collection a chaque acces pour etre a jour des update des copains
        /// </summary>
        private static LiveServerList singleton
        {
            get
            {
                return _instance.Value;
            }
        }

        private static Lazy<LiveServerList> _instance = new Lazy<LiveServerList>(() => new LiveServerList());

        ///// <summary>
        ///// Ajoute un server
        ///// </summary>
        ///// <param name="ip"></param>
        //public static void Add(string ip)
        //{
        //    try
        //    {
        //        singleton.AddIP(ip);
        //    }
        //    catch
        //    {
        //    }
        //}

        ///// <summary>
        ///// Elimine un server
        ///// </summary>
        ///// <param name="ip"></param>
        //public static void Remove(string ip)
        //{
        //    try
        //    {
        //        singleton.RemoveIP(ip);
        //    }
        //    catch
        //    {
        //    }
        //}

        ///// <summary>
        ///// Retourne la lu=iste de serveur potentielement actif
        ///// </summary>
        //public static List<string> Servers
        //{
        //    get
        //    {
        //        try
        //        {
        //            return singleton.ServersIP;
        //        }
        //        catch
        //        {
        //            return new List<string>();
        //        }
        //    }
        //}

        public static void Add(string ip)
        {
            Advertise(ip);
        }
    }
}