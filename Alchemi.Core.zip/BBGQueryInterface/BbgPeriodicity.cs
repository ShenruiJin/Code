﻿using System;
using System.Collections.Generic;
using System.Text;

namespace RemotingInterfaces
{
    /// <summary>
    /// Periodicité
    /// </summary>
    [Serializable]
    public enum BbgPeriodicity
    {
        Daily,
        Weekly,
        Monthly,
        Quarterly,
        Semi_Annually,
        Yearly
    }

    /// <summary>
    /// nonTradingDayFillOption
    /// </summary>
    [Serializable]
    public enum BbgNonTradingDayFillOption
    {
        Non_Trading_Weekdays, // Include all weekdays (Monday to Friday) in the data set
        All_Calendar_Days,  // Include all days of the calendar in the data set returned
        Active_Days_Only // Include only active days (days where the instrument and field pair updated) in the data set returned
    }

    /// <summary>
    /// NonTradingDayFillMethod
    /// </summary>
    [Serializable]
    public enum BbgNonTradingDayFillMethod
    {
        Previous_Value,
        Nil_Value
    }
}