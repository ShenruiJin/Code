﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class VolatilityTask
    {
        #region attributes
        private string _name; // nom de la tache : on l'attribue à la première insertion.
        private IList<AssetContext> _volAssets;
        #endregion

        #region constructors

        private VolatilityTask()
        {
        }

        public VolatilityTask(string name)
        {
            _name = name;
        }

        public VolatilityTask(string name, IList<AssetContext> volAssets)
        {
            _name = name;
            _volAssets = volAssets;
        }

        #endregion

        #region Properties

        public string Name{
            get { return _name; }
            set { _name = value; }
        }

        
        public IList<AssetContext> VolAssets
        {
            get { return _volAssets; }
            set { _volAssets = value; }
        }

        #endregion

        //public override bool Equals(object obj)
        //{
        //    if (obj == null || !(obj is VolatilityTask))
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return ((this._name == null && (obj as VolatilityTask)._name == null) || (this._name.ToUpperInvariant().Equals((obj as VolatilityTask)._name.ToUpperInvariant())))
        //            && ((this._volAssets == null && (obj as VolatilityTask)._volAssets==null) || this._volAssets.SequenceEqual((obj as VolatilityTask)._volAssets));
        //    }
        //}

        ///// <summary>
        ///// GetHashCode
        ///// </summary>
        ///// <returns></returns>
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}
    }
}
