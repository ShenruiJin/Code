﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class VolatilityHistorizedResults
    {
        #region attributes

        private DateTime _timestamp;
        private string _volatilityTaskName;
        private string _result;

        #endregion

        #region properties

        public DateTime Timestamp
        {
            get { return _timestamp; }
            set { _timestamp = value; }
        }

        public string VolatilityTaskName
        {
            get { return _volatilityTaskName; }
            set { _volatilityTaskName = value; }
        }

        // TO DO  : formater le résultat.
        public string Result
        {
            get { return _result; }
            set { _result = value; }
        }

        #endregion

        #region Constructors

        private VolatilityHistorizedResults()
        {
        }

        public VolatilityHistorizedResults(string volatilityTaskName, string result, DateTime timeStamp)
        {
            Result = result;
            _volatilityTaskName = volatilityTaskName;
            _timestamp = timeStamp;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

        //public override bool Equals(object obj)
        //{
        //    if (obj == null || !(obj is VolatilityHistorizedResults))
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return ((this._result == null && (obj as VolatilityHistorizedResults)._result == null) || (this._result.ToUpperInvariant().Equals((obj as VolatilityHistorizedResults)._result.ToUpperInvariant())))
        //            && ((this._timestamp.Equals((obj as VolatilityHistorizedResults)._timestamp)))
        //            && ((this._volatilityTaskName == null && (obj as VolatilityHistorizedResults)._volatilityTaskName == null) || (this._volatilityTaskName.ToUpperInvariant().Equals((obj as VolatilityHistorizedResults)._volatilityTaskName.ToUpperInvariant())));
        //    }
        //}

        ///// <summary>
        ///// GetHashCode
        ///// </summary>
        ///// <returns></returns>
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}

    }
}
