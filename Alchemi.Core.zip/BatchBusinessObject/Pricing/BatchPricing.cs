﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Un batch = un ensemble de taches a executer
    /// </summary>
    [Serializable]
    public class BatchPricing
    {
        #region constructor
        private BatchPricing()
        {
        }

        public BatchPricing(string name)
        {
            this.Name = name;
            this.PrivateTask = new List<BatchPricingTask>();
        }
        #endregion

        #region Properties
        /// <summary>
        /// Nom du batch
        /// </summary>
        public string Name
        {
            get;
            private set;
        }

        /// <summary>
        /// Les taches a executer
        /// </summary>
        public IEnumerable<BatchPricingTask> Tasks
        {
            get { return PrivateTask;}
        }

        /// <summary>
        /// Nombre de tache
        /// </summary>
        public int Count
        {
            get
            {
                return PrivateTask.Count;
            }
        }

        /// <summary>
        /// Stock les taches en interne
        /// </summary>
        protected IList<BatchPricingTask> PrivateTask
        {
            get;
            set;
        }
        #endregion

        /// <summary>
        /// Ajoute la tache (et set l'id)
        /// </summary>
        /// <param name="task"></param>
        public void AddTask(BatchPricingTask task)
        {
            // l'id dans ce batch
            task.ID = PrivateTask.Count;
            // zigouille l'acces en base si on passe par ici
            task.GUID = 0;
            // ajoute
            PrivateTask.Add(task);
        }

        /// <summary>
        /// Une nouvelle tache pour ce batch
        /// </summary>
        public BatchPricingTask AddTask(string name, ProductTask product, BatchBasket basket, BatchCalculation calculation, string Tag)
        {
            // fabrique interne
            BatchPricingTask toAdd = new BatchPricingTask(name, product, basket, calculation);
            // ajoute et choppe un ID
            AddTask(toAdd);
            // on le ballourde
            return toAdd;
        }

        /// <summary>
        /// Une nouvelle tache pour ce batch
        /// </summary>
        public BatchPricingTask AddTask(string name, ProductTask product, BatchBasket basket, BatchCalculation calculation)
        {
            // on le ballourde
            return AddTask(name, product, basket, calculation, string.Empty);
        }

        #region Helpers

        /// <summary>
        /// Retourne les devises de ce batch
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        public static IList<string> GetCurrencies(BatchPricing batch)
        {
            IList<string> list = new List<string>();
            string item;
            foreach (var task in batch.Tasks)
            {
                item = task.Basket.Currency.ToUpperInvariant();
                if (!list.Contains(item))
                {
                    list.Add(item);
                }
            }
            return list;
        }

        /// <summary>
        /// La liste des ss jacent de ce batch
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        public static IList<string> GetAssets(BatchPricing batch)
        {
            IList<string> ret = new List<string>();
            foreach (var task in batch.Tasks)
            {
                ret = ret.Concat<string>(task.Basket.Assets.Select<WeightedAssets, string>(elt => elt.Asset)).ToList<string>();
            }
            return ret;
        }

        /// <summary>
        /// La liste des ss jacent de ce batch
        /// </summary>
        /// <param name="batch"></param>
        /// <returns></returns>
        public static IList<string> GetAssets(BatchPricing batch, string currency)
        {
            IList<string> ret = new List<string>();
            foreach (var task in batch.Tasks)
            {
                // si la devise es la meme on ajoute
                if (task.Basket.Currency == currency)
                    ret = ret.Concat<string>(task.Basket.Assets.Select<WeightedAssets, string>(elt => elt.Asset)).ToList<string>();
            }
            return ret;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
