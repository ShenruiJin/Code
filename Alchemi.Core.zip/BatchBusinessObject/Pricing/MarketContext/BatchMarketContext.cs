﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Gere le contexte de marché
    /// Bid/Ask
    /// Deformation
    /// et peut etre certaines conventions, choix ...
    /// </summary>
    [Serializable]
    public class BatchMarketContext
    {
        private BatchMarketContext()
        {
        }

        /// <summary>
        /// Container
        /// </summary>
        public BatchMarketContext(string name, IList<AssetContext> assets)
        {
            this.Name = name;
            this.Assets = assets;
        }

        #region properties

        /// <summary>
        /// Le nom du context
        /// </summary>
        public string Name
        {
            get;
            private set;
        }

        /// <summary>
        /// Les differents bumps par asset
        /// </summary>
        protected IList<AssetContext> Assets
        {
            get;
            private set;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

        /// <summary>
        /// Retourne les bumps pour ce sous jacent
        /// </summary>
        /// <param name="asset"></param>
        /// <returns></returns>
        protected AssetContext GetAssetContext(string asset)
        {
            return this.Assets.FirstOrDefault(x => x.Name == asset);
        }

        /// <summary>
        /// Retourne le bump a appliquer dans cette catégorie
        /// </summary>
        public double GetVolatilityBump(string asset, string sensitivity)
        {
            AssetContext context = GetAssetContext(asset);
            if (context == null)
                return 0.0;
            if (sensitivity.ToLowerInvariant().CompareTo("ask") == 0)
            {
                return double.Parse(context.VolatilityAsk, System.Globalization.CultureInfo.InvariantCulture);
            }
            else if (sensitivity.ToLowerInvariant().CompareTo("bid") == 0)
            {
                return double.Parse(context.VolatilityBid, System.Globalization.CultureInfo.InvariantCulture);
            }
            return 0.0;
        }

        /// <summary>
        /// Retourne le bump de div
        /// </summary>
        public double GetDividendBump(string asset, string divBump)
        {
            AssetContext context = GetAssetContext(asset);
            if (context == null)
                return 0.0;

            double bumpValue = double.Parse(context.Dividend, System.Globalization.CultureInfo.InvariantCulture);
            if (divBump.ToLowerInvariant().CompareTo("ask") == 0)
            {
               return bumpValue;
            }
            else if (divBump.ToLowerInvariant().CompareTo("bid") == 0)
            {
                return -bumpValue;
            }
            return 0.0;
        }
    }
}
