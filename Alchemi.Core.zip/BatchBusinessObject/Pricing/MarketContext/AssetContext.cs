﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// une petite class indiquant les deformation a appliquer sur ce sous jacent
    /// </summary>
    [Serializable]
    public class AssetContext
    {
        #region attributes
        private string _name;
        private string _volatilityBid = "0.0"; // source pour le bid : Maps ou -2%
        private string _volatilityAsk = "0.0"; // source pour le ask : Maps ou +2%
        private string _dividend = "0.0"; // source pour le bump de div
        #endregion

        private AssetContext()
        {
        }
        
        /// <summary>
        /// Bump vide
        /// </summary>
        /// <param name="name"></param>
        public AssetContext(string name)
        {
            _name = name.ToUpperInvariant();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="name"></param>
        /// <param name="volatilityBid"></param>
        /// <param name="volatilityAsk"></param>
        /// <param name="dividend"></param>
        public AssetContext(string name, string volatilityBid, string volatilityAsk, string dividend)
		{
            _name = name.ToUpperInvariant();
            _volatilityBid = volatilityBid;
            _volatilityAsk = volatilityAsk;
            _dividend = dividend;
		}

        #region properties

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public string VolatilityBid
        {
            get { return _volatilityBid; }
            set { _volatilityBid = value; }
        }

        public string VolatilityAsk
        {
            get { return _volatilityAsk; }
            set { _volatilityAsk = value; }
        }

        public string Dividend
        {
            get { return _dividend; }
            set { _dividend = value; }
        }

        #endregion

        /// <summary>
        /// Retourne le bum de volatilite en fonction de la sensi
        /// </summary>
        /// <param name="sensi"></param>
        /// <returns></returns>
        public string GetVolatility(string sensi)
        {
            if (sensi.ToLowerInvariant().CompareTo("ask") == 0)
            {
                return VolatilityAsk;
            }
            else if (sensi.ToLowerInvariant().CompareTo("bid") == 0)
            {
                return VolatilityBid;
            }
            return null;
        }

        /// <summary>
        /// Pour l'affichage
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return Name;
        }

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
