﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class ProductCompulsoryProperties
    {
        #region attributes

        private string _strike;
        private string _maturityValue;

        #endregion

        private ProductCompulsoryProperties()
        {
        }

        public ProductCompulsoryProperties(string strike, string maturityValue)
        {
            _strike = strike;
            _maturityValue = maturityValue;
        }

        #region Properties
        public string Strike
        {
            get { return _strike; }
            set { _strike = value; }
        }

        public string MaturityValue
        {
            get { return _maturityValue; }
            set { _maturityValue = value; }
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

        //public override bool Equals(object obj)
        //{
        //    if (obj == null || !(obj is ProductCompulsoryProperties))
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return ((this._strike==null && (obj as ProductCompulsoryProperties)._strike==null) || (this._strike.ToUpperInvariant().Equals((obj as ProductCompulsoryProperties)._strike.ToUpperInvariant())))
        //            && ((this._maturityValue==null && (obj as ProductCompulsoryProperties)._maturityValue==null) || (this._maturityValue.ToUpperInvariant().Equals((obj as ProductCompulsoryProperties)._maturityValue.ToUpperInvariant())));
        //    }
        //}

        ///// <summary>
        ///// GetHashCode
        ///// </summary>
        ///// <returns></returns>
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}
    }
}
