﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Represente une sensibilité pour un produit
    /// on evite un calcul de sensi pour prendre les bid/ask
    /// </summary>
    [Serializable]
    public class ProductSensitivity
    {
        #region attributes

        private string _bumpProperty;
        private string _bumpValue;

        #endregion

        private ProductSensitivity()
        {
        }

        public ProductSensitivity(string bumpProperty, string bumpValue)
        {
            _bumpProperty = bumpProperty;
            _bumpValue = bumpValue;
        }

        #region Properties
        public string BumpProperty
        {
            get { return _bumpProperty; }
            set { _bumpProperty = value; }
        }

        public string BumpValue
        {
            get { return _bumpValue; }
            set { _bumpValue = value; }
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
