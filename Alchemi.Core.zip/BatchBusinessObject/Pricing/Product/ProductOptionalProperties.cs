﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class ProductOptionalProperties
    {
        #region attributes

        private string _productProperty;
        private string _propertyValue;

        #endregion

        private ProductOptionalProperties()
        {
        }

        public ProductOptionalProperties(string productProperty, string propertyValue)
        {
            _productProperty = productProperty;
            _propertyValue = propertyValue;
        }

        #region Properties
        public string ProductProperty
        {
            get { return _productProperty; }
            set { _productProperty = value; }
        }

        public string PropertyValue
        {
            get { return _propertyValue; }
            set { _propertyValue = value; }
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

        //public override bool Equals(object obj)
        //{
        //    if (obj == null || !(obj is ProductOptionalProperties))
        //    {
        //        return false;
        //    }
        //    else
        //    {
        //        return ((this._productProperty==null && (obj as ProductOptionalProperties)._productProperty==null) || (this._productProperty.ToUpperInvariant().Equals((obj as ProductOptionalProperties)._productProperty.ToUpperInvariant())))
        //            && ((this._propertyValue==null && (obj as ProductOptionalProperties).PropertyValue==null) || (this._propertyValue.ToUpperInvariant().Equals((obj as ProductOptionalProperties)._propertyValue.ToUpperInvariant())));
        //    }
        //}

        ///// <summary>
        ///// GetHashCode
        ///// </summary>
        ///// <returns></returns>
        //public override int GetHashCode()
        //{
        //    return base.GetHashCode();
        //}
    }
}
