﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Represente un produit avec un panier vide
    /// </summary>
    [Serializable]
    public class ProductTask
    {
        #region attributes

        private string _ID; // the ID on the file, just for compatibility with previous version.
        private string _scriptName;
        private string _description;
        private IList<ProductSensitivity> _bump;
        private ProductCompulsoryProperties _compulsoryProperties;
        private IList<ProductOptionalProperties> _optionalProperties;

        #endregion

        public ProductTask()
        {
        }

        public ProductTask(string ID, string scriptName, string description,  IList<ProductSensitivity> bump,
            ProductCompulsoryProperties compulsoryProperties, IList<ProductOptionalProperties> optionalProperties)
        {
            _ID = ID;
            _scriptName = scriptName;
            _description = description;
            _bump = bump;
            _compulsoryProperties = compulsoryProperties;
            _optionalProperties = optionalProperties;
        }

        #region Properties

        public string ID
        {
            get { return _ID; }
            set { _ID = value; }
        }

        public string ScriptName
        {
            get { return _scriptName; }
            set { _scriptName = value; }
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

     
        public IList<ProductSensitivity> Sensitivities
        {
            get { return _bump; }
            set { _bump = value; }
        }

        public ProductCompulsoryProperties CompulsoryProperties
        {
            get { return _compulsoryProperties; }
            set { _compulsoryProperties = value; }
        }

        public IList<ProductOptionalProperties> OptionalProperties
        {
            get { return _optionalProperties; }
            set { _optionalProperties = value; }
        }

        #endregion

        // returns the bumps of the task.
        public string GetSensitivity(string property)
        {
            ProductSensitivity temp = Sensitivities.FirstOrDefault<ProductSensitivity>(bump => bump.BumpProperty.CompareTo(property) == 0);
            if (temp != null)
            {
                return temp.BumpValue;
            }
            return "";
        }

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
