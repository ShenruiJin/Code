﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Represente une tache dans le batch
    /// soit un produit, un panier et un calcul
    /// </summary>
    [Serializable]
    public class BatchPricingTask
    {
        #region constructor
        private BatchPricingTask()
        {
            this.Tag = string.Empty;
        }

        internal BatchPricingTask(string name, ProductTask product, BatchBasket basket, BatchCalculation calculation):this()
        {
            this.Name = name;
            this.Calculation = calculation;
            this.Product = product;
            this.Basket = basket;
        }

        internal BatchPricingTask(string name, ProductTask product, BatchBasket basket, BatchCalculation calculation, string Tag)
            : this(name, product, basket, calculation)
        {
            this.Tag = Tag;
        }

        #endregion

        #region Properties

        public string Name
        {
            get;
            private set;
        }

        public ProductTask Product
        {
            get;
            private set ;
        }

        public BatchBasket Basket
        {
            get;
            private set;
        }

        public BatchCalculation Calculation
        {
            get;
            private set;
        }

        public string Tag
        {
            get;
            set;
        }

        /// <summary>
        /// L'id au seins du Batch (et non le GUID de la base)
        /// </summary>
        public int ID
        {
            get;
            internal set;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        internal Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

    }
}
