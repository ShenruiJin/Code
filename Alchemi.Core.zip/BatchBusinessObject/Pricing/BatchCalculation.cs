﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class BatchCalculation
    {

        #region attributes

        private string _calculationType; // Type of the calculation method.
        private string _margin = "0.0";
        private string _objective;
        private string _alpha = "0.0";
        private string _beta = "0.0";
        private string _paramSolving;
        private string _model;
        private string _engine;
        private string _guess;

        #endregion

        private BatchCalculation()
        {
        }

        public BatchCalculation(string calculationType, string margin, string objective,
            string alpha, string beta, string paramSolving, string model, string engine,
            string guess)
        {
            _calculationType = calculationType;
            _margin = margin;
            _objective = objective;
            _alpha = alpha;
            _beta = beta;
            _paramSolving = paramSolving;
            _model = model;
            _engine = engine;
            _guess = guess;
        }

        #region Properties
        public string CalculationType
        {
            get { return _calculationType; }
            set { _calculationType = value; }
        }

        public string Margin
        {
            get { return _margin; }
            set { _margin = value; }
        }

        
        public string Objective
        {
            get { return _objective; }
            set { _objective = value; }
        }


        public string Alpha
        {
            get { return _alpha; }
            set { _alpha = value; }
        }


        public string Beta
        {
            get { return _beta; }
            set { _beta = value; }
        }

        
        public string ParamSolving
        {
            get { return _paramSolving; }
            set { _paramSolving = value; }
        }

        public string Model 
        {
            get { return _model;}
            set { _model = value;}
        }

        public string Engine 
        {
            get { return _engine; }
            set { _engine = value; } 
        }

        public string Guess
        {
            get { return _guess; }
            set { _guess = value; }
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

    }
}
