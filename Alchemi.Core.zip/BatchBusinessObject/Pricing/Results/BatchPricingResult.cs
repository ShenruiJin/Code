﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Le resultat d'un pricing/solving sur la grille
    /// </summary>
    [Serializable]
    public class BatchPricingResult
    {
        private BatchPricingResult() {}

        public BatchPricingResult(int taskID, string Variable, double VariableValue, string errorMsg)
        {
            this.TaskID = taskID;
            this.Variable = Variable;
            this.VariableValue = VariableValue;
            this.ErrorMsg = errorMsg;
        }

        #region properties

        public int TaskID
        {
            get;
            private set;
        }

        public string Variable
        {
            get;
            private set;
        }

        public double VariableValue
        {
            get;
            private set;
        }

        public string ErrorMsg
        {
            get;
            private set;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
