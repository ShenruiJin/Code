﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BatchBusinessObject.BatchTasks
{
    [Serializable]
    public class BatchHistorizedResults
    {
        private BatchHistorizedResults()
        {
        }

        public BatchHistorizedResults(string aBatchName)
        {
            this.BatchName = aBatchName;
            this.StartDate = DateTime.MaxValue;
            this.EndDate = DateTime.MaxValue;
            this.ResultPrivate = new List<BatchPricingResult>();
        }

        #region properties

        public string BatchName
        {
            get;
            private set;
        }


        public DateTime StartDate
        {
            get;
            private set;
        }

        public DateTime EndDate
        {
            get;
            private set;
        }

        protected IList<BatchPricingResult> ResultPrivate
        {
            get;
            set;
        }

        /// <summary>
        /// Pour enumerer les results
        /// </summary>
        public IEnumerable<BatchPricingResult> Result
        {
            get { return ResultPrivate; }
        }
      
        #endregion

        /// <summary>
        /// Indique le debut du batch
        /// </summary>
        public void Start()
        {
            this.StartDate = DateTime.Now;
        }

        /// <summary>
        /// Indique la fin
        /// </summary>
        public void End()
        {
            this.EndDate = DateTime.Now;
        }

        /// <summary>
        /// Ajoute ce result
        /// </summary>
        /// <param name="result"></param>
        public void AddResult(BatchPricingResult result)
        {
            this.ResultPrivate.Add(result);
        }

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
