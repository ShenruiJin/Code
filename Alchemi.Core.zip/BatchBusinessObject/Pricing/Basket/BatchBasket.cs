﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Un panier + une devise de cotation
    /// </summary>
    [Serializable]
    public class BatchBasket
    {
        #region Properties
        /// <summary>
        /// Les sous jacents
        /// </summary>
        public IList<WeightedAssets> Assets
        {
            get;
            private set;
        }
        /// <summary>
        /// La devise de cotation
        /// </summary>
        public string Currency
        {
            get;
            private set;
        }

        #endregion

        private BatchBasket()
        {
        }

        /// <summary>
        /// Le panier et la devise de cotation
        /// </summary>
        public BatchBasket(IList<WeightedAssets> assets, string currency) 
        {
            Assets = assets;
            Currency = currency;
        }
     
        /// <summary>
        /// Retourne une version 
        /// </summary>
        /// <returns></returns>
        public string GetPrintableValue()
        {
            return string.Join(",", Assets.Select<WeightedAssets, string>(Wasset => Wasset.Asset).ToArray<string>());
        }

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion
    }
}
