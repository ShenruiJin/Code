﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BatchBusinessObject.BatchTasks
{
    /// <summary>
    /// Pour un panier : la composante + son poid
    /// </summary>
    [Serializable]
    public class WeightedAssets
    {
        private WeightedAssets()
        {
        }
        /// <summary>
        /// La composante d'un panier
        /// </summary>
        /// <param name="asset">le ticker sophis</param>
        /// <param name="weight">le poids</param>
        public WeightedAssets(string asset, double weight)
        {
            this.Asset = asset;
            this.Weight = weight;
        }

        #region Properties
        /// <summary>
        /// Le ticker Sophis
        /// </summary>
        public string Asset
        {
            get;
            private set;
        }

        /// <summary>
        /// Le poids en % (0.10 = 10%)
        /// </summary>
        public double Weight
        {
            get;
            private set;
        }

        #endregion

        #region identification and serialisation specifics
        private Int64 _Guid;
        /// <summary>
        /// Guid: identifies uniquely an instance.
        /// </summary>
        private Int64 GUID
        {
            get { return _Guid; }
            set { _Guid = value; }
        }
        #endregion

    }
}
