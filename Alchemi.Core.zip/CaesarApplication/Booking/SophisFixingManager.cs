﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;
using GlobalDerivativesApplications.Reporting;

namespace CaesarApplication.Booking
{
    public class SophisFixingManager
    {
        public void WriteFile(string filePath,  ISophisFixings[] fixings)
        {
            var stdClauses = fixings.Cast<SophisFixings>().ToArray();

            var headerLine = string.Join(",", "Code", "Name", "Date", "Cloture", "Cloture2", "Cloture3");

            var lines = stdClauses.Select(x =>
            {
                var reference = BookingGeneric.GetReferenceFromSicovam(x.Sicovam);
                var array = new string[]
                {
                    reference,
                    x.Name,
                    x.Date.ToString("dd/MM/yyyy"),
                    x.Closing1.ToString(CultureInfo.InvariantCulture),
                    x.Closing2.ToString(CultureInfo.InvariantCulture),
                    x.Closing3.ToString(CultureInfo.InvariantCulture),
                };



                return array;
            }/*.Union(
                */);

            File.WriteAllLines(filePath, headerLine.AsArray().Union(lines.Select(x => string.Join(",", x))));
        }
    }
}
