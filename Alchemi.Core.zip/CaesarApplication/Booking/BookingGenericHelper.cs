﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Date;
using PricingBase.Dates.DatesHelper;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;
using System.IO;

namespace CaesarApplication.Booking
{
    public class BookingGenericHelper
    {
        #region Private Fields
        private SophisFixingManager sophisFixingManager;
        private SophisClauseManager sophisClauseManager;
        #endregion

        public BookingGenericHelper()
        {
            sophisFixingManager = new SophisFixingManager();
            sophisClauseManager = new SophisClauseManager();
        }

        /// <summary>
        /// (cloture colummn)copy Value to the next clause date for clause to delete
        /// </summary>
        /// <param name="clotureColValueToKeep"></param>
        /// <param name="baseClauses"></param>
        /// <param name="clausesToKeep"></param>
        public void SetClosingValueToFollowingClause(double[] clotureColValueToKeep, IList<IClause> baseClauses, List<IClause> clausesToKeep)
        {
            if (clotureColValueToKeep != null)
            {
                var clausesToDelete = baseClauses.Except(clausesToKeep).ToArray();
                clausesToDelete.Where(x => x.Closing.IsIn(clotureColValueToKeep)).ForEach(toDelete =>
                {
                    var next = clausesToKeep.FirstOrDefault(c => c.EndDate > toDelete.EndDate);
                    if (next != null)
                    {
                        next.Closing = toDelete.Closing;
                    }
                });
            }
        }
        /// <summary>
        /// Order by EndDate + set StartDate and EndDate
        /// </summary>
        /// <param name="clausesToKeep"></param>
        /// <returns></returns>
        public List<IClause> OrderClause(List<IClause> clausesToKeep)
        {
            var tmp = clausesToKeep.OrderBy(x => x.EndDate).ToList();
            if (tmp[0].StartDate == tmp[0].EndDate)
                tmp[0].StartDate = CalendarHelper.AddAdjustedPeriod(new PricingCalendar(), -1, tmp[0].EndDate);
            for (int i = 1; i < tmp.Count; i++)
            {
                tmp[i].StartDate = tmp[i - 1].EndDate;
            }

            return tmp;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="baseClauses"></param>
        /// <param name="date"></param>
        /// <param name="isHybrid"></param>
        /// <param name="clausesToKeep"></param>
        public void AddClauseToKeep(IList<IClause> baseClauses, DateTime date, List<IClause> clausesToKeep, bool isHybrid )
        {
            var previousClause = baseClauses.Any(x => x.EndDate < date)
                ? baseClauses.LastOrDefault(x => x.EndDate < date)
                : baseClauses.FirstOrDefault(x => x.EndDate > date);


            var newClause = isHybrid
                ? CreateHybridClause(null, 0, 0, 0, 0, date)
                : CreateClause(null, 0, 0, 0, 0, date);
            if (previousClause != null)
            {
                newClause.Gearing = previousClause.Gearing;
                newClause.ExDate = previousClause.ExDate;
                newClause.PaymentDate = previousClause.PaymentDate;
                newClause.AdditionalColumns = previousClause.AdditionalColumns;
                newClause.Max = previousClause.Max;
                newClause.Min = previousClause.Min;
                newClause.Closing = previousClause.Closing;

                if(previousClause is IHybridClause)
                {
                    ((IHybridClause)newClause).HybGearing = ((IHybridClause)previousClause).HybGearing;
                    ((IHybridClause)newClause).HybMax = ((IHybridClause)previousClause).HybMax;
                    ((IHybridClause)newClause).HybMin = ((IHybridClause)previousClause).HybMin;
                }
            }
            newClause.EndDate = date;
            clausesToKeep.Add(newClause);
        }

        internal HybridClause CreateHybridClause(HybridClause clause, double min, double hybMin, double max, double hybMax, DateTime date, Dictionary<int, double> additionnalColumns = null, bool putHybInAdditionalCols = true)
        {
            var clauseToChange = clause ?? new HybridClause(date, date);

            var originalAdditionalColumns = CreateAdditionalColumns(clauseToChange.AdditionalColumns, hybMin, hybMax, putHybInAdditionalCols);

            if (additionnalColumns != null && originalAdditionalColumns.Any())
            {
                var newAdditionnalColumns = MergeAdditionnalColumns(additionnalColumns, originalAdditionalColumns);

                originalAdditionalColumns = newAdditionnalColumns;
            }

            clauseToChange.Min = min;
            clauseToChange.HybMin = hybMin;
            clauseToChange.Max = max;
            clauseToChange.HybMax = hybMax;
            clauseToChange.Gearing = 0.0d;

            clauseToChange.AdditionalColumns = originalAdditionalColumns;

            return clauseToChange;
        }

        internal Clause CreateClause(Clause clause, double min, double max, double hybMin, double hybMax, DateTime date, Dictionary<int, double> additionnalColumns = null, bool putHybInAdditionalCols = true)
        {
            var clauseToChange = clause ?? new Clause(date, date);

            var originalAdditionalColumns = CreateAdditionalColumns(clauseToChange.AdditionalColumns, hybMin, hybMax, putHybInAdditionalCols);

            if (additionnalColumns != null && originalAdditionalColumns.Any())
            {
                var newAdditionnalColumns = MergeAdditionnalColumns(additionnalColumns, originalAdditionalColumns);

                originalAdditionalColumns = newAdditionnalColumns;
            }

            clauseToChange.Min = min;
            clauseToChange.Max = max;
            clauseToChange.Gearing = 0.0d;
            clauseToChange.AdditionalColumns = originalAdditionalColumns;

            return clauseToChange;
        }

        private double[] CreateAdditionalColumns(IList<double> additionalColumns, double hybMin, double hybMax, bool putHybInAdditionalCols = true)
        {
            var valuesToSet = putHybInAdditionalCols ? new[] { 0.0, hybMin, hybMax } : new double[0];

            var size = additionalColumns != null && additionalColumns.Count > valuesToSet.Length ? additionalColumns.Count : valuesToSet.Length;

            var newAdditionnalColumns = new double[size];

            if (additionalColumns != null)
            {
                Array.Copy(additionalColumns.ToArray(), newAdditionnalColumns, additionalColumns.Count);
            }

            for (int i = 0; i < valuesToSet.Length; i++)
            {
                newAdditionnalColumns[i] = valuesToSet[i];
            }

            return newAdditionnalColumns;
        }

        private double[] MergeAdditionnalColumns(Dictionary<int, double> initialValues, double[] newValues)
        {
            var maxIndex = initialValues.Max(x => x.Key);

            var size = maxIndex > newValues.Length ? maxIndex : newValues.Length;

            var newAdditionnalColumns = new double[size];

            for (int i = 0; i < size; i++)
            {
                if (i < newValues.Length)
                {
                    newAdditionnalColumns[i] = newValues[i];
                }

                if (initialValues.ContainsKey(i + 1))
                {
                    newAdditionnalColumns[i] = initialValues[i + 1];
                }
            }
            return newAdditionnalColumns;
        }

        internal void BackupFixings(int sicovam, ISophisFixings[] final, string prefix)
        {
            try
            {
                var fileName = GetFixingsBackupFileName(sicovam, prefix);

                sophisFixingManager.WriteFile(fileName, final.ToArray());
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("Booking")
                    .Error(string.Format("Error while write backup file name " + prefix + " for clauses {0}", sicovam), e);
            }
        }
        private string GetFixingsBackupFileName(int sicovam, string prefix)
        {
            return Path.Combine(Environment.GetEnvironmentVariable("TEMP"), prefix + @"_UpdateSophisOptionsFixings_" + sicovam + "_" + DateTime.Now.ToString("ddMMyyyHHmmss") + ".csv");
        }
        internal void BackupClauses(int sicovam, bool isHybrid, IClause[] final, string prefix)
        {
            try
            {
                var fileName = GetClausesBackupFileName(sicovam, prefix);

                sophisClauseManager.WriteFile(fileName, isHybrid, final.ToArray());
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("Booking")
                    .Error(string.Format("Error while write backup file name " + prefix + " for clauses {0}", sicovam), e);
            }
        }

        private string GetClausesBackupFileName(int sicovam, string prefix)
        {
            return Path.Combine(Environment.GetEnvironmentVariable("TEMP"), prefix + @"_UpdateSophisOptions_" + sicovam + "_" + DateTime.Now.ToString("ddMMyyyHHmmss") + ".csv");
        }


    }
}
