﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Reporting;

namespace CaesarApplication.Booking
{
    public class SophisClauseManager
    {
        public void WriteFile(string filePath, bool isHybrid, IClause[] clauses)
        {
            if (isHybrid)
            {
                var hybridClauses = clauses.Cast<HybridClause>().ToArray();


                var headerLine = string.Join(",", "StartDate", "EndDate", "ExDate", "PaymentDate", "Min", "Max", "HybMin", "HybMax", "Gearing", "HybGearing", "Closing");

                File.WriteAllLines(filePath, headerLine.AsArray().Union(hybridClauses.Select(x =>
                {
                    var lines = new[] {
                        x.StartDate.ToString("dd/MM/yyyy"),
                        x.EndDate.ToString("dd/MM/yyyy"),
                        x.ExDate.ToString("dd/MM/yyyy"),
                        x.PaymentDate.ToString("dd/MM/yyyy"),
                        x.FixingDate.ToString("dd/MM/yyyy"),
                        x.Min.ToString(CultureInfo.InvariantCulture),
                        x.Max.ToString(CultureInfo.InvariantCulture),
                        x.HybMin == null ? string.Empty : x.HybMin.ToString(),
                        x.HybMax == null ? string.Empty : x.HybMax.ToString(),
                        x.Gearing.ToString(),
                        x.HybGearing == null ? "" : x.HybGearing.ToString(),
                        x.Closing.ToString(CultureInfo.InvariantCulture)}
                        .Concat(
                            Enumerable.Range(0, 9).Select(i => i < x.AdditionalColumns.Count ? x.AdditionalColumns[i].ToString(CultureInfo.InvariantCulture) : "")).ToArray();


                    return string.Join(",",
                        lines);
                })).ToArray());
            }
            else
            {
                var stdClauses = clauses.Cast<Clause>().ToArray();

                var headerLine = string.Join(",", "StartDate", "EndDate", "ExDate", "PaymentDate", "Min", "Max", "Gearing", "Closing");

                var lines = stdClauses.Select(x =>
                {
                    var array = new string[]
                    {
                        x.StartDate.ToString("dd/MM/yyyy"),
                        x.EndDate.ToString("dd/MM/yyyy"),
                        x.ExDate.ToString("dd/MM/yyyy"),
                        x.PaymentDate.ToString("dd/MM/yyyy"),
                        x.FixingDate.ToString("dd/MM/yyyy"),
                        x.Min.ToString(CultureInfo.InvariantCulture),
                        x.Max.ToString(CultureInfo.InvariantCulture),
                        x.Gearing.ToString(CultureInfo.InvariantCulture),
                        x.Closing.ToString(CultureInfo.InvariantCulture)
                    };

                    var additionalColumns = Enumerable.Range(0, 9)
                        .Select(i => i < x.AdditionalColumns.Count ? x.AdditionalColumns[i].ToString() : "").
                    ToArray();

                    

                    return array.Concat(additionalColumns).ToArray();
                }/*.Union(
                    */).ToArray();




                File.WriteAllLines(filePath, headerLine.AsArray().Union(lines.Select(x => string.Join(",", x))));
            }
        }

        private IClause CreateClause(string clauseAsString)
        {
            var parts = clauseAsString.Split(',');

            if (parts.Length == 21)
            {
                return new HybridClause
                {
                    StartDate = DateTime.ParseExact(parts[0], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    EndDate = DateTime.ParseExact(parts[1], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    ExDate = DateTime.ParseExact(parts[2], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    PaymentDate = DateTime.ParseExact(parts[3], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    FixingDate = DateTime.ParseExact(parts[4], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    Min = double.Parse(parts[5], CultureInfo.InvariantCulture),
                    Max = double.Parse(parts[6], CultureInfo.InvariantCulture),
                    HybMin = double.Parse(parts[7], CultureInfo.InvariantCulture),
                    HybMax = double.Parse(parts[8], CultureInfo.InvariantCulture),
                    Gearing = double.Parse(parts[9], CultureInfo.InvariantCulture),
                    HybGearing = double.Parse(parts[10], CultureInfo.InvariantCulture),
                    Closing = double.Parse(parts[11], CultureInfo.InvariantCulture),
                    AdditionalColumns = parts.Skip(12).Select(x => string.IsNullOrEmpty(x) ? 0 : double.Parse(x, CultureInfo.InvariantCulture)).ToList()
                };
            }
            else
            {
                return new Clause
                {
                    StartDate = DateTime.ParseExact(parts[0], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    EndDate = DateTime.ParseExact(parts[1], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    ExDate = DateTime.ParseExact(parts[2], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    PaymentDate = DateTime.ParseExact(parts[3], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    FixingDate = DateTime.ParseExact(parts[4], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                    Min = double.Parse(parts[5], CultureInfo.InvariantCulture),
                    Max = double.Parse(parts[6], CultureInfo.InvariantCulture),
                    Gearing = double.Parse(parts[7], CultureInfo.InvariantCulture),
                    Closing = double.Parse(parts[8], CultureInfo.InvariantCulture),
                    AdditionalColumns = parts.Skip(9).Select(x => string.IsNullOrEmpty(x) ? 0 : double.Parse(x, CultureInfo.InvariantCulture)).ToList()
                };
            }
        }

        public IClause[] LoadClausesFromFile(string filePath)
        {
            return File.ReadAllLines(filePath).Skip(1).Select(CreateClause).ToArray();
        }
    }
}
