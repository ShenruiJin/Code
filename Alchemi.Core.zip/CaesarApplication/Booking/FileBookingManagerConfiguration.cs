namespace CaesarApplication.Booking
{
    public class FileBookingManagerConfiguration
    {
        public BookingCompareConfigurationItem[] BookingCompareConfigurationItems { get; set; }
    }
}