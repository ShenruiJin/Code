﻿namespace CaesarApplication.Booking
{
    public enum BookingPrismCompositionCompareItemStatus
    {
        OK,
        KO
    }
}
