namespace CaesarApplication.Booking
{
    public class BookingBasketWeightCompareItem : BookingFixingBaseCompareItem
    {
        public int Lag { get; set; }

        public int? WeightColumn
        {
            get;
            set;
        }
    }
}