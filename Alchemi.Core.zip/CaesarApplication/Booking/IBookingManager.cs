﻿using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;

namespace CaesarApplication.Booking
{
    public interface IBookingManager
    {
        BookingCalendarCompareItem[] CompareCalendar(int sicovam, IndexInfos index, DateTime startDate, DateTime endDate, bool compareFuture, int futureCheckNbDays, double? valoTolerance = null, bool addDayIfLastDayIsHoliday = false, int? futureCheckNbYears = null);

        BookingCalendarCompareItem[] CompareCalendar(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate);

        BookingFixingCompareItem[] CompareFixings(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate);

        IEnumerable<BookingFixingCompareItem> CompareFixings(int sicovam, IndexInfos idxInfos,
            DateTime startDate, DateTime endDate, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings= null, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodingsToIgnore = null, int? fixingRounding = null, double? valoTolerance = null);

        IEnumerable<BookingBasketWeightCompareItem> CompareBaskets(int sicovam, IndexInfos idxInfos, DateTime startDate, DateTime endDate, int lag, double? valoTolerance = null, int? weightColumn = 2);

        BookingBasketWeightCompareItem[] CompareBaskets(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate);
    }
}
