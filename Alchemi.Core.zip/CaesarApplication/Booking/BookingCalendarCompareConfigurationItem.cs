﻿using System.Collections.Generic;

namespace CaesarApplication.Booking
{
    public class BookingCompareConfigurationItem
    {
        private int futureCheckNbDays = 100;
        private bool compareFuture = true;
        private bool applyRounding = true;
        private int lag = 1;
        private List<SophisCaesarTranscodingItem> sophisCaesarTranscoding;

        private int basketBookingLag = 0;

        private int? fixingRounding;

        private List<SophisCaesarTranscodingItem> sophisCaesarTranscodingToIgnore;

        public int[] Sicovams { get; set; }

        public string IndexBloombergTicker { get; set; }

        public bool ApplyRounding
        {
            get { return applyRounding; }
            set { applyRounding = value; }
        }

        public int Lag
        {
            get { return lag; }
            set { lag = value; }
        }

        public int BasketBookingLag
        {
            get { return basketBookingLag; }
            set { basketBookingLag = value; }
        }

        public List<SophisCaesarTranscodingItem> SophisCaesarTranscoding
        {
            get { return sophisCaesarTranscoding; }
            set { sophisCaesarTranscoding = value; }
        }

        public List<SophisCaesarTranscodingItem> SophisCaesarTranscodingToIgnore
        {
            get { return sophisCaesarTranscodingToIgnore; }
            set { sophisCaesarTranscodingToIgnore = value; }
        }

        public bool CompareFuture
        {
            get
            {
                return compareFuture;
            }

            set
            {
                compareFuture = value;
            }
        }

        public int FutureCheckNbDays
        {
            get
            {
                return futureCheckNbDays;
            }

            set
            {
                futureCheckNbDays = value;
            }
        }

        public int? FixingRounding
        {
            get
            {
                return fixingRounding;
            }

            set
            {
                fixingRounding = value;
            }
        }

        public class SophisCaesarTranscodingItem
        {
            public string CaesarValue { get; set; }
            public string SophisValue { get; set; }
        }

        public bool SicovamsFromSophis
        {
            get;
            set;
        }

        public bool SicovamFromIndexDTO
        {
            get;
            set;
        }

        public string SpecificFolder
        {
            get;
            set;
        }

        public double? ValoTolerance
        {
            get;
            set;
        }

        public int? WeightColumn
        {
            get;
            set;
        }

        public bool? CheckOnlyPublishedDate
        {
            get;
            set;
        }
    }
}