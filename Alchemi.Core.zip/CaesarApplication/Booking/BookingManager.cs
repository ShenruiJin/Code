using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using FuncFramework.Business;
using GlobalDerivativesApplications.Data.Booking;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Date;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;
using CaesarApplication.DataProvider.Bloomberg;
using CaesarApplication.Service.Validation;
using CaesarApplication.DataProvider.Prism;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;

namespace CaesarApplication.Booking
{
    public class BookingManager : IBookingManager
    {
        public static string Database = "PROD";
        public static string Login = "APP_CAESAR_BATCH";
        public static string Password = "@6Nf2YuT";


        private DateTime _startDate = DateTime.Today.AddDays(-90);
        private static DateTime _endDate = DateTime.Today;

        private ITimeSeriesProvider tsp;
        private static GenericBooker genericBooker = new GenericBooker();

        public BookingManager(ITimeSeriesProvider tsp)
        {
            this.tsp = tsp;
        }

        public int[] GetOptionSicovamForExternalRef(string externalReferenceName = "Indice algo", string externalRefValue = null)
        {
            return BookingManagerExtensions.GetOptionSicovamForExternalRef(externalRefValue, externalReferenceName);
        }

        public int[] GetSicovamForExternalRef(string externalReferenceName, string externalRefValue = null)
        {
            var sm2 = new SophisManager2FactoryWrapper().CreateSophisManager(Database, Login, Password);

            return sm2.Instrument.GetAllForExternalRef(externalReferenceName, externalRefValue).Select(x => x.Sicovam).ToArray();
        }

        public BookingCalendarCompareItem[] CompareCalendar(int sicovam, IndexInfos index, DateTime startDate, DateTime endDate, bool compareFuture, int futureCheckNbDays, double? valoTolerance = null, bool addDayIfLastDayIsHoliday = false, int? futureCheckNbYears = null)
        {
            var quotes = tsp.GetIndexQuotes(index.id.ToString(), startDate, endDate, true);

            return CompareCalendar(sicovam, index, startDate, endDate, quotes, compareFuture, futureCheckNbDays, valoTolerance, addDayIfLastDayIsHoliday, futureCheckNbYears);
        }

        public BookingCalendarCompareItem[] CompareCalendar(int sicovam, IndexInfos index, DateTime startDate, DateTime endDate, TimeSerieDB quotes, bool compareFuture, int futureCheckNbDays, double? valoTolerance = null, bool addDayIfLastDayIsHoliday = false, int? futureCheckNbYears = null)
        {
            var vTolerance = valoTolerance.GetValueOrDefault(0.0005d);

            var existingClauses = genericBooker.ReadClauses(sicovam, startDate, quotes.X.Max().AddDays(futureCheckNbDays), Database, Login, Password);

            var missingQuotesInSophis = quotes.Where(x => x.Key >= existingClauses.Select(v => v.EndDate).FirstOrDefault() && !existingClauses.Any(c => c.EndDate == x.Key)).ToArray();
            var clausesToRemove = existingClauses.Where(c => c.EndDate >= quotes.Select(x => x.Key).FirstOrDefault() && c.EndDate <= quotes.Select(x => x.Key).Cast<DateTime?>().LastOrDefault().GetValueOrDefault(DateTime.MaxValue) && !quotes.Any(x => c.EndDate == x.Key)).ToArray();

            var validated = existingClauses.Except(clausesToRemove).ToArray();

            if (!existingClauses.Any())
            {
                return new BookingCalendarCompareItem[0];
            }

            var clauseStartDate = existingClauses.Min(x => x.EndDate);

            startDate = new DateTime[] { clauseStartDate, startDate }.Min();

            var futureBookingCalendarCompareItems = new BookingCalendarCompareItem[0];

            if (compareFuture || quotes.X.Max() < startDate)
            {
                var cal = tsp.GetCalendarForBbgTicker(index.bloomberg_ticker, endDate);

                if (cal != null)
                {
                    var lastDate = quotes.X.Cast<DateTime?>().LastOrDefault() ?? endDate;
                    var lastSearchedDate = lastDate.AddDays(futureCheckNbDays).AddYears(futureCheckNbYears.GetValueOrDefault());

                    var expectedDates = cal.GetBusinessDays(lastDate.AddDays(1), lastSearchedDate);

                    var futuresClauseDates = genericBooker.ReadClauses(sicovam, lastDate.AddDays(1), lastSearchedDate, Database, Login, Password).Where(x => x.EndDate > lastDate && x.EndDate <= lastSearchedDate).Select(x => x.EndDate).ToArray();

                    var additionalClauseS = addDayIfLastDayIsHoliday && !cal.IsBusinessDay(lastSearchedDate) ? new BookingCalendarCompareItem { Date = cal.GetBusinessDays(lastSearchedDate, lastSearchedDate.AddDays(10)).First(), Index = index, IndexBloombergTicker = index.bloomberg_ticker, Sicovam = sicovam, Status = BookingCalendarCompareItemStatus.ToRemove, Estimated = true }.AsArray() : new BookingCalendarCompareItem[0];

                    futureBookingCalendarCompareItems = futuresClauseDates.Except(expectedDates).Select(x => new BookingCalendarCompareItem { Date = x, Index = index, IndexBloombergTicker = index.bloomberg_ticker, Sicovam = sicovam, Status = BookingCalendarCompareItemStatus.ToRemove, Estimated = true })
                        .Concat(additionalClauseS)
                        .ToArray();
                }
            }

            return missingQuotesInSophis.Select(x => new BookingCalendarCompareItem { Date = x.Key, Index = index, IndexBloombergTicker = index.bloomberg_ticker, Sicovam = sicovam, Status = BookingCalendarCompareItemStatus.ToAdd, ValoTolerance = vTolerance })
                .Union(clausesToRemove.Select(x => new BookingCalendarCompareItem { Date = x.EndDate, Index = index, IndexBloombergTicker = index.bloomberg_ticker, Sicovam = sicovam, Status = BookingCalendarCompareItemStatus.ToRemove, ValoTolerance = vTolerance }))
                .Union(validated.Select(x => new BookingCalendarCompareItem { Date = x.EndDate, Index = index, IndexBloombergTicker = index.bloomberg_ticker, Sicovam = sicovam, Status = BookingCalendarCompareItemStatus.OK, ValoTolerance = vTolerance }))
                .Union(futureBookingCalendarCompareItems)
                .ToArray();

        }

        public BookingCalendarCompareItem[] CompareCalendar(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return configs.SelectMany(cfg =>
            {
                var indexInfos = tsp.GetIndexInfos(cfg.IndexBloombergTicker);
                var quotes = tsp.GetIndexQuotes(indexInfos.id.ToString(), startDate, endDate, true);
                var eDate = endDate;

                if (cfg.CheckOnlyPublishedDate.GetValueOrDefault(true))
                {
                    var bbgQuotes = tsp.Load(indexInfos.bloomberg_ticker, DataFieldsEnum.Last, startDate, endDate);

                    eDate = bbgQuotes.X.Cast<DateTime?>().LastOrDefault() ?? endDate;
                }

                return cfg.Sicovams.SelectMany(sico => CompareCalendar(sico, indexInfos, StartDate, ApplyLag(eDate, cfg.Lag), quotes, cfg.CompareFuture, cfg.FutureCheckNbDays, cfg.ValoTolerance));
            }).ToArray();
        }

        private DateTime ApplyLag(DateTime date, int lag)
        {
            var res = date;

            int nbDays = 0;

            while (nbDays < lag)
            {
                res = res.AddDays(lag > 0 ? -1 : 1);
                if (res.DayOfWeek != DayOfWeek.Saturday && res.DayOfWeek != DayOfWeek.Sunday)
                {
                    nbDays++;
                }
            }

            return res;
        }

        public BookingFixingCompareItem[] CompareFixings(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return configs.SelectMany(cfg =>
            {
                try
                {
                    var indexInfos = tsp.GetIndexInfos(cfg.IndexBloombergTicker);
                    var bktsList = GetBasketAuditTs(startDate, endDate, indexInfos);

                    var eDate = endDate;

                    if (cfg.CheckOnlyPublishedDate.GetValueOrDefault(true))
                    {
                        var bbgQuotes = tsp.Load(indexInfos.bloomberg_ticker, DataFieldsEnum.Last, startDate, endDate);

                        eDate = bbgQuotes.X.Cast<DateTime?>().LastOrDefault() ?? endDate;
                    }

                    return CompareFixings(cfg.Sicovams, indexInfos, StartDate, ApplyLag(eDate, cfg.Lag), bktsList, cfg.ApplyRounding, cfg.SophisCaesarTranscoding, cfg.SophisCaesarTranscodingToIgnore, cfg.FixingRounding, cfg.ValoTolerance).ToArray();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Fail to compute :" + cfg.IndexBloombergTicker);
                    Console.WriteLine(ex);

                    return new BookingFixingCompareItem[0];
                }
            }).ToArray();
        }

        private TimeSerieDB GetBasketAuditTs(DateTime startDate, DateTime endDate, IndexInfos indexInfos)
        {
            tsp.ClearTreeData(DataFieldsEnum.IndexAuditBasketResult);
            var bktsList = tsp.GetBasketsAudit(indexInfos.id.ToString(), startDate, endDate);
            return bktsList;
        }

        public BookingBasketWeightCompareItem[] CompareBaskets(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return configs.SelectMany(cfg =>
            {
                try
                {
                    var indexInfos = tsp.GetIndexInfos(cfg.IndexBloombergTicker);
                    var bktsList = GetBasketIndexLists(indexInfos, startDate, endDate);

                    var eDate = endDate;

                    if (cfg.CheckOnlyPublishedDate.GetValueOrDefault(true))
                    {
                        var bbgQuotes = tsp.Load(indexInfos.bloomberg_ticker, DataFieldsEnum.Last, startDate, endDate);

                        eDate = bbgQuotes.X.Cast<DateTime?>().LastOrDefault() ?? endDate;
                    }

                    return cfg.Sicovams.SelectMany(sico =>
                    {
                        try
                        {
                            return CompareBaskets(sico, indexInfos, StartDate, ApplyLag(eDate, cfg.Lag), bktsList, cfg.BasketBookingLag, weightColumn: cfg.WeightColumn);
                        }
                        catch (Exception exInner)
                        {
                            Console.WriteLine("Fail to compute :" + cfg.IndexBloombergTicker);
                            Console.WriteLine(exInner);

                            return new BookingBasketWeightCompareItem[0];
                        }
                    });
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Fail to compute :" + cfg.IndexBloombergTicker);
                    Console.WriteLine(ex);

                    return new BookingBasketWeightCompareItem[0];
                }
            }).ToArray();
        }

        public BookingPrismCompositionCompareItem[] ComparePrismCompositions(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return configs.SelectMany(cfg =>
            {
                var indexInfos = tsp.GetIndexInfos(cfg.IndexBloombergTicker);

                return ComparePrismCompositions(indexInfos, StartDate, ApplyLag(EndDate, cfg.Lag));
            }).ToArray();
        }

        public IEnumerable<BookingFixingCompareItem> CompareFixings(int sicovam, IndexInfos idxInfos,
            DateTime startDate, DateTime endDate, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodingsToIgnore = null, int? fixingRounding = null, double? valoTolerance = null)
        {
            var bktsList = GetBasketAuditTs(startDate, endDate, idxInfos);

            return CompareFixings(sicovam, idxInfos, startDate, endDate, bktsList, applyRounding, sophisCaesarTranscodings, sophisCaesarTranscodingsToIgnore, fixingRounding, valoTolerance);
        }

        public IEnumerable<BookingFixingCompareItem> CompareFixings(int sicovam, IndexInfos idxInfos,
            DateTime startDate, DateTime endDate, TimeSerieDB bktsList, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodingsToIgnore = null, int? fixingRounding = null, double? valoTolerance = null)
        {
            return CompareFixings(sicovam.AsArray(), idxInfos, startDate, endDate, bktsList, applyRounding, sophisCaesarTranscodings, sophisCaesarTranscodingsToIgnore, fixingRounding, valoTolerance);


        }

        public IEnumerable<BookingFixingCompareItem> CompareFixings(int[] sicovams, IndexInfos idxInfos,
    DateTime startDate, DateTime endDate, TimeSerieDB bktsList, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodingsToIgnore = null, int? fixingRounding = null, double? valoTolerance = null)
        {
            var res = new List<BookingFixingCompareItem>();


            var components = bktsList.Any() ? bktsList.Y.Cast<BasketIndexList>().Last().Baskets.Where(b => b.Components != null && b.Components.Any()).Select(x => x.LastComposition).SelectMany(x => x.BloombergTickers()).Distinct().ToArray() : null;

            var project =
                PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(idxInfos.id.AsArray(),
                    UserService.CaesarSession).First().Value;

            project = PersistanceService.IndexProvider.ReadProject(project.id, UserService.CaesarSession);

            var componentBaskets = GetComponentAuditBaskets(startDate, endDate, components, project);
            Dictionary<int, string> tickersOverrides = null;

            var underlyingsToIndexInfosDico = new Dictionary<string, IndexInfos>();

            foreach (var sicovam in sicovams)
            {
                var fixings = genericBooker.ReadFixings(sicovam, startDate, endDate, Database, Login, Password);

                if (fixings.Any())
                { 
                tickersOverrides = tickersOverrides ?? SophisHelper.GetTickerOverrides(sicovams.First());

                var startDateFixing = fixings.Min(x => x.Date);

                var sicovamByTickersDico = new Dictionary<string, int>();

                    foreach (var bkts in bktsList.Y.Cast<BasketIndexList>().Where(x => x.VersionDate >= startDateFixing))
                    {
                        if (bkts.Baskets.Any(b => b.Name == BasketIndex.AuditBasketName))
                        {
                            var globalBkt = BasketTools.AggregateBaskets(componentBaskets.Where(x => x.EffectiveDate == bkts.EffectiveDate).SelectMany(x => x.Baskets).Union(bkts.Baskets).ToArray());

                            var nextDate = bktsList.X.Cast<DateTime?>().FirstOrDefault(x => x > bkts.EffectiveDate);
                            var nextglobalBkt = nextDate.HasValue ? BasketTools.AggregateBaskets(componentBaskets.Where(x => x.EffectiveDate == nextDate.GetValueOrDefault()).SelectMany(x => x.Baskets).Union(bktsList.Y.Cast<BasketIndexList>().Where(x => x.EffectiveDate == nextDate).SelectMany(x => x.Baskets)).ToArray()) : null;

                            if (globalBkt.Data.Count > 0)
                            {
                                var underlyingTimeSeries = (globalBkt.Data.ContainsKey(DataFieldsEnum.Last.ToString()) ? globalBkt.Data[DataFieldsEnum.Last.ToString()] : new TimeSerieDB[0])
                                  .Union((globalBkt.Data.ContainsKey(DataFieldsEnum.IndexQuote.ToString()) ? globalBkt.Data[DataFieldsEnum.IndexQuote.ToString()] : new TimeSerieDB[0])).ToArray();

                                var dayFixings = fixings.Where(x => x.Date >= underlyingTimeSeries.SelectMany(ts => ts.X).Min() && x.Date <= underlyingTimeSeries.SelectMany(ts => ts.X).Max()).ToArray();
                                var referenceDate = bkts.EffectiveDate.GetValueOrDefault();

                                bool globalMatching = true;

                                var underlyings = underlyingTimeSeries.Distinct()
                                    .Select(x => x.Instrument).ToArray();

                                var riskedSelectionDico = globalBkt.ResultData.ContainsKey(DefaultFields.SelectionValue) ? globalBkt.ResultData[DefaultFields.SelectionValue].ToDictionary(x => x.Instrument, x => x) : new Dictionary<string, TimeSerieDB>();
                                var isTargetVolOption = false;

                                foreach (var fixing in dayFixings)
                                {
                                    var sophisValue = fixing.Closing1;

                                    var instrument =
                                        SophisHelper.GetInstrumentInfo(fixing.Sicovam.ToString(),
                                            EnumSophisRefCodeType.Sicovam);

                                    if (sophisCaesarTranscodingsToIgnore == null || !sophisCaesarTranscodingsToIgnore.Any(x => x.SophisValue == instrument.Reference))
                                    {
                                        var ticker = instrument != null
                                        ? (string.IsNullOrEmpty(instrument.GL) ? instrument.Reference : instrument.GL)
                                        : null;

                                        ticker = tickersOverrides.ContainsKey(fixing.Sicovam)
                                            ? tickersOverrides[fixing.Sicovam]
                                            : ticker;

                                        AdaptTickerIfFX(instrument, underlyings, ref ticker);

                                        if (ticker != null)
                                        {
                                            sicovamByTickersDico[ticker] = fixing.Sicovam;
                                        }

                                        var indexInfos = idxInfos.ticker == ticker
                                            ? idxInfos
                                            : GetIndexInfos(underlyingsToIndexInfosDico, ticker);

                                        var caesarValue = GetCaesarValue(globalBkt, ticker, indexInfos, fixing.Date, applyRounding, sophisCaesarTranscodings, fixingRounding, riskedSelectionDico);

                                        caesarValue = AdjustWithQuoteFactor(ticker, caesarValue);

                                        var matching = Math.Abs(sophisValue - caesarValue) < 1e-5;

                                        if (riskedSelectionDico.ContainsKey(ticker))
                                        {
                                            isTargetVolOption = true;
                                        }

                                        if (!double.IsNaN(caesarValue))
                                        {
                                            res.Add(new BookingFixingCompareItem
                                            {
                                                UnderlyingCode = ticker,
                                                UnderlyingSicovam = fixing.Sicovam,
                                                CaesarValue = caesarValue,
                                                SophisValue = sophisValue,
                                                Date = fixing.Date,
                                                Index = idxInfos,
                                                IndexBloombergTicker = idxInfos.bloomberg_ticker,
                                                Sicovam = sicovam,
                                                ApplyRounding = applyRounding,
                                                Status = matching
                                                    ? BookingFixingCompareItemStatus.OK
                                                    : BookingFixingCompareItemStatus.ValueKO,
                                                SophisCaesarTranscodings = sophisCaesarTranscodings,
                                                IsTargetVolOption = isTargetVolOption,
                                                ValoTolerance = valoTolerance.GetValueOrDefault(0.0005d)
                                            });
                                        }
                                    }
                                }

                                underlyings = isTargetVolOption ? sicovamByTickersDico.Keys.ToArray() : underlyings;

                                foreach (var udl in underlyings.Distinct().ToArray())
                                {
                                    if (sophisCaesarTranscodingsToIgnore == null || !sophisCaesarTranscodingsToIgnore.Any(x => x.CaesarValue == udl))
                                    {
                                        var isCurrentIndex = idxInfos.ticker == udl || idxInfos.ticker == udl.Replace("\u001a", "");

                                        var indexInfos = isCurrentIndex
                                            ? idxInfos
                                            : GetIndexInfos(underlyingsToIndexInfosDico, (project.indexes.Any(i => i.ticker == udl) ? (project.project_name + IndexPathHelper.Delimiter) : string.Empty) + udl);

                                        if ((indexInfos == null || !string.IsNullOrEmpty(indexInfos.sophis_reference)) &&
                                            !isCurrentIndex)
                                        {
                                            var sico =
                                                indexInfos != null
                                                    ? int.Parse(indexInfos.sophis_reference)
                                                    : (sicovamByTickersDico.ContainsKey(udl)
                                                        ? sicovamByTickersDico[udl]
                                                    : SophisHelper.GetSicovams(NormalizeTickerForSophis(udl, sophisCaesarTranscodings).AsArray()).Select(x => x.Value)
                                                            .FirstOrDefault());

                                            if (sico == 0)
                                            {
                                                LoggingService.WarnFormatted(GetType(), "No sicovam for {0}", udl);
                                            }
                                            else
                                            {
                                                var fixing =
                                                    fixings.FirstOrDefault(x => x.Date == referenceDate && x.Sicovam == sico);
                                                var caesarValue =
                                                    GetCaesarValue(globalBkt, udl, indexInfos, referenceDate, applyRounding, sophisCaesarTranscodings, riskedSelectionDico: riskedSelectionDico);

                                                caesarValue = AdjustWithQuoteFactor(udl, caesarValue);

                                                if (nextglobalBkt != null && double.IsNaN(caesarValue))
                                                {
                                                    caesarValue = GetCaesarValue(nextglobalBkt, udl, indexInfos, referenceDate, applyRounding, sophisCaesarTranscodings, fixingRounding, riskedSelectionDico);
                                                }

                                                var instrument =
                                                    SophisHelper.GetInstrumentInfo(sico.ToString(),
                                                        EnumSophisRefCodeType.Sicovam);

                                                if (fixing == null && !double.IsNaN(caesarValue))
                                                {
                                                    res.Add(new BookingFixingCompareItem
                                                    {
                                                        UnderlyingName = instrument.Name,
                                                        UnderlyingCode = udl,
                                                        UnderlyingSicovam = sico,
                                                        CaesarValue = caesarValue,
                                                        SophisValue = null,
                                                        Date = referenceDate,
                                                        Index = idxInfos,
                                                        IndexBloombergTicker = idxInfos.bloomberg_ticker,
                                                        Sicovam = sicovam,
                                                        ApplyRounding = applyRounding,
                                                        Status = BookingFixingCompareItemStatus.Missing,
                                                        ValoTolerance = valoTolerance.GetValueOrDefault(0.0005d)
                                                    });
                                                }
                                            }

                                        }
                                    }
                                }
                            }
                            else
                            {
                                LoggingService.WarnFormatted(GetType(), "No data for {0}", bkts.EffectiveDate);
                            }
                        }
                    }
                }
            }

            return res.GroupBy(x => new { x.Date, x.UnderlyingName, x.UnderlyingSicovam, x.IndexBloombergTicker, x.Sicovam }).Select(x => x.Last()).ToArray();
        }

        public IEnumerable<BookingFixingCompareItem> GetFixingsToAdd(int[] sicovams, IndexInfos idxInfos, DateTime startDate, DateTime endDate)
        {
            var res = new List<BookingFixingCompareItem>();


            var underlyingsToIndexInfosDico = new Dictionary<string, IndexInfos>();

            foreach (var sicovam in sicovams)
            {
                var fixings = genericBooker.ReadFixings(sicovam, startDate, endDate, Database, Login, Password);
                var clauses = genericBooker.ReadClauses(sicovam, startDate, endDate, Database, Login, Password);

                if (!fixings.Any())
                    return new BookingFixingCompareItem[0];

                var refFixings = fixings.GroupBy(x => x.Date).Where(x => x.All(v => !double.IsNaN(v.Closing1) && v.Closing1 != 0.0d)).Last();

                foreach (var clause in clauses.Where(x => x.EndDate > refFixings.First().Date))
                {
                    foreach (var refFixing in refFixings)
                    {
                        var fix = fixings.FirstOrDefault(x => x.Sicovam == refFixing.Sicovam && x.Date == clause.EndDate);

                        if (fix == null)
                        {
                            res.Add(new BookingFixingCompareItem
                            {
                                UnderlyingName = refFixing.Name,
                                UnderlyingCode = SophisHelper.GetReference(refFixing.Sicovam),
                                UnderlyingSicovam = refFixing.Sicovam,
                                CaesarValue = null,
                                SophisValue = null,
                                Date = clause.EndDate,
                                Index = idxInfos,
                                IndexBloombergTicker = idxInfos.bloomberg_ticker,
                                Sicovam = sicovam,
                                ApplyRounding = false,
                                Status = BookingFixingCompareItemStatus.Missing,
                                ValoTolerance = null
                            });
                        }
                    }
                }
            }

            return res.GroupBy(x => new { x.Date, x.UnderlyingName, x.UnderlyingSicovam, x.IndexBloombergTicker, x.Sicovam }).Select(x => x.Last()).ToArray();
        }

        private BasketIndexList[] GetComponentAuditBaskets(DateTime startDate, DateTime endDate, string[] components, ProjectDTO project)
        {
            return BasketTools.GetComponentAuditBaskets(tsp, startDate, endDate, project, components);
        }

        private double AdjustWithQuoteFactor(string ticker, double val)
        {
            if (SophisHelper.IsCurrencyTicker(ticker))
            {
                var quoteFactorTs = tsp.Load(ticker, DataFieldsEnum.QuoteFactor);

                if (quoteFactorTs.Any())
                {
                    var quoteFactor = quoteFactorTs.EvaluateLast();

                    return val / quoteFactor;
                }
            }

            return val;
        }

        private string NormalizeTickerForSophis(string rawRef, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null)
        {
            if (sophisCaesarTranscodings != null)
            {
                var sophisCaesarTranscoding = sophisCaesarTranscodings.FirstOrDefault(x => x.CaesarValue == rawRef);

                if (sophisCaesarTranscoding != null)
                {
                    return sophisCaesarTranscoding.SophisValue;
                }
            }

            return rawRef.Contains(IndexPathHelper.Delimiter) ? rawRef : BloombergHelper.GetTickerWithoutSuffix(rawRef);
        }

        public IEnumerable<BookingBasketWeightCompareItem> CompareBaskets(int sicovam, IndexInfos idxInfos,
            DateTime startDate, DateTime endDate, int lag, double? valoTolerance = null, int? weightColumn = 2)
        {
            var bktsList = GetBasketIndexLists(idxInfos, startDate, endDate);

            return CompareBaskets(sicovam, idxInfos, startDate, endDate, bktsList, lag, valoTolerance, weightColumn: weightColumn);
        }

        public IEnumerable<BookingPrismCompositionCompareItem> ComparePrismCompositions(IndexInfos idxInfos, DateTime startDate, DateTime endDate)
        {
            var bktsList = GetBasketIndexAuditLists(idxInfos, startDate, endDate);

            return ComparePrismCompositions(idxInfos, startDate, endDate, bktsList);
        }

        public IEnumerable<BookingBasketWeightCompareItem> CompareBaskets(int sicovam, IndexInfos idxInfos,
            DateTime startDate, DateTime endDate, List<BasketIndexList> bktsList, int lag, double? valoTolerance = null, int? weightColumn = 2)
        {
            var res = new List<BookingBasketWeightCompareItem>();

            var bktsListFirstCompo = TakeFirstCompo(idxInfos.id, bktsList, startDate, endDate);

            var fixings = genericBooker.ReadFixings(sicovam, startDate, endDate, Database, Login, Password);

            if (!fixings.Any())
            {
                return new BookingBasketWeightCompareItem[0];
            }

            foreach (var compoByDate in bktsListFirstCompo)
            {
                var dates = fixings.Select(x => x.Date).Distinct().OrderBy(x => x).ToArray();

                var itemWithDate = dates.Select((x, i) => new { Index = i, Value = x }).FirstOrDefault(x => x.Value >= compoByDate.Key);

                if (itemWithDate == null)
                {
                    continue;
                }

                var fixingDate = dates[itemWithDate.Index + lag];

                var dayFixings = fixings.Where(x => x.Date == fixingDate).ToArray();
                var underlyings = compoByDate.Value.Select(x => x.BloombergTicker).ToArray();

                bool globalMatching = true;

                foreach (var fixing in dayFixings)
                {
                    var sophisValue = GetSophisValue(fixing, weightColumn.GetValueOrDefault(2));

                    var instrument =
                        SophisHelper.GetInstrumentInfo(fixing.Sicovam.ToString(), EnumSophisRefCodeType.Sicovam);
                    var ticker = instrument != null
                        ? (string.IsNullOrEmpty(instrument.GL) ? instrument.Reference : instrument.GL)
                        : null;

                    AdaptTickerIfFX(instrument, underlyings, ref ticker);


                    var caesarValue = GetCaesarWeightValue(compoByDate.Value, ticker);

                    var matching = sophisValue == caesarValue;

                    if (!double.IsNaN(caesarValue))
                    {
                        res.Add(new BookingBasketWeightCompareItem
                        {
                            UnderlyingCode = ticker,
                            UnderlyingSicovam = fixing.Sicovam,
                            CaesarValue = caesarValue,
                            SophisValue = sophisValue,
                            Date = fixing.Date,
                            Index = idxInfos,
                            IndexBloombergTicker = idxInfos.bloomberg_ticker,
                            Sicovam = sicovam,
                            Status = matching
                                ? BookingFixingCompareItemStatus.OK
                                : BookingFixingCompareItemStatus.ValueKO,
                            ValoTolerance = valoTolerance.GetValueOrDefault(0.0005d),
                            WeightColumn = weightColumn,
                            Lag = lag
                        });
                    }
                }
            }

            return res;
        }

        private static double GetSophisValue(ISophisFixings fixing, int weightColumn)
        {
            switch(weightColumn)
            {
                case 1:
                    return fixing.Closing1;
                case 2:
                    return fixing.Closing2;
                case 3:
                    return fixing.Closing3;
            }

            return double.NaN;
        }

        public IEnumerable<BookingPrismCompositionCompareItem> ComparePrismCompositions(IndexInfos idxInfos, DateTime startDate, DateTime endDate, List<BasketIndexList> bktsList)
        {
            var res = new List<BookingPrismCompositionCompareItem>();
            var prismManager = new PrismBookingManager();


            if (prismManager.GetIndex(idxInfos.bloomberg_ticker) == null)
            {
                return new BookingPrismCompositionCompareItem[0];
            }

            var project = PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(idxInfos.id.AsArray(), UserService.CaesarSession).First().Value;
            var quotes = tsp.GetIndexQuotes(idxInfos.id.ToString(), startDate, endDate);
            var indexInfos = tsp.GetIndexInfos(idxInfos.id.ToString());

            var calendarTs = tsp.Load(BasketTools.GetCalendarTicker(project, indexInfos), DataFieldsEnum.Calendar, startDate.AddDays(-400), endDate);

            var calendar = calendarTs.Y.Cast<ICalendar>().Last();

            foreach (var compoByDate in bktsList)
            {
                var nextDay = calendar.GetBusinessDays(compoByDate.EffectiveDate.GetValueOrDefault().AddDays(1), compoByDate.EffectiveDate.GetValueOrDefault().AddDays(50)).First();
                var auditBasket = compoByDate.Baskets.First(x => x.Name == BasketIndex.AuditBasketName);
                var mainBasket = compoByDate.Baskets.First(x => x.Name != BasketIndex.AuditBasketName && x.Components.Any());
                var quote = quotes.Evaluate(compoByDate.EffectiveDate);

                Dictionary<string, double> adjustmentsFactors = new Dictionary<string, double>();

                var prismComposition = prismManager.RequestComposition(idxInfos.bloomberg_ticker, nextDay);
                var targetComposition = prismManager.GetComposition(idxInfos.bloomberg_ticker, idxInfos.currency_code, mainBasket, quote, compoByDate.EffectiveDate.GetValueOrDefault(), new Dictionary<string, TimeSerieDB>(), ref adjustmentsFactors, auditBasket: auditBasket);

                var weightMatchingsResult = targetComposition.component.Select(x =>
                {
                    var comp = prismComposition.composition.component.FirstOrDefault(c => c.marketFinancialProduct.bloombergCode == x.listing.bloombergCode);

                    if (comp != null)
                    {
                        Console.WriteLine(x.listing.bloombergCode + ":" + comp.markitWeight + "!=" + x.basketWeight);

                        return new { BBG = x.listing.bloombergCode, CaesarWeight = x.basketWeight, PrismWeight = comp.markitWeight, Result = x.basketWeight == comp.markitWeight };
                    }

                    return null;
                })
                .Where(x => x != null)
                .ToArray();

                var weightMismatchings = weightMatchingsResult.Where(x => !x.Result).ToArray();

                var weightMatchings = targetComposition.component.Where(x => prismComposition.composition.component.Any(c => c.marketFinancialProduct.bloombergCode == x.listing.bloombergCode) &&
                    prismComposition.composition.component.First(c => c.marketFinancialProduct.bloombergCode == x.listing.bloombergCode).markitWeight == x.basketWeight).ToArray();

                var unexistingComponentsInPrism = targetComposition.component.Where(x => !prismComposition.composition.component.Any(c => c.marketFinancialProduct.bloombergCode == x.listing.bloombergCode)).ToArray();
                var toRemoveComponentsInPrism = prismComposition.composition.component.Where(x => !targetComposition.component.Any(c => c.listing.bloombergCode == x.marketFinancialProduct.bloombergCode)).ToArray();

                res.Add(new BookingPrismCompositionCompareItem
                {
                    Date = compoByDate.EffectiveDate.GetValueOrDefault(),
                    Index = idxInfos,
                    IndexBloombergTicker = idxInfos.bloomberg_ticker,
                    CaesarComposition = targetComposition.component.OrderBy(x => x.listing.bloombergCode).Select(x => x.listing.bloombergCode + ":" + x.basketWeight).Stringify("\r\n"),
                    PrismComposition = prismComposition.composition.component.OrderBy(x => x.marketFinancialProduct.bloombergCode).Select(x => x.marketFinancialProduct.bloombergCode + ":" + x.markitWeight).Stringify("\r\n"),
                    ResultSummary = new[] { "Ticker", "Caesar", "Prism", "Result" }.Select(x => x.PadRight(20)).Stringify("|").AsArray()
                    .Union(weightMatchingsResult.Select(x => new[] { x.BBG, x.CaesarWeight.ToString(), x.PrismWeight.ToString(), x.Result ? "OK" : "KO" }.Select(e => e.PadRight(20)).Stringify("|"))).Stringify("\r\n"),
                    Status = weightMatchings.Count() == targetComposition.component.Count() && !unexistingComponentsInPrism.Any() && !toRemoveComponentsInPrism.Any() ? BookingPrismCompositionCompareItemStatus.OK : BookingPrismCompositionCompareItemStatus.KO
                });
            }

            return res;
        }

        private List<BasketIndexList> GetBasketIndexLists(IndexInfos idxInfos, DateTime startDate, DateTime endDate)
        {
            tsp.ClearTreeData(DataFieldsEnum.IndexBasketResult);
            tsp.ClearTreeData(DataFieldsEnum.IndexAuditBasketResult);
            var bktsList = tsp.GetBaskets(idxInfos.id.ToString(), startDate, endDate).Y.Cast<BasketIndexList>()
                .ToList();
            return bktsList;
        }

        private List<BasketIndexList> GetBasketIndexAuditLists(IndexInfos idxInfos, DateTime startDate, DateTime endDate)
        {
            tsp.ClearTreeData(DataFieldsEnum.IndexBasketResult);
            tsp.ClearTreeData(DataFieldsEnum.IndexAuditBasketResult);
            var bktsList = tsp.GetBasketsAudit(idxInfos.id.ToString(), startDate, endDate).Y.Cast<BasketIndexList>()
                .ToList();
            return bktsList;
        }

        private static string AdaptTickerIfFX(IInstrument instrument, string[] underlyings, ref string ticker)
        {
            return ticker = instrument != null && instrument.Reuter.Length >= 6 &&
                            instrument.Reuter.Split('=').Length == 2 &&
                            SophisHelper.IsCurrencyTicker(instrument.Reuter.Substring(0, 6))
                ? (underlyings.FirstOrDefault(u => u.StartsWith(instrument.Reuter.Substring(0, 6))) ?? ticker)
                : ticker;
        }

        private Dictionary<DateTime, IList<IBasketComponent>> TakeFirstCompo(long indexId, List<BasketIndexList> bktsList, DateTime startDate, DateTime endDate)
        {
            var result = new Dictionary<DateTime, IList<IBasketComponent>>();

            var basketIndexLists = bktsList.Where(x => x.Baskets.Any()).ToArray();
            if (!basketIndexLists.Any())
            {
                return new Dictionary<DateTime, IList<IBasketComponent>>();
            }

            var project =
                PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(indexId.AsArray(),
                    UserService.CaesarSession).First().Value;

            project = PersistanceService.IndexProvider.ReadProject(project.id, UserService.CaesarSession);

            var components = basketIndexLists.Any() ? basketIndexLists.Last().Baskets.Where(b => b.Components != null && b.Components.Any()).Select(x => x.LastComposition).SelectMany(x => x.BloombergTickers()).Distinct().ToArray() : null;

            var componentBaskets = GetComponentBaskets(startDate, endDate, project, components);

            var firstBasketList = basketIndexLists.First();
            var currentCompositionBkt = BasketTools.GetExplodedComposition(firstBasketList.EffectiveDate.GetValueOrDefault(), firstBasketList.Baskets.First(x => x.Name != BasketIndex.AuditBasketName), project.project_name, componentBaskets);

            if (startDate == endDate)
            {
                result.Add(firstBasketList.EffectiveDate.GetValueOrDefault(), currentCompositionBkt.LastComposition);

                return result;
            }

            foreach (var basketIndexList in basketIndexLists)
            {
                var newCompositionBkt = BasketTools.GetExplodedComposition(basketIndexList.EffectiveDate.GetValueOrDefault(), basketIndexList.Baskets.First(x => x.Name != BasketIndex.AuditBasketName), project.project_name, componentBaskets);

                if (!BasketTools.IsSameComposition(newCompositionBkt.LastComposition, currentCompositionBkt.LastComposition))
                {
                    result.Add(basketIndexList.EffectiveDate.GetValueOrDefault(), newCompositionBkt.LastComposition);
                }

                currentCompositionBkt = newCompositionBkt;
            }

            return result;
        }

        private Dictionary<string, BasketIndexList[]> GetComponentBaskets(DateTime startDate, DateTime endDate, ProjectDTO project, string[] components)
        {
            return BasketTools.GetComponentBaskets(tsp, startDate, endDate, project, components);
        }

        private IndexInfos GetIndexInfos(Dictionary<string, IndexInfos> underlyingsToIndexInfosDico, string udl)
        {
            if (!underlyingsToIndexInfosDico.ContainsKey(udl))
            {
                underlyingsToIndexInfosDico.Add(udl, tsp.GetIndexInfos(udl));
            }

            return underlyingsToIndexInfosDico[udl];
        }

        private double GetCaesarWeightValue(IEnumerable<IBasketComponent> bktComponents, string ticker)
        {
            return bktComponents.Where(x => x.BloombergTicker == ticker).Select(x => (double?)x.Weight)
                       .FirstOrDefault() ?? double.NaN;
        }

        private double GetCaesarValue(BasketIndex bkt, string originalTicker, IndexInfos indexInfos, DateTime date, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null, int? fixingRounding = null, Dictionary<string, TimeSerieDB> riskedSelectionDico = null)
        {
            double caesarValue;

            if (riskedSelectionDico.ContainsKey(originalTicker))
            {
                caesarValue = bkt[DefaultFields.SelectionValue, originalTicker].Evaluate(date);
            }
            else
            {
                var ticker = sophisCaesarTranscodings != null && sophisCaesarTranscodings.Select(x => x.SophisValue).Contains(originalTicker) ? sophisCaesarTranscodings.First(x => x.SophisValue == originalTicker).CaesarValue : originalTicker;


                caesarValue = bkt[indexInfos == null ? DataFieldsEnum.Last : DataFieldsEnum.IndexQuote, ticker]
                    .Evaluate(date);

                if (double.IsNaN(caesarValue))
                {
                    caesarValue = bkt[indexInfos == null ? DataFieldsEnum.Last : DataFieldsEnum.IndexQuote, indexInfos == null ? ticker : bkt.Data[DataFieldsEnum.IndexQuote.ToString()].Select(x => x.Instrument).FirstOrDefault(x => x.EndsWith(indexInfos.ticker))]
                        .Evaluate(date);
                }

                if (double.IsNaN(caesarValue))
                {
                    caesarValue = bkt[indexInfos == null ? DataFieldsEnum.Last : DataFieldsEnum.IndexQuote, indexInfos == null ? SophisHelper.GetBloombergTicker(ticker) : ticker].Evaluate(date);
                }
            }

            return indexInfos != null && applyRounding ? Math.Round(caesarValue, indexInfos.publication_decimal_number.GetValueOrDefault(2), indexInfos.publication_rounding_policy.GetValueOrDefault()) : (fixingRounding.HasValue ? Math.Round(caesarValue, fixingRounding.GetValueOrDefault()) : caesarValue);
        }

        public DateTime StartDate
        {
            get { return _startDate; }
            set { _startDate = value; }
        }

        public DateTime EndDate
        {
            get { return _endDate; }
            set { _endDate = value; }
        }
    }

    public class BookingManagerExtensions
    {
        const string PMM = "Panier Multi Methodes";
        const string PMMHyb = "Panier Multi Methodes Hybrides HJM";
        const string PMMFudge = "Panier Multi Methodes HJM Fudge";
        const string PMMMixFudge = "Panier Multi Methodes Mix Fudge";


        public static int[] GetOptionSicovamForExternalRef(string externalRefValue = null, string externalReferenceName = "Indice algo")
        {
            var sm2 = new SophisManager2FactoryWrapper().CreateSophisManager(BookingManager.Database, BookingManager.Login, BookingManager.Password);

            var sicovams = sm2.Instrument.GetAllForExternalRef(externalReferenceName, externalRefValue).Select(x => x.Sicovam).ToArray();

            var sicovamWithInstrument = sicovams.ToDictionary(x => x, x => SophisHelper.GetInstrumentInfo(x.ToString(), EnumSophisRefCodeType.Sicovam));

            return sicovamWithInstrument.Where(x => x.Value.InstrumentType == "D" && new[] { PMM, PMMHyb, PMMFudge, PMMMixFudge }.Contains(x.Value.Model)).Select(x => x.Key).ToArray();
        }
    }

}