﻿namespace CaesarApplication.Booking
{
    public enum BookingCalendarCompareItemStatus
    {
        ToAdd,
        ToRemove,
        OK
    }
}