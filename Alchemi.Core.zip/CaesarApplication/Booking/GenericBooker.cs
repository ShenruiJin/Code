﻿using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.DataProvider.Prism;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Booking.Services;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Data.Services;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using PrismWS.IndexAlgoFeedService;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Configuration;
using log4net;
using GlobalDerivativesApplications.Data.Booking;
using System.IO;
using GlobalDerivativesApplications.Sophis.Command;
using GlobalDerivativesApplications.Sophis.Mapping.ByType;

namespace CaesarApplication.Booking
{
    public class GenericBooker
    {
        #region Private fields
        private readonly string caesarBatchSophisPasswd = ConfigurationManager.AppSettings["CaesarBatchSophisPasswd"] ?? "@6Nf2YuT";
        private readonly string caesarBatchTable = ConfigurationManager.AppSettings["CaesarBatchSophisTable"] ?? "APP_CAESAR_BATCH";
        private PrismBookingManager manager;
        private SophisHelperWrapper sophisHelperWrapper;
        private ISophisManager2Factory sophisManagerFactoryWrapper;
        private IBookingService sophisBooker;
        private BookingGenericHelper bookingHelper = new BookingGenericHelper();

        private ILog logger = LogManager.GetLogger(typeof(GenericBooker));
        #endregion

        #region .Ctor
        public GenericBooker()
            : this(new PrismBookingManager(), new SophisHelperWrapper(), new SophisManager2FactoryWrapper(), null)
        { }

        public GenericBooker(string envName)
    : this(new PrismBookingManager(), new SophisHelperWrapper(), new SophisManager2FactoryWrapper(), null, envName)
        { }

        public GenericBooker(PrismBookingManager manager, SophisHelperWrapper sophisHelperWrapper,
            ISophisManager2Factory sophisManagerFactoryWrapper, IBookingService sophisBooker, string envName = null)
        {
            this.manager = manager;
            this.sophisHelperWrapper = sophisHelperWrapper;
            this.sophisManagerFactoryWrapper = sophisManagerFactoryWrapper;
            this.sophisBooker = sophisBooker ?? CreateBooker(envName);
        }
        #endregion

        #region Public Methods
        public string PrismBookingInsertBasket(string bbgCode, string currency, BasketIndex basketIndex,
            double currentQuote, DateTime dateComposition, Dictionary<string, TimeSerieDB> forex = null, bool forwardCompo = false,
            string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodeCompo = true, bool testMode = false, bool fxHedge = false, bool removeNullWeights = false)
        {
            try
            {
                manager.Insert(bbgCode, currency, basketIndex, currentQuote, dateComposition, forex, forwardCompo, fieldUseAsLast, auditBasket, compositionDate, explodeCompo: explodeCompo, testMode: testMode, fxHedge: fxHedge, removeNullWeights:removeNullWeights);
                return string.Format("booking OK for {0} the {1}", bbgCode ?? "bbgCode: N.A", dateComposition);
            }
            catch (Exception e)
            {
                LoggingService.Error(typeof(PrismBookingManager), e);
                return string.Format("KO for {0} the {1}" + e, bbgCode ?? "bbgCode: N.A", dateComposition);
            }
        }

        internal IList<SpotCommand.RealizedValue> SophisGetRealizedValues(int sicoPackage, string database = null, string user = null, string passWord = null)
        {
            var mgr = new SophisManager2FactoryWrapper().CreateSophisManager(database, user, passWord);


            return mgr.Spot.GetRealizedValues(sicoPackage);
        }


        internal TheroreticalResult SophisGetTheoricalValue(int sicoPackage, string database = null, string user = null, string passWord = null, DateTime? pricingDate = null)
        {
            var mgr = new SophisManager2FactoryWrapper().CreateSophisManager(database, user, passWord);


            return mgr.Theroretical.Get(new TheoreticalInput(sicoPackage, pricingDate.GetValueOrDefault(DateTime.Today)));
        }

        public string SophisCompositionBookingInsertBasket(int sicoPackage, Dictionary<string, double> weights, string database, string user, string passWord, bool cleanerMode = false)
        {
            string comment = "";


            var sicovamToRemove = new List<int> { };
            var matchingComponents = new List<string> { };
            IBasket bkt = ReadComposition(sicoPackage, database, user, passWord);

            foreach (var element in bkt.Components)
            {
                var elementName = element.Reference;

                double? componentWeight =
                    weights.ContainsKey(element.Sicovam.ToString())
                    ?
                    weights[element.Sicovam.ToString()]
                    :
                        weights.Where(x => x.Key.StartsWith(elementName)).Select(x => (double?)x.Value).FirstOrDefault();

                if (componentWeight != null)
                {
                    var tmpWeight = componentWeight.GetValueOrDefault();
                    element.Weight = double.IsNaN(tmpWeight) ? 0 : tmpWeight;
                    comment += string.Format("{0} - {1} ,", elementName, element.Weight);
                    logger.InfoFormat(@"{0} - {1} ", "weight " + elementName, tmpWeight);
                    matchingComponents.Add(element.Reference);
                }
                else
                {
                    if (cleanerMode)
                    {
                        sicovamToRemove.Add(element.Sicovam);
                        logger.InfoFormat(@"{0} - {1} ", "Removed " + elementName, element.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "Removed", element.Sicovam);
                    }
                    else
                    {
                        element.Weight = 0.0;
                        logger.InfoFormat(@"{0} - {1} ", "To Remove " + elementName, element.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "To Remove", element.Sicovam);
                    }
                }
            }

            if (cleanerMode)
            {
                sicovamToRemove.ForEach(x => bkt.Components.RemoveWhere(c => c.Sicovam == x));
            }

            var instrumentNames = weights.Keys;
            var tickerToAdd = instrumentNames.Except(matchingComponents).ToArray();
            foreach (var element in tickerToAdd)
            {
                logger.InfoFormat("Name : " + element);
                var weight = weights.Where(x => x.Key == element).Select(x => (double?)x.Value).FirstOrDefault();

                if (weight.HasValue)
                {
                    logger.InfoFormat("weight : " + weight);

                    int sico;
                    string reference;

                    if (!int.TryParse(element, out sico))
                    {
                        sico = GetSicovamFromReference(element.Trim());
                        reference = element.Trim();
                    }
                    else
                    {
                        reference = SophisHelper.GetReference(sico);
                    }

                    IBasketComponent ic = new GlobalDerivativesApplications.Data.Instrument.BasketComponent(sico, weight.GetValueOrDefault(), true);
                    bkt.Components.Add(ic);
                }
            }

            logger.InfoFormat("Update composition");
            UpdateComposition(sicoPackage, bkt, database, user, passWord);
            logger.InfoFormat("Updated composition");

            return comment;
        }

        public string SophisPackageBookingInsertBasket(int sicoPackage, Dictionary<string, double> weights, string database, string user, string passWord, bool cleanerMode = false)
        {
            string comment = "";

            Dictionary<string, double> adjustmentsFactors = new Dictionary<string, double>();

            var sicovamToRemove = new List<int> { };
            var matchingComponents = new List<string> { };
            IPackage package = ReadPackage(sicoPackage, database, user, passWord);

            foreach (var element in package.Components)
            {
                IPackageComponent instrument = (IPackageComponent)element.Instrument;
                var elementName = instrument.Reference;

                double? componentWeight =
                    weights.ContainsKey(instrument.Sicovam.ToString())
                    ?
                    weights[instrument.Sicovam.ToString()]
                    :
                        weights.Where(x => x.Key.StartsWith(elementName)).Select(x => (double?)x.Value).FirstOrDefault();

                if (componentWeight != null)
                {
                    var tmpWeight = componentWeight.GetValueOrDefault();
                    element.Weight = double.IsNaN(tmpWeight) ? 0 : tmpWeight;
                    comment += string.Format("{0} - {1} ,", elementName, element.Weight);
                    logger.InfoFormat(@"{0} - {1} ", "weight " + elementName, tmpWeight);
                    matchingComponents.Add(instrument.Reference);
                }
                else
                {
                    if (cleanerMode)
                    {
                        sicovamToRemove.Add(instrument.Sicovam);
                        logger.InfoFormat(@"{0} - {1} ", "Removed " + elementName, instrument.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "Removed", instrument.Sicovam);
                    }
                    else
                    {
                        element.Weight = 0.0;
                        logger.InfoFormat(@"{0} - {1} ", "To Remove " + elementName, instrument.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "To Remove", instrument.Sicovam);
                    }
                }
            }

            if (cleanerMode)
            {
                sicovamToRemove.ForEach(x => package.Components.RemoveWhere(c => ((IPackageComponent)c.Instrument).Sicovam == x));
            }

            var instrumentNames = weights.Keys;
            var tickerToAdd = instrumentNames.Except(matchingComponents).ToArray();
            foreach (var element in tickerToAdd)
            {
                logger.InfoFormat("Name : " + element);
                var weight = weights.Where(x => x.Key == element).Select(x => (double?)x.Value).FirstOrDefault();

                if (weight.HasValue)
                {
                    logger.InfoFormat("weight : " + weight);

                    int sico;
                    string reference;

                    if (!int.TryParse(element, out sico))
                    {
                        sico = GetSicovamFromReference(element.Trim());
                        reference = element.Trim();
                    }
                    else
                    {
                        reference = SophisHelper.GetReference(sico);
                    }

                    IPackageComponent ipc = new PackageComponent(reference, sico, reference, InstrumentType.Future);
                    IComponent ic = new Component(weight.GetValueOrDefault(), ipc);
                    package.Components.Add(ic);
                }
            }

            logger.InfoFormat("Update package");
            UpdatePackage(sicoPackage, package);
            logger.InfoFormat("Updated package");

            return comment;
        }

        public indexCompositionAlgoWs GetPrismComposition(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote,
            DateTime dataDate, Dictionary<string, TimeSerieDB> fx, ref Dictionary<string, double> ajustmentFactors, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodedCompo = true, bool transcodeTickerToPrism = true, Dictionary<string, double> forexValues = null, bool fxHedged = false)
        {
            return manager.GetComposition(bbgCode, currency, basketIndex, currentQuote,
            dataDate, fx, ref ajustmentFactors, isForward, fieldUseAsLast, auditBasket, compositionDate, explodedCompo, transcodeTickerToPrism, forexValues, fxHedged);
        }

        public string SophisPackageBookingInsertBasket(int sicoPackage, string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database, string user, string passWord, bool cleanerMode = false, bool fxHedged = false)
        {
            string comment = "";
            var idxInfos = PersistanceService.IndexProvider.GetIndexFromCode(bbgCode, UserService.CaesarSession);

            Dictionary<string, double> forexValues = new Dictionary<string, double>();
            Dictionary<string, double> adjustmentsFactors = new Dictionary<string, double>();
            var targetComposition = manager.GetComposition(idxInfos.bloomberg_ticker, idxInfos.currency_code, basketIndex, quote, dateComposition, new Dictionary<string, TimeSerieDB>(), ref adjustmentsFactors, auditBasket: auditBasket, transcodeTickerToPrism: false, forexValues: forexValues);

            var weightsForPackage = targetComposition.component.ToDictionary(x => x.listing.bloombergCode, x => x.priceWeight);

            var sicovamToRemove = new List<int> { };
            var matchingComponents = new List<string> { };
            IPackage package = ReadPackage(sicoPackage, database, user, passWord);

            foreach (var element in package.Components)
            {

                IPackageComponent instrument = (IPackageComponent)element.Instrument;
                var elementName = instrument.Reference;

                var component = targetComposition.component.Select(x => x.listing.bloombergCode).FirstOrDefault(x => x.StartsWith(elementName));
                if (component != null)
                {
                    var tmpWeight = weightsForPackage[component];
                    element.Weight = double.IsNaN(tmpWeight) ? 0 : tmpWeight;
                    comment += string.Format("{0} - {1} ,", elementName, element.Weight);
                    logger.InfoFormat(@"{0} - {1} ", "weight " + elementName, weightsForPackage[component]);
                    matchingComponents.Add(component);
                }
                else
                {
                    if (cleanerMode)
                    {
                        sicovamToRemove.Add(instrument.Sicovam);
                        logger.InfoFormat(@"{0} - {1} ", "Removed " + elementName, instrument.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "Removed", instrument.Sicovam);
                    }
                    else
                    {
                        element.Weight = 0.0;
                        logger.InfoFormat(@"{0} - {1} ", "To Remove " + elementName, instrument.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "To Remove", instrument.Sicovam);
                    }
                }
            }
            if (cleanerMode)
            {
                sicovamToRemove.ForEach(x => package.Components.RemoveWhere(c => ((IPackageComponent)c.Instrument).Sicovam == x));
            }
            var instrumentNames = basketIndex.LastComposition.Select(x => x.InstrumentName);
            var tickerToAdd = instrumentNames.Except(matchingComponents).ToArray();
            foreach (var element in tickerToAdd)
            {
                logger.InfoFormat("Name : " + element);
                var weight = weightsForPackage.First(x => x.Key == element).Value;

                logger.InfoFormat("weight : " + weight);
                int sico = GetSicovamFromReference(element.Trim());
                IPackageComponent ipc = new PackageComponent(element, sico, element, InstrumentType.Future);
                IComponent ic = new Component(weight, ipc);
                package.Components.Add(ic);
            }

            if (fxHedged)
            {
                var fxWeights = targetComposition.component.Select(x => x.listing.quotationCurrency).Distinct()
    .ToDictionary(x => x, x => targetComposition.component.Where(c => c.listing.quotationCurrency == x).Select(c => c.basketWeight * c.closingPrice).Sum());

                var hedgeInIndexCurrency = -targetComposition.component.Where(x => x.listing.quotationCurrency != idxInfos.currency_code).Sum(c => c.basketWeight * c.closingPrice * adjustmentsFactors[c.listing.bloombergCode] * forexValues[c.listing.bloombergCode]);


                foreach (var foreignCurrency in fxWeights.Concat(new KeyValuePair<string, double>(idxInfos.currency_code, 0).AsArray()))
                {
                    var instrumentName = GetCurrencyInstrumentName(string.IsNullOrEmpty(foreignCurrency.Key) ? idxInfos.currency_code : foreignCurrency.Key);
                    var sico = SophisHelper.GetSicovam(instrumentName);

                    var item = package.Components.Where(x => x.Instrument is IPackageComponent).FirstOrDefault(x => ((IPackageComponent)x).Sicovam == sico);

                    if (item == null)
                    {
                        IPackageComponent ipc = new PackageComponent(instrumentName, sico, instrumentName, InstrumentType.Forex);
                        item = new Component(0.0d, ipc);
                        package.Components.Add(item);
                    }

                    item.Weight = foreignCurrency.Key == idxInfos.currency_code ? hedgeInIndexCurrency : foreignCurrency.Value;
                }
            }

            logger.InfoFormat("Update package");
            UpdatePackage(sicoPackage, package);
            logger.InfoFormat("Updated package");

            return comment;
        }

        public string SophisCompositionBookingInsertBasket(string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database = null, string user = null, string passWord = null, bool cleanerMode = false, bool fxHedged = false, bool removeNullWeights = false)
        {
            var sico = -1;

            try
            {
                var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
                sico = sm2.Instrument.Get(new InstrumentInput(bbgCode, EnumSophisRefCodeType.Reference)).Code;
            }
            catch
            {

            }
            return SophisCompositionBookingInsertBasket(sico, bbgCode, basketIndex, quote, dateComposition, auditBasket, database, user, passWord, cleanerMode, fxHedged, removeNullWeights);
        }

        public string SophisCompositionBookingInsertBasket(int sicoPackage, string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database, string user, string passWord, bool cleanerMode = false, bool fxHedged = false, bool removeNullWeights = false)
        {
            Dictionary<string, double> forexValues = new Dictionary<string, double>();
            string comment = "";
            var idxInfos = PersistanceService.IndexProvider.GetIndexFromCode(bbgCode, UserService.CaesarSession);
            Dictionary<string, double> adjustmentsFactors = new Dictionary<string, double>();
            var targetComposition = manager.GetComposition(idxInfos.bloomberg_ticker, idxInfos.currency_code, basketIndex, quote, dateComposition, new Dictionary<string, TimeSerieDB>(), ref adjustmentsFactors, auditBasket: auditBasket, transcodeTickerToPrism: false, forexValues: forexValues);

            var weightsForPackage = targetComposition.component.ToDictionary(x => x.listing.bloombergCode, x => x.priceWeight);

            targetComposition.component = targetComposition.component.Where(x => !removeNullWeights || x.basketWeight != 0.0d).ToArray();

            var fxWeights = targetComposition.component.Select(x => x.listing.quotationCurrency).Distinct()
                .Where(x => !string.IsNullOrEmpty(x))
                .ToDictionary(x => x, x => targetComposition.component.Where(c => c.listing.quotationCurrency == x).Select(c => -c.basketWeight * c.closingPrice * adjustmentsFactors[c.listing.bloombergCode]).Sum());

            var hedgeInIndexCurrency = targetComposition.component.Where(x => x.listing.quotationCurrency != idxInfos.currency_code).Sum(c => c.basketWeight * c.closingPrice * adjustmentsFactors[c.listing.bloombergCode] * forexValues[c.listing.bloombergCode]);

            var ResultFeedingFilePath = Guid.NewGuid().ToString() + ".txt";

            var sicovamToRemove = new List<int> { };
            var matchingComponents = new List<string> { };
            IBasket basket = ReadComposition(sicoPackage, database, user, passWord);

            bool shouldBeModified = false;

            foreach (var element in basket.Components)
            {
                var elementName = element.Reference;

                var component = targetComposition.component.Where(x => x.basketWeight != 0.0d).Select(x => x.listing.bloombergCode).FirstOrDefault(x => x.StartsWith(elementName));
                if (component != null)
                {
                    var tmpWeight = weightsForPackage[component];

                    if (element.Weight != (double.IsNaN(tmpWeight) ? 0 : tmpWeight))
                    {
                        shouldBeModified = true;
                    }

                    element.Weight = double.IsNaN(tmpWeight) ? 0 : tmpWeight;
                    comment += string.Format("{0} - {1} ,", elementName, element.Weight);
                    logger.InfoFormat(@"{0} - {1} ", "weight " + elementName, weightsForPackage[component]);
                    matchingComponents.Add(component);

                    if (removeNullWeights && element.Weight == 0.0d)
                    {
                        sicovamToRemove.Add(element.Sicovam);
                    }
                }
                else
                {
                    if (cleanerMode)
                    {
                        sicovamToRemove.Add(element.Sicovam);
                        logger.InfoFormat(@"{0} - {1} ", "Removed " + elementName, element.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "Removed", element.Sicovam);
                    }
                    else
                    {
                        if (element.Weight != 0.0d)
                        {
                            shouldBeModified = true;
                        }

                        element.Weight = 0.0;
                        logger.InfoFormat(@"{0} - {1} ", "To Remove " + elementName, element.Sicovam);
                        comment += string.Format(@"{0} - {1} ", "To Remove", element.Sicovam);
                    }
                }
            }
            if (cleanerMode)
            {
                sicovamToRemove.ForEach(x =>
                {
                    shouldBeModified = true;
                    basket.Components.RemoveWhere(c => c.Sicovam == x);
                });
            }
            var instrumentNames = targetComposition.component.Select(x => x.listing.bloombergCode).ToArray();
            var tickerToAdd = instrumentNames.Except(matchingComponents).ToArray();
            Exception lastError = null;


            foreach (var element in tickerToAdd)
            {
                shouldBeModified = true;

                try
                {

                    logger.InfoFormat("Name : " + element);
                    var weight = weightsForPackage.First(x => x.Key == element).Value;

                    logger.InfoFormat("weight : " + weight);
                    int sico = GetSicovamFromReference(NormalizeTicker(element.Trim()));
                    var bc = new GlobalDerivativesApplications.Data.Instrument.BasketComponent(sico, weight, true);
                    basket.Components.Add(bc);
                }
                catch (Exception ex)
                {
                    File.AppendAllLines(ResultFeedingFilePath, ex.ToString().AsArray());
                    lastError = ex;
                }
            }

            if (lastError != null)
                throw lastError;

            if (!targetComposition.component.All(x => !string.IsNullOrEmpty(x.listing.quotationCurrency) && x.listing.quotationCurrency == idxInfos.currency_code))
            {
                ManageFxHedge(fxHedged, idxInfos, fxWeights, hedgeInIndexCurrency, basket, ref shouldBeModified);
            }

            basket.Currency = idxInfos.currency_code;

            if (shouldBeModified)
            {
                logger.InfoFormat("Update composition");
                UpdateComposition(sicoPackage, basket, database, user, passWord);
                logger.InfoFormat("Updated composition");
            }
            else
            {
                logger.InfoFormat("Update composition useless");
            }

            return comment;
        }

        private void ManageFxHedge(bool fxHedged, DealIndexDataTransferObject.IndexDTO idxInfos, Dictionary<string, double> fxWeights, double hedgeInIndexCurrency, IBasket basket, ref bool shouldBeModified)
        {
            if (fxHedged)
            {
                foreach (var foreignCurrency in fxWeights.Concat(new KeyValuePair<string, double>(idxInfos.currency_code, 0).AsArray()))
                {
                    var instrumentName = GetCurrencyInstrumentName(string.IsNullOrEmpty(foreignCurrency.Key) ? idxInfos.currency_code : foreignCurrency.Key);
                    var sico = SophisHelper.GetSicovam(instrumentName);

                    var item = basket.Components.FirstOrDefault(x => x.Sicovam == sico);

                    if (item == null)
                    {
                        item = new GlobalDerivativesApplications.Data.Instrument.BasketComponent(sico, foreignCurrency.Value, true);
                        basket.Components.Add(item);

                        shouldBeModified = true;
                    }

                    var newWeight = foreignCurrency.Key == idxInfos.currency_code ? hedgeInIndexCurrency : foreignCurrency.Value;

                    if (item.Weight != newWeight)
                    {
                        shouldBeModified = true;
                        item.Weight = newWeight;
                    }
                }
            }
        }

        private string GetCurrencyInstrumentName(string code)
        {
            return string.Format("EDA23.1.{0}", code);
        }

        public string PrismBookingInsertBasket(indexCompositionAlgoWs composition)
        {
            try
            {
                manager.Insert(composition);
                return string.Format("booking OK for {0} the {1}", composition.indexProduct.bloombergCode ?? "bbgCode: N.A", composition.compositionDate);
            }
            catch (Exception e)
            {
                LoggingService.Error(typeof(PrismBookingManager), e);
                return string.Format("KO for {0} the {1}" + e, composition.indexProduct.bloombergCode ?? "bbgCode: N.A", composition.compositionDate);
            }
        }

        public indexCompositionAlgoWs PrismGetComposition(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote,
            DateTime dataDate, Dictionary<string, TimeSerieDB> fx, Dictionary<string, double> ajustmentFactors, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null)
        {
            return manager.GetComposition(bbgCode, currency, basketIndex, currentQuote, dataDate, fx, ref ajustmentFactors, isForward, fieldUseAsLast, auditBasket, compositionDate);
        }

        public string GetReferenceFromSicovam(int sicovam)
        {
            var res = sophisHelperWrapper.GetReferences(new[] { sicovam });
            if (res == null && !res.Any())
                return string.Empty;

            return res[sicovam];
        }

        public int GetSicovamFromReference(string reference)
        {
            return sophisHelperWrapper.GetSicovam(reference);
        }

        public bool UpdateBasket(int Sicovam, IBasket basket, string database, string user, string passWord)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var basketBase = sm2.IndexComposition.Get(new CompositionInput(Sicovam, true));
            basketBase.Components = basket.Components;
            var status = sm2.IndexComposition.Set(basketBase);
            return status.State == CommandStatus.CommandStatusState.Success;
        }

        public string UpdateBasket(int inputSicovam, BasketIndex basket, DateTime today, string database, string user, string passWord)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var basketBase = sm2.IndexComposition.Get(new CompositionInput(inputSicovam, true));
            GlobalDerivativesApplications.Data.Instrument.Basket sophisBasket = new GlobalDerivativesApplications.Data.Instrument.Basket();
            bool IsAlreadyIn = (basketBase.Components.Count == basket.Components[today].Count);

            foreach (PricingBase.Product.CsInfoContainer.BasketComponent asset in basket.Components[today])
            {
                int sicovam = -1;
                if (asset.SophisSicovam == "" || !int.TryParse(asset.SophisSicovam, out sicovam))
                {

                    sophisBasket.Components.Clear();
                    break;
                }

                if (sicovam > 0)
                {
                    sophisBasket.Components.Add(new GlobalDerivativesApplications.Data.Instrument.BasketComponent(sicovam, asset.Weight, false));
                }
                else
                {
                    sophisBasket.Components.Clear();
                    break;
                }
                if (IsAlreadyIn)
                {

                    GlobalDerivativesApplications.Data.Instrument.IBasketComponent Compo = basketBase.Components.FirstOrDefault(x => x.Sicovam == sicovam);
                    IsAlreadyIn = (Compo != null) && Math.Abs(Compo.Weight - asset.Weight) < 1E-14;
                }
            }
            if (IsAlreadyIn && basketBase.Components.Count == sophisBasket.Components.Count)
            {
                return inputSicovam.ToString() + " : No Change";
            }

            basketBase.Components = sophisBasket.Components;
            CommandStatus status = sm2.IndexComposition.Set(basketBase);
            if (status.State == CommandStatus.CommandStatusState.Success)
            {
                return inputSicovam.ToString() + " : Successfull update " + status.ToString();
            }
            else if (status.State == CommandStatus.CommandStatusState.Warning)
            {
                return inputSicovam.ToString() + " Warning: " + status.ToString();
            }
            return inputSicovam.ToString() + "Error: " + status.ToString();
        }

        public ISophisFixings[] ReadFixings(int sicovam, DateTime startDate, DateTime endDate, string database, string user, string passWord)
        {
            if (sicovam < 0) return new ISophisFixings[] { };

            var optionInput = new OptionInput(sicovam);
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var baseOption = sm2.Option.Get(optionInput);
            var fixings = baseOption.Values.Cast<IMultiAssetOption>().First().Fixings;

            return fixings.Where(f => startDate <= f.Date && f.Date <= endDate).ToArray();
        }

        public IClause[] ReadClauses(int sicovam, DateTime startDate, DateTime endDate, string database, string user, string passWord)
        {
            if (sicovam < 0) return new IClause[] { };

            OptionInput optioninput = new OptionInput(sicovam);
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var baseOption = sm2.Option.Get(optioninput);
            var clauses = baseOption.Values.Cast<IMultiAssetOption>().First().Clauses;

            return clauses.Where(f => startDate <= f.EndDate && f.EndDate <= endDate).ToArray();
        }

        public List<IComponent> ReadPackageComposition(int sicovam, string database, string user, string passWord)
        {
            if (sicovam < 0) return null;

            return ReadPackage(sicovam, database, user, passWord).Components.ToList();
        }

        public IBasket ReadComposition(int sicovam, string database, string user, string passWord)
        {
            if (sicovam < 0) return null;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var basketBase = sm2.IndexComposition.Get(new CompositionInput(sicovam, true));

            return basketBase;
        }

        public IPackage ReadPackage(int sicovam, string database, string user, string passWord)
        {
            if (sicovam < 0) return null;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);
            var package = sm2.Package.Get(sicovam);
            return package;
        }

        public void UpdatePackage(int sicovam, IPackage package)
        {
            if (sicovam < 0) return;

            package.Sicovam = sicovam;
            if (package.IssueDate < new DateTime(1970, 01, 01))
                package.IssueDate = new DateTime(1970, 01, 01);
            sophisBooker.Process(package);
        }

        public void UpdateComposition(int sicovam, IBasket basket, string database, string user, string passWord)
        {
            if (sicovam < 0) return;

            basket.Sicovam = sicovam;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, user, passWord);

            sm2.IndexComposition.Set(basket);
        }

        public void UpdateFixings(int sicovam, IEnumerable<DateTime> dates, Action<ISophisFixings> p, string database, string user, string passWord)
        {
            if (sicovam < 0) return;

            var optioninput = new OptionInput(sicovam);
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetBookingEnvironement(database), user, passWord);
            var baseOption = sm2.Option.Get(optioninput);
            var fixings = baseOption.Values.Cast<IMultiAssetOption>().First().Fixings;

            var basket = baseOption.Values.Cast<IMultiAssetOption>().First().Basket;

            var newFixings = new List<ISophisFixings>();
            foreach (DateTime date in dates)
            {
                foreach (var asset in basket)
                {
                    ISophisFixings fixing = fixings.FirstOrDefault(f => f.Date == date && f.Sicovam == asset.Sicovam)
                        ?? new SophisFixings() { Date = date, Sicovam = asset.Sicovam };

                    var oldFixing = new SophisFixings() { Date = date, Sicovam = asset.Sicovam, Closing1 = fixing.Closing1, Closing2 = fixing.Closing2, Closing3 = fixing.Closing3, Name = fixing.Name };

                    p(fixing);

                    if (fixing.Closing1 != oldFixing.Closing1 || fixing.Closing2 != oldFixing.Closing2 ||
                        fixing.Closing3 != oldFixing.Closing3 || fixing.Name != oldFixing.Name)
                    {
                        newFixings.Add(fixing);
                    }
                }
            }

            if (newFixings.Any())
            {
                sm2.Option.UpdateSubFixings(sicovam, newFixings);
            }
        }

        public void UpdateWeightFixings(int sicovam, DateTime startDate, DateTime endDate, Dictionary<DateTime, BasketIndexList> basketLists, string database, string user, string passWord, int weightColIndex = 3)
        {
            if (sicovam < 0) return;

            var sophisTranscoder = new SophisTranscoder();

            var optioninput = new OptionInput(sicovam);
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetBookingEnvironement(database), user, passWord);
            var baseOption = sm2.Option.Get(optioninput);
            var opt = baseOption.Values.Cast<IMultiAssetOption>().First();

            var fixings = opt.Fixings.Where(x => x.Date >= startDate && x.Date <= endDate).ToArray();

            if(opt.EndDate.ToDate() < endDate)
            {
                return;
            }

            var updates = new Dictionary<DateTime, Dictionary<string, double?>>();

            var sicovamForComponentTicker = new Dictionary<int, string>();

            foreach (var fixing in fixings)
            {
                if (!updates.ContainsKey(fixing.Date))
                {
                    updates.Add(fixing.Date, new Dictionary<string, double?>());
                }

                if (basketLists.ContainsKey(fixing.Date))
                {
                    var basketList = basketLists[fixing.Date];
                    var mainBasket = basketList.Baskets.First(x => x.Name != BasketIndex.AuditBasketName);

                    mainBasket.LastComposition.ForEach(c =>
                    {
                        if (!sicovamForComponentTicker.Values.Contains(c.BloombergTicker))
                        {
                            sicovamForComponentTicker.Add(sophisTranscoder.TranscodeExternalToInternalIfNotSicovam(c.BloombergTicker), c.BloombergTicker);
                        }
                    });

                    var component = sicovamForComponentTicker.Where(x => x.Key == fixing.Sicovam).SelectMany(x => mainBasket.LastComposition.Where(i => i.BloombergTicker == x.Value)).FirstOrDefault();

                    if (component != null)
                    {
                        updates[fixing.Date].Add(fixing.Sicovam.ToString(), component.Weight);
                    }
                    else
                    {
                        updates[fixing.Date].Add(fixing.Sicovam.ToString(), null);
                    }
                }
                else
                {
                    updates[fixing.Date].Add(fixing.Sicovam.ToString(), null);
                }
            }

            UpdateWeightFixings(sicovam, updates, database, user, passWord, weightColIndex);
        }

        public void UpdateWeightFixings(int sicovam, Dictionary<DateTime, Dictionary<string, double?>> weightUpdates, string database, string user, string passWord, int weightColIndex = 3, bool cleanerMode = false)
        {
            var sophisTranscoder = new SophisTranscoder();

            Dictionary<DateTime, Dictionary<int, double?>> weightUpdatesBySicovam = weightUpdates.ToDictionary(kv => kv.Key, kv => kv.Value.ToDictionary(x => sophisTranscoder.TranscodeExternalToInternalIfNotSicovam(x.Key), v => v.Value));

            UpdateFixings(sicovam, weightUpdates.Keys.ToArray(), p =>
            {
                var haveWeight = weightUpdatesBySicovam[p.Date].ContainsKey(p.Sicovam);
                var w = haveWeight ? weightUpdatesBySicovam[p.Date][p.Sicovam].GetValueOrDefault() : 0.0d;
                
                if(haveWeight || cleanerMode)
                {
                    switch (weightColIndex)
                    {
                        case 1:
                            p.Closing1 = w;
                            break;
                        case 2:
                            p.Closing2 = w;
                            break;
                        case 3:
                            p.Closing3 = w;
                            break;
                    }
                }
            }, database, user, passWord);
        }

        public void SaveAndFilterFixings(int sicovam, IDictionary<DateTime, BasketIndex> baskets, DateTime startBooking,
            DateTime endBooking, string database, string user, string passWord)
        {
            if (sicovam < 0)
                return;

            var dates = baskets.Keys;

            var today = DateTime.Today;
            OptionInput optioninput = new OptionInput(sicovam);
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetBookingEnvironement(database), user, passWord);
            var baseOption = sm2.Option.Get(optioninput);
            var baseFixings = baseOption.Values.Cast<IMultiAssetOption>().First().Fixings;

            var fixingsToSave = baseFixings.Where(x => dates.Contains(x.Date) || x.Date < startBooking || x.Date > endBooking).ToList();

            IList<DateTime> fixingsDates = baseFixings.Select(x => x.Date).Distinct().ToArray();
            var notExistingDates = dates.Except(fixingsDates).ToArray();
            if (!notExistingDates.Any() && baseFixings.Count == fixingsToSave.Count)
                return;

            if (notExistingDates.Any())
            {
                var distinctFixingName = baseFixings.Select(x => x.Name).Distinct();
                foreach (var date in notExistingDates)
                {
                    foreach (var name in distinctFixingName)
                    {
                        var f = baseFixings.FirstOrDefault(x => x.Name == name);
                        var reference = GetReferenceFromSicovam(f.Sicovam);
                        var tmp = baskets[date][DataFieldsEnum.Last, reference].Evaluate(date);
                        double cloture = double.IsNaN(tmp) ? 0.0 : tmp;
                        SophisFixings item = new SophisFixings { Date = date, Sicovam = f.Sicovam, Name = f.Name, Closing1 = cloture };

                        fixingsToSave.Add(item);
                    }
                }
            }

            fixingsToSave = fixingsToSave.OrderBy(x => x.Date).ToList();

            bookingHelper.BackupFixings(sicovam, baseFixings.ToArray(), "Original");
            sm2.Option.UpdateFixings(sicovam, fixingsToSave);
            bookingHelper.BackupFixings(sicovam, fixingsToSave.ToArray(), "New");
        }

        public void SaveAndFilterClauses(int sicovam, IList<DateTime> dates, DateTime startBooking,
            DateTime endBooking, string database, double[] clotureColValueToKeep = null)
        {
            if (sicovam < 0)
                return;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetBookingEnvironement(database), caesarBatchTable, caesarBatchSophisPasswd);
            var baseOption = sm2.Option.Get(new OptionInput(sicovam));
            var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;
            bool isHybrid = baseClauses.Any(c => c is IHybridClause);

            List<IClause> clausesToKeep = baseClauses.Where(x => dates.Contains(x.EndDate) || x.EndDate < startBooking || x.EndDate > endBooking).ToList();

            IList<DateTime> clausesDates = baseClauses.Select(x => x.EndDate).ToArray();
            var notExistingDates = dates.Except(clausesDates).ToArray();

            if (!notExistingDates.Any() && baseClauses.Count == clausesToKeep.Count)
                return;

            var helper = new BookingGenericHelper();
            foreach (var date in notExistingDates)
            {
                helper.AddClauseToKeep(baseClauses, date, clausesToKeep, isHybrid);
            }

            clausesToKeep = helper.OrderClause(clausesToKeep);
            helper.SetClosingValueToFollowingClause(clotureColValueToKeep, baseClauses, clausesToKeep);

            bookingHelper.BackupClauses(sicovam, false, baseClauses.ToArray(), "Original");
            //save clause
            sm2.Option.UpdateClauses(sicovam, clausesToKeep);
            bookingHelper.BackupClauses(sicovam, false, clausesToKeep.ToArray(), "New");

        }


        public void ApplyClausesAmendements(int sicovam, BookingCalendarCompareItem[] bookingCalendarCompareItems, string database, double[] clotureColValueToKeep = null)
        {
            if (sicovam < 0)
                throw new ArgumentException("Sicovam should not be equal to zero");

            if (!bookingCalendarCompareItems.All(b => b.Sicovam == sicovam))
                throw new ArgumentException("Sicovam parameter and BookingCalendarCompareItems  should have the same sicovam");

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetBookingEnvironement(database), caesarBatchTable, caesarBatchSophisPasswd);
            var baseOption = sm2.Option.Get(new OptionInput(sicovam));
            var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;
            bool isHybrid = baseClauses.Any(c => c is IHybridClause);


            List<IClause> clausesToKeep = baseClauses.Where(x => !bookingCalendarCompareItems.Any(b => b.Date == x.EndDate && b.Status == BookingCalendarCompareItemStatus.ToRemove)).ToList();

            var notExistingDates = bookingCalendarCompareItems.Where(x => x.Status == BookingCalendarCompareItemStatus.ToAdd && !baseClauses.Any(bc => bc.EndDate == x.Date)).Select(x => x.Date).ToArray();

            if (!notExistingDates.Any() && baseClauses.Count == clausesToKeep.Count)
                return;

            var helper = new BookingGenericHelper();
            foreach (var date in notExistingDates)
            {
                helper.AddClauseToKeep(baseClauses, date, clausesToKeep, isHybrid);
            }

            clausesToKeep = helper.OrderClause(clausesToKeep);
            helper.SetClosingValueToFollowingClause(clotureColValueToKeep, baseClauses, clausesToKeep);

            bookingHelper.BackupClauses(sicovam, false, baseClauses.ToArray(), "Original");
            //save clause
            sm2.Option.UpdateClauses(sicovam, clausesToKeep);
            bookingHelper.BackupClauses(sicovam, false, clausesToKeep.ToArray(), "New");
        }

        private string GetBookingEnvironement(string database)
        {
            return database == "PROD" ? "ProdCaesarIndexBooking" : database;
        }

        public void ApplyFixingsAmendements(int sicovam, BookingFixingCompareItem[] bookingCompareItems, string database = null)
        {
            if (sicovam < 0)
                throw new ArgumentException("Sicovam should not be equal to zero");

            if (bookingCompareItems.Any(b => b.Sicovam != sicovam))
                throw new ArgumentException("Sicovam parameter and BookingFixingCompareItem  should have the same sicovam");

            var fixingsToAdd = bookingCompareItems.Where(f => f.Status == BookingFixingCompareItemStatus.Missing)
                .ToArray();

            AddFixings(sicovam, fixingsToAdd.Select(b => new SophisFixings()
            {
                Date = b.Date,
                Sicovam = b.UnderlyingSicovam,
                Name = b.UnderlyingName,
                Closing1 = b.CaesarValue.GetValueOrDefault()
            }).ToList(), database);


            var fixingValuesToFix = bookingCompareItems.Where(f => f.Status == BookingFixingCompareItemStatus.ValueKO).ToArray();

            UpdateFixings(sicovam, fixingValuesToFix.Select(x => x.Date).ToArray(),
                f =>
                {
                    {
                        var fixingValueToFix =
                            fixingValuesToFix.FirstOrDefault(x => x.Date == f.Date && x.UnderlyingSicovam == f.Sicovam);

                        if (fixingValueToFix != null)
                        {
                            f.Closing1 = Math.Round(fixingValueToFix.CaesarValue.GetValueOrDefault(), 6);
                        }
                    }
                }, GetBookingEnvironement(database), caesarBatchTable, caesarBatchSophisPasswd);
        }

        public void ApplyBasketsAmendements(int sicovam, BookingBasketWeightCompareItem[] bookingCompareItems, string database = null)
        {
            if (sicovam < 0)
                throw new ArgumentException("Sicovam should not be equal to zero");

            if (bookingCompareItems.Any(b => b.Sicovam != sicovam))
                throw new ArgumentException("Sicovam parameter and BookingFixingCompareItem  should have the same sicovam");

            var fixingValuesToFix = bookingCompareItems.Where(f => f.Status == BookingFixingCompareItemStatus.ValueKO).ToArray();

            UpdateFixings(sicovam, fixingValuesToFix.Select(x => x.Date).ToArray(),
                f =>
                {
                    {
                        var fixingValueToFix =
                            fixingValuesToFix.FirstOrDefault(x => x.Date == f.Date && x.UnderlyingSicovam == f.Sicovam);

                        if (fixingValueToFix != null)
                        {
                            f.Closing2 = fixingValueToFix.CaesarValue.GetValueOrDefault();
                        }
                    }
                }, database, caesarBatchTable, caesarBatchSophisPasswd);
        }

        public void AddFixings(int sicovam, IList<SophisFixings> fixingsToAdd, string database)
        {
            if (sicovam < 0 || !fixingsToAdd.Any())
                return;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, caesarBatchTable, caesarBatchSophisPasswd);

            var baseOption = sm2.Option.Get(new OptionInput(sicovam));

            var fixings = baseOption.Values.Cast<IMultiAssetOption>().First().Fixings;

            var fixingsToUpdate = fixings.Concat(fixingsToAdd).OrderBy(x => x.Date).ToArray();

            sm2.Option.UpdateFixings(sicovam, fixingsToUpdate.Cast<ISophisFixings>().ToList());
        }

        internal SophisBooker CreateBooker(string envName = null)
        {
            try
            {
                GlobalDerivativesApplications.Settings.SophisSettings.SophisSettingsManager ssm = new GlobalDerivativesApplications.Settings.SophisSettings.SophisSettingsManager("CAESAR");

                // gets the active configuration
                string config = envName ?? ssm.CurrentDatabase;

                var environment = ssm.GetSophisEnvironment(config);
                var context = environment.Contexts.FirstOrDefault(x => x.Id.ToUpper() == "BOOKING");

                if (String.IsNullOrEmpty(context.IdServer))
                {
                    throw new Exception("Booking is not supported for this Sophis environment");
                }
                // string user = "APP_SOPHIS_FO";
                // string password = "TOP";
                string user = "APP_CAESAR_BATCH";
                string password = "@6Nf2YuT";
                SophisBooker bookingManager = new SophisBooker(context.IdServer, user, password);
                bookingManager.UpdateIfNecessary = true;

                return bookingManager;
            }
            catch (Exception e)
            {
                LoggingService.Error(this.GetType(), e);
                return null;
            }
        }

        private string NormalizeTicker(string ticker)
        {
            return ticker.Replace(" " + SophisHelper.BbgCurrencySuffix, string.Empty)
                    .Replace(" " + SophisHelper.BloombergSuffixCommo, string.Empty)
                    .Replace(" " + SophisHelper.BloombergSuffixCorp, string.Empty)
                    .Replace(" " + SophisHelper.BloombergSuffixEquity, string.Empty)
                    .Replace(" " + SophisHelper.BloombergSuffixIndex, string.Empty);
        }
    }



    #endregion

}

