﻿using PricingBase.Product.CsInfoContainer;
using System;

namespace CaesarApplication.Booking
{
    public class BookingPrismCompositionCompareItem : IBookingCompareItem
    {
        public string IndexBloombergTicker { get; set; }

        public DateTime Date { get; set; }

        public IndexInfos Index { get; set; }

        public string ResultSummary { get; set; }

        public string PrismComposition { get; set; }

        public string CaesarComposition { get; set; }

        public BookingPrismCompositionCompareItemStatus Status { get; set; }

        public int? Sicovam { get; set; }
        public double? SophisValo { get; set; }
        public double? CaesarValo { get; set; }
    }
}
