﻿using System;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.Booking
{
    public interface IBookingCompareItem
    {
        IndexInfos Index { get; set; }

        int? Sicovam { get; set; }

        string IndexBloombergTicker { get; set; }

        DateTime Date { get; set; }

        double? SophisValo { get; set; }

        double? CaesarValo { get; set; }
    }
}