using System;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.Booking
{
    public class BookingCalendarCompareItem : IBookingCompareItem
    {
        public int? Sicovam { get; set; }

        public string IndexBloombergTicker { get; set; }

        public DateTime Date { get; set; }

        public BookingCalendarCompareItemStatus Status { get; set; }

        public IndexInfos Index { get; set; }

        public bool Estimated { get; set; }
        public double? ValoTolerance { get; set; }
        public double? SophisValo { get; set; }
        public double? CaesarValo { get; set; }
    }
}