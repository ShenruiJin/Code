﻿using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using FuncFramework.Business;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;
using PrismWS.IndexAlgoFeedService;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CaesarApplication.Booking
{
    public static class BasketTools
    {
        private static ProjectDTO[] projects = null;

        public static ProjectDTO[] Projects
        {
            get
            {
                return projects = projects ?? PersistanceService.IndexProvider.ReadAllProjectsWithoutRevisions(UserService.CaesarSession);
            }
        }

        public static BasketIndexList[] GetComponentAuditBaskets(ITimeSeriesProvider tsp, DateTime startDate, DateTime endDate, ProjectDTO project, IList<IBasketComponent> components)
        {
            return GetComponentAuditBaskets(tsp, startDate, endDate, project, components.Select(x => x.BloombergTicker).ToArray());
        }

        public static BasketIndexList[] GetComponentAuditBaskets(ITimeSeriesProvider tsp, DateTime startDate, DateTime endDate, ProjectDTO project, string[] components)
        {
            return components != null ? components.Where(c => c.Contains(IndexPathHelper.Delimiter)).SelectMany(c =>
            {
                return tsp.GetBasketsAudit(GetFullPath(c, project), startDate, endDate).Y.Cast<BasketIndexList>().ToList();
            }).ToArray() : new BasketIndexList[0];
        }

        public static BasketIndex AggregateBaskets(BasketIndex[] baskets)
        {
            var res = new BasketIndex();

            baskets.ForEach(b => res.AddTimeSeries(new TimeSeries(b.Data.SelectMany(x => x.Value).ToArray()), false));
            baskets.ForEach(b => res.AddTimeSeries(new TimeSeries(b.ResultData.SelectMany(x => x.Value).ToArray())));

            return res;
        }

        public static bool IsSameComposition(IList<IBasketComponent> compo1, IList<IBasketComponent> compo2)
        {
            return compo1.Count == compo2.Count &&
                   compo1.All(x => compo2.Any(y => y.BloombergTicker == x.BloombergTicker && Math.Abs(y.Weight - x.Weight) < 1E-6));
        }


        public static string GetCalendarTicker(ProjectDTO project, IndexInfos indexInfos)
        {
            return project.project_name + IndexPathHelper.Delimiter + indexInfos.ticker +
                                                     IndexPathHelper.Delimiter + "Calendar." + IndexPathHelper.GetIndexName(indexInfos.ticker);
        }

        public static string GetCalendarTicker(string projectName, string ticker)
        {
            return (projectName != null ? (projectName + IndexPathHelper.Delimiter) : string.Empty) + ticker +
                                                     IndexPathHelper.Delimiter + "Calendar." + IndexPathHelper.GetIndexName(ticker);
        }

        public static BasketIndex GetExplodedComposition(DateTime date, BasketIndex basketIndex, string projectName, Dictionary<string, BasketIndexList[]> componentBaskets)
        {
            try
            {
                var components = basketIndex.LastComposition.SelectMany(
                    x => x.BloombergTicker.Contains(IndexPathHelper.Delimiter)
                        ? (
                        componentBaskets.ContainsKey(projectName + IndexPathHelper.Delimiter + x.BloombergTicker)
                        ?
                        componentBaskets[projectName + IndexPathHelper.Delimiter + x.BloombergTicker]
                        :
                        componentBaskets[x.BloombergTicker]
                        )
                            .Last(l => l.EffectiveDate <= date)
                            .Baskets
                            .First(v => v.Name != BasketIndex.AuditBasketName).LastComposition
                        : x.AsArray()).ToArray();

                var bkt = new BasketIndex();

                bkt.AddComposition(components.ToArray(), date);


                return bkt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static BasketIndex GetExplodedCompositionWithWeights(DateTime date, BasketIndex basketIndex, ProjectDTO project, Dictionary<string, BasketIndexList[]> componentBaskets, Dictionary<string, indexCompositionAlgoWs> compositions, Dictionary<string, IndexDTO> indexComponentsIndexInfos, bool explodedComposition = true)
        {
            var projectName = project.project_name;

            try
            {
                var components = basketIndex.LastComposition.SelectMany(
                    x =>
                     {
                         if (x.BloombergTicker.Contains(IndexPathHelper.Delimiter))
                         {
                             IndexDTO idx = indexComponentsIndexInfos.ContainsKey(x.BloombergTicker) ?
                             (project.indexes.FirstOrDefault(i => i.ticker == x.BloombergTicker) ?? PersistanceService.IndexProvider.GetIndexFromCode(x.BloombergTicker, UserService.CaesarSession))

                             : null;

                             if (!explodedComposition)
                             {
                                 if ((idx != null && !string.IsNullOrEmpty(idx.bloomberg_ticker)))
                                 {
                                     return new BasketComponent(x.BloombergTicker, x.Weight).AsArray();
                                 }
                             }

                             return componentBaskets[x.BloombergTicker]
                              .Last(l => l.EffectiveDate <= date)
                              .Baskets
                              .First(v => v.Name != BasketIndex.AuditBasketName).LastComposition.Select(c => new BasketComponent(c.BloombergTicker, compositions[x.BloombergTicker].component.First(i => i.listing.bloombergCode == c.BloombergTicker).priceWeight * x.Weight)).ToArray();
                         }
                         else
                         {
                             return x.AsArray();
                         }
                     }).GroupBy(x => x.BloombergTicker).Select(x => new BasketComponent(x.Key, x.Sum(i => i.Weight))).ToArray();

                var bkt = new BasketIndex();

                bkt.AddComposition(components.ToArray(), date);


                return bkt;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Dictionary<string, string[]> GetExplodedCompositionTickerTranscoDico(DateTime date, BasketIndex basketIndex, ProjectDTO project, Dictionary<string, BasketIndexList[]> componentBaskets, Dictionary<string, indexCompositionAlgoWs> compositions, bool explodedComposition = true)
        {
            var projectName = project.project_name;

            try
            {
                return basketIndex.LastComposition.ToDictionary(x => x.BloombergTicker,
                    x =>
                    {
                        if (x.BloombergTicker.Contains(IndexPathHelper.Delimiter))
                        {
                            IndexDTO idx;

                            if (!explodedComposition && !project.indexes.Any(i => i.ticker == x.BloombergTicker) && ((idx = PersistanceService.IndexProvider.GetIndexFromCode(x.BloombergTicker, UserService.CaesarSession)) != null))
                            {
                                if (!string.IsNullOrEmpty(idx.bloomberg_ticker))
                                {
                                    return idx.bloomberg_ticker.AsArray();
                                }
                            }

                            return componentBaskets[x.BloombergTicker]
                             .Last(l => l.EffectiveDate <= date)
                             .Baskets
                             .First(v => v.Name != BasketIndex.AuditBasketName).LastComposition.Select(c => c.BloombergTicker).ToArray();
                        }
                        else
                        {
                            return x.BloombergTicker.AsArray();
                        }
                    });
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static Dictionary<string, BasketIndexList[]> GetComponentBaskets(ITimeSeriesProvider tsp, DateTime startDate, DateTime endDate, ProjectDTO project, IList<IBasketComponent> components)
        {
            return GetComponentBaskets(tsp, startDate, endDate, project, components.Select(x => x.BloombergTicker).ToArray());
        }

        public static Dictionary<string, BasketIndexList[]> GetComponentBaskets(ITimeSeriesProvider tsp, DateTime startDate, DateTime endDate, ProjectDTO project, string[] components)
        {
            return components != null ? components.Where(c => c.Contains(IndexPathHelper.Delimiter)).ToDictionary(c => c, c =>
            {
                return tsp.GetBaskets(GetFullPath(c, project), startDate, endDate).Y.Cast<BasketIndexList>().ToArray();
            }) : new Dictionary<string, BasketIndexList[]>();
        }

        public static string GetFullPath(string path, ProjectDTO project)
        {
            var suffixToAdd = !project.indexes.Select(x => x.ticker).Contains(path) && Projects.Any(p => p.project_name == IndexPathHelper.GetProjectName(path)) ? string.Empty : project.project_name + IndexPathHelper.Delimiter;

            return path.Split(IndexPathHelper.Delimiter).Length >= 2 ? suffixToAdd + path : path;
        }
    }
}
