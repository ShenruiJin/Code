using System.Collections.Generic;

namespace CaesarApplication.Booking
{
    public class BookingFixingCompareItem : BookingFixingBaseCompareItem
    {
        public bool IsTargetVolOption { get; set; }
        public double? ValoTolerance { get; set; }
    }
}