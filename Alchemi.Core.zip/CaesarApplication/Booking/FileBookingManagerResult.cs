using System;
using System.Collections.Generic;

namespace CaesarApplication.Booking
{
    public class FileBookingManagerResult
    {
        public DateTime ResultDate { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public BookingCalendarCompareItem[] BookingCalendarCompareItems { get; set; }

        public BookingFixingCompareItem[] BookingFixingCompareItems { get; set; }
        public BookingBasketWeightCompareItem[] BookingBasketWeightCompareItems { get; set; }
        public BookingPrismCompositionCompareItem[] BookingPrismCompositionCompareItems { get; set; }

        public string SepcificFolder { get; set; }
    }
}