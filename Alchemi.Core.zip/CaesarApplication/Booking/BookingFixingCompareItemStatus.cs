﻿namespace CaesarApplication.Booking
{
    public enum BookingFixingCompareItemStatus
    {
        Missing,
        ValueKO,
        OK
    }
}