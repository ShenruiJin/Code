using System;
using PricingBase.Product.CsInfoContainer;
using System.Collections.Generic;

namespace CaesarApplication.Booking
{
    public abstract class BookingFixingBaseCompareItem : IBookingCompareItem
    {
        public int? Sicovam { get; set; }

        public string IndexBloombergTicker { get; set; }

        public DateTime Date { get; set; }

        public string UnderlyingName { get; set; }

        public string UnderlyingCode { get; set; }

        public int UnderlyingSicovam { get; set; }

        public double? SophisValue { get; set; }

        public double? CaesarValue { get; set; }

        public BookingFixingCompareItemStatus Status { get; set; }

        public IndexInfos Index { get; set; }

        public bool ApplyRounding { get; set; }

        public List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> SophisCaesarTranscodings { get; set; }

        public double? ValoTolerance { get; set; }
        public double? SophisValo { get; set; }

        public double? CaesarValo { get; set; }
    }
}