﻿using CaesarApplication.DataProvider.Helpers;
using GlobalDerivativesApplications.Booking.Services;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Data.Services;
using GlobalDerivativesApplications.Date;
using GlobalDerivativesApplications.Pricer;
using MarketDataMgr;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalDerivativesApplications.Data.MarketData;
using System.IO;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;
using GlobalDerivativesApplications.Sophis;
using CaesarApplication.Service.Contribution;
using GlobalDerivativesApplications.Data.Booking;
using GlobalDerivativesApplications.Data.Pricing;
using GlobalDerivativesApplications.EdaProto;
using GlobalDerivativesApplications.Reporting;
using FuncFramework;

namespace CaesarApplication.Booking
{
    public class OverlayBooker
    {
        private readonly string CaesarBatchSophisPasswd = ConfigurationManager.AppSettings["CaesarBatchSophisPasswd"] ?? "@6Nf2YuT";
        private readonly string CaesarBatchTable = ConfigurationManager.AppSettings["CaesarBatchSophisTable"] ?? "APP_CAESAR_BATCH";
        private readonly string CaesarSophisPasswd = ConfigurationManager.AppSettings["CaesarSophisPasswd"] ?? "TOP";
        private readonly string CaesarSophisTable = ConfigurationManager.AppSettings["CaesarSophisTable"] ?? "CAESAR";
        private BookingWrapper bookingWrapper;
        private GenericBooker genericBooker;
        private EdaProtoPricer pricerdriver;
        private SophisClauseManager sophisClauseManager;

        private SophisManager2FactoryWrapper sophisManagerFactoryWrapper;
        private SophisBooker sophisBooker;
        private BookingGenericHelper bookingHelper = new BookingGenericHelper();

        private static string currentDatabase = "PROD";

        static OverlayBooker()
        {
            BookingMode = PricingReference.BookingMode;
        }

        public static string CurrentDatabase
        {
            get
            {
                return currentDatabase;
            }
            set
            {
                currentDatabase = value ?? "PROD";
            }
        }

        private static BookingMode bookingMode = BookingMode.Production;

        public static BookingMode BookingMode
        {
            set
            {
                bookingMode = value;

                if (bookingMode == BookingMode.Production)
                {
                    CurrentDatabase = "PROD";
                }
                else if (bookingMode == BookingMode.Recette)
                {
                    CurrentDatabase = "RECETTE";
                }
            }
        }

        private static string GetDatabase(string dbParameter)
        {
            return CurrentDatabase ?? dbParameter;
        }

        #region .ctor
        public OverlayBooker()
            : this(new GenericBooker(), new SophisManager2FactoryWrapper(),
                 new SophisClauseManager(), new SophisFixingManager(), new BookingWrapper(), null)
        { }
        public OverlayBooker(GenericBooker genericBooker, SophisManager2FactoryWrapper sophisManagerFactoryWrapper,
            SophisClauseManager sophisClauseManager, SophisFixingManager sophisFixingManager,
            BookingWrapper bookingWrapper, SophisBooker sophisBooker)
        {
            this.genericBooker = genericBooker;
            this.sophisManagerFactoryWrapper = sophisManagerFactoryWrapper;
            this.sophisClauseManager = sophisClauseManager;
            this.bookingWrapper = bookingWrapper;
            this.sophisBooker = sophisBooker ?? CreateBooker();
        }
        #endregion

        #region Public methods
        public void BNPUpdateSophisOptions(DateTime referenceDate, IPricingCalendar calendar, int sicovam,
            IDictionary<DateTime, BasketIndex> baskets, string database, DateTime? bookingStart, string premiumField, bool throwExIfFutureBooked = false)
        {
            bool isInitialBooking = bookingStart != null;
            try
            {
                if (sicovam > 0)
                {
                    var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);
                    var baseOption = sm2.Option.Get(new OptionInput(sicovam));

                    List<IClause> clauses = new List<IClause>();

                    List<DateTime> overridenDates = new List<DateTime>();

                    var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;

                    bool isHybrid = baseClauses.Any(c => c is IHybridClause);

                    var bookingDates = baskets.Keys.OrderBy(x => x).ToArray();

                    var startBookingDate = bookingDates.First();
                    var endBookingDate = bookingDates.Last();

                    foreach (var dateAndBasket in baskets)
                    {
                        var index = dateAndBasket.Value;
                        var bktDate = dateAndBasket.Key;
                        var components = index.GetOptions();

                        if (premiumField == "Premium")
                        {
                            foreach (var callAndPutGroup in components.GroupBy(c => c.Option.StrikingDate)
                                      .Where(g => g.Key == bktDate)
                                      .OrderBy(g => g.Key))
                            {
                                var calls = callAndPutGroup.Where(c => c.Option.Nature == OptionNature.Call)
                                                          .OrderBy(o => o.Option.Strike)
                                                          .ToArray();
                                var put = callAndPutGroup.FirstOrDefault(c => c.Option.Nature == OptionNature.Put);

                                if (calls.Count() != 3 || put == null)
                                { // one of those options is no longer in the basket
                                    continue;
                                }
                                var callPremiums = calls.Select(call => index[premiumField, call.Option.ToString()].Evaluate()).ToArray();
                                var putPremium = index[premiumField, put.Option.ToString()].Evaluate();

                                if (callPremiums.Any(callPremium => double.IsNaN(callPremium)) || double.IsNaN(putPremium))
                                {
                                    continue;
                                }

                                overridenDates.Add(callAndPutGroup.Key);

                                Func<OptionComponent, double, double> check = (option, premium) =>
                                {
                                    if (option.Option.StrikingDate >= bookingStart.GetValueOrDefault())
                                        return premium;
                                    if (option.Option.ExpirationDate >= bookingStart.GetValueOrDefault())
                                        return 1.0;
                                    return 0.0;
                                };

                                double factorPremium = premiumField == "Premium" ? 100.0 : 1.0;

                                double min = factorPremium * check(put, putPremium);
                                double max = factorPremium * check(calls[0], callPremiums[0]);
                                double gearing = factorPremium * check(calls[1], callPremiums[1]);
                                double cloture = factorPremium * check(calls[2], callPremiums[2]);

                                var firstOrDefault = index.GetBasketComponentsForDateOrLatest(bktDate).Value.FirstOrDefault(bc => bc.InstrumentName == "Cash");
                                if (firstOrDefault != null)
                                {
                                    double hybMin = bktDate < bookingStart.GetValueOrDefault() ? 100.0 *
                                                                                                 firstOrDefault.Weight : 0.0;

                                    IClause clause = isHybrid
                                        ? BNP.CreateHybridClause(min, max, gearing, cloture, hybMin, callAndPutGroup.Key)
                                        : BNP.CreateClause(min, max, gearing, cloture, hybMin, callAndPutGroup.Key);
                                    clauses.Add(clause);
                                }
                            }
                        }
                        else
                        {
                            try
                            {
                                var result = dateAndBasket.Value.ResultData[premiumField].Where(o => o.Field == DataFieldsEnum.AdjustContract);

                                if (result.Count() == 4)
                                {
                                    result = result.OrderBy(o => DateTime.ParseExact(o.Instrument.Split('|')[4], "ddMMyy", null));

                                    double min = ((MarketDataDouble)result.ElementAt(3).Y.First()).Data;
                                    double max = ((MarketDataDouble)result.ElementAt(0).Y.First()).Data;
                                    double gearing = ((MarketDataDouble)result.ElementAt(1).Y.First()).Data;
                                    double cloture = ((MarketDataDouble)result.ElementAt(2).Y.First()).Data;

                                    IClause clause = BNP.CreateClause(min, max, gearing, cloture, 0.0, dateAndBasket.Key);
                                    clauses.Add(clause);
                                }
                            }
                            catch (Exception ex)
                            {
                                log4net.LogManager.GetLogger("Booking").Error(string.Format("Error while booking clause into {0}", sicovam), ex);
                            }
                        }
                    }

                    var oldClausesNotOverrided = baseClauses.Where(c => !overridenDates.Contains(c.EndDate) && c.EndDate <= referenceDate).ToArray();

                    var oldClausesOutsideBookingScope =
                        oldClausesNotOverrided.Where(x => x.StartDate < startBookingDate || x.StartDate > endBookingDate)
                            .ToArray();

                    var oldClausesInsideBookingScope = oldClausesNotOverrided.Except(oldClausesOutsideBookingScope).ToArray();

                    oldClausesInsideBookingScope = oldClausesInsideBookingScope
                        .Select(c =>
                        {
                            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == c.EndDate);

                            if (c is HybridClause)
                            {
                                return bookingHelper.CreateHybridClause((HybridClause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                            else
                            {
                                return bookingHelper.CreateClause((Clause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                        }).ToArray();

                    var futureClauses = CreateFuturesClauses(isHybrid, calendar, referenceDate);
                    var futureClausesWithAlreadyExistings = futureClauses.Select(f => baseClauses.FirstOrDefault(b => b.StartDate == f.StartDate && b.EndDate == f.EndDate) ?? f).ToArray();

                    if (throwExIfFutureBooked)
                    {
                        CheckIfClausesHasBeenBookedAfterThisDate(referenceDate, sicovam, baseClauses);
                    }

                    var final = (isInitialBooking ?
                        Enumerable.Empty<IClause>()
                        : oldClausesOutsideBookingScope)
                            .Concat(clauses)
                            .Concat(futureClausesWithAlreadyExistings)
                            .OrderBy(c => c.EndDate)
                            .ToArray();

                    bookingHelper.BackupClauses(sicovam, isHybrid, baseClauses.ToArray(), "Original");
                    sm2.Option.UpdateClauses(sicovam, final);
                    bookingHelper.BackupClauses(sicovam, isHybrid, final, "New");
                }
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("Booking").Error(string.Format("Error whole updating booking for sicovam {0}", sicovam), e);
                throw e;
            }
        }

        public IList<IClause> GetSophisOptionClauses(int sicovam, string database)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);
            var baseOption = sm2.Option.Get(new OptionInput(sicovam));
            return ((IMultiAssetOption)baseOption.Values.First()).Clauses;
        }

        public MarketDataWrapper LoadSophisMarketdata(string udl, string database)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarSophisTable, CaesarSophisPasswd);
            var wrapper = new MarketDataWrapper(sm2);
            wrapper.Load(udl);
            return wrapper;
        }

        public IList<GlobalDerivativesApplications.Data.Pricing.IResult> PriceVanilla(IList<VanillaOption> options,
            IMarketDataWrapper wrapper, DateTime calculationDate)
        {
            if (options.Count == 0)
                return new List<IResult>();

            if (null == pricerdriver || pricerdriver.CalculationDate != calculationDate)
            {
                if (pricerdriver != null)
                    pricerdriver.Dispose();

                pricerdriver = new EdaProtoPricer(wrapper, true);
                pricerdriver.CalculationDate = calculationDate;
            }

            options.GroupBy(x => x.UnderlyingCode).ForEach(o =>
            {
                var stock = wrapper.GetSpot(options.First().UnderlyingCode);

                o.ForEach(x => x.Notional = stock.Value);
                o.ForEach(x => x.DeliveryType = DeliveryType.Cash);
            });

            var result = pricerdriver.Price(options.Cast<IAccept>().ToList(), new MarketContext { Greeks = true });
            return result;
        }

        public IList<PricingResult> PriceVanillaOptions(List<VanillaOption> options, string database, DateTime? calculationDate = null)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarSophisTable, CaesarSophisPasswd);

            return sm2.Pricing.GetVanillaPricesWithContext(calculationDate, options.Cast<IOption>().ToList(), calculationDate);
        }

        public void SaveClausesInFile(string filePath, int sicovam, string database)
        {
            if (File.Exists(filePath))
            {
                File.Delete(filePath);
            }

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);
            var baseOption = sm2.Option.Get(new OptionInput(sicovam));
            var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;
            bool isHybrid = baseClauses.Any(c => c is IHybridClause);

            sophisClauseManager.WriteFile(filePath, isHybrid, baseClauses.ToArray());
        }

        public void SLUpdateSophisVanillaOptions(IDictionary<int, OTCOption> options, string database)
        {
            sophisBooker.UpdateIfNecessary = true;

            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            foreach (var sicoAndOption in options)
            {
                try
                {
                    var sophisOption = sm2.Option.Get(new OptionInput(sicoAndOption.Key)).Values.FirstOrDefault();

                    /// clone dumbly  sophis option into a vanillacashdiv
                    sophisOption = new VanillaOption()
                    {
                        UnderlyingCode = sophisOption.UnderlyingCode,
                        Currency = sophisOption.Currency,
                        Strike = sophisOption.Strike,
                        StartDate = sophisOption.StartDate,
                        EndDate = sophisOption.EndDate,
                        Sicovam = sophisOption.Sicovam,
                        OptionType = sophisOption.OptionType,
                        ExerciseType = sophisOption.ExerciseType,
                        DeliveryType = sophisOption.DeliveryType,
                        Basis = sophisOption.Basis,
                        IsInPerformance = sophisOption.IsInPerformance,
                        Model = sophisOption.Model,
                        Quotity = sophisOption.Quotity,
                        Notional = sophisOption.Notional,
                    };

                    int currencyCode = 0;
                    if (int.TryParse(sophisOption.Currency, out currencyCode))
                    {
                        ICurrency currency = sm2.Currency.Get(new CurrencyInput(sophisOption.Currency));
                        sophisOption.Currency = currency.Name;
                    }

                    int underlyingCode = 0;
                    if (int.TryParse(sophisOption.UnderlyingCode, out underlyingCode))
                    {
                        IInstrument instr = sm2.Instrument.Get(new InstrumentInput(underlyingCode));
                        sophisOption.UnderlyingCode = instr.Reference;
                    }


                    sophisOption.Sicovam = sicoAndOption.Key;
                    /// override with caesaroption
                    var caesarOption = sicoAndOption.Value;

                    sophisOption.OptionType = caesarOption.Nature == MarketData.OptionNature.Call ?
                            GlobalDerivativesApplications.Data.Booking.OptionType.Call : GlobalDerivativesApplications.Data.Booking.OptionType.Put;

                    sophisOption.StartDate = new AbsoluteMaturity(caesarOption.StrikingDate);
                    sophisOption.PremiumPaymentDate = sophisOption.StartDate;
                    sophisOption.EndDate = new AbsoluteMaturity(caesarOption.ExpirationDate);
                    if (Math.Abs(caesarOption.UnderlyingPrice - 0.0) <= 0.00001)
                    { //// relative
                        sophisOption.Strike = caesarOption.Strike;
                        sophisOption.Basis = 0.0;
                        sophisOption.Notional = 100;
                        //// striking today...
                    }
                    else
                    { //// absolute
                        sophisOption.Strike = caesarOption.Strike;
                        sophisOption.Basis = caesarOption.UnderlyingPrice;
                        sophisOption.Notional = 100;
                    }

                    sophisBooker.Book(sophisOption as Option);
                }
                catch (Exception e)
                {
                    log4net.LogManager.GetLogger("Booking").Error(string.Format("Error whole updating booking for sicovam {0}", sicoAndOption.Key), e);
                    throw e;
                }
            }
        }

        public void UpdateClausesFromFile(string filePath, int sicovam, string database)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            var fileClauses = sophisClauseManager.LoadClausesFromFile(filePath);

            sm2.Option.UpdateClauses(sicovam, fileClauses);
        }

        public void UpdateSophisOptions(int sicovam, BasketIndex index, IPricingCalendar calendar, DateTime referenceDate, string database, DateTime? bookingStart = null, bool throwExIfFutureBooked = false)
        {
            Dictionary<DateTime, BasketIndex> baskets = new Dictionary<DateTime, BasketIndex>();
            baskets[referenceDate] = index;
            UpdateSophisOptions(referenceDate, calendar, sicovam, baskets, GetDatabase(database), bookingStart, throwExIfFutureBooked: throwExIfFutureBooked);
        }
        public void UpdateSophisOptions(DateTime referenceDate, IPricingCalendar calendar,
            int sicovam, IDictionary<DateTime, BasketIndex> baskets, string database, DateTime? bookingStart = null, Dictionary<DateTime,
                Dictionary<int, double>> additionnalColumns = null, Dictionary<DateTime, double> clotureColumns = null, bool checkOptionParity = true, Dictionary<DateTime, double> hybGearings = null, bool throwExIfFutureBooked = false)
        {
            bool isInitialBooking = bookingStart != null;
            try
            {
                if (sicovam > 0)
                {
                    var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);
                    var baseOption = sm2.Option.Get(new OptionInput(sicovam));

                    List<IClause> clauses = new List<IClause>();

                    List<DateTime> overridenDates = new List<DateTime>();

                    var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;

                    bool isHybrid = baseClauses.Any(c => c is IHybridClause);

                    var bookingDates = baskets.Keys.OrderBy(x => x).ToArray();

                    var startBookingDate = bookingDates.First();
                    var endBookingDate = bookingDates.Last();

                    foreach (var dateAndBasket in baskets)
                    {
                        var index = dateAndBasket.Value;
                        var bktDate = dateAndBasket.Key;
                        var components = index.GetOptions();

                        foreach (var callAndPutGroup in components.GroupBy(c => c.Option.StrikingDate)
                                  .Where(g => g.Key == bktDate)
                                  .OrderBy(g => g.Key))
                        {
                            var call = callAndPutGroup.FirstOrDefault(c => c.Option.Nature == OptionNature.Call);
                            var put = callAndPutGroup.FirstOrDefault(c => c.Option.Nature == OptionNature.Put);

                            if ((call == null || put == null) && checkOptionParity)
                            { // one of those options is no longer in the basket
                                continue;
                            }
                            bool callIsNull = call == null;
                            bool putIsNull = put == null;
                            var callPremium = !callIsNull ? index[DataFieldsEnum.Premium, call.Option.ToString()].Evaluate() : 0.0d;
                            var putPremium = !putIsNull ? index[DataFieldsEnum.Premium, put.Option.ToString()].Evaluate() : 0.0d;


                            if ((double.IsNaN(callPremium) || double.IsNaN(putPremium)) && checkOptionParity)
                            {
                                continue;
                            }

                            overridenDates.Add(callAndPutGroup.Key);

                            double min = !callIsNull && call.Option.StrikingDate >= bookingStart.GetValueOrDefault() ? callPremium * 100.0 : 0.0;
                            double hybMin = !putIsNull && put.Option.StrikingDate >= bookingStart.GetValueOrDefault() ? putPremium * 100.0 : 0.0;
                            double max = !callIsNull && call.Option.ExpirationDate >= bookingStart.GetValueOrDefault() ? call.Option.Strike * 100.0 : 0;
                            double hybMax = !putIsNull && put.Option.ExpirationDate >= bookingStart.GetValueOrDefault() ? put.Option.Strike * 100.0 : 0;

                            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == callAndPutGroup.Key);

                            IClause clause = isHybrid
                                ? bookingHelper.CreateHybridClause((HybridClause)existingClause, min, hybMin, max, hybMax, callAndPutGroup.Key, additionnalColumns != null && additionnalColumns.ContainsKey(callAndPutGroup.Key) ? additionnalColumns[callAndPutGroup.Key] : null)
                                : bookingHelper.CreateClause((Clause)existingClause, min, max, hybMin, hybMax, callAndPutGroup.Key, additionnalColumns != null && additionnalColumns.ContainsKey(callAndPutGroup.Key) ? additionnalColumns[callAndPutGroup.Key] : null);

                            if (isHybrid && hybGearings != null && hybGearings.ContainsKey(bktDate))
                            {
                                ((HybridClause)clause).HybGearing = hybGearings[bktDate];
                            }

                            if (clotureColumns != null && clotureColumns.ContainsKey(bktDate))
                            {
                                clause.Closing = clotureColumns[bktDate];
                            }
                            clauses.Add(clause);
                        }
                    }

                    var oldClausesNotOverrided = baseClauses.Where(c => !overridenDates.Contains(c.EndDate) && c.EndDate <= referenceDate).ToArray();

                    var oldClausesOutsideBookingScope =
                        oldClausesNotOverrided.Where(x => x.StartDate < startBookingDate || x.StartDate > endBookingDate)
                            .ToArray();

                    var oldClausesInsideBookingScope = oldClausesNotOverrided.Except(oldClausesOutsideBookingScope).ToArray();

                    oldClausesInsideBookingScope = oldClausesInsideBookingScope
                        .Select(c =>
                        {
                            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == c.EndDate);

                            if (c is HybridClause)
                            {
                                return bookingHelper.CreateHybridClause((HybridClause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                            else
                            {
                                return bookingHelper.CreateClause((Clause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                        }).ToArray();

                    var futureClauses = CreateFuturesClauses(isHybrid, calendar, referenceDate);

                    var futureClausesWithAlreadyExistings = futureClauses.Select(f => baseClauses.FirstOrDefault(b => b.StartDate == f.StartDate && b.EndDate == f.EndDate) ?? f).ToArray();

                    if (throwExIfFutureBooked)
                    {
                        CheckIfClausesHasBeenBookedAfterThisDate(referenceDate, sicovam, baseClauses);
                    }

                    var final = (isInitialBooking ?
                        Enumerable.Empty<IClause>()
                        : (oldClausesOutsideBookingScope.Union(oldClausesInsideBookingScope)))
                            .Concat(clauses)
                            .Concat(futureClausesWithAlreadyExistings)
                            .OrderBy(c => c.EndDate)
                            .ToArray();

                    bookingHelper.BackupClauses(sicovam, isHybrid, baseClauses.ToArray(), "Original");

                    sm2.Option.UpdateClauses(sicovam, final);

                    bookingHelper.BackupClauses(sicovam, isHybrid, final, "New");
                }
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("Booking").Error(string.Format("Error whole updating booking for sicovam {0}", sicovam), e);
                throw e;
            }
        }


        public void UpdateSophisOptions(DateTime referenceDate, IPricingCalendar calendar,
    int sicovam, string database, DateTime bookingDate, double? callPremium, double? putPremium, double? callStrike, double? putStrike, Dictionary<int, double> additionnalColumns = null)
        {
            bool isInitialBooking = false;
            try
            {
                if (sicovam > 0)
                {
                    var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);
                    var baseOption = sm2.Option.Get(new OptionInput(sicovam));

                    List<IClause> clauses = new List<IClause>();

                    List<DateTime> overridenDates = new List<DateTime>();

                    var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;

                    bool isHybrid = baseClauses.Any(c => c is IHybridClause);


                    var startBookingDate = referenceDate;
                    var endBookingDate = referenceDate;

                    {
                        var bktDate = referenceDate;


                        {
                            double min = callPremium.HasValue ? callPremium.GetValueOrDefault() * 100.0 : 0.0;
                            double hybMin = putPremium.HasValue ? putPremium.GetValueOrDefault() * 100.0 : 0.0;
                            double max = callStrike.HasValue ? callStrike.GetValueOrDefault() * 100.0 : 0;
                            double hybMax = putStrike.HasValue ? putStrike.GetValueOrDefault() * 100.0 : 0;


                            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == referenceDate);

                            IClause clause = isHybrid
                                ? bookingHelper.CreateHybridClause((HybridClause)existingClause, min, hybMin, max, hybMax, referenceDate, additionnalColumns, false)
                                : bookingHelper.CreateClause((Clause)existingClause, min, max, hybMin, hybMax, referenceDate, additionnalColumns, false);

                            clauses.Add(clause);
                            overridenDates.Add(clause.EndDate);
                        }
                    }

                    var oldClausesNotOverrided = baseClauses.Where(c => !overridenDates.Contains(c.EndDate) && c.EndDate <= referenceDate).ToArray();

                    var oldClausesOutsideBookingScope =
                        oldClausesNotOverrided.Where(x => x.StartDate < startBookingDate || x.StartDate > endBookingDate)
                            .ToArray();

                    var oldClausesInsideBookingScope = oldClausesNotOverrided.Except(oldClausesOutsideBookingScope).ToArray();

                    oldClausesInsideBookingScope = oldClausesInsideBookingScope
                        .Select(c =>
                        {
                            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == c.EndDate);

                            if (c is HybridClause)
                            {
                                return bookingHelper.CreateHybridClause((HybridClause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                            else
                            {
                                return bookingHelper.CreateClause((Clause)existingClause, 0, 0, 0, 0, c.StartDate);
                            }
                        }).ToArray();

                    var futureClauses = CreateFuturesClauses(isHybrid, calendar, referenceDate);

                    var futureClausesWithAlreadyExistings = futureClauses.Select(f => baseClauses.FirstOrDefault(b => b.StartDate == f.StartDate && b.EndDate == f.EndDate) ?? f).ToArray();


                    var final = (isInitialBooking ?
                        Enumerable.Empty<IClause>()
                        : (oldClausesOutsideBookingScope.Union(oldClausesInsideBookingScope)))
                            .Concat(clauses)
                            .Concat(futureClausesWithAlreadyExistings)
                            .OrderBy(c => c.EndDate)
                            .ToArray();

                    bookingHelper.BackupClauses(sicovam, isHybrid, baseClauses.ToArray(), "Original");

                    sm2.Option.UpdateClauses(sicovam, final);

                    bookingHelper.BackupClauses(sicovam, isHybrid, final, "New");
                }
            }
            catch (Exception e)
            {
                log4net.LogManager.GetLogger("Booking").Error(string.Format("Error whole updating booking for sicovam {0}", sicovam), e);
                throw e;
            }
        }

        public double? GetSpot(int sicovam, string database = null)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            return sm2.Spot.Get(new SpotInput(sicovam)).Value;
        }

        public double? GetSpot(string reference, string database = null)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            return sm2.Spot.Get(new SpotInput(reference)).Value;
        }


        private void CheckIfClausesHasBeenBookedAfterThisDate(DateTime referenceDate, int sicovam, IList<IClause> baseClauses)
        {
            var alreadyWrittenFuturesClauses = baseClauses.Where(x => x.StartDate > referenceDate && HasBeenWritten(x)).ToArray();

            if (alreadyWrittenFuturesClauses.Any())
            {
                throw new Exception(string.Format("You try to book in the sicovam {0} clauses at {1} but clauses {2} has been booked after this date", sicovam, referenceDate, alreadyWrittenFuturesClauses.Select(x => x.StartDate.ToShortDateString()).Stringify(",")));
            }
        }

        private bool HasBeenWritten(IClause x)
        {
            return x.Closing != default(double) || x.Gearing != default(double) || x.Max != default(double) || x.Min != default(double);
        }

        public void UpdateSophisOptionsWithSophisPrice(int sicovam, int callSicovam, int putSicovam, OTCOption call, OTCOption put,
                    string database, Dictionary<int, double> additionnalColumns = null, bool checkParity = true)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(database, CaesarBatchTable, CaesarBatchSophisPasswd);
            var baseOption = sm2.Option.Get(new OptionInput(sicovam));
            var baseClauses = (baseOption.Values.First() as IMultiAssetOption).Clauses;
            bool isHybrid = baseClauses.Any(c => c is IHybridClause);

            double max = 0;
            double min = 0;
            double hybMin = 0;
            double hybMax = 0;

            var endDate = checkParity || call != null ? call.StrikingDate : put.StrikingDate;
            var existingClause = baseClauses.FirstOrDefault(x => x.EndDate == endDate);

            if (checkParity || call != null)
            {

                var callPremium = sm2.Theroretical.Get(new TheoreticalInput(callSicovam)).Price;
                max = call.Strike * 100.0;
                min = callPremium;
            }
            else
            {
                max = existingClause != null ? existingClause.Max : 0.0;
                min = existingClause != null ? existingClause.Min : 0.0;
            }
            if (checkParity || put != null)
            {
                var putPremium = sm2.Theroretical.Get(new TheoreticalInput(putSicovam)).Price;
                hybMin = putPremium;
                hybMax = put.Strike * 100.0;
            }
            else
            {
                hybMin = existingClause != null ? (isHybrid ? ((HybridClause)existingClause).HybMin.GetValueOrDefault() : existingClause.AdditionalColumns[1]) : 0.0;
                hybMax = existingClause != null ? (isHybrid ? ((HybridClause)existingClause).HybMin.GetValueOrDefault() : existingClause.AdditionalColumns[2]) : 0.0;
            }

            IClause clause = isHybrid
                ? bookingHelper.CreateHybridClause((HybridClause)existingClause, min, hybMin, max, hybMax, call.StrikingDate, additionnalColumns)
                : bookingHelper.CreateClause((Clause)existingClause, min, max, hybMin, hybMax, call.StrikingDate, additionnalColumns);

            var final = baseClauses.Where(x => x.StartDate != clause.StartDate).Union(clause.AsArray()).OrderBy(x => x.StartDate).ToArray();

            sm2.Option.UpdateClauses(sicovam, final);
        }
        public CommandStatus UpdateSpot(string database, string ticker, string currency, DateTime date, double value)
        {
            return bookingWrapper.UpdateSpot(GetDatabase(database), ticker, currency, date, value);
        }

        public string GetOptionParsingZone(int sicovam, string database)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            var options = sm2.Option.Get(new OptionInput(sicovam));

            if (options.Values != null && options.Values.Any())
            {
                return ((MultiAssetOption)options.Values.First()).ParsingZone;
            }

            return null;
        }

        public void SetOptionParsingZone(int sicovam, string database, string parsingZone)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            sm2.Option.SetParsingZone(sicovam, parsingZone);
        }

        public DateTime? GetOptionStartDate(int sicovam, string database)
        {
            var sm2 = sophisManagerFactoryWrapper.CreateSophisManager(GetDatabase(database), CaesarBatchTable, CaesarBatchSophisPasswd);

            var options = sm2.Option.Get(new OptionInput(sicovam));

            if (options.Values != null && options.Values.Any())
            {
                return options.Values.First().StartDate.ToDate();
            }

            return null;
        }

        #endregion


        #region Private and internal methods

        private SophisBooker CreateBooker()
        {
            return genericBooker.CreateBooker();
        }

        private IClause[] CreateFuturesClauses(bool isHybrid, IPricingCalendar cal, DateTime referenceDate)
        {
            return
                cal.GetBusinessDays(referenceDate.AddDays(1), referenceDate.AddYears(2))
                    .Select(d => isHybrid ? (IClause)bookingHelper.CreateHybridClause(null, 0, 0, 0, 0, d)
                    : bookingHelper.CreateClause(null, 0, 0, 0, 0, d))
                    .ToArray();
        }
        private string GetSicovamFromTicker(ISophisManager2 sophisManager2, string ticker)
        {
            return sophisManager2.Instrument.Get(new InstrumentInput(ticker)).Code.ToString();
        }


        #endregion

    }
}
