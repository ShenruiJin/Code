﻿using GlobalDerivativesApplications.Data.Instrument;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using CaesarApplication.DataProvider.Helpers;
using GlobalDerivativesApplications.Data.Instrument.MultiAsset;
using PricingBase.DataProvider;
using PrismWS.IndexAlgoFeedService;
using GlobalDerivativesApplications.Sophis.Command;
using System.Linq;
using FuncFramework;

namespace CaesarApplication.Booking
{
    public static class BookingGeneric
    {
        private static string currentDatabase = "PROD";

        static BookingGeneric()
        {
            BookingMode = PricingReference.BookingMode;
        }

        public static string CurrentDatabase
        {
            get
            {
                return currentDatabase;
            }
            set
            {
                currentDatabase = value ?? "PROD";

                genericBooker = new GenericBooker(currentDatabase);
            }
        }

        private static BookingMode bookingMode = FuncFramework.BookingMode.Production;

        public static BookingMode BookingMode
        {
            set
            {
                bookingMode = value;

                if(bookingMode == BookingMode.Production)
                {
                    CurrentDatabase = "PROD";
                }
                else if(bookingMode == BookingMode.Recette)
                {
                    CurrentDatabase = "RECETTE";
                }
            }
        }

        private static GenericBooker genericBooker = new GenericBooker(currentDatabase);

        private static string GetDatabase(string dbParameter)
        {
            return CurrentDatabase ?? dbParameter;
        }

        public static string PrismBookingInsertBasket(string bbgCode, string currency, BasketIndex basketIndex,
            double currentQuote, DateTime dateComposition, Dictionary<string, TimeSerieDB> forex = null, bool forwardCompo = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodeCompo = true, bool testMode = false, bool fxHedge = false, bool removeNullWeights = false)
        {
            return genericBooker.PrismBookingInsertBasket(bbgCode, currency, basketIndex, currentQuote, dateComposition, 
                forex, forwardCompo, fieldUseAsLast, auditBasket, compositionDate, explodeCompo, testMode, fxHedge, removeNullWeights);
        }

        public static string SophisPackageBookingInsertBasket(int sicoPackage, string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database = null, string user = null, string passWord = null, bool cleanerMode = false, bool fxHedged = false)
        {
            return new GenericBooker(GetDatabase(database)).SophisPackageBookingInsertBasket(sicoPackage, bbgCode, basketIndex, quote, dateComposition, auditBasket, GetDatabase(database), user ?? "APP_CAESAR_BATCH", passWord ?? "@6Nf2YuT", cleanerMode, fxHedged);
        }

        public static indexCompositionAlgoWs GetPrismComposition(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote,
     DateTime dataDate, Dictionary<string, TimeSerieDB> fx, ref Dictionary<string, double> ajustmentFactors, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodedCompo = true, bool transcodeTickerToPrism = true, Dictionary<string, double> forexValues = null, bool fxHedged = false)
        {
            return new GenericBooker(null).GetPrismComposition(bbgCode, currency, basketIndex, currentQuote,
            dataDate, fx, ref ajustmentFactors, isForward, fieldUseAsLast, auditBasket, compositionDate, explodedCompo, transcodeTickerToPrism, forexValues, fxHedged);
        }

        public static string SophisCompositionBookingInsertBasket(string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database = null, string user = null, string passWord = null, bool cleanerMode = false, bool fxHedged = false, bool removeNullWeights = false)
        {
            return new GenericBooker(GetDatabase(database)).SophisCompositionBookingInsertBasket(bbgCode, basketIndex, quote, dateComposition, auditBasket, database, user, passWord, cleanerMode, fxHedged, removeNullWeights);
        }

        public static string SophisCompositionBookingInsertBasket(int sicoPackage, Dictionary<string, double> weights, string database, string user, string passWord, bool cleanerMode = true)
        {
            return new GenericBooker(GetDatabase(database)).SophisCompositionBookingInsertBasket(sicoPackage, weights, GetDatabase(database), user ?? "APP_CAESAR_BATCH", passWord ?? "@6Nf2YuT", cleanerMode);

        }

        public static string SophisCompositionBookingInsertBasket(int sicoPackage, string bbgCode, BasketIndex basketIndex, double quote, DateTime dateComposition, BasketIndex auditBasket, string database = null, string user = null, string passWord = null, bool cleanerMode = false, bool fxHedged = false)
        {
            return new GenericBooker(GetDatabase(database)).SophisCompositionBookingInsertBasket(sicoPackage, bbgCode, basketIndex, quote, dateComposition, auditBasket, GetDatabase(database), user ?? "APP_CAESAR_BATCH", passWord ?? "@6Nf2YuT", cleanerMode, fxHedged);
        }

        public static string SophisPackageBookingInsertBasket(int sicoPackage, Dictionary<string, double> weights, string database = null, string user = null, string passWord = null, bool cleanerMode = true)
        { 
            return new GenericBooker(GetDatabase(database)).SophisPackageBookingInsertBasket(sicoPackage, weights, GetDatabase(database), user ?? "APP_CAESAR_BATCH", passWord ?? "@6Nf2YuT", cleanerMode);
        }

        public static Dictionary<DateTime, Dictionary<string, double>> SophisGetRealizedValues(int sicoPackage, string database = null, string user = null, string passWord = null, bool cleanerMode = false, bool fxHedged = false)
        {
            var realizedValues = new GenericBooker(GetDatabase(database)).SophisGetRealizedValues(sicoPackage, GetDatabase(database), user ?? "APP_CAESAR_BATCH", passWord ?? "@6Nf2YuT");

            return realizedValues.Any() ? realizedValues.ToDictionary(x => x.ObservationDate, x => x.Labels.Select((it, i) => new { Key = it, Value = x.Values[i] }).ToDictionary(kv => kv.Key, kv => kv.Value)) : new Dictionary<DateTime, Dictionary<string, double>>();
        }

        public static string GetReferenceFromSicovam(int sicovam)
        {
            return genericBooker.GetReferenceFromSicovam(sicovam);
        }

        public static int GetSicovamFromReference(string reference)
        {
            var res = SophisHelper.GetSicovam(reference);
            return res;
        }
        public static bool UpdateBasket(int sicovam, IBasket basket, string database = null)
        {
            return genericBooker.UpdateBasket(sicovam, basket, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }

        public static string UpdateBasket(int sicovam, BasketIndex basket, DateTime today, string database = null)
        {
            return genericBooker.UpdateBasket(sicovam, basket, today, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }
        public static ISophisFixings[] ReadFixings(int sicovam, DateTime startDate, DateTime endDate, string database = null)
        {
            return genericBooker.ReadFixings(sicovam, startDate, endDate, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }
        public static IClause[] ReadClauses(int sicovam, DateTime startDate, DateTime endDate, string database = null)
        {
            return genericBooker.ReadClauses(sicovam, startDate, endDate, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }

        public static List<IComponent> ReadPackageComposition(int sicovam, string database = null)
        {
            return genericBooker.ReadPackageComposition(sicovam, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }

        public static IPackage ReadPackage(int sicovam, string database = null)
        {
            return genericBooker.ReadPackage(sicovam, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }

        public static void UpdatePackage(int sicovam, IPackage package)
        {
            genericBooker.UpdatePackage(sicovam, package);
        }

        public static void UpdateFixings(int sicovam, IEnumerable<DateTime> dates, Action<ISophisFixings> action, string database = null)
        {
            genericBooker.UpdateFixings(sicovam, dates, action, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }

        public static void UpdateWeightFixings(int sicovam, Dictionary<DateTime, Dictionary<string, double?>> weightUpdates, string database, string user, string passWord, int weightColIndex = 3, bool cleanerMode = true)
        {
            genericBooker.UpdateWeightFixings(sicovam, weightUpdates, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT", weightColIndex, cleanerMode);
        }

        public static string PrismBookingInsertBasket(indexCompositionAlgoWs composition)
        {
            return genericBooker.PrismBookingInsertBasket(composition);
        }

        public static indexCompositionAlgoWs PrismGetComposition(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote,
                DateTime dataDate, Dictionary<string, TimeSerieDB> fx, out Dictionary<string, double> ajustmentFactors, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null)
        {
            ajustmentFactors = new Dictionary<string, double>();
            return genericBooker.PrismGetComposition(bbgCode, currency, basketIndex, currentQuote, dataDate, fx, ajustmentFactors, isForward, fieldUseAsLast, auditBasket, compositionDate);
        }


        /// <summary>
        /// Keeps and saves fixings at indicated dates
        /// </summary>
        /// <param name="sicovam"></param>
        /// <param name="baskets"></param>
        /// <param name="startBooking">Keep fixings before this date</param>
        /// <param name="endBooking">Keep fixings after this dates</param>
        /// <param name="database"></param>
        public static void SaveAndFilterFixings(int sicovam, IDictionary<DateTime, BasketIndex> baskets, DateTime startBooking, 
            DateTime endBooking, string database = null)
        {
            genericBooker.SaveAndFilterFixings(sicovam, baskets, startBooking, endBooking, GetDatabase(database), "APP_CAESAR_BATCH", "@6Nf2YuT");
        }
        /// <summary>
        /// Keeps and saves clauses at indicated dates
        /// </summary>
        /// <param name="sicovam"></param>
        /// <param name="dates">Keep clauses at this dates</param>
        /// <param name="startBooking">Keep clauses before this date</param>
        /// <param name="endBooking">Keep clauses after this dates</param>
        /// <param name="database"></param>
        /// <param name="clotureColValueToKeep">(cloture colummn)Values to copy on the next clause date when deleting a clause</param>
        public static void SaveAndFilterClauses(int sicovam, IList<DateTime> dates, DateTime startBooking, DateTime endBooking,
            string database = null, double[] clotureColValueToKeep = null)
        {
            genericBooker.SaveAndFilterClauses(sicovam, dates, startBooking, endBooking, GetDatabase(database), clotureColValueToKeep);
        }

        public static void AddFixings(int sicovam, IList<SophisFixings> fixingsToAdd, string database = null)
        {
            genericBooker.AddFixings(sicovam, fixingsToAdd, GetDatabase(database));
        }

    }
}
