﻿using GlobalDerivativesApplications.Data.Instrument;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaesarApplication.Booking
{
    class BNP
    {
        public static HybridClause CreateHybridClause(double min, double max, double gearing, double closing, double hybMin, DateTime date)
        {
            return new HybridClause(date, date)
            {
                Min = min,
                Max = max,
                Gearing = gearing,
                Closing = closing,
                HybMin = hybMin,

            };
        }

        public static Clause CreateClause(double min, double max, double gearing, double closing, double hybMin, DateTime date)
        {
            return new Clause(date, date)
            {
                Min = min,
                Max = max,
                Gearing = gearing,
                Closing = closing,
                AdditionalColumns = new[] { 0.0, hybMin },
            };
        }

    }
}
