using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using CaesarApplication.BlotterAsService;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using FuncFramework.Business;
using GlobalDerivativesApplications.Serialization;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System.Globalization;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using CaesarApplication.Service.PricingEngine;
using PricingBase.Dates;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using GlobalDerivativesApplications.Data.Instrument;
using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Service.Strategy;
using GlobalDerivativesApplications.Date;

namespace CaesarApplication.Booking
{
    public class FileBookingManager : IBookingManager
    {
        private readonly BookingManager bookingManager;

        private string FileBookingManagerConfigFilePath = ConfigurationManager.AppSettings["FileBookingManagerConfigFilePath"];
        private string FileBookingManagerDirectoryPath = ConfigurationManager.AppSettings["FileBookingManagerDirectoryPath"];
        ITimeSeriesProvider tsp;

        public FileBookingManager(int nbDayLag, DateTime referenceDate)
            : this(CreateTimeSeriesProvider(), nbDayLag, referenceDate)
        {
        }

        private static ITimeSeriesProvider CreateTimeSeriesProvider()
        {
            var tsp = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()), new TimeSeriesProviderParameters { NoCacheLoading = true });
            tsp.PricingContext = new PricingContext();

            tsp.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            return tsp;
        }

        public FileBookingManager(ITimeSeriesProvider tsp, int nbDayLag, DateTime referenceDate)
        {
            this.tsp = tsp;
            bookingManager = new BookingManager(tsp);
            EndDate = referenceDate;
            StartDate = referenceDate.AddDays(-Math.Max(-nbDayLag, 1));

            bookingManager.StartDate = StartDate;
            bookingManager.EndDate = EndDate;
        }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public BookingCalendarCompareItem[] CompareCalendar(int sicovam, IndexInfos index, DateTime startDate, DateTime endDate, bool compareFuture, int futureCheckNbDays, double? valoTolerance = null, bool addDayIfLastDayIsHoliday = false, int? futureCheckNbYears = null)
        {
            return bookingManager.CompareCalendar(sicovam, index, startDate, endDate, false, 0, valoTolerance, addDayIfLastDayIsHoliday, futureCheckNbYears);
        }

        public BookingCalendarCompareItem[] CompareCalendar(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return bookingManager.CompareCalendar(configs, startDate, endDate);
        }

        public BookingFixingCompareItem[] CompareFixings(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return bookingManager.CompareFixings(configs, startDate, endDate);
        }

        public IEnumerable<BookingFixingCompareItem> CompareFixings(int sicovam, IndexInfos idxInfos, DateTime startDate, DateTime endDate, bool applyRounding, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodings = null, List<BookingCompareConfigurationItem.SophisCaesarTranscodingItem> sophisCaesarTranscodingsToIgnore = null, int? fixingRounding = null, double? valoTolerance = null)
        {
            return bookingManager.CompareFixings(sicovam, idxInfos, startDate, endDate, applyRounding, sophisCaesarTranscodings, sophisCaesarTranscodingsToIgnore, fixingRounding, valoTolerance);
        }

        public IEnumerable<BookingBasketWeightCompareItem> CompareBaskets(int sicovam, IndexInfos idxInfos, DateTime startDate, DateTime endDate, int lag, double? valoTolerance = null, int? weightColumn = 2)
        {
            return bookingManager.CompareBaskets(sicovam, idxInfos, startDate, endDate, lag, valoTolerance, weightColumn);
        }

        public IEnumerable<BookingPrismCompositionCompareItem> ComparePrismCompositions(IndexInfos idxInfos, DateTime startDate, DateTime endDate)
        {
            return bookingManager.ComparePrismCompositions(idxInfos, startDate, endDate);
        }

        public BookingBasketWeightCompareItem[] CompareBaskets(IEnumerable<BookingCompareConfigurationItem> configs, DateTime startDate, DateTime endDate)
        {
            return bookingManager.CompareBaskets(configs, startDate, endDate);
        }

        public FileBookingManagerResult Compute(string configFilePath = null)
        {
            var config = File.ReadAllText(configFilePath ?? FileBookingManagerConfigFilePath).FromSerializedString<FileBookingManagerConfiguration>();

            var result = new FileBookingManagerResult
            {
                ResultDate = DateTime.Now,
                StartDate = StartDate,
                EndDate = EndDate,
            };

            config.BookingCompareConfigurationItems.Where(x => x.SicovamFromIndexDTO)
    .ForEach(x =>
    {
        x.Sicovams = int.Parse(Service.Persistance.PersistanceService.IndexProvider.GetIndexFromBbgTicker(x.IndexBloombergTicker, Service.Configuration.UserService.CaesarSession).sophis_reference).AsArray();
    });

            config.BookingCompareConfigurationItems.Where(x => x.SicovamsFromSophis).AsParallel()
                .ForEach(x =>
                {
                    x.Sicovams = BookingManagerExtensions.GetOptionSicovamForExternalRef(x.IndexBloombergTicker).ToArray();

                    x.Sicovams = x.Sicovams.Where(s =>
                    {
                        try
                        {
                            var instr = SophisHelper.GetInstrumentInfo(s.ToString());

                            return (instr.Expiry.GetValueOrDefault() >= DateTime.Today);
                        }
                        catch
                        {
                            return false;
                        }

                    }).ToArray();
                });


            config.BookingCompareConfigurationItems
                .ForEach(x =>
                {
                    x.ValoTolerance = x.ValoTolerance.GetValueOrDefault(0.003);
                });

            new Task[]
            {
                Task.Factory.StartNew(() => result.BookingCalendarCompareItems = bookingManager.CompareCalendar(config.BookingCompareConfigurationItems, StartDate, EndDate), TaskCreationOptions.LongRunning),
                Task.Factory.StartNew(() => result.BookingFixingCompareItems = bookingManager.CompareFixings(config.BookingCompareConfigurationItems, StartDate, EndDate), TaskCreationOptions.LongRunning),
                Task.Factory.StartNew(() => result.BookingBasketWeightCompareItems = bookingManager.CompareBaskets(config.BookingCompareConfigurationItems, StartDate, EndDate), TaskCreationOptions.LongRunning),
                Task.Factory.StartNew(() => result.BookingPrismCompositionCompareItems = bookingManager.ComparePrismCompositions(config.BookingCompareConfigurationItems, StartDate, EndDate), TaskCreationOptions.LongRunning)
            }.ForEach(t => t.Wait());


            SetValorisationsInResult(result);
            SaveResult(result, config);

            return result;
        }

        private void SetValorisationsInResult(FileBookingManagerResult result)
        {
            var items = result.BookingCalendarCompareItems.Cast<IBookingCompareItem>()
                 .Concat(result.BookingBasketWeightCompareItems.Cast<IBookingCompareItem>())
                  .Concat(result.BookingFixingCompareItems.Cast<IBookingCompareItem>())
                    .Concat(result.BookingPrismCompositionCompareItems.Cast<IBookingCompareItem>())
                    .ToArray();

            var tspDbOnly = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, new TimeSeriesProviderParameters { DataHandlersToUse = "DB".AsArray(), SpecificDBSources = "DB".AsArray(), ReadOnly = true });
            tspDbOnly.PricingContext = new PricingContext(DateTime.Today, new PricingCalendar());

            tspDbOnly.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var sicovams = items.Select(x => x.Sicovam).Distinct();

            var bbgTickers = items.Select(x => x.IndexBloombergTicker).Distinct();
            var startDate = items.Min(x => x.Date);
            var endDate = new DateTime[] { DateTime.Today, items.Max(x => x.Date) }.Min();

            var indexByTicker = bbgTickers.ToDictionary(x => x, x => tspDbOnly.GetIndexInfosByBbgTicker(x));

            var quotes = tsp.Load(indexByTicker.Values.Select(x => x.bloomberg_ticker.ToString()).ToArray(), DataFieldsEnum.Last.AsArray(), startDate, endDate);

            var sicovamsWithTicker = items.Select(i => new { i.IndexBloombergTicker, i.Sicovam }).Distinct().ToArray().ToDictionary(x => x, x => SophisOptionPricer.Helper.GetSophisValoTicker(x.Sicovam.GetValueOrDefault(), x.IndexBloombergTicker));

            var contreValoSeries = tspDbOnly.Load(sicovamsWithTicker.Values, DataFieldsEnum.Last.AsArray(), startDate, endDate, new OpenDaysCalendar());

            items.GroupBy(x => x.IndexBloombergTicker)
    .ForEach(grp =>
    {
        var quoteTs = quotes.First(x => grp.Key == x.Instrument);

        grp.ForEach(i => i.CaesarValo = quoteTs.Evaluate(i.Date));
    });


        items.GroupBy(x => new { x.IndexBloombergTicker, x.Sicovam })
                .ForEach(grp =>
                {
                        var cvTs = contreValoSeries.FirstOrDefault(v => v.Instrument == SophisOptionPricer.Helper.GetSophisValoTicker(grp.Key.Sicovam.GetValueOrDefault(), grp.Key.IndexBloombergTicker));

                        if (cvTs != null)
                        {
                            grp.ForEach(i => i.SophisValo = NormalizeValo(cvTs.Evaluate(i.Date), i.CaesarValo.GetValueOrDefault()));
                        }
                });
        }

        public static double NormalizeValo(double val, double refVal)
        {
            double v = val;

            if(val == 0.0d)
            {
                return double.NaN;
            }

            var log10_1 = Math.Round(Math.Log10(val));
            var log10_2 = Math.Round(Math.Log10(refVal));
            

            return val * Math.Pow(10, log10_2 - log10_1);
        }

        private void SaveResult(FileBookingManagerResult result, FileBookingManagerConfiguration config)
        {
            foreach (var folder in config.BookingCompareConfigurationItems.Select(x => x.SpecificFolder).Distinct())
            {
                var impactedScope = config.BookingCompareConfigurationItems.Select(x => x.IndexBloombergTicker).ToArray();

                SaveResult(result, folder, impactedScope);
            }
        }

        private void SaveResult(FileBookingManagerResult result, string folder, string[] impactedScope = null)
        {

            var specificFolder = Path.Combine(FileBookingManagerDirectoryPath, folder ?? string.Empty);
            var resultToSave = new FileBookingManagerResult
            {
                ResultDate = result.ResultDate,
                StartDate = result.StartDate,
                EndDate = result.EndDate,
                BookingCalendarCompareItems = result.BookingCalendarCompareItems.Where(x => impactedScope == null || impactedScope.Contains(x.IndexBloombergTicker)).ToArray(),
                BookingFixingCompareItems = result.BookingFixingCompareItems.Where(x => impactedScope == null || impactedScope.Contains(x.IndexBloombergTicker)).ToArray(),
                BookingBasketWeightCompareItems = result.BookingBasketWeightCompareItems.Where(x => impactedScope == null || impactedScope.Contains(x.IndexBloombergTicker)).ToArray(),
                BookingPrismCompositionCompareItems = result.BookingPrismCompositionCompareItems.Where(x => impactedScope == null || impactedScope.Contains(x.IndexBloombergTicker)).ToArray(),
                SepcificFolder = folder
            };

            if (!Directory.Exists(specificFolder))
            {
                Directory.CreateDirectory(specificFolder);
            }

            var dayDirectory = Path.Combine(specificFolder, resultToSave.ResultDate.ToString("ddMMyyyy"));

            if (!Directory.Exists(dayDirectory))
            {
                Directory.CreateDirectory(dayDirectory);
            }

            var filePath = Path.Combine(dayDirectory, "Result" + resultToSave.ResultDate.ToString("ddMMyyyyHHmmss") + ".xml");

            File.WriteAllText(filePath, resultToSave.ToSerializedString());
        }

        public bool FolderExistsForProfile(string profil)
        {
            return Directory.Exists(Path.Combine(FileBookingManagerDirectoryPath, profil));
        }

        public FileBookingManagerResult LoadLastResult(string folder = null)
        {
            var lastDirectory = new DirectoryInfo(Path.Combine(FileBookingManagerDirectoryPath, folder ?? "")).GetDirectories()
                .Where(x =>
                {
                    DateTime d;

                    return DateTime.TryParseExact(x.Name, "ddMMyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out d);
                }).OrderBy(d => d.CreationTime).LastOrDefault();

            if (lastDirectory == null)
            {
                return null;
            }
            var lastFile = lastDirectory.GetFiles().OrderBy(x => x.CreationTime).LastOrDefault();

            if (lastFile == null)
            {
                return null;
            }

            return File.ReadAllText(lastFile.FullName).Replace("&#x1A;", "").FromSerializedString<FileBookingManagerResult>();
        }

        public void MergeResults(FileBookingManagerResult resultToMerge, FileBookingManagerResult resultToRemove, string currentFolder = null)
        {
            var existingResult = LoadLastResult(currentFolder);

            var mergedResult = new FileBookingManagerResult
            {
                StartDate = new[] { resultToMerge.StartDate, existingResult.StartDate }.Min(),
                EndDate = new[] { resultToMerge.EndDate, existingResult.EndDate }.Min(),
                ResultDate = DateTime.Now,
                BookingCalendarCompareItems = GetBookingCompareItemsToSave(resultToMerge.BookingCalendarCompareItems, resultToRemove.BookingCalendarCompareItems, existingResult.BookingCalendarCompareItems),
                BookingFixingCompareItems = GetBookingCompareItemsToSave(resultToMerge.BookingFixingCompareItems, resultToRemove.BookingFixingCompareItems, existingResult.BookingFixingCompareItems),
                BookingBasketWeightCompareItems = GetBookingCompareItemsToSave(resultToMerge.BookingBasketWeightCompareItems, resultToRemove.BookingBasketWeightCompareItems, existingResult.BookingBasketWeightCompareItems),
                BookingPrismCompositionCompareItems = GetBookingCompareItemsToSave(resultToMerge.BookingPrismCompositionCompareItems, resultToRemove.BookingPrismCompositionCompareItems, existingResult.BookingPrismCompositionCompareItems),
            };

            SaveResult(mergedResult, existingResult.SepcificFolder);
        }

        private T[] GetBookingCompareItemsToSave<T>(T[] resultToMerge, T[] resultToRemove, T[] existingResult)
            where T : IBookingCompareItem
        {
            return Expect(Expect(existingResult, resultToMerge).Union(resultToMerge), resultToRemove);
        }

        public T[] Expect<T>(IEnumerable<T> items, IEnumerable<T> excludedItems)
            where T : IBookingCompareItem
        {
            return items.Where(e => !excludedItems.Any(
                n => n.Date == e.Date && n.Sicovam == e.Sicovam &&
                     n.IndexBloombergTicker == e.IndexBloombergTicker)).ToArray();
        }

        private BookingFixingCompareItem[] GetBookingCompareItemsToSave(BookingFixingCompareItem[] resultToMerge, BookingFixingCompareItem[] resultToRemove, BookingFixingCompareItem[] existingResult)
        {
            return Expect(Expect(existingResult, resultToMerge).Union(resultToMerge), resultToRemove);
        }

        public BookingFixingCompareItem[] Expect(IEnumerable<BookingFixingCompareItem> items, IEnumerable<BookingFixingCompareItem> excludedItems)
        {
            return items.Where(e => !excludedItems.Any(
                n => n.Date == e.Date && n.Sicovam == e.Sicovam && n.UnderlyingSicovam == e.UnderlyingSicovam &&
                     n.IndexBloombergTicker == e.IndexBloombergTicker)).ToArray();
        }
    }
}