﻿using CaesarApplication.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Prism;
using System.Xml;
using GlobalDerivativesApplications.Prism.Polling;
using CaesarCommon.Configuration;
using System.IO;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;

namespace CaesarApplication
{
    /// <summary>
    /// Transcoder for Prism
    /// </summary>
    [Serializable]
    public class PrismTranscoder : InstrumentCodeTranscoder
    {
        private readonly bool _priceMode;
        private static ILookup<string, string> marketPlacesMapping;

        /// <summary>
        /// Constructor - initialize list of market place mnemonics to transcode
        /// </summary>
        public PrismTranscoder(bool priceMode = true)
        {
            _priceMode = priceMode;
            marketPlacesMapping = new List<KeyValuePair<string, string>>
            {
                new KeyValuePair<string, string>("SQ", "SM"),
                new KeyValuePair<string, string>("UQ", "UW"),
                new KeyValuePair<string, string>("US", "UW"),
                new KeyValuePair<string, string>("US", "UN"),
                new KeyValuePair<string, string>("CN", "CT"),
                new KeyValuePair<string, string>("KS", "KP"),
                new KeyValuePair<string, string>("SW", "SE"),
            }.ToLookup(o => o.Key, o => o.Value);
        }

        /// <summary>
        /// Transcode instrument codes from current provider to next provider
        /// </summary>
        /// <param name="internalCode"></param>
        /// <returns></returns>
        public override string TranscodeInternalToExternal(string internalCode, ILoadingContext context)
        {
            return internalCode;
        }

        /// <summary>
        /// Transcode instrument codes from previous provider to current provider
        /// </summary>
        /// <param name="externalCode"></param>
        /// <returns></returns>
        public override string TranscodeExternalToInternal(string externalCode, ILoadingContext context)
        {
            string[] externalCodeSplitted = externalCode.Split(' ');

            if (externalCodeSplitted.Count() == 2 && marketPlacesMapping.Contains(externalCodeSplitted[1]))
            {
                if (marketPlacesMapping[externalCodeSplitted[1]].Count() > 1)
                {
                    foreach (string marketPlacePrism in marketPlacesMapping[externalCodeSplitted[1]])
                    {
                        var externalCodePrism = externalCodeSplitted[0] + " " + marketPlacePrism;

                        if (PrismHelper.ReferenceExists(externalCodePrism))
                        {
                            return externalCodePrism;
                        }
                    }
                }
                else
                {
                    externalCode = externalCodeSplitted[0] + " " + marketPlacesMapping[externalCodeSplitted[1]].First();
                }
            }

            if (!_priceMode && externalCode.Trim().EndsWith("Corp") && externalCode.Contains("@"))
            {
                var parts = externalCode.Split(" ".AsArray(), StringSplitOptions.None);
                return string.Join(" ", parts[0].AsArray().Union(parts.Skip(2)));
            }

            return externalCode;
        }


        /// <summary>
        /// optional switch, let to null for production directory
        /// </summary>
        public string PrismIOPollingDirectory { get; set; }


        public string GetRequest(string[] tickers)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = DataProvider.Prism.PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = DataProvider.Prism.PrismConstants.TICKER,
                Service = DataProvider.Prism.PrismConstants.ServiceMarketListing,
                Product = DataProvider.Prism.PrismConstants.ProductEquity,
                RequestTime = DateTime.Today,
                Codes = tickers
            };

            return prismRequest.ToSerializedString();
        }

        /// <summary>
        /// 
        /// </summary>
        public class PrismTickerMatch
        {
            /// <summary>
            /// 
            /// </summary>
            public string Root { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string BbgCode { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string ISINCode { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string MicCode { get; set; }

            /// <summary>
            /// 
            /// </summary>
            public string cusipCode { get; set; }
        }


        public enum NotFoundBehaviour
        {
            Throw = 0,
            Exclude = 1,
            IncludeAsIs = 2,
        }

        public IDictionary<string, string> GetValidPrismTickers(IList<string> tickers, NotFoundBehaviour errorBehaviour = NotFoundBehaviour.Throw)
        {
            if(!tickers.Any())
            {
                return new Dictionary<string, string>();
            }

            var id = Guid.NewGuid();

            string requestName = string.Format("{0}{1:yyyyMMdd}{2}", id, DateTime.Today,
                "GETLISTING");

            var settingsManager = new CaesarSettingsManager();


            var prism_valid = new[] { new PrismTickerMatch { Root = "", BbgCode = "", ISINCode = "", MicCode = "", cusipCode = "" } }.ToList();

            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing: true, pollingDirectory: PrismIOPollingDirectory))
            {
                var tickersAsArray = tickers as string[] ?? tickers.ToArray();

                var request = prismPollingManager.SendRequestSync(requestName,
                    GetRequest(tickersAsArray),
                    (int)TimeSpan.FromSeconds(120).TotalMilliseconds);

                string currentroot = string.Empty;

                using (XmlReader xmlreader = XmlReader.Create(new StringReader(request.ResultContent)))
                {
                    while (xmlreader.Read())
                    {
                        if (xmlreader.Name.IsNeitherNullNorEmpty())
                        {
                            if (xmlreader.Name == "product")
                            {
                                currentroot = xmlreader.GetAttribute("ticker");
                            }
                            if (xmlreader.Name == "listing")
                            {
                                string bbgCode = xmlreader.GetAttribute("bbgCode");
                                string isinCode = xmlreader.GetAttribute("isinCode");
                                string micCode = xmlreader.GetAttribute("micCode");
                                string cusipCode = xmlreader.GetAttribute("cusipCode");
                                prism_valid.Add(new PrismTickerMatch { Root = currentroot, BbgCode = bbgCode, ISINCode = isinCode, MicCode = micCode, cusipCode = cusipCode });
                            }
                        }
                    }
                }
            }



            var index_by_bbg = prism_valid.Aggregate(new Dictionary<string, PrismTickerMatch>(), (dico, elt) =>
            {
                dico[elt.BbgCode] = elt;
                return dico;
            });
            //var index_by_root = prism_valid.Aggregate(new Dictionary<string, PrismTickerMatch>(), (dico, elt) =>
            //{
            //    dico[elt.Root] = elt;
            //    return dico;
            //});

            Dictionary<string, string> equivalences = new Dictionary<string, string>();

            ILookup<string, CaesarCommon.Configuration.CompositeMarket> markets =
                settingsManager.GetCompositeMarketDefinitions().ToLookup(cm => cm.Composite);

            IDictionary<string, CaesarCommon.Configuration.CompositeMarket> markets_to_composite =
                settingsManager.GetCompositeMarketDefinitions().ToDictionary(cm => cm.Element);

            foreach (var ticker in tickers)
            {
                //// found a market
                if (index_by_bbg.ContainsKey(ticker))
                {
                    equivalences[ticker] = ticker;
                    continue;
                }

                var tokens = ticker.Split(' ');
                if (tokens.Length > 1)
                {
                    var potential_market = tokens.Last();
                    var potential_root = string.Join(" ", tokens.Take(tokens.Length - 1).ToArray());


                    /// input SE when prism is up to date with ticker relising as VX
                    if (markets_to_composite.ContainsKey(potential_market))
                    {
                        ////overwite SE by SW, the next stop will convert it to VX if the new ticker is found there
                        potential_market = markets_to_composite[potential_market].Composite;
                    }
                    ///input a composite market
                    if (markets.Contains(potential_market))
                    {
                        var othermarkets = markets[potential_market];
                        var match = othermarkets.FirstOrDefault(m => index_by_bbg.ContainsKey(potential_root + " " + m.Element));
                        if (match.Element.IsNeitherNullNorEmpty())
                        {
                            equivalences[ticker] = potential_root + " " + match.Element;
                            continue;
                        }
                    }
                    if (errorBehaviour == NotFoundBehaviour.IncludeAsIs)
                    {
                        equivalences[ticker] = ticker;
                    }
                }
            }
            if (errorBehaviour == NotFoundBehaviour.Throw)
            {
                var notfound = tickers.Except(equivalences.Keys).ToArray();
                if (notfound.Length > 0)
                {
                    throw new InvalidOperationException(string.Format("Could not find tickers in prism {0}", string.Join(";", notfound)));
                }
            }
            return equivalences;
        }


    }
}
