﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.DataProvider
{
    public class AuditDataHandler : IDataHandler
    {
        private readonly BasketIndex[] auditBasketsIndex;

        private readonly IDataHandler originalDataHandler;

        public AuditDataHandler(BasketIndex[] auditBasketsIndex, IDataHandler originalDataHandler)
        {
            this.auditBasketsIndex = auditBasketsIndex;
            this.originalDataHandler = originalDataHandler;
        }

        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate,
            bool removeEmptySeries = false)
        {
            return Load(tickers, fields, startDate, endDate, null, removeEmptySeries);
        }

        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate,
            ILoadingContext loadingContext, bool removeEmptySeries = false)
        {
           return fields
                .SelectMany(f =>
                {
                    return tickers.Select(t =>
                    {
                        return auditBasketsIndex.Select(auditBasketIndex => {
                            if (auditBasketIndex.Data.ContainsKey(f.ToString()))
                            {
                                return auditBasketIndex.Data[f.ToString()].FirstOrDefault(x => x.Instrument == t);
                            }

                            Console.WriteLine("WARN Market data coming from outside the basket [{0}/{1}]", t, f);
                            return
                                originalDataHandler.Load(t.AsArray(), f.AsArray(), startDate, endDate, loadingContext)
                                    .FirstOrDefault();
                        }).FirstOrDefault(x => x != null);
                    });

                }).Where(x => x != null).ToArray();
        }

        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, IList<DateTime> schedule)
        {
            throw new NotImplementedException();
        }

        public void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
        }

        public void SetSuccessor(IDataHandler handler)
        {
            
        }

        public IDataHandler NextHandler { get; private set; }
        public IEnumerable<DataFieldsEnum> ManagedFields { get; private set; }
        public IEnumerable<DataFieldsEnum> ManagedFieldsWithSuccessors { get; private set; }
        public string Name { get; private set; }
        public bool ShouldLoadPredicate(ILoadingContext context)
        {
            return true;
        }
    }
}
