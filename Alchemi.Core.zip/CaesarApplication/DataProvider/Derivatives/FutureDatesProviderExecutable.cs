﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using CaesarCommon.Configuration;
using CaesarCommon.Utils;
using System.IO;
using GlobalDerivativesApplications.Data.MarketData;
using System.Linq;
using System.Globalization;
using MarketData;
using CaesarApplication.Utilities;

namespace CaesarApplication.DataProvider.Derivatives
{
    public class FutureDatesProviderExecutable : ProviderExecutable
    {
        private ICalendar goldCalendar;
        protected string directoryPath;

        private string[] supportedUnderlyings = new string[]
        {
            "GC"
        };

        public FutureDatesProviderExecutable(string directory = null, string calendarDirectory = null)
        {
            directoryPath = directory ?? new CaesarSettingsManager().ComexDataFilesDirectoryPath;
            goldCalendar = new GlobalDerivativesApplications.Data.MarketData.Calendar(new List<DateTime>(), IOTools.ReadLockFree(Path.Combine(calendarDirectory ?? directoryPath, "GCOptionCalendar.csv")).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries)
                .Select(x => DateTime.ParseExact(x, "dd/MM/yyyy", CultureInfo.InvariantCulture)).ToList());
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = default(DateTime?), DateTime? endDate = default(DateTime?), ILoadingContext loadingContext = null)
        {
            var udlsToTreat = tickers.Where(t => supportedUnderlyings.Contains(FutureConventions.GetUnderlyingFromTicker(t))).ToArray();

            return tickers.Select(x => supportedUnderlyings.Contains(FutureConventions.GetUnderlyingFromTicker(x))
            ?
            new TimeSerieDB(DateTime.MinValue, new MarketDataString(FutureConventions.GetGoldFutureFirstDeliveryDate(goldCalendar, FutureConventions.GetYearFromTicker(x), FutureConventions.GetMonthFromTicker(x)).ToString("O")), x, DataFieldsEnum.FirstFutureDeliveryDate)
            :
            new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], x, DataFieldsEnum.FirstFutureDeliveryDate)).ToArray();
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return DataFieldsEnum.FirstFutureDeliveryDate.AsArray();
            }
        }
    }
}
