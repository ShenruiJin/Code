﻿using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    public interface ITickerHandler
    {
        string[] GetTickersToRequest(string ticker);

        TimeSerieDB[] Calculate(string ticker, DataFieldsEnum field, Dictionary<string, TimeSerieDB[]> calculationMembers);

        string TickerRegex { get; }

        Dictionary<DataFieldsEnum, DataFieldsEnum[]> CalculationFields { get; }

        DataFieldsEnum[] ImpactedFields { get; }
    }
}