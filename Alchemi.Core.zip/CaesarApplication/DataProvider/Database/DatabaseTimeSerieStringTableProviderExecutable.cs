using System;
using System.Collections.Generic;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseTimeSerieStringTableProviderExecutable : DatabaseTimeSerieStringProviderExecutableBase
    {
        public DatabaseTimeSerieStringTableProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieStringDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory, timeSerieDtoConverter)
        {
        }

        public DatabaseTimeSerieStringTableProviderExecutable()
        {
        }


        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.CashflowDescription
                };
            }
        }
    }
}