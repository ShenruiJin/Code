namespace CaesarApplication.DataProvider.Database
{
    public interface IDatabaseTimeSerieProviderBaseExecutable
    {
        string[] SourcePriority { set; }

        bool SaveAsDefault { set; }

        bool HasSourceOverrided { set; }
    }
}