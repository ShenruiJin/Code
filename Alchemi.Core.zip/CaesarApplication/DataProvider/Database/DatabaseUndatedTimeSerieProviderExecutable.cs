﻿using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseUndatedTimeSerieProviderExecutable : DatabaseTimeSerieProviderBaseExecutable<TimeSerieDTO>
    {
        public DatabaseUndatedTimeSerieProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory)
        {

            TimeSerieConverter = timeSerieDtoConverter ?? new TimeSerieDtoConverter();
        }

        public DatabaseUndatedTimeSerieProviderExecutable()
            : this(new IndexDBProviderFactory())
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var tickersAsArray = tickers.ToArray();
            var series = IndexProvider.LoadTimeSeries(tickersAsArray, (int)field, GetSourceToRequest(loadingContext), null, null, GetVersionDate(loadingContext), UserService.CaesarSession);

            return TimeSerieConverter.ConvertFromDTO(series, loadingContext != null ? loadingContext.RequestedType : null, field == DataFieldsEnum.IndexPricingInstruction, loadingContext).ToList();
        }


        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            var series = timeSeries.Where(x => x.X.Any()).AsParallel().SelectMany(ts => TimeSerieConverter.ConvertToDTO(ts)).Group(100).ToArray();
            int nbTreatedItems = 0;

            foreach (var grp in series)
            {
                if (loadingContext != null)
                {
                    loadingContext.CancellationToken.ThrowIfCancellationRequested();
                }

                grp.ForEach(x => x.values = x.values = x.values.Select(v => new TimeSerieValueDTO { date_creation = v.date_version == DateTime.MinValue ? DateTime.Now : v.date_version, date_version = DateTime.MinValue, serie_id = v.serie_id, value = v.value }).ToArray());


                if (loadingContext != null && loadingContext.SessionId.HasValue)
                {
                    IndexProvider.SaveTimeSeriesTransac(loadingContext.SessionId.GetValueOrDefault(), grp, UserService.CaesarSession);
                }
                else
                {
                    IndexProvider.SaveTimeSeries(grp, UserService.CaesarSession);
                }

                nbTreatedItems += grp.Length;

                if (loadingContext != null)
                {
                    loadingContext.RaiseOnProgessChanged(this, new TimeSeriesProviderProgressEventArgs("Save Time Series (double)\r\n", "timeserie", timeSeries.Count, nbTreatedItems));
                }
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.QuoteFactor,
                    DataFieldsEnum.FUT_INIT_SPEC_ML
                };
            }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}
