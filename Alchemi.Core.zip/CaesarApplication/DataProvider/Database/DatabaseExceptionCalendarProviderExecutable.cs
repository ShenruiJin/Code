﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseExceptionCalendarProviderExecutable : DatabaseProviderExecutableBase
    {
        private readonly IExceptionCalendarConverter exceptionCalendarConverter;

        public DatabaseExceptionCalendarProviderExecutable()
            : base(new IndexDBProviderFactory())
        {
            this.exceptionCalendarConverter = new ExceptionCalendarConverter();
        }

        public DatabaseExceptionCalendarProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, IExceptionCalendarConverter exceptionCalendarConverter)
            : base(indexDBProviderFactory)
        {
            this.exceptionCalendarConverter = exceptionCalendarConverter;
        }


        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            return tickers.Select(t =>
            {
                var calendar = exceptionCalendarConverter.ConvertFromDto(startDate, endDate,IndexProvider.LoadCalendarException(t, startDate, endDate, GetVersionDate(loadingContext), UserService.CaesarSession));

                return new TimeSerieDB(new[]
                {
                    new KeyValuePair<DateTime, IMarketData>(DateTime.Now, calendar)
                }, t, DataFieldsEnum.ExceptionCalendar);
            }).ToArray();
        }

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            foreach (var serie in timeSeries)
            {
                if (serie.X.Any())
                {
                    var calendar = (ExceptionCalendar) serie.ElementAt(0).Value;

                    IndexProvider.SaveCalendarException(serie.Instrument, calendar.StartDate, calendar.EndDate,
                        exceptionCalendarConverter.ConvertToDto(calendar),
                        UserService.CaesarSession);
                }
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new []
            {
                DataFieldsEnum.ExceptionCalendar
            }; }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}
