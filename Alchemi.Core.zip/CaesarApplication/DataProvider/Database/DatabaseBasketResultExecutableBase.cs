using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Diagnostics;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public abstract class DatabaseBasketResultExecutableBase<T, TConverter> : DatabaseProviderExecutableBase
        where T : BasketResultBaseDTO
        where TConverter : IBasketResultDTOConverter<T>, new()
    {
        private IBasketResultDTOConverter<T> basketResultDTOConverter = new TConverter();

        public DatabaseBasketResultExecutableBase(IIndexDBProviderFactory indexDBProviderFactory,
            IBasketResultDTOConverter<T> basketResultDTOConverter)
            : base(indexDBProviderFactory)
        {
            this.basketResultDTOConverter = basketResultDTOConverter;
        }

        public DatabaseBasketResultExecutableBase()
            : base(new IndexDBProviderFactory())
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var output =
                tickers.SelectMany(
                    t =>
                        basketResultDTOConverter.ConvertFromDTO(
                            LoadBasketResults(startDate, endDate, t, loadingContext))).ToList();

            if (output.IsEmpty())
                return tickers.Select(ticker => new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(), ticker, field, isConsederedAsComplete: true) { StartDate = startDate, EndDate = endDate }).ToList();

            output.ForEach(ts =>
            {
                ts.Field = field;
                ts.IsConsideredAsComplete = true;
                ts.StartDate = startDate;
                ts.EndDate = endDate;
            });
            return output;
        }

        protected abstract IEnumerable<T> LoadBasketResults(DateTime? startDate, DateTime? endDate, string ticker, ILoadingContext context);

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            int treatedItemsCount = 0;
            int totalItemCount = timeSeries.SelectMany(x => x.Y).Count();

            foreach (var serie in timeSeries)
            {
                if (serie.X.Any())
                {
                    using (new TimeLaps(string.Format("Save Baskets {0} items", serie.X.Count())))
                    {
                        var dates = serie.X.ToList();
                        var dataToSendQueue = new ConcurrentQueue<SourceAndResult>();
                        var orderedDataToSendQueue = new ConcurrentQueue<SourceAndResult[]>();

                        var dataToSerialize = new ConcurrentQueue<SourceAndToSave>(serie.GetElements().Select(x => new SourceAndToSave(x.Key, (BasketIndexList)x.Value, GetBasketListToSave((BasketIndexList)x.Value))));

                        var onSerialFinished = new ManualResetEvent(false);
                        var onSortingFinished = new ManualResetEvent(false);

                        var serializerWorkers = Enumerable.Range(0, 4).Select(i =>
                        {
                            return new Thread(() =>
                            {
                                SourceAndToSave itemToTreat;

                                while (dataToSerialize.TryDequeue(out itemToTreat) && IsNotCanceled(context))
                                {
                                    var it = basketResultDTOConverter.ConvertToDTO(
                                        new TimeSerieDB(itemToTreat.Date, itemToTreat.ToSave, serie.Instrument, serie.Field).AsArray())
                                        .First();

                                    dataToSendQueue.Enqueue(new SourceAndResult(itemToTreat.Source, it));
                                }
                            });
                        }).ToArray();

                        var sortThread = new Thread(() =>
                        {
                            var block = new List<SourceAndResult>();
                            var bufferItems = new List<SourceAndResult>();
                            SourceAndResult itemToTreat;

                            while ((dataToSendQueue.TryDequeue(out itemToTreat) ||
                                 !onSerialFinished.WaitOne(TimeSpan.Zero) ||
                                 (onSerialFinished.WaitOne(TimeSpan.Zero) && bufferItems.Any()))
                                 &&
                                 IsNotCanceled(context))
                            {
                                if (itemToTreat != null || onSerialFinished.WaitOne(TimeSpan.Zero))
                                {
                                    if (itemToTreat != null)
                                    {
                                        bufferItems.Add(itemToTreat);
                                    }

                                    var blocks = GetContinuousBlock(bufferItems.ToArray(), dates);

                                    if (blocks.Any())
                                    {
                                        blocks.ForEach(b =>
                                        {
                                            orderedDataToSendQueue.Enqueue(b);
                                            b.ForEach(i => bufferItems.Remove(i));
                                        });
                                    }
                                    else if (onSerialFinished.WaitOne(TimeSpan.Zero))
                                    {
                                        bufferItems.ToArray().ForEach(i =>
                                        {
                                            orderedDataToSendQueue.Enqueue(i.AsArray());
                                            bufferItems.Remove(i);
                                        });
                                    }
                                }
                            }
                        });



                        var dbWorkers = Enumerable.Range(0, 4).Select(i =>
                        {
                            return new Thread(() =>
                            {
                                var block = new List<SourceAndResult>();

                                SourceAndResult[] itemToTreat;

                                while ((orderedDataToSendQueue.TryDequeue(out itemToTreat) ||
                                       !onSortingFinished.WaitOne(TimeSpan.Zero) ||
                                       (onSortingFinished.WaitOne(TimeSpan.Zero) && block.Any()))
                                       &&
                                       IsNotCanceled(context))
                                {
                                    if (itemToTreat != null)
                                    {
                                        block = itemToTreat.ToList();
                                    }

                                    if ((orderedDataToSendQueue.Count != 0 || onSortingFinished.WaitOne(TimeSpan.Zero)))
                                    {
                                        if (block.Count != 0)
                                        {
                                            var blockToSend = block.Select(x => x.Result).ToArray();

                                            var savedDtos = Save(blockToSend, dates.FirstOrDefault(x => x > blockToSend.Max(it => it.date_version)), context);

                                            block.ForEach((b, idx) =>
                                            {
                                                b.Source.Id = savedDtos.Length != 0  && savedDtos.Count() > idx ? savedDtos[idx].id : -1;
                                            });

                                            treatedItemsCount += block.Count;

                                            RaiseProgressChanged(context, treatedItemsCount, totalItemCount,
                                                "Saving " + serie.FieldName, "basket");

                                            block.Clear();
                                        }
                                    }
                                }
                            });
                        }).ToArray();

                        sortThread.Start();
                        serializerWorkers.ForEach(w => w.Start());
                        dbWorkers.ForEach(w => w.Start());

                        serializerWorkers.ForEach(t => t.Join());
                        onSerialFinished.Set();

                        sortThread.Join();
                        onSortingFinished.Set();

                        dbWorkers.ForEach(t => t.Join());
                    }
                }
            }
        }

        private SourceAndResult[][] GetContinuousBlock(SourceAndResult[] items, List<DateTime> order)
        {
            var orderedItems = items.ToDictionary(x => x, x => order.IndexOf(x.Result.date_version)).OrderBy(x => x.Value).ToDictionary(x => x.Key, x => x.Value);

            var sourceAndResultsWithSpread = new Dictionary<SourceAndResult, int>();
            int? lastIndex = null;

            for (int i = 0; i < orderedItems.Count; i++)
            {
                var currentItem = orderedItems.ElementAt(i);
                sourceAndResultsWithSpread.Add(currentItem.Key, currentItem.Value - lastIndex.GetValueOrDefault());
                lastIndex = currentItem.Value;
            }

            var blocks = new List<SourceAndResult[]>();

            var currentBlock = new List<SourceAndResult>();
            var lastItem = sourceAndResultsWithSpread.Select(x => x.Key).FirstOrDefault();

            for (int i = 0; i < sourceAndResultsWithSpread.Count; i++)
            {
                var currentItem = sourceAndResultsWithSpread.ElementAt(i);

                if (currentItem.Value <= 1)
                {
                    if (!currentBlock.Contains(lastItem))
                    {
                        currentBlock.Add(lastItem);
                    }

                    currentBlock.Add(currentItem.Key);

                    if (IsCompleteBlock(currentBlock))
                    {
                        currentBlock = CreateBlock(blocks, currentBlock);
                    }
                }
                else if (currentBlock.Any())
                {
                    currentBlock = CreateBlock(blocks, currentBlock);
                }

                lastItem = currentItem.Key;
            }

            return blocks.ToArray();
        }

        private List<SourceAndResult> CreateBlock(List<SourceAndResult[]> blocks, List<SourceAndResult> currentBlock)
        {
            if (IsCompleteBlock(currentBlock))
            {
                blocks.Add(currentBlock.ToArray());
            }

            currentBlock = new List<SourceAndResult>();
            return currentBlock;
        }

        private int blockSize = 1024 * 1024 * sizeof(byte);

        private bool IsCompleteBlock(List<SourceAndResult> currentBlock)
        {
            return currentBlock.Sum(x => x.Result.binarydata.LongLength) >= blockSize;
        }

        public virtual BasketIndexList GetBasketListToSave(BasketIndexList basketList)
        {
            return basketList;
        }

        public class SourceAndResult
        {
            public SourceAndResult(BasketIndexList source, T result)
            {
                Source = source;
                Result = result;
            }

            public BasketIndexList Source { get; private set; }

            public T Result { get; private set; }

        }

        public class SourceAndToSave
        {
            public SourceAndToSave(DateTime date, BasketIndexList source, BasketIndexList toSave)
            {
                Source = source;
                ToSave = toSave;
                Date = date;
            }

            public BasketIndexList Source { get; private set; }

            public BasketIndexList ToSave { get; private set; }

            public DateTime Date { get; private set; }

        }

        private static bool IsNotCanceled(ILoadingContext context)
        {
            return (context == null || !context.CancellationToken.IsCancellationRequested);
        }

        protected virtual int GroupSize
        {
            get { return 15; }
        }

        protected abstract BasketResultBaseDTO[] Save(T[] dataToSave, DateTime? nextDate, ILoadingContext context);


        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}