using System;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public abstract class DatabaseTimeSerieProviderBaseExecutable<TSerie> : DatabaseProviderExecutableBase, IDatabaseTimeSerieProviderBaseExecutable
    {
        public string[] SourcePriority
        {
            set { TimeSerieConverter.SourcePriority = value; }
        }

        public bool SaveAsDefault
        {
            set { TimeSerieConverter.SaveAsDefault = value; }
        }
         
        public bool HasSourceOverrided
        {
            set { TimeSerieConverter.HasSourceOverrided = value; }
        }

        protected ITimeSerieDtoConverter<TSerie> TimeSerieConverter { get; set; }

        public DatabaseTimeSerieProviderBaseExecutable(IIndexDBProviderFactory indexDBProviderFactory) : base(indexDBProviderFactory)
        {
        }

        protected static string GetSourceToRequest(ILoadingContext loadingContext)
        {
            return loadingContext != null && loadingContext.DBSource != null ? loadingContext.DBSource : null;
        }
    }
}