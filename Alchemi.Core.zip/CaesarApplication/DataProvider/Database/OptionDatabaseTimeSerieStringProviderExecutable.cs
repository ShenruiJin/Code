using System;
using System.Collections.Generic;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class OptionDatabaseDatabaseTimeSerieStringProviderExecutable : DatabaseTimeSerieStringProviderExecutable
    {
        public OptionDatabaseDatabaseTimeSerieStringProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory,
            ITimeSerieStringDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory ?? new IndexDBProviderFactory(), timeSerieDtoConverter ?? new ProtoTimeSerieStringDtoConverter())
        {
            
        }

        protected override Dictionary<DataFieldsEnum, Type> DataTypeByFieldName
        {
            get
            {
                return new Dictionary<DataFieldsEnum, Type>
                {
                    {DataFieldsEnum.OptionDescAndPrices, typeof (OptionDescAndPricesList)}
                };
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new DataFieldsEnum[0];
                //{
                //    DataFieldsEnum.OptionDescAndPrices
                //};
            }
        }
    }
}