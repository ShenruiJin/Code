﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using Caesar.Pricing.Engine.Indices;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using Pricing.Engine.Indices;
using PricingBase.DataProvider;
using DealIndexDataTransferObject.Helper;
using Microsoft.Exchange.WebServices.Data;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.Database.Converters
{
    [Serializable]
    public class IndexQuoteDtoConverter : IIndexQuoteDtoConverter
    {
        private static string applicationVersion;
        private static string machineName;
        private static string userName;

        public TimeSerieDB ConvertFromDTO(IEnumerable<IndexQuoteDTO> dataToConvert, string ticker)
        {
            return new TimeSerieDB(dataToConvert.Select(ConvertFromDTO).ToList(), ticker, DataFieldsEnum.IndexQuote);
        }

        public KeyValuePair<DateTime, IMarketData> ConvertFromDTO(IndexQuoteDTO dataToConvert)
        {
            return new KeyValuePair<DateTime, IMarketData>(dataToConvert.date_version, 
                new IndexQuote(dataToConvert.date_version, dataToConvert.value.GetValueOrDefault(double.NaN)) { Id = dataToConvert.id, Comment = dataToConvert.comment, Status = dataToConvert.status != null ? (QuoteStatus)Enum.Parse(typeof(QuoteStatus), dataToConvert.status) : QuoteStatus.Calculated, ComputationDate = dataToConvert.date_computation, IsHoliday = (dataToConvert.status != null && dataToConvert.status != QuoteStatus.Calculated.ToString())});
        }

        public IEnumerable<IndexQuoteDTO> ConvertToDTO(TimeSerieDB dataToConvert, Predicate<IIndexQuote> shouldConvert = null)
        {
            var dateCreation = DateTime.Now;

            return dataToConvert.Where(i => shouldConvert == null || shouldConvert((IIndexQuote)i.Value))
                .Select(x => ConvertToDTO(dateCreation, x, dataToConvert.Instrument)).ToArray();
        }

        private IndexQuoteDTO ConvertToDTO(DateTime dateCreation, KeyValuePair<DateTime, IMarketData> dataToConvert, string instrument)
        {
            var quote = (IndexQuote)dataToConvert.Value;
            return new IndexQuoteDTO
            {
                date_version = dataToConvert.Key,
                date_computation = quote.ComputationDate.GetValueOrDefault(dateCreation),
                date_creation = dateCreation,
                value = double.IsNaN(((PricingBase.Index.IIndexQuoteTechnical)quote).ValueWithoutTest) ? (double?)null : quote.Value,
                computation_index_ticker = instrument,
                version = applicationVersion = applicationVersion ?? FileVersionHelper.GetApplicationVersion(),
                login = userName  = userName ?? Environment.UserName,
                computer = machineName = machineName ?? Environment.MachineName,
                comment = quote.Comment,
                status = quote.Status.ToString()
            };
        }
    }

    public interface IIndexQuoteDtoConverter
    {
        TimeSerieDB ConvertFromDTO(IEnumerable<IndexQuoteDTO> dataToConvert, string ticker);
        IEnumerable<IndexQuoteDTO> ConvertToDTO(TimeSerieDB dataToConvert, Predicate<IIndexQuote> shouldConvert = null);
    }
}
