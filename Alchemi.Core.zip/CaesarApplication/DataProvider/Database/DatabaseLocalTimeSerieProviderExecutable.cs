﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseLocalTimeSerieProviderExecutable : DatabaseTimeSerieProviderBaseExecutable<TimeSerieDTO>
    {

        public DatabaseLocalTimeSerieProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory)
        {
            if (timeSerieDtoConverter != null)
            {
                TimeSerieConverter = timeSerieDtoConverter;
            }
        }

        public DatabaseLocalTimeSerieProviderExecutable()
            : base(new IndexDBProviderFactory())
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            return tickers.SelectMany(instr => TimeSerieConverter.ConvertFromDTO(IndexProvider.LoadTimeSerieOverride(loadingContext.IndexId, instr, (int)field, GetSourceToRequest(loadingContext), startDate, endDate, GetVersionDate(loadingContext), UserService.CaesarSession).AsArray(), context: loadingContext)).ToList();
        }

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            timeSeries.ForEach(ts => IndexProvider.SaveTimeSerieOverride(new TimeSerieOverrideDTO(TimeSerieConverter.ConvertToDTO(ts)[0], loadingContext.IndexId), UserService.CaesarSession));
        }

        public override IList<DataFieldsEnum> SupportedFields {
            get
            {
                return new []
                {
                    DataFieldsEnum.Ask,
                    DataFieldsEnum.Bid,
                    DataFieldsEnum.Close,
                    DataFieldsEnum.Last
                };
            }}

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Local; }
        }
    }
}
