﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Caesar.Pricing.Engine.Indices;
using CaesarApplication.DataProvider.Database.Converters;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.Data.MarketData;
using Pricing.Engine.Indices;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseIndexQuoteProviderExecutable : DatabaseProviderExecutableBase
    {
        private readonly IIndexQuoteDtoConverter indexQuoteDtoConverter;

        public DatabaseIndexQuoteProviderExecutable()
            : base(new IndexDBProviderFactory())
        {
            this.indexQuoteDtoConverter = new IndexQuoteDtoConverter();
        }

        public DatabaseIndexQuoteProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, IIndexQuoteDtoConverter indexQuoteDtoConverter)
            : base(indexDBProviderFactory)
        {
            this.indexQuoteDtoConverter = indexQuoteDtoConverter;
        }


        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {

            return tickers.Select(t =>
            {
                var indexQuotes = IndexProvider.LoadIndexHistoryQuotesByPath(UserService.CaesarSession, t,
                    startDate.GetValueOrDefault(DateTime.MinValue), endDate.GetValueOrDefault(DateTime.MaxValue),
                    GetVersionDate(loadingContext));
                var ts = indexQuoteDtoConverter.ConvertFromDTO(indexQuotes.OrderBy(x => x.date_version), t);

                return ts;
            }).ToList();
        }

        /// <summary>
        /// Save
        /// </summary>
        /// <param name="timeSeries"></param>
        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            foreach (var timeSerie in timeSeries)
            {
                int nbTreatedItems = 0;

                timeSerie.GetElements().Group(512)
                    .AsParallel()
                    .ForEach(grp =>
                    {
                        var indexQuoteDtos = indexQuoteDtoConverter.ConvertToDTO(new TimeSerieDB(grp, timeSerie.Instrument, timeSerie.Field), x => x.Id == 0).ToArray();

                        if (loadingContext != null)
                        {
                            loadingContext.CancellationToken.ThrowIfCancellationRequested();
                        }

                        var dbQuotes = SaveIndexQuotes(indexQuoteDtos, loadingContext);

                        foreach (var dbQuote in dbQuotes)
                        {
                            var ts = timeSeries.First(x => x.Instrument == dbQuote.computation_index_ticker);

                            var quote = ts.Y.Cast<IndexQuote>().FirstOrDefault(x => x.Date == dbQuote.date_version);

                            if (quote != null)
                            {
                                quote.Id = dbQuote.id;
                            }
                        }

                        nbTreatedItems += grp.Length;

                        RaiseProgressChanged(loadingContext, nbTreatedItems, timeSerie.Count, "Save Quotes\r\n", "quote");
                    });
            }
        }

        private IEnumerable<IndexQuoteDTO> SaveIndexQuotes(IndexQuoteDTO[] grp, ILoadingContext loadingContext)
        {
            if (loadingContext != null && loadingContext.SessionId.HasValue)
            {
                return IndexProvider.SaveIndexQuotesTransac(loadingContext.SessionId.Value, grp, UserService.CaesarSession);
            }
            else
            {
                return IndexProvider.SaveIndexQuotes(grp, UserService.CaesarSession);
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.IndexQuote
                };
            }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}
