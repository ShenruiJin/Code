using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseTimeSerieBinaryProviderExecutable : DatabaseTimeSerieProviderBaseExecutable<TimeSerieBinaryDTO>
    {
        public DatabaseTimeSerieBinaryProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory = null, ITimeSerieBinaryDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory ?? new IndexDBProviderFactory())
        {
            TimeSerieConverter = timeSerieDtoConverter ?? new ProtoTimeSerieBinaryDtoConverter();
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var dtos = IndexProvider.LoadTimeSeriesBinary(tickers.ToArray(), (int) field, GetSourceToRequest(loadingContext), startDate, endDate, GetVersionDate(loadingContext), UserService.CaesarSession);
            
           return TimeSerieConverter.ConvertFromDTO(dtos, DataTypeByFieldName.ContainsKey(field) ? DataTypeByFieldName[field] : null, context: loadingContext);
        }

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            var timeSerieBinaryDtos = timeSeries.SelectMany(ts => TimeSerieConverter.ConvertToDTO(ts)).ToArray();
            IndexProvider.SaveTimeSeriesBinary(timeSerieBinaryDtos, UserService.CaesarSession);
        }

        private Dictionary<DataFieldsEnum, Type> DataTypeByFieldName
        {
            get
            {
                return new Dictionary<DataFieldsEnum, Type>()
                {
                    {DataFieldsEnum.OptionDescAndPrices, typeof (OptionDescAndPricesList)}
                };
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return DataTypeByFieldName.Keys.ToArray(); }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}