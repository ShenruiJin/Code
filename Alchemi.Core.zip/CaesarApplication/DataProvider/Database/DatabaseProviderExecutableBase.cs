using System;
using System.Collections.Generic;
using System.Linq;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public abstract class DatabaseProviderExecutableBase : IProviderExecutable
    {
        private readonly IIndexDBProviderFactory indexDBProviderFactory;

        protected DatabaseProviderExecutableBase(IIndexDBProviderFactory indexDBProviderFactory)
        {
            this.indexDBProviderFactory = indexDBProviderFactory;
        }

        public virtual TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
        {
            return Load(new[] {ticker}, field, startDate, endDate).FirstOrDefault();
        }

        public virtual TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            return Load(new[] { ticker }, field, startDate, endDate, loadingContext).FirstOrDefault();
        }

        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
        {
            return Load(tickers, field, startDate, endDate, null);
        }

        protected IIndexDBProvider IndexProvider
        {
            get { return indexDBProviderFactory.Create(); }
        }

        public abstract IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field,DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null);

        public virtual void Save(IList<TimeSerieDB> timeSeries)
        {
            Save(timeSeries, null);
        }
        
        public virtual void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            Save(timeSeries);
        }

        protected DateTime? GetVersionDate(ILoadingContext loadingContext)
        {
            return loadingContext != null ? loadingContext.VersionDate : null;
        }

        public abstract IList<DataFieldsEnum> SupportedFields { get; }
        public abstract DataTypeEnum SourceType { get; }

        protected void RaiseProgressChanged(ILoadingContext loadingContext, int nbTreatedItems, int totalCount, string stepName, string unit)
        {
            if (loadingContext != null)
            {
                loadingContext.RaiseOnProgessChanged(this,
                    new TimeSeriesProviderProgressEventArgs(stepName, unit, totalCount, nbTreatedItems));
            }
        }
    }
}