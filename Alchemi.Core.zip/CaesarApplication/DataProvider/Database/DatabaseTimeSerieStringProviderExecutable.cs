using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Index;
using CaesarApplication.Service.Logging;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public abstract class DatabaseTimeSerieStringProviderExecutableBase : DatabaseTimeSerieProviderBaseExecutable<TimeSerieStringDTO>
    {
        public DatabaseTimeSerieStringProviderExecutableBase(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieStringDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory)
        {
            if (timeSerieDtoConverter != null)
            {
                TimeSerieConverter = timeSerieDtoConverter;
            }
        }

        public DatabaseTimeSerieStringProviderExecutableBase()
            : base(new IndexDBProviderFactory())
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var tickersAsArray = tickers.ToArray();
            var series = LoadTimeSeriesStringByYear(field, startDate, endDate, tickersAsArray, loadingContext);

            return series.ToList();
        }

        private TimeSerieDB[] LoadTimeSeriesStringByYear(DataFieldsEnum field, DateTime? startDate, DateTime? endDate, string[] tickersAsArray, ILoadingContext context)
        {
            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault();

            var currentDate = startDateOrDefault;


            List<TimeSerieDB> timeSeries = new List<TimeSerieDB>();
            List<Task> tasks = new List<Task>();

            while (currentDate <= endDateOrDefault)
            {
                var newStartDate = currentDate;
                var newEndDate = currentDate.AddDays(RequestWindow) > endDateOrDefault ? endDateOrDefault : currentDate.AddDays(120);

                var dbTs = IndexProvider.LoadTimeSeriesString(tickersAsArray, (int)field, GetSourceToRequest(context),
                    newStartDate,
                    newEndDate,
                    GetVersionDate(context), UserService.CaesarSession);

                var task = new Task(obj =>
                {
                    var timeSerieStringDtos = dbTs;

                    if (field == DataFieldsEnum.OSTCollection)
                    {
                        foreach (var timeSerieStringDto in timeSerieStringDtos)
                        {
                            timeSerieStringDto.values =
                                timeSerieStringDto.values.Where(x => x.date_version >= startDateOrDefault && x.date_version <= endDateOrDefault).ToArray();
                        }
                    }

                    var convertedTimeSeries = TimeSerieConverter.ConvertFromDTO(timeSerieStringDtos, DataTypeByFieldName.ContainsKey(field) ? DataTypeByFieldName[field] : (context != null ? context.RequestedType : null), context: context);
                    foreach (var convertedTs in convertedTimeSeries)
                    {
                        try
                        {
                            lock (((ICollection)timeSeries).SyncRoot)
                            {
                                if (convertedTs != null)
                                {
                                    var timeSerie = timeSeries.FirstOrDefault(x => x.Instrument == convertedTs.Instrument && x.FieldName == convertedTs.FieldName);

                                    if (timeSerie == null)
                                    {
                                        timeSeries.Add(convertedTs);
                                    }
                                    else
                                    {
                                        timeSerie.Merge(convertedTs);
                                        //timeSerie.Merge2(convertedTs, true);
                                    }
                                }
                            }
                        }
                        catch (Exception e)
                        {
                            LoggingService.Error(this.GetType(), e.Message);
                        }
                    }
                }, null);

                tasks.Add(task);
                task.Start();

                currentDate = newEndDate.AddDays(1);
            }

            tasks.ForEach(t => t.Wait());

            return timeSeries.ToArray();
        }

        private static string GetReferenceAsString(TimeSerieStringDTO timeSerieStringDto)
        {
            int id;

            if (int.TryParse(timeSerieStringDto.instrument, out id))
            {
                return SophisHelper.GetReference(id);
            }

            return timeSerieStringDto.instrument;
        }

        protected virtual int RequestWindow
        {
            get { return 180; }
        }

        public override void Save(IList<TimeSerieDB> timeSeries)
        {
            var timeSerieStringDtosGrouped = timeSeries.Where(x => x.X.Any()).SelectMany(ts => TimeSerieConverter.ConvertToDTO(ts)).Group(20);

            timeSerieStringDtosGrouped.ForEach(g => IndexProvider.SaveTimeSeriesString(g, UserService.CaesarSession));
        }

        protected virtual Dictionary<DataFieldsEnum, Type> DataTypeByFieldName
        {
            get
            {
                return new Dictionary<DataFieldsEnum, Type>();
            }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
        public IEnumerable<TimeSerieDB> LoadAllInstrumentsByType(DataFieldsEnum marketDatatType)
        {
            var tmp = IndexProvider.LoadAllInstruments((int)marketDatatType);
            var result = TimeSerieConverter.ConvertFromDTO(tmp.ToArray());
            return result;
        }
    }

    [Serializable]
    public class DatabaseTimeSerieStringProviderExecutable : DatabaseTimeSerieStringProviderExecutableBase
    {
        public DatabaseTimeSerieStringProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieStringDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory, timeSerieDtoConverter)
        {
        }

        public DatabaseTimeSerieStringProviderExecutable()
        {
        }


        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.IndexcomponentsWeightsAndPrices,
                    DataFieldsEnum.IndexComponents,
                    DataFieldsEnum.IndexcomponentsWeightsAndPricesSpecialized,
                    DataFieldsEnum.Calendar,
                    DataFieldsEnum.OtherString,
                    DataFieldsEnum.OSTCollection,
                 DataFieldsEnum.FUT_CUR_GEN_TICKER
                };
            }
        }
    }
}