﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseDividendProviderExecutable : DatabaseProviderExecutableBase
    {
        private readonly IDividendDtoConverter dividendDtoConverter;

        public DatabaseDividendProviderExecutable()
            : base(new IndexDBProviderFactory())
        {
            this.dividendDtoConverter = new DividendDtoConverter();
        }

        public DatabaseDividendProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, IDividendDtoConverter dividendDtoConverter)
            : base(indexDBProviderFactory)
        {
            this.dividendDtoConverter = dividendDtoConverter;
        }


        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var dtoDividends = IndexProvider.LoadDividendGlobal(tickers.ToArray(), startDate, endDate, UserService.CaesarSession);

            return dividendDtoConverter.ConvertFromGlobalDTO(dtoDividends.GroupBy(x => x.identifier).ToDictionary(x => x.Key, x => x.ToList()));
        }

        public override void Save(IList<TimeSerieDB> timeSeries)
        {
            var convertToGlobalDto = dividendDtoConverter.ConvertToGlobalDTO(timeSeries.Where(x => x.Any()).ToArray());

            if (convertToGlobalDto.Any())
            {
                IndexProvider.SaveDividendsGlobal(convertToGlobalDto, UserService.CaesarSession);
            }
        }

        public override IList<DataFieldsEnum> SupportedFields {
            get
            {
                return new []
                {
                    DataFieldsEnum.DividendDeliveryType,
                    DataFieldsEnum.DividendExDivDate, 
                    DataFieldsEnum.DividendPayDate, 
                    DataFieldsEnum.DividendValueGross,
                    DataFieldsEnum.Dividend
                };
            }}

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}
