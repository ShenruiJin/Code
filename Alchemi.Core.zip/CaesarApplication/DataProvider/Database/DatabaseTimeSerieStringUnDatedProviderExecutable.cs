using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseTimeSerieStringUnDatedProviderExecutable : DatabaseTimeSerieProviderBaseExecutable<TimeSerieStringDTO>
    {
        public DatabaseTimeSerieStringUnDatedProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieStringDtoConverter timeSerieDtoConverter = null) : base(indexDBProviderFactory)
        {
            if (timeSerieDtoConverter != null)
            {
                TimeSerieConverter = timeSerieDtoConverter;
            }
        }

        public DatabaseTimeSerieStringUnDatedProviderExecutable()
            : base(new IndexDBProviderFactory())
        {
			TimeSerieConverter = new TimeSerieStringDtoConverter();
		}

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            if (field == DataFieldsEnum.OSTCollection && TimeSeriesProviderInitializer.HistoricBloombergIsAvailable)
                return new TimeSerieDB[0];

            var tickersAsArray = tickers.ToArray();
            var series = IndexProvider.LoadTimeSeriesString(tickersAsArray, (int)field, GetSourceToRequest(loadingContext), null, null, GetVersionDate(loadingContext), UserService.CaesarSession);

            return TimeSerieConverter.ConvertFromDTO(series, loadingContext != null ? loadingContext.RequestedType : null, field == DataFieldsEnum.IndexPricingInstruction).ToList();
        }

        public override void Save(IList<TimeSerieDB> timeSeries)
        {
            var tsToSave = timeSeries.SelectMany(ts =>
            {
                var series = TimeSerieConverter.ConvertToDTO(ts);

                series.ForEach(x => x.values = x.values = x.values.Select(v => new TimeSerieStringValueDTO { date_creation = v.date_version == DateTime.MinValue ? DateTime.Now : v.date_version, date_version = DateTime.MinValue, serie_id = v.serie_id, value = v.value}).ToArray());

                return series;
            }).ToArray();

            IndexProvider.SaveTimeSeriesString(tsToSave, UserService.CaesarSession);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.ICB_INDUSTRY_NAME,
                    DataFieldsEnum.Currency,
                    DataFieldsEnum.IndexPricingInstruction,
                    DataFieldsEnum.Isin,
                    DataFieldsEnum.DividendCurrency,
                    DataFieldsEnum.CountryIssue,
                    DataFieldsEnum.Country,
                    DataFieldsEnum.CountryOfDomicile,
                    DataFieldsEnum.CountryOfIncorporation,
                    DataFieldsEnum.SettlementDate,
                    DataFieldsEnum.FirstFutureDeliveryDate,
                    DataFieldsEnum.LastTradeableDate,
                    DataFieldsEnum.PriceFlag
                };
            }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}