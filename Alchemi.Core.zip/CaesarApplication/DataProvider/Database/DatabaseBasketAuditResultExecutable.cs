using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseBasketAuditResultExecutable : DatabaseBasketResultExecutableBase<BasketResultAuditDTO, BasketResultDTOConverter<BasketResultAuditDTO>>
    {
        public DatabaseBasketAuditResultExecutable(IIndexDBProviderFactory indexDBProviderFactory, IBasketResultDTOConverter<BasketResultAuditDTO> basketResultDTOConverter)
            : base(indexDBProviderFactory, basketResultDTOConverter)
        {
        }

        public DatabaseBasketAuditResultExecutable()
            : base(new IndexDBProviderFactory(), new BasketResultDTOConverter<BasketResultAuditDTO>())
        {
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.IndexAuditBasketResult
                };
            }
        }
        
        protected override BasketResultBaseDTO[] Save(BasketResultAuditDTO[] dataToSave, DateTime? nextDate, ILoadingContext context)
        {
            if (context != null && context.SessionId.HasValue)
            {
                return IndexProvider.SaveBasketResultsTransac(context.SessionId.GetValueOrDefault(), dataToSave, nextDate, UserService.CaesarSession).ToArray();
            }
            else
            {
                return IndexProvider.SaveBasketResults(dataToSave, nextDate, UserService.CaesarSession).ToArray();
            }
        }

        protected override IEnumerable<BasketResultAuditDTO> LoadBasketResults(DateTime? startDate, DateTime? endDate, string t, ILoadingContext context)
        {
            return IndexProvider.LoadBasketAuditResults(UserService.CaesarSession, t, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.MaxValue), GetVersionDate(context));
        }

        protected override int GroupSize
        {
            get { return 10; }
        }
    }
}