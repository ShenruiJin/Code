using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using DealServerInterface.Service;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Database
{
    [Serializable]
    public class DatabaseTimeSerieProviderExecutable : DatabaseTimeSerieProviderBaseExecutable<TimeSerieDTO>
    {
        public DatabaseTimeSerieProviderExecutable(IIndexDBProviderFactory indexDBProviderFactory, ITimeSerieDtoConverter timeSerieDtoConverter = null)
            : base(indexDBProviderFactory)
        {

            TimeSerieConverter = timeSerieDtoConverter ?? new TimeSerieDtoConverter();
        }

        public DatabaseTimeSerieProviderExecutable()
            : this(new IndexDBProviderFactory())
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            var instruments = tickers.ToArray();

            var series = IndexProvider.LoadTimeSeries(instruments, (int)field, GetSourceToRequest(loadingContext), startDate, endDate, GetVersionDate(loadingContext), UserService.CaesarSession);

            var result = TimeSerieConverter.ConvertFromDTO(series, context: loadingContext).ToList();

			return result;
        }

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            var series = timeSeries.Where(x => x.X.Any()).AsParallel().SelectMany(ts => TimeSerieConverter.ConvertToDTO(ts)).Group(50).ToArray();
            int nbTreatedItems = 0;

            foreach (var grp in series)
            {
                if (loadingContext != null)
                {
                    loadingContext.CancellationToken.ThrowIfCancellationRequested();
                }

                if (loadingContext != null && loadingContext.SessionId.HasValue)
                {
                    IndexProvider.SaveTimeSeriesTransac(loadingContext.SessionId.GetValueOrDefault(), grp, UserService.CaesarSession);
                }
                else
                {
                    IndexProvider.SaveTimeSeries(grp, UserService.CaesarSession);
                }

                nbTreatedItems += grp.Length;

                if (loadingContext != null)
                {
                    loadingContext.RaiseOnProgessChanged(this, new TimeSeriesProviderProgressEventArgs("Save Time Series (double)\r\n", "timeserie", timeSeries.Count, nbTreatedItems));
                }
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                DataFieldsEnum.Ask,
                DataFieldsEnum.Bid,
                DataFieldsEnum.Close,
                DataFieldsEnum.Last,
                DataFieldsEnum.LastAdjustedDividend,
                DataFieldsEnum.RealizedVolatility10d,
                DataFieldsEnum.RealizedVolatility30d,
                DataFieldsEnum.RealizedVolatility60d,
                DataFieldsEnum.RealizedVolatility90d,
                DataFieldsEnum.RealizedVolatility180d,
                DataFieldsEnum.MarketCap,
                DataFieldsEnum.MarketCapitalization,
                DataFieldsEnum.EarningYield,
                DataFieldsEnum.BookToMarketRatio,
                DataFieldsEnum.Volume,
                DataFieldsEnum.VolumeAverage6Months,
                DataFieldsEnum.FreeCashFlowYield,
                DataFieldsEnum.Other,
                DataFieldsEnum.SettlementPrice,
                DataFieldsEnum.Notional,
                DataFieldsEnum.DirtyMidPrice,
                DataFieldsEnum.ContractValue
                };
            }
        }

        public override DataTypeEnum SourceType
        {
            get { return DataTypeEnum.Global; }
        }
    }
}
