﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class DatesAdapterDataHandler : DataHandler
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate, ILoadingContext context, bool removeEmptySeries = false)
        {
            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();
            var originalTickers = tickers.ToArray();

            var startDateToRequest = startDate.GetValueOrDefault();
            var endDateToRequest = endDate.GetValueOrDefault(DateTime.MaxValue);

            if (context != null && context.DatesHandlers != null)
            {
                originalTickers.ForEach(t => context.DatesHandlers.ForEach(dh =>
                {
                    var tmpStartDate = startDateToRequest;
                    var tmpEndDate = endDateToRequest;

                    dh.GeDatesToRequest(t, ref tmpStartDate, ref tmpEndDate);

                    startDateToRequest = tmpStartDate < startDateToRequest ? tmpStartDate : startDateToRequest;
                    endDateToRequest = tmpEndDate > endDateToRequest ? tmpEndDate : endDateToRequest;
                }));
            }

            var result = GetResultFromSuccessor(startDateToRequest, endDateToRequest, originalTickers, dataFieldsAsArray, context, false).ToArray();

            if (context != null && context.DatesHandlers != null)
            {
                context.DatesHandlers.ForEach(dh => result = dh.Calculate(result, startDate, endDate));
            }

            return result;
        }

        protected override void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
        }
    }
}
