﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Sophis
{
    public class CalendarSophisExecutable : ProviderExecutable
    {

        public CalendarSophisExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Calendar
            };
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();


            var tmp = tickers.Select(t => Tuple.Create(t.Replace(SophisTranscoder.UnknownPrefix, string.Empty), t));

            try
            {
                foreach (var ticker in tmp)
                {
                    IMarketData calendar = null;

                    if (endDate == DateTime.Today)
                    {
                        int tickernum;
                        bool isSico = int.TryParse(ticker.Item1, out tickernum);
                        IList<ICalendar> calendars;
                        if (isSico)
                        {
                            calendars = SophisHelper.GetCalendarBySicovam(ticker.Item1);
                        }
                        else //// try market
                        {
                            calendars = SophisHelper.GetCalendarByMarketMnemo(ticker.Item1).AsArray();
                        }

                        calendar = ConvertToMarketData(calendars).First();
                    }

                    var timeSerieDB = new TimeSerieDB(calendar != null ? new KeyValuePair<DateTime, IMarketData>(DateTime.Today, calendar).AsArray() : new KeyValuePair<DateTime, IMarketData>[0], ticker.Item2, field);

                    timeSerieDB.StartDate = startDate;
                    timeSerieDB.EndDate = endDate;
                    timeSerieDB.IsConsideredAsComplete = true;

                    output.Add(timeSerieDB);
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Error loading Calendar", ex);
            }


            return output;
        }

        /// <summary>
        /// Need to return Calendar which is a market data
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public IEnumerable<IMarketData> ConvertToMarketData(IEnumerable<ICalendar> value)
        {
            return value.Select(cal => cal as Calendar);
        }
    }
}
