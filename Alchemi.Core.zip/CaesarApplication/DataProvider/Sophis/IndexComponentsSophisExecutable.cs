using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Index;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Sophis
{
    public class IndexComponentsSophisExecutable : ProviderExecutable
    {

        public IndexComponentsSophisExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.IndexcomponentsWeightsAndPrices
            };
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();


            var tmp = tickers.Select(t => Tuple.Create<string, string>(t.Replace(SophisTranscoder.UnknownPrefix, string.Empty), t));

            try
            {
                foreach (var ticker in tmp)
                {
                    IndexComponents result = null;

                    if (endDate == DateTime.Today)
                    {
                        int tickernum;
                        bool isSico = int.TryParse(ticker.Item1, out tickernum);

                        var compo = SophisHelper.GetCompoositionsBySicovam(tickernum);
                        result = new IndexComponents(ticker.Item2, IndexComponentWeight_Type.Absolute, compo.Basis, compo.Currency);

                        var transcoDico = SophisHelper.GetReferences(compo.Components.Select(c => c.Sicovam).ToArray());

                        result.Components =
                            compo.Components.Select(c => (IIndexComponent)new IndexComponent(transcoDico[c.Sicovam], c.Weight, -1.0, c.Weight)).ToList();
                    }

                    var timeSerieDB = new TimeSerieDB(result != null ? new KeyValuePair<DateTime, IMarketData>(DateTime.Today, result).AsArray() : new KeyValuePair<DateTime, IMarketData>[0], ticker.Item2, field);

                    timeSerieDB.StartDate = startDate;
                    timeSerieDB.EndDate = endDate;
                    timeSerieDB.IsConsideredAsComplete = true;

                    output.Add(timeSerieDB);
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Error loading Composition", ex);
            }


            return output;
        }
    }
}