﻿using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaesarApplication.DataProvider.Sophis
{
    public class CurrencySophisExecutable : ProviderExecutable
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public CurrencySophisExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Currency
            };
        }

        /// <summary>
        /// Load method
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var knownTickers = tickersAsArray.Where(t => !t.StartsWith(SophisTranscoder.UnknownPrefix)).ToArray();
                var unknownSicovams = tickersAsArray.Except(knownTickers).ToArray();

            if (tickersAsArray.Any())
            {
                IDictionary<int, string> currencies = new Dictionary<int, string>();
                IDictionary<int, double> tradingUnits = new Dictionary<int, double>();

                foreach (int sicovam in knownTickers.Select(int.Parse).ToArray())
                {
                    currencies.Add(sicovam, SophisHelper.GetCurrency(sicovam));
                    tradingUnits.Add(sicovam, SophisHelper.GetTradingUnit(sicovam));
                }

                foreach (var instrumentSicovam in currencies.Keys)
                {
                    output.Add(new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>()
                    {
                        new KeyValuePair<DateTime, IMarketData>(DateTime.MinValue, new MarketDataString(GetCurrency(currencies[instrumentSicovam], tradingUnits[instrumentSicovam])))
                    }, 
                    instrumentSicovam.ToString(),
                    DataFieldsEnum.Currency));
                }

                foreach (var unknownSicovam in unknownSicovams)
                {
                    var originalTicker = unknownSicovam.Substring(SophisTranscoder.UnknownPrefix.Length);
                    if (SophisHelper.IsCurrencyTicker(originalTicker))
                    {
                        output.Add(new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>()
                    {
                        new KeyValuePair<DateTime, IMarketData>(DateTime.MinValue, new MarketDataString(originalTicker.Split(" ".AsArray(), StringSplitOptions.None)[0].Substring(3, 3)))
                    },
                           unknownSicovam,
                           DataFieldsEnum.Currency));
                    }
                    else
                    {
                        output.Add(new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(),
                                unknownSicovam,
                                DataFieldsEnum.Currency)
                        { StartDate = DateTime.MinValue, EndDate = DateTime.MinValue });

                    }
                }
            }

            return output;
        }

        private string GetCurrency(string currency, double tradingUnit)
        {
            return tradingUnit == 0.01d ? currency.Substring(0, 2) + currency.Substring(2).ToLower() : currency;
        }
    }
}
