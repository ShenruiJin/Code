﻿using CaesarApplication.DataProvider.Helpers;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;


namespace CaesarApplication.DataProvider.Sophis
{
    public class LastSophisExecutable : ProviderExecutable
    {
        private static Dictionary<string, int> transcoDico;

        static LastSophisExecutable()
        {
            transcoDico = new Dictionary<string, int>
            {
                { "Unknown$SIBF1M Index", SophisHelper.GetSicovam("SIBOR_1M")  }
        };
        }

        public LastSophisExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Last
            };
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();

            var knownSicovams = tickers.Where(t => transcoDico.ContainsKey(t) || (!t.StartsWith(SophisTranscoder.UnknownPrefix) && IsTickerToLoad(t))).Select(x => transcoDico.ContainsKey(x) ? transcoDico[x] : int.Parse(x)).ToArray();

            if (tickers.Any())
            {
                var histories = SophisHelper.GetHistories(knownSicovams, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.Now));

                foreach (var historySerie in histories)
                {
                    output.Add(new TimeSerieDB(historySerie.Values.Select(h => new KeyValuePair<DateTime, IMarketData>(h.Date, new MarketDataDouble(h.Last))).ToArray(), transcoDico.Any(x => x.Value.ToString() == historySerie.Code.ToString()) ? transcoDico.First(x => x.Value.ToString() == historySerie.Code.ToString()).Key : historySerie.Code.ToString(), DataFieldsEnum.Last));
                }
            }

            return output;
        }

        /// <summary>
        /// Check if given Sicovam is an IAPR
        /// </summary>
        /// <param name="t"></param>
        /// <returns></returns>
        private static bool IsTickerToLoad(string t)
        {
            string reference = SophisHelper.GetReference(int.Parse(t));

            return string.IsNullOrWhiteSpace(reference) ? false : new[] { "SIBF1M" }.Any(x => SophisHelper.GetReference(int.Parse(t)).Contains(x));
        }
    }
}
