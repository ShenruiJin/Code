﻿using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CaesarApplication.DataProvider.Sophis
{
    public class IsinSophisExecutable : ProviderExecutable
    {
        /// <summary>
        /// Constructor
        /// </summary>
        public IsinSophisExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Isin
            };
        }

        /// <summary>
        /// Load method
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();

            var knownSicovams = tickers.Where(t => !t.StartsWith(SophisTranscoder.UnknownPrefix)).Select(int.Parse).ToArray();

            if (tickers.Any())
            {
                IDictionary<int, string> isins = new Dictionary<int, string>();

                foreach(int sicovam in knownSicovams)
                {
                    isins.Add(sicovam, SophisHelper.GetIsin(sicovam.ToString(), GlobalDerivativesApplications.Data.Booking.EnumSophisRefCodeType.Sicovam));
                }

                foreach (var instrumentSicovam in isins.Keys)
                {
                    output.Add(new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>()
                    {
                        new KeyValuePair<DateTime, IMarketData>(DateTime.MinValue, new MarketDataString(isins[instrumentSicovam]))
                    }, 
                    instrumentSicovam.ToString(),
                    DataFieldsEnum.Isin));
                }
            }

            return output;
        }
    }
}
