﻿using System;
using System.Collections.Generic;
using System.Linq;
using Caesar.Pricing.MarketData.Exceptions;
using CaesarApplication.DataProvider.MarketDataTree;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using DealServerInterface.Service;
using FuncFramework;
using FuncFramework.Business;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Date;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;
using GlobalDerivativesApplications.EdaProto;
using Pricing.Engine.Indices;
using PricingBase.Dates;
using OverloadedMarketDataTree = MarketDataMgr.Trees.Ext.OverloadedMarketDataTree;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.DataProvider.TickerHandlers;
using CaesarApplication.DataProvider.Helpers;
using PricingBase.MarketData;
using DealIndexDataTransferObject.Converters;
using CaesarApplication.Service.Logging;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Data Accessor (access to Index from Database and MarketData through multiple providers)
    /// </summary>
    [Serializable]
    public class TimeSeriesProvider : ITimeSeriesProvider
    {
        #region Fields
        /// <summary>
        /// First handler to be called
        /// Must be a cache to be used as a result bag
        /// </summary>
        internal IDataHandler entryPoint;

        /// <summary>
        /// First handler to be called
        /// Must be a cache to be used as a result bag
        /// </summary>
        internal IDataHandler entryPointWithoutTranscoding;

        /// <summary>
        /// Calculate indicator
        /// </summary>
        private readonly CalculationEngine.CalculationEngine calculationEngine;

        /// <summary>
        /// Enable or disable save into Database
        /// </summary>
        private readonly bool isReadOnly;

        private readonly bool markSource;

        /// <summary>
        /// Managed fields
        /// </summary>
        private IList<DataFieldsEnum> _managedFields;

        /// <summary>
        /// MarketDataTree needed for operations on cache (MarketDataTree is the cache)
        /// </summary>
        private OverloadedMarketDataTree tree;

        private string[] specificSourcesToUSe;

        private ITimeSerieStringDtoConverter converter;

        #endregion

        #region Properties
        public BasketIndexList AuditDataBaskets
        {
            set
            {

                var dataHandler = new DatesAdapterDataHandler();
                var adapterDataHandler = new AdapterDataHandler(new ITickerHandler[] { new GBpoundTickerHandler() });
                dataHandler.SetSuccessor(adapterDataHandler);
                adapterDataHandler.SetSuccessor(new AuditDataHandler(value.Baskets.ToArray(), entryPoint));

                entryPoint = dataHandler;
                entryPointWithoutTranscoding = entryPoint;
            }
        }

        public BasketIndex AuditData
        {
            set
            {
                AuditDataBaskets = new BasketIndexList(DateTime.MinValue, value.AsArray());
            }
        }

        public string DBSource { get; set; }

        /// <summary>
        /// Managed fields
        /// </summary>
        public IEnumerable<DataFieldsEnum> ManagedFields
        {
            get
            {
                if (_managedFields == null)
                {
                    _managedFields = entryPoint.ManagedFieldsWithSuccessors.ToList();
                }

                return _managedFields;
            }
        }

        /// <summary>
        /// Managed fields as strings
        /// </summary>
        public IEnumerable<string> ManagedFieldsAsStrings
        {
            get
            {
                return ManagedFields.Select(o => o.ToString());
            }
        }

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="tree"></param>
        /// <param name="readOnly"></param>
        /// <param name="noCacheLoading"></param>
        /// <param name="initializer"></param>
        /// 
        public PricingContext PricingContext { get; set; }

        #endregion

        #region .Ctor
        public TimeSeriesProvider(OverloadedMarketDataTree tree, bool readOnly = false, bool noDBLoading = false, bool isTreeOnly = false,
            bool noCacheLoading = false, ITimeSeriesProviderInitializer initializer = null, string[] dataHandlersToUse = null,
            bool saveAsDefault = true, IIndexDBProviderFactory indexDbProviderFactory = null, string[] specificDBSources = null, bool noFilterSources = false,
            ITimeSerieStringDtoConverter converter = null)
        {
            this.tree = tree;
            calculationEngine = new CalculationEngine.CalculationEngine(this);

            isReadOnly = readOnly;

            if (isTreeOnly)
            {
                InitializeTreeOnly();
                return;
            }

            var timeSeriesProviderInitializer = initializer ?? new TimeSeriesProviderInitializer(dataHandlersToUse, specificDBSources: specificDBSources, noFilterSources: noFilterSources);
            entryPoint = timeSeriesProviderInitializer.Initialize(tree, noDBLoading, noCacheLoading, isReadOnly, entryPoint, saveAsDefault, indexDbProviderFactory ?? new IndexDBProviderFactory());

            entryPointWithoutTranscoding = GetEntryPointWithoutTranscoding(entryPoint);
            this.converter = converter ?? new TimeSerieStringDtoConverter();
        }

        public TimeSeriesProvider(OverloadedMarketDataTree tree, TimeSeriesProviderParameters parameters,
            ITimeSeriesProviderInitializer initializer = null, IIndexDBProviderFactory indexDbProviderFactory = null)
        : this(tree, parameters.ReadOnly, parameters.NoDBLoading, parameters.IsTreeOnly,
            parameters.NoCacheLoading, initializer, parameters.DataHandlersToUse, parameters.SaveAsDefault, indexDbProviderFactory,
            parameters.SpecificDBSources, parameters.NoFilterSources, new TimeSerieStringDtoConverter())
        { }
        #endregion

        #region Public Methods
        public void AddExecutable(string dataHandlerName, IProviderExecutable executable)
        {
            var dataHandler = GetDataHandlerFromName(dataHandlerName);

            if (dataHandler == null)
            {
                return;
            }

            if (!(dataHandler is IDataHandlerExtensible) || !(((IDataHandlerExtensible)dataHandler).ProviderRouter is IProviderRouterExtensible))
            {
                throw new ArgumentException("DataHandler is not extensible");
            }

            ((IProviderRouterExtensible)(((IDataHandlerExtensible)dataHandler).ProviderRouter)).AddExecutable(executable);
        }

        public void ClearTreeData(DataFieldsEnum field)
        {
            tree.OriginalTree.Tree.ClearData(field);
        }

        public void ClearTreeData(DataFieldsEnum field, string[] tickers = null, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext context = null)
        {
            tree.OriginalTree.Tree.ClearData(field, tickers, startDate, endDate, context);
        }

        public BasketIndexList GetBasket(string ticker, DateTime? startDate = null, DateTime? endDate = null)
        {
            var requestedStartDate = GetRequestedEndDate(startDate);
            var requestedEndDate = GetRequestedEndDate(endDate);

            var timeSeries = PricingContext != null ? Preload(entryPoint, ticker.AsArray(), DataFieldsEnum.IndexBasketResult.AsArray(), requestedStartDate, requestedEndDate, PricingContext) :
             entryPoint.Load(ticker.AsArray(), DataFieldsEnum.IndexBasketResult.AsArray(), requestedStartDate, requestedEndDate, PricingContext, false);

            AddTimeSerieToAudit(timeSeries);

            return !timeSeries.IsNullOrEmpty() && timeSeries.First().Any() ? (BasketIndexList)timeSeries[0].GetPeriod(DateTime.MinValue, requestedEndDate).Y.LastOrDefault() : null;
        }

        public TimeSerieDB GetBaskets(string ticker, DateTime? startDate = null, DateTime? endDate = null, bool filterAudit = true)
        {
            //Preload(ticker.AsArray(), DataFieldsEnum.IndexBasketResult.AsArray(), startDate, endDate);

            var res = entryPoint.Load(ticker.AsArray(), DataFieldsEnum.IndexBasketResult.AsArray(), startDate, GetRequestedEndDate(endDate), PricingContext).FirstOrDefault();

            AddTimeSerieToAudit(res);


            return res != null && filterAudit ? new TimeSerieDB(res.GetElements()
                .Where(kv =>
                {
                    if (!filterAudit)
                        return true;

                    var bList = ((BasketIndexList)kv.Value);

                    return bList.Baskets.Count != 1 ||
                           bList.Baskets.FirstOrDefault(b => b.Name != BasketIndex.AuditBasketName) != null;
                }).ToArray(), res.Instrument, res.Field) : res;
        }

        public TimeSerieDB GetBasketsAudit(string ticker, DateTime? startDate = null, DateTime? endDate = null, DateTime? versionDate = null, bool filterAudit = true)
        {
            //Preload(ticker.AsArray(), DataFieldsEnum.IndexAuditBasketResult.AsArray(), startDate, endDate);

            var res = entryPoint.Load(ticker.AsArray(), DataFieldsEnum.IndexAuditBasketResult.AsArray(), startDate, GetRequestedEndDate(endDate.GetValueOrDefault(DateTime.Today)), GetLoadingContextWithVersionDate(versionDate)).FirstOrDefault() ?? new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], ticker, DataFieldsEnum.IndexAuditBasketResult);

            return res != null && filterAudit ? new TimeSerieDB(res.GetElements()
           .Where(kv =>
           {
               if (!filterAudit)
                   return true;

               var bList = ((BasketIndexList)kv.Value);

               return bList.Baskets.Count != 1 ||
                      bList.Baskets.FirstOrDefault(b => b.Name != BasketIndex.AuditBasketName) != null;
           }).ToArray(), res.Instrument, res.Field) : res;
        }

        /// <summary>
        /// Get result baskets of a script by query
        /// </summary>
        /// <param name="indexQuery"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerieDB GetIndexBaskets(string indexQuery, DateTime? startDate = null, DateTime? endDate = null)
        {
            var indexBaskets = LoadWithoutPreload(indexQuery.AsArray(), DataFieldsEnum.IndexBasketResult.AsArray(), startDate, endDate, new OpenDaysCalendar()).FirstOrDefault() ?? new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(), indexQuery, DataFieldsEnum.IndexBasketResult);


            return new TimeSerieDB(indexBaskets.GetElements().ToDictionary(x => x.Key, x =>
            {
                var originalBasket = (BasketIndexList)x.Value;


                return (IMarketData)new BasketIndexList(originalBasket.ComputationDate.GetValueOrDefault(),
                    originalBasket.Baskets.Where(b => b.Name != BasketIndex.AuditBasketName).ToArray())
                {
                    CalculationDate = originalBasket.CalculationDate,
                    Creator = originalBasket.Creator,
                    EffectiveDate = originalBasket.EffectiveDate,
                    ComputationDate = originalBasket.ComputationDate,
                    CreationDate = originalBasket.CreationDate,
                    VersionDate = originalBasket.VersionDate,
                };
            }).Where(x => ((BasketIndexList)x.Value).Baskets.Any()).ToArray(), indexQuery, DataFieldsEnum.IndexBasketResult);
        }

        public IndexInfos GetIndexInfos(string identifier)
        {
            var indexDto = PersistanceService.IndexProvider.GetIndexFromCode(identifier, UserService.CaesarSession);
            
            return indexDto != null ? indexDto.ToIndexInfos() : null;
        }

        public IndexInfos GetIndexInfosByBbgTicker(string identifier)
        {
            var indexDto = PersistanceService.IndexProvider.GetIndexFromBbgTicker(identifier, UserService.CaesarSession);

            return indexDto != null ? indexDto.ToIndexInfos() : null;
        }

        public ICalendar GetCalendar(string ticker, DateTime date)
        {
            try
            {
                var calendarTs = Load(IndexPathHelper.GetProjectName(ticker) + IndexPathHelper.Delimiter + IndexPathHelper.GetLocalPath(ticker) +
                                                         IndexPathHelper.Delimiter + "Calendar." + IndexPathHelper.GetIndexName(ticker), DataFieldsEnum.Calendar, date.AddDays(-400), date);

                return calendarTs.Y.Cast<ICalendar>().Last();
            }
            catch (Exception ex)
            {
                var message = string.Format("Error while retrieving calendar for {0} : {1}", ticker, ex.Message);
                LoggingService.Error(GetType(), message);
                return null;
            }
        }

        public ICalendar GetCalendarForBbgTicker(string bbgTicker, DateTime date)
        {
            var idxInfos = GetIndexInfos(bbgTicker);
            var project = PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(idxInfos.id.AsArray(), UserService.CaesarSession).First().Value;

            return GetCalendar(IndexPathHelper.Combine(project.project_name, idxInfos.ticker), date);
        }

        /// <summary>
        /// Get result quotes of a script by query
        /// </summary>
        /// <param name="indexQuery"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerieDB GetIndexQuotes(string indexQuery, DateTime? startDate = null, DateTime? endDate = null, bool onlyWithValue = false)
        {
            var originalQuoteTs = LoadWithoutPreload(indexQuery.AsArray(), DataFieldsEnum.IndexQuote.AsArray(), startDate, endDate, new OpenDaysCalendar()).FirstOrDefault() ?? new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(), indexQuery, DataFieldsEnum.IndexQuote);

            return onlyWithValue ? new TimeSerieDB(originalQuoteTs.GetElements().Where(kv => !double.IsNaN(((IIndexQuoteTechnical)kv.Value).ValueWithoutTest)).ToArray(), originalQuoteTs.Instrument, originalQuoteTs.Field) : originalQuoteTs;
        }

        /// <summary>
        /// Get Index Pricing Instruction from product name
        /// </summary>
        /// <param name="projectId"></param>
        /// <param name="name">Product name</param>
        /// <returns>Pricing sequence</returns>
        public IndexPricingInstruction GetInstructionFromFullPath(long? projectId, string name)
        {
            var timeSerie = Load(IndexPathHelper.GetFullPath(projectId.GetValueOrDefault(), name).AsArray(), DataFieldsEnum.IndexPricingInstruction.AsArray(),
                DateTime.MinValue, DateTime.MinValue);

            if (timeSerie != null && timeSerie.Any() && timeSerie[0].X.Any())
            {
                return (IndexPricingInstruction)timeSerie[0][DateTime.MinValue];
            }

            return null;
        }

        public BasketIndex GetLatestBasket(string ticker, string basketName, DateTime startDate, DateTime endDate, bool UpgradedCompoOnly = false)
        {
            var baskets = GetBaskets(ticker, startDate, endDate);
            var basketIndexLists = baskets.Select(x => x.Value as IBasketIndexList);
            if (!basketIndexLists.Any())
                return null;
            var latestBasketIndexList = UpgradedCompoOnly ?
                basketIndexLists.OrderByDescending(x => x.VersionDate).FirstOrDefault(x => x.Baskets.All(b => b.IsUpgradedCompoIndicator)) :
                basketIndexLists.OrderByDescending(x => x.VersionDate).FirstOrDefault(x => x.Baskets.Count != 0);

            if (latestBasketIndexList == null)
                return null;

            var result = latestBasketIndexList.Baskets.FirstOrDefault(b => b.Name == basketName);
            return result;
        }

        /// <summary>
        /// Get result quotes of a script by query
        /// </summary>
        /// <param name="indexQuery"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> GetResultQuotes(string indexQuery, DateTime? startDate = null, DateTime? endDate = null)
        {
            var res = entryPoint.Load(indexQuery.AsArray(), DataFieldsEnum.IndexQuote.AsArray(), startDate, endDate, PricingContext, true);

            if (res != null)
            {
                res.ForEach(r => r.Instrument = indexQuery);
            }

            AddTimeSerieToAudit(res);

            return res;
        }

        /// <summary>
        /// Load requested data for all basket components and matching field
        /// </summary>
        /// <param name="basketIndex">Requested tickers</param>
        /// <param name="components">Requested tickers</param>
        /// <param name="fields">Type of data for each respective ticker</param>
        /// <param name="startDate">Start data date</param>
        /// <param name="endDate">End data date</param>
        /// <param name="calendar"></param>
        /// <returns>Requested data</returns>
        public TimeSeries LoadMultiFields(IBasketIndex basketIndex, IList<KeyValuePair<IBasketComponent, DataFieldsEnum>> components, DateTime? startDate, DateTime? endDate, IPricingCalendar calendar)
        {
            TimeSeries results = new TimeSeries();
            IEnumerable<DataFieldsEnum> differentFields = components.Select(c => c.Value).Distinct();

            foreach (DataFieldsEnum field in differentFields)
            {
                IEnumerable<string> tickers = components.Where(c => c.Value == field).Select(c => c.Key.BloombergTicker);
                results.AddRange(Load(basketIndex, tickers, new List<DataFieldsEnum>() { field }, startDate, endDate, calendar));
                //Load(preloadActivated, tickers, new List<DataFieldsEnum>() { field }, startDate, endDate, calendar, disableChecks, loadInLocal, dateHandler));
            }
            return results;  
        }

        /// <summary>
        /// Load requested data for all basket components and matching field
        /// </summary>
        /// <param name="components">Requested tickers</param>
        /// <param name="fields">Type of data for each respective ticker</param>
        /// <param name="startDate">Start data date</param>
        /// <param name="endDate">End data date</param>
        /// <param name="calendar"></param>
        /// <param name="disableChecks"></param>
        /// <returns>Requested data</returns>
        public TimeSeries LoadMultiFields(IList<KeyValuePair<IBasketComponent, DataFieldsEnum>> components, DateTime? startDate, DateTime? endDate, IPricingCalendar calendar, bool disableChecks = false)
        {
            return LoadMultiFields(true, components, startDate, endDate, calendar, disableChecks);
        }
        /// <summary>
        /// Load requested data for all basket components and matching field
        /// </summary>
        /// <param name="tickers">Requested tickers</param>
        /// <param name="fields">Type of data for each respective ticker</param>
        /// <param name="startDate">Start data date</param>
        /// <param name="endDate">End data date</param>
        /// <param name="calendar"></param>
        /// <param name="disableCheck"></param>
        /// <returns>Requested data</returns>
        public TimeSeries LoadMultiFields(bool preloadActivated, IList<KeyValuePair<IBasketComponent, DataFieldsEnum>> components, DateTime? startDate = null, DateTime? endDate = null,
            IPricingCalendar calendar = null, bool disableChecks = false, bool loadInLocal = true, IDatesHandler dateHandler = null)
        {
            TimeSeries results = new TimeSeries();
            IEnumerable<DataFieldsEnum> differentFields = components.Select(c => c.Value).Distinct();

            foreach (DataFieldsEnum field in differentFields)
            {
                IEnumerable<string> tickers = components.Where(c => c.Value == field).Select(c => c.Key.BloombergTicker);
                results.AddRange(Load(preloadActivated, tickers, new List<DataFieldsEnum>() { field }, startDate, endDate, calendar, disableChecks, loadInLocal, dateHandler));
            }
            return results;
        }
        /// <summary>
        /// Load the market data
        /// </summary>
        /// <param name="preloadActivated"></param>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="disableChecks"></param>
        /// <param name="dateHandler"></param>
        /// <returns></returns>
        public TimeSeries Load(bool preloadActivated, IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, bool disableChecks = false, bool loadInLocal = true, IDatesHandler dateHandler = null, bool filterDataByCal = false)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();

            if (!disableChecks)
            {
                CheckDateLimits(endDate);
            }

            var requestedStartDate = GetRequestedStartDate(startDate, endDate);
            var requestedEndDate = GetRequestedEndDate(endDate);
            var loadingContext = GetLoadingContext(calendar, dateHandler, null, loadInLocal);
            var itemsToFilter = preloadActivated && PricingContext != null ? Preload(entryPoint, tickersAsArray, dataFieldsAsArray, requestedStartDate, requestedEndDate, loadingContext) : entryPoint.Load(tickersAsArray, dataFieldsAsArray, requestedStartDate, requestedEndDate, loadingContext);

            CheckIfDataIsNull(itemsToFilter, tickersAsArray, dataFieldsAsArray, requestedStartDate, requestedEndDate);

            var resultTimeSeries = new TimeSeries(FilterTimeSeries(tickersAsArray, dataFieldsAsArray, requestedStartDate,
                requestedEndDate, itemsToFilter, filterDataByCal, calendar));

            if (PricingContext != null && PricingContext.AuditDataBasket != null)
            {
                PricingContext.AuditDataBasket.AddTimeSeries(resultTimeSeries, false);
            }

            return new TimeSeries(resultTimeSeries);
        }

        /// <summary>
        /// Load the market data
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="calendar">Calendar to check if data serie is complete</param>
        /// <returns></returns>
        public TimeSeries Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields,
            DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, bool disableCheck = false)
        {
            return Load(true, tickers, fields, startDate, endDate, calendar, disableCheck);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="calendar"></param>
        /// <param name="handler"></param>
        /// <param name="loadInLocal"></param>
        /// <param name="datesHandler"></param>
        /// <param name="requestedType"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> Load(IBasketIndex basketIndex, IEnumerable<string> tickers, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, IDataHandler handler = null, bool loadInLocal = true, IDatesHandler datesHandler = null, Type requestedType = null, bool filterDataByCal = false)
        {
            var res = new List<TimeSerieDB>();

            var fieldsAsArray = fields as string[] ?? fields.ToArray();
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            var indicatorFieldsAsArray = fieldsAsArray.Where(i => calculationEngine.IsSupportedIndicator(i)).ToArray();
            var dataFields = fieldsAsArray.Except(indicatorFieldsAsArray).Select(x => (DataFieldsEnum)Enum.Parse(typeof(DataFieldsEnum), x)).ToArray();

            var requestedStartDate = GetRequestedStartDate(startDate, endDate);
            var requestedEndDate = GetRequestedEndDate(endDate);

            tickersAsArray = GetTickersToTreat(tickersAsArray);

            foreach (var field in indicatorFieldsAsArray)
            {
                res.AddRange(calculationEngine.Load(basketIndex ?? new BasketIndex(), tickersAsArray, field, requestedStartDate, requestedEndDate));
            }

            //CheckDateLimits(endDate);

            var entryPointToUse = handler ?? entryPoint;

            var loadingContext = GetLoadingContext(calendar, datesHandler, requestedType, loadInLocal);

            var itemsToFilter = PricingContext != null ? Preload(entryPointToUse, tickersAsArray, dataFields, requestedStartDate, requestedEndDate, loadingContext) : entryPointToUse.Load(tickersAsArray, dataFields, requestedStartDate, requestedEndDate, loadingContext);
            CheckIfDataIsNull(itemsToFilter, tickersAsArray, fieldsAsArray, requestedStartDate, requestedEndDate);

            var result = FilterTimeSeries(tickersAsArray, dataFields.ToArray(), requestedStartDate, requestedEndDate, itemsToFilter, filterDataByCal, calendar);

            if (result != null)
            {
                res.AddRange(result);
            }

            if (basketIndex != null)
            {
                foreach (var ts in res)
                {
                    basketIndex[ts.FieldName, null, null, false] = ts.AsArray();
                }
            }

            AddTimeSerieToAudit(result);

            return res;
        }

        /// <summary>
        ///  Load data simple with field as string
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerieDB Load(string ticker, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var series = Load(null, ticker.AsArray(), field.AsArray(), startDate, endDate, calendar);
            return series != null ? series.FirstOrDefault() : null;
        }

        /// <summary>
        ///  Load data simple with field as DataFieldsEnum
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(ticker, field.ToString(), startDate, endDate, calendar);
        }

        public TimeSerieDB Load(IBasketIndex basketIndex, string ticker, DataFieldsEnum field, DateTime? startDate = null,
            DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return LoadAndUpdate(basketIndex, ticker, field.ToString(), startDate, endDate, calendar);
        }

        public TimeSerieDB Load(DataPath path, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(null, path.Path.AsArray(), field.ToString().AsArray(), startDate, endDate, calendar, entryPointWithoutTranscoding).FirstOrDefault();
        }

        public IList<TimeSerieDB> Load(IBasketIndex basketIndex, IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, tickers, fields.Select(x => x.ToString()).ToArray(), startDate, endDate, calendar);
        }

        /// <summary>
        /// Load market data from a schedule
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="schedule"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, IList<DateTime> schedule)
        {
            var startDate = schedule.First();
            var endDate = schedule.Last();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var fieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();

            CheckDateLimits(endDate);

            if (PricingContext != null)
            {
                Preload(entryPoint, tickersAsArray, fieldsAsArray, startDate, endDate, PricingContext);
            }

            return entryPoint.Load(tickersAsArray, fieldsAsArray, schedule);
        }

        public IList<TimeSerieDB> Load(BasketIndex basketIndex, string[] tickers, DataFieldsEnum field, DateTime startDate, DateTime endDate, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, tickers, field.AsArray(), startDate, endDate, calendar);
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(), fields, startDate, endDate, calendar);
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, IEnumerable<string> tickers, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, tickers, fields, startDate, endDate, calendar);
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(), new[] { field }, startDate, endDate, calendar);
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(), new[] { field }, startDate, endDate, calendar);
        }

        public TimeSerieDB LoadAndUpdate(BasketIndex indexBasket, string ticker, DataFieldsEnum field, DateTime? startDate = null,
            DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return LoadAndUpdate(indexBasket, ticker.AsArray(), field.ToString().AsArray(), startDate, endDate, calendar).FirstOrDefault();
        }

        public TimeSeries LoadAndUpdate(IBasketIndex basketIndex, string[] tickers, DataFieldsEnum field, DateTime? startDate = null,
            DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return new TimeSeries(LoadAndUpdate(basketIndex, tickers, field.ToString().AsArray(), startDate, endDate, calendar));
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, IEnumerable<DataFieldsEnum> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(), fields, startDate, endDate, calendar);
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="compositionDate"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdate(IBasketIndex basketIndex, DateTime compositionDate, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(compositionDate), fields, startDate, endDate, calendar);
        }

        public TimeSerieDB LoadAndUpdate(IBasketIndex basketIndex, string ticker, string field, DateTime? startDate = null,
            DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, ticker.AsArray(), field.AsArray(), startDate, endDate, calendar).FirstOrDefault();
        }

        /// <summary>
        /// Load currencies
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="targetCurrency"></param>
        /// <param name="fixing"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSeries LoadAndUpdateCurrencies(IBasketIndex basketIndex, string targetCurrency, string fixing, DateTime? startDate = null, DateTime? endDate = null)
        {
            var currenciesTs = Load(basketIndex, basketIndex.BloombergTickers(), new[] { DataFieldsEnum.Currency }, startDate, endDate);

            var curveIds = currenciesTs.Select(c => c.Y.Any() ? c.EvaluateString() : c.Instrument.Substring(0, 3)).Distinct().Where(c => c != targetCurrency).Select(c => string.Format("{0}{1} {2}", c, targetCurrency, fixing).Trim()).ToArray();

            return basketIndex[DataFieldsEnum.Last, isResult: false] = new TimeSeries(Load(curveIds, DataFieldsEnum.Last.AsArray(), startDate, endDate));
        }

        /// <summary>
        /// Load currencies for dividends
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="dividends"></param>
        /// <param name="fixing"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSeries LoadAndUpdateDividendsCurrencies(IBasketIndex basketIndex, TimeSeries dividends, string fixing, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var currencies = dividends.SelectMany(ts => ts.Select(kv => new KeyValuePair<string, string>(basketIndex[DataFieldsEnum.Currency, ts.Instrument].EvaluateString(), ((Dividend)kv.Value).Currency))).Distinct().ToArray();

            var curveIds = currencies.Where(pair => pair.Key != pair.Value).Select(c => string.Format("{0}{1} {2}", c.Key, c.Value, fixing)).Distinct().ToArray();

            return basketIndex[DataFieldsEnum.Last, isResult: false] = new TimeSeries(Load(curveIds, DataFieldsEnum.Last.AsArray(), startDate, endDate, calendar));
        }

        /// <summary>
        /// Load data into Basket
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> LoadAndUpdateWithStrategy(IBasketIndex basketIndex, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, IDatesHandler datesHandler = null)
        {
            return Load(basketIndex, basketIndex.BloombergTickers(), field.ToString().AsArray(), startDate, endDate, calendar, datesHandler: datesHandler);
        }

        /// <summary>
        /// Load currencies for dividends
        /// </summary>
        /// <param name="basketIndex"></param>
        /// <param name="dividends"></param>
        /// <param name="fixing"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSeries LoadDividendsCurrencies(IBasketIndex basketIndex, TimeSeries dividends, string fixing, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var currencies = dividends.SelectMany(ts => ts.Select(kv => new KeyValuePair<string, string>(basketIndex[DataFieldsEnum.Currency, ts.Instrument].EvaluateString(), ((Dividend)kv.Value).Currency))).Distinct().ToArray();

            var curveIds = currencies.Where(pair => pair.Key != pair.Value).Select(c => string.Format("{0}{1} {2}", c.Key, c.Value, fixing)).Distinct().ToArray();

            return Load(curveIds, DataFieldsEnum.Last.AsArray(), startDate, endDate, calendar);
        }

        /// <summary>
        ///  Load data simple with field as string
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerie<double> LoadNumeric(string ticker, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var series = Load(null, ticker.AsArray(), field.AsArray(), startDate, endDate, calendar).FirstOrDefault();
            return series != null ? (TimeSerie<double>)series : null;
        }

        /// <summary>
        ///  Load data simple with field as string
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerie<double> LoadNumeric(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return LoadNumeric(ticker, field.ToString(), startDate, endDate, calendar);
        }

        /// <summary>
        ///  Load data simple with field as DataFieldsEnum
        /// </summary>
        /// <param name="ticker"></param>
        /// <returns></returns>
        public Object LoadSpecificObject(Type requestedType, string ticker)
        {
            var series = Load(null, ticker.AsArray(), DataFieldsEnum.OtherString.ToString().AsArray(), DateTime.MinValue, DateTime.MinValue, requestedType: requestedType);
            return series != null ? series.FirstOrDefault().Y.LastOrDefault() : null;
        }

        /// <summary>
        ///  Load data simple with field as DataFieldsEnum
        /// </summary>
        /// <param name="ticker"></param>
        /// <returns></returns>
        public T LoadSpecificObject<T>(string ticker)
            where T : class
        {
            var series = Load(null, ticker.AsArray(), DataFieldsEnum.OtherString.ToString().AsArray(), DateTime.MinValue, DateTime.MinValue, requestedType: typeof(T));
            return series != null && series.Any() ? (T)series.First().Y.LastOrDefault() : null;
        }

        /// <summary>
        ///  Load data simple with field as string
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSerie<string> LoadString(string ticker, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var series = Load(null, ticker.AsArray(), field.AsArray(), startDate, endDate, calendar);
            return series != null ? series.FirstOrDefault() : null;
        }

        /// <summary>
        /// Load volatility matrix
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<EdaVol> LoadVolatility(string ticker, DataFieldsEnum field, DateTime startDate, DateTime endDate)
        {
            IList<EdaVol> volatilities = new List<EdaVol>();

            if (field == DataFieldsEnum.VolatilityForward || field == DataFieldsEnum.VolatilitySpot)
            {
                var result = Load(ticker.AsArray(), field.AsArray(), startDate, endDate);

                if (result != null)
                {
                    int i = 0;
                    foreach (IMarketData data in result[field, ticker].Y)
                    {
                        IVolatilityMatrix matrix = (IVolatilityMatrix)data;

                        volatilities.Add(SophisHelper.Convert(matrix, ticker, result[field, ticker].X.ToList()[i]));

                        i++;
                    }
                }
            }

            return volatilities;
        }

        /// <summary>
        /// Load data with metadata
        /// </summary>
        /// <param name="tickers">Tickers to download</param>
        /// <param name="field">Data</param>
        /// <param name="metaDataField">Field giving informations about data</param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public TimeSeriesWithMetaData LoadWithMetaData(IEnumerable<string> tickers, DataFieldsEnum field, DataFieldsEnum metaDataField, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            return new TimeSeriesWithMetaData
            {
                Data = new TimeSeries(Load(tickersAsArray, field.AsArray(), startDate, endDate, calendar)),
                MetaData = new TimeSeries(Load(tickersAsArray, metaDataField.AsArray(), startDate, endDate, calendar))
            };
        }

        /// <summary>
        /// Load the market data
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="calendar"></param>
        /// <returns></returns>
        public TimeSeries LoadWithoutPreload(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields,
            DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            return Load(false, tickers, fields, startDate, endDate, calendar);
        }

        public TimeSerieDB LoadWithStrategy(IBasketIndex basketIndex, string ticker, DataFieldsEnum field, DateTime? startDate = null,
            DateTime? endDate = null, IDatesHandler datesHandler = null, IPricingCalendar calendar = null)
        {
            return Load(basketIndex, ticker.AsArray(), field.ToString().AsArray(), startDate, endDate, calendar, null, true, datesHandler).FirstOrDefault();
        }

        /// <summary>
        /// Save TimeSeries
        /// </summary>
        /// <param name="timeSeries"></param>
        public void Save(IList<TimeSerieDB> timeSeries)
        {
            entryPoint.Save(timeSeries, PricingContext);
        }

        /// <summary>
        /// Save TimeSeries
        /// </summary>
        /// <param name="timeSeries"></param>
        public void Save(IList<TimeSerieDB> timeSeries, bool noCacheSaving)
        {
            entryPoint.Save(timeSeries, GetSaveLoadingContext(noCacheSaving));
        }

        public void Save(string basketName, BasketIndex basket)
        {
            if (PricingContext.BasketList != null)
            {
                PricingContext.BasketList.CreationDate = PricingContext.BasketList.ComputationDate ?? DateTime.Now;
                PricingContext.BasketList.ComputationDate = PricingContext.BasketList.ComputationDate ?? DateTime.Now;
                basket.Name = basketName;
                if (PricingContext.BasketList.Baskets.Any(b => b.Name == basketName && b.Parameter == basket.Parameter))
                {
                    var toRemove = PricingContext.BasketList.Baskets.Where(b => b.Name == basketName && b.Parameter == basket.Parameter).ToArray();
                    toRemove.ForEach(oldBasket => PricingContext.BasketList.Baskets.Remove(oldBasket));
                }
                PricingContext.BasketList.Baskets.Add(basket);
            }
        }

        private TimeSerieDB[] GetCustomValuesToSave(BasketIndex basket)
        {
            var timeSeries = new List<TimeSerieDB>();

            foreach (var resData in basket.ResultData.Where(x => x.Key != BasketIndex.OptionTimeSerieKey).ToArray())
            {
                timeSeries.AddRange(resData.Value.Where(ts => ts.Field.ToString() != ts.FieldName || new[] { DataFieldsEnum.Other, DataFieldsEnum.OtherString, DataFieldsEnum.OtherUnDated, DataFieldsEnum.Calendar }.Contains(ts.Field)).Select(
                        r =>
                            new TimeSerieDB(r.X.ToList(), r.Y.ToList(), GetBasketSeriePath(PricingContext.CurrentIndexPath, resData.Key, r.Instrument),
                            GetSerieField(r), r.Context)).ToArray());
            }

            return timeSeries.ToArray();
        }

        public void SetBasketsEffectiveDate(DateTime effectiveDate)
        {
            if (PricingContext.BasketList != null)
            {
                PricingContext.BasketList.EffectiveDate = effectiveDate;
            }
        }

        public void SetBasketsCalculationDate(DateTime calculationDate)
        {
            if (PricingContext.BasketList != null)
            {
                PricingContext.BasketList.CalculationDate = calculationDate;
            }
        }

        private DataFieldsEnum GetSerieField(TimeSerieDB ts)
        {
            if (ts.Field == DataFieldsEnum.Calendar)
                return DataFieldsEnum.Calendar;

            if (ts.Y.All(x => x is MarketDataString))
                return DataFieldsEnum.OtherString;

            return DataFieldsEnum.Other;
        }

        public void Save(string ticker, double value, DateTime? date = default(DateTime?))
        {
            InternalSave(ticker, DataFieldsEnum.Other, new MarketDataDouble(value), date, null);
        }

        public void Save(string ticker, string value, DateTime? date = default(DateTime?))
        {
            InternalSave(ticker, DataFieldsEnum.OtherString, new MarketDataString(value), date, null);
        }

        public void Save(IBasketIndex basketIndex, string ticker, DataFieldsEnum field, double value, DateTime? date = default(DateTime?))
        {
            InternalSave(ticker, field, new MarketDataDouble(value), date, basketIndex);
        }

        public void Save(IBasketIndex basketIndex, string ticker, DataFieldsEnum field, string value, DateTime? date = default(DateTime?))
        {
            InternalSave(ticker, field, new MarketDataString(value), date, basketIndex);
        }

        public void SaveBaskets(string ticker, IList<BasketIndexList> basketComponentLists)
        {
            SaveBasketsResultOnly(ticker, basketComponentLists);

            SaveBasketsAudit(ticker, basketComponentLists);

            SaveCustomValues(basketComponentLists);
        }

        public void SaveBasketsAudit(string ticker, long indexId)
        {
            var baskets = GetBasketsAuditToSave(ticker);

            SaveBasketsAudit(indexId.ToString(), baskets);
        }

        public void SaveBasketsAudit(string ticker, IList<BasketIndexList> basketComponentLists)
        {
            Save(new[]
            {
                new TimeSerieDB(
                    basketComponentLists.Select(
                        x => new KeyValuePair<DateTime, IMarketData>(x.VersionDate.GetValueOrDefault(), x)).ToList(), ticker,
                    DataFieldsEnum.IndexAuditBasketResult),
            });
        }

        public void SaveBasketsResultOnly(string ticker, long indexId)
        {
            var baskets = GetBasketsToSave(ticker);

            SaveBasketsResultOnly(indexId.ToString(), baskets);
        }

        public void SaveBasketsResultOnly(string ticker, IList<BasketIndexList> basketComponentLists)
        {
            Save(new[]
                {
                    new TimeSerieDB(basketComponentLists.Select(x => new KeyValuePair<DateTime, IMarketData>(x.VersionDate.GetValueOrDefault(), new BasketIndexList(x.VersionDate.GetValueOrDefault(), x.Baskets.Where(b => b.Name != BasketIndex.AuditBasketName).ToArray())
                    {
                        ComputationDate = x.ComputationDate,
                        CreationDate = x.CreationDate,
                        Creator = x.Creator,
                        EffectiveDate = x.EffectiveDate,
                        Validated = x.Validated,
                        ValidationDate = x.ValidationDate,
                        Validator = x.Validator,
                        VersionDate = x.VersionDate,
                        CalculationDate = x.CalculationDate,
                    })).ToList(), ticker, DataFieldsEnum.IndexBasketResult)
                });
        }

        public bool SaveCalculationInstruction(long projectId)
        {
            var dataProviderTreeOnly = new TimeSeriesProvider(tree, isTreeOnly: true);
            var calculationInstructions = dataProviderTreeOnly.GetInstructionsFromProjectId(projectId);

            if (calculationInstructions.Any())
            {
                Save(calculationInstructions);

                return true;
            }

            return false;
        }

        /// <summary>
        /// Save index specific data from current tree
        /// </summary>
        /// <param name="paths"></param>
        /// <param name="indexPaths">Index paths</param>
        /// <param name="noCacheSaving"></param>
        public void SaveCustomValues(OverloadedMarketDataTree tree, string[] indexPaths, bool noCacheSaving)
        {
            Save(MarketDataTreeUtils.GetCustomDataFromTree(tree.OriginalTree.Tree, indexPaths), noCacheSaving);
        }

        public void SaveCustomValues(IList<BasketIndexList> basketComponentLists)
        {
            basketComponentLists.SelectMany(basketList => basketList.Baskets).ForEach(basket => Save(GetCustomValuesToSave(basket)));
        }

        public void SaveCustomValues(string indexPath, bool noCacheSaving)
        {
            Save(MarketDataTreeUtils.GetCustomDataFromTree(MarketDataService.CurrentOverloadedMarketDataTree.OriginalTree.Tree, indexPath.AsArray()), noCacheSaving);
        }

        public bool SaveNewIndexResults(long projectId, string ticker, long indexId)
        {
            SaveQuotes(ticker, indexId);

            SaveBasketsResultOnly(ticker, indexId);
            SaveBasketsAudit(ticker, indexId);

            SaveCalculationInstruction(projectId);

            SaveCustomValues(ticker, false);

            return true;
        }

        public void SaveQuotes(string ticker, IEnumerable<IIndexQuote> indexQuotes)
        {
            Save(new[]
                {
                    new TimeSerieDB(indexQuotes.Select(x => new KeyValuePair<DateTime, IMarketData>(x.Date, x)).ToList(), ticker, DataFieldsEnum.IndexQuote)
                });
        }

        public bool SaveQuotes(string ticker, long indexId)
        {
            var dataProviderTreeOnly = new TimeSeriesProvider(tree, isTreeOnly: true);

            var resultQuotes = dataProviderTreeOnly.GetResultQuotes(ticker);

            if (resultQuotes.Count != 0)
            {
                var quotesTs = resultQuotes[0];

                var elements = quotesTs.GetElements().Where(
                    ts =>
                        ts.Value is IndexQuote &&
                        ((IndexQuote)ts.Value).Id == 0).ToList();

                TimeSerieDB quotes =
                    new TimeSerieDB(elements,
                        indexId.ToString(),
                        quotesTs.Field,
                        quotesTs.Context);

                Save(quotes.AsArray());
            }

            return false;
        }

        public void UpdateBasket(IBasketIndex basketIndex, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, field, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, field, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, IEnumerable<DataFieldsEnum> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, fields, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, fields, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, string ticker, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, ticker, field, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, ticker, field.ToString(), startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, IEnumerable<string> tickers, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, tickers, fields, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, DateTime compositionDate, IEnumerable<string> fields, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, compositionDate, fields, startDate, endDate, calendar);
        }

        public void UpdateBasket(BasketIndex basketIndex, string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, ticker, field, startDate, endDate, calendar);
        }

        public void UpdateBasket(IBasketIndex basketIndex, string[] tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdate(basketIndex, tickers, field, startDate, endDate, calendar);
        }

        public void UpdateBasketLocalData(BasketIndex basketIndex, string indexPath, string field,
            DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, string[] excludedTickers = null, bool withPreload = false, bool isStringData = false)
        {
            Func<IBasketComponent, string> selector = 
                (comp) => string.IsNullOrWhiteSpace(comp.InstrumentName) ? comp.BloombergTicker : comp.InstrumentName;

            var tickersWithTransco = basketIndex.LastComposition
                                        .Where(kv => 
                                            !(excludedTickers ?? new string[0]).Contains(selector(kv)))
                                        .ToDictionary(x => GetBasketSeriePath(indexPath, field, selector(x)), x => selector(x));

            var fieldToLoad = isStringData ? 
                                DataFieldsEnum.OtherString 
                                : ParseUpdateLocalDataField(field);

            var timeSeries = withPreload ? 
                                Load(true, tickersWithTransco.Keys.ToArray(), fieldToLoad.AsArray(), startDate, endDate, calendar, loadInLocal: false) 
                                : Load(false, tickersWithTransco.Keys.ToArray(), fieldToLoad.AsArray(), startDate, endDate, calendar, loadInLocal: false);

            foreach (var tickerWithTransco in tickersWithTransco)
            {
                var timeSerieDB = timeSeries.FirstOrDefault(ts => ts.Instrument == tickerWithTransco.Key);

                basketIndex.AddTimeSeries(field, new TimeSeries(timeSerieDB != null ? new TimeSerieDB(timeSerieDB.X.ToList(), timeSerieDB.Y.ToList(), tickerWithTransco.Value, fieldToLoad).AsArray() : new TimeSerieDB[0]));
            }
        }

        private DataFieldsEnum ParseUpdateLocalDataField(string field)
        {
            DataFieldsEnum result;
            if (Enum.TryParse(field, out result))
            {
                if (result == DataFieldsEnum.Calendar || result == DataFieldsEnum.Other || result == DataFieldsEnum.OtherString || result == DataFieldsEnum.OtherUnDated)
                {
                    return result;
                }
            }

            return DataFieldsEnum.Other;
        }

        public void UpdateBasketLocalData(BasketIndex basketIndex, string[] tickers, string indexPath, string field,
            DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, bool withPreload = false)
        {
            var tickersWithTransco = tickers.ToDictionary(x => GetBasketSeriePath(indexPath, field, x), x => x);
            var fieldToLoad = ParseUpdateLocalDataField(field);
            var timeSeries = withPreload ? Load(true, tickersWithTransco.Keys.ToArray(), fieldToLoad.AsArray(), startDate, endDate, calendar, loadInLocal: false) : Load(false, tickersWithTransco.Keys.ToArray(), fieldToLoad.AsArray(), startDate, endDate, calendar, loadInLocal: false);

            foreach (var tickerWithTransco in tickersWithTransco)
            {
                var timeSerieDB = timeSeries.FirstOrDefault(ts => ts.Instrument == tickerWithTransco.Key);

                basketIndex.AddTimeSeries(field, new TimeSeries(timeSerieDB != null ? new TimeSerieDB(timeSerieDB.X.ToList(), timeSerieDB.Y.ToList(), tickerWithTransco.Value, fieldToLoad).AsArray() : new TimeSerieDB[0]));
            }
        }

        public void UpdateBasketLocalData(BasketIndex basketIndex, string ticker, string indexPath, string field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, bool withPreload = false)
        {
            var basketSeriePath = GetBasketSeriePath(indexPath, field, ticker);
            var fieldToLoad = ParseUpdateLocalDataField(field);
            var timeSerieDB = withPreload ? Load(basketSeriePath, fieldToLoad, startDate, endDate, calendar) : LoadWithoutPreload(basketSeriePath.AsArray(), fieldToLoad.AsArray(), startDate, endDate, calendar).FirstOrDefault();
            basketIndex.AddTimeSeries(field, new TimeSeries(timeSerieDB != null ? new TimeSerieDB(timeSerieDB.X.ToList(), timeSerieDB.Y.ToList(), ticker, fieldToLoad).AsArray() : new TimeSerieDB[0]));
        }

        public void UpdateBasketWithForeignDividends(IBasketIndex basketIndex, TimeSeries dividends, string fixing, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null)
        {
            LoadAndUpdateDividendsCurrencies(basketIndex, dividends, fixing, startDate, endDate, calendar);
        }

        public IList<TimeSerieDB> UpdateBasketWithoutPreload(BasketIndex basketIndex, DataFieldsEnum field, DateTime startDate, DateTime endDate)
        {
            return Load(false, basketIndex.LastComposition.BloombergTickers(), field.AsArray(), startDate, endDate);
        }

        public void UpdateBasketWithStrategy(IBasketIndex basketIndex, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, IPricingCalendar calendar = null, IDatesHandler datesHandler = null)
        {
            LoadAndUpdateWithStrategy(basketIndex, field, startDate, endDate, calendar, datesHandler);
        }

        public IList<GlobalTaxConfiguration> LoadTaxConfigurations(IEnumerable<string> tickers, DateTime? startDate, DateTime? endDate, DateTime? versionDate)
        {
            try
            {
                var tsDto = PersistanceService.IndexProvider.LoadTimeSeriesString(tickers.ToArray(), (int)DataFieldsEnum.OtherString, "DB", startDate, endDate, versionDate,
                    UserService.CaesarSession, (int)DataType.TaxConfiguration);
                var ts = converter.ConvertFromDTO(tsDto);
                if (ts.Length != 0 && ts.Any(i => i.Count != 0))
                {
                    var elements = ts.Select(i => i.GetElements());
                    var loadedConfigurations = elements.SelectMany(i => i).Select(i => i.Value as GlobalTaxConfiguration).ToList();
                    return loadedConfigurations;
                }
                return null;
            }
            catch (Exception e)
            {
                LoggingService.Error(this.GetType(), e);
                return null;
            }
        }

        public GlobalTaxConfiguration LoadLatestTaxConfiguration(string ticker, DateTime? date)
        {
            try
            {
                var tsDto = PersistanceService.IndexProvider.LoadTimeSeriesString(new[] { ticker }, (int)DataFieldsEnum.OtherString, "DB", null, null, null,
                    UserService.CaesarSession, (int)DataType.TaxConfiguration);
                var ts = converter.ConvertFromDTO(tsDto);
                if (ts.Length != 0 && ts.Any(i => i.Count != 0))
                {
                    var elements = ts.Select(i => i.GetElements());
                    var loadedConfigurations = elements.SelectMany(i => i).Select(i => i.Value as GlobalTaxConfiguration).ToList();
                    var eligibleConfigurations = loadedConfigurations.Where(i => i.VersionDate <= date).OrderByDescending(i => i.VersionDate);

                    return eligibleConfigurations.FirstOrDefault();
                }
                return null;
            }
            catch (Exception e)
            {
                LoggingService.Error(this.GetType(), e);
                return null;
            }
        }
        #endregion

        #region Private Methods
        private static void CheckIfDataIsNull(IList<TimeSerieDB> itemsToFilter, string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray,
            DateTime? requestedStartDate, DateTime? requestedEndDate)
        {
            CheckIfDataIsNull(itemsToFilter, tickersAsArray,
                dataFieldsAsArray.Select(x => x.ToString()).ToArray(),
                requestedStartDate, requestedEndDate);
        }

        private static void CheckIfDataIsNull(IList<TimeSerieDB> itemsToFilter, string[] tickersAsArray,
            string[] dataFieldsAsArray,
            DateTime? requestedStartDate, DateTime? requestedEndDate)
        {
            if (itemsToFilter == null)
            {
                throw new MissingDataException(string.Join(",", dataFieldsAsArray), requestedStartDate.GetValueOrDefault(), requestedEndDate.GetValueOrDefault(DateTime.MaxValue),
                    string.Format("Null data series found for [{0}/{1}] for [{2:dd/MM/yyyy}-{3:dd/MM/yyyy}]",
                        tickersAsArray.Stringify(","), dataFieldsAsArray.Stringify(","), requestedStartDate,
                        requestedEndDate));
            }
        }
        private static DateTime Max(params DateTime[] values)
        {
            return values.Max();
        }

        private static DateTime Min(params DateTime[] values)
        {
            return values.Min();
        }

        private void AddTimeSerieToAudit(IEnumerable<TimeSerieDB> timeSeries)
        {
            if (PricingContext != null && PricingContext.AuditDataBasket != null && timeSeries != null)
            {
                PricingContext.AuditDataBasket.AddTimeSeries(new TimeSeries(timeSeries), false);
            }
        }

        private void AddTimeSerieToAudit(TimeSerieDB timeSerie)
        {
            if (timeSerie == null)
                return;
            AddTimeSerieToAudit(timeSerie.AsArray());
        }

        private void CheckDateLimits(DateTime? endDate)
        {
            if (PricingContext == null)
                return;

            if (endDate.GetValueOrDefault() > PricingContext.ReferenceDate)
            {
                throw new InvalidOperationException(
                    String.Format("Requesting data further than pricing date is not allowed. Requesting date was [{0}].",
                        endDate.GetValueOrDefault()));
            }
        }

        private TimeSerieDB[] FilterTimeSeries(string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray, DateTime? requestedStartDate, DateTime? requestedEndDate, IList<TimeSerieDB> itemsToFilter, bool filterDataByCal, IPricingCalendar calendar = null)
        {
            var result = itemsToFilter.Where(ts => dataFieldsAsArray.Contains(ts.Field) && tickersAsArray.Contains(ts.Instrument)).ToArray();

            result = result.Where(ts => ts.X.Any() && ts.X.First() == DateTime.MinValue)
                .Union(result.Where(ts => !ts.X.Any() || ts.X.FirstOrDefault() != DateTime.MinValue).Select(ts => ts.GetPeriod(requestedStartDate, requestedEndDate))).ToArray();

            if (!filterDataByCal)
                return result;

            List<TimeSerieDB> filteredResult = null;
            var opendayscal = calendar as OpenDaysCalendar;
            if (calendar != null && (opendayscal == null || opendayscal.OpenDays.Length > 0))
            {
                var closedDays = calendar.GetHolidays(
                    requestedStartDate ?? (result.Min(ts => ts.StartDate.Value)),
                    requestedEndDate ?? (result.Max(ts => ts.EndDate.Value)));

                if (closedDays.Length > 0)
                {
                    filteredResult = new List<TimeSerieDB>(result.Length);

                    foreach (var timeserie in result)
                    {
                        ////filter values on timeserie for wich the calendar is a closed day
                        var opendaysvalues = timeserie.Where(o => o.Key != closedDays.InferiorBound(DateTime.Compare, o.Key)).ToList();
                        if (opendaysvalues.Count != timeserie.Count)
                        {
                            filteredResult.Add(new TimeSerieDB(opendaysvalues, timeserie.Instrument, timeserie.Field, timeserie.Context));
                        }
                        else
                        {
                            filteredResult.Add(timeserie);
                        }
                    }
                }
            }

            return filteredResult != null ? filteredResult.ToArray() : result;
        }

        private string GetBasketSeriePath(string currentPath, string field, string instrument)
        {
            return DataPath.Create(currentPath, field + "." + instrument);
        }

        private BasketIndexList[] GetBasketsToSave(string ticker)
        {
            var dataProviderTreeOnly = new TimeSeriesProvider(tree, isTreeOnly: true);

            var baskets = dataProviderTreeOnly.GetBaskets(ticker, DateTime.MinValue, DateTime.MaxValue, false);

            return baskets != null ? baskets.Select(b => (BasketIndexList)b.Value).ToArray() : new BasketIndexList[0];
        }

        private BasketIndexList[] GetBasketsAuditToSave(string ticker)
        {
            var dataProviderTreeOnly = new TimeSeriesProvider(tree, isTreeOnly: true);

            var baskets = dataProviderTreeOnly.GetBasketsAudit(ticker, DateTime.MinValue, DateTime.MaxValue);

            return baskets != null ? baskets.Select(b => (BasketIndexList)b.Value).ToArray() : new BasketIndexList[0];
        }

        private IDataHandler GetDataHandlerFromName(string dataHandlerName)
        {
            var currentHandler = entryPoint;

            while (currentHandler != null && currentHandler.Name != dataHandlerName)
            {
                currentHandler = currentHandler.NextHandler;
            }

            return currentHandler;
        }

        private IDataHandler GetEntryPointWithoutTranscoding(IDataHandler dataHandler)
        {
            if (dataHandler is InternalTickerDataHandler)
            {
                return dataHandler.NextHandler;
            }

            return dataHandler;
        }

        /// <summary>
        /// Get Index Pricing Instruction from product name
        /// </summary>
        /// <param name="projectId"></param>
        /// <returns>Pricing sequence</returns>
        private IList<TimeSerieDB> GetInstructionsFromProjectId(long projectId)
        {
            var timeSeries = entryPoint.Load(projectId.ToString().AsArray(), DataFieldsEnum.IndexPricingInstruction.AsArray(),
                DateTime.MinValue, DateTime.MinValue);

            return timeSeries;
        }

        private ILoadingContext GetLoadingContext(IPricingCalendar calendar, IDatesHandler datesHandler, Type requestedType, bool loadInLocal)
        {
            var versionDate = PricingContext != null ? PricingContext.VersionDate : null;

            var context = calendar == null
                ? PricingContext
                : new PricingContext(PricingContext.ReferenceDate, PricingContext.StartComputationDate,
                PricingContext.EndComputationDate, PricingContext.IndexPaths, PricingContext.CurrentIndexPath, calendar, PricingContext.CancellationToken, PricingContext.ProjectName, loadInLocal);

            if (context == null && (datesHandler != null || requestedType != null || !loadInLocal))
            {
                context = new PricingContext("", new string[0]);
            }

            if (context != null)
            {
                context.VersionDate = PricingReference.ReferenceDate != default(DateTime)
                    ? (DateTime?)PricingReference.ReferenceDate.AddDays(1)
                    : null;

                if(versionDate.HasValue)
                {
                    context.VersionDate = versionDate;
                }

                context.LoadInLocal = loadInLocal;
                context.DBSource = DBSource;
                context.RequestedType = requestedType;

                context.DatesHandlers = datesHandler != null ? datesHandler.AsArray() : null;
            }

            return context;
        }

        private PricingContext GetLoadingContextWithVersionDate(DateTime? versionDate)
        {
            var copyPricingContext = PricingContext != null ? (PricingContext)PricingContext.Clone() : new PricingContext();

            copyPricingContext.VersionDate = versionDate;

            return copyPricingContext;
        }

        private DateTime? GetRequestedEndDate(DateTime? endDate)
        {
            if (PricingContext == null)
            {
                return endDate;
            }

            return endDate.GetValueOrDefault(PricingContext.ReferenceDate);
        }

        private DateTime? GetRequestedStartDate(DateTime? startDate, DateTime? endDate)
        {
            if (PricingContext == null)
            {
                return startDate;
            }

            return !startDate.HasValue && !endDate.HasValue ? PricingContext.ReferenceDate : startDate.GetValueOrDefault(PricingContext.StartComputationDate);
        }

        private PricingContext GetSaveLoadingContext(bool noCacheSaving)
        {
            var ctx = PricingContext != null ? (PricingContext)PricingContext.Clone() : new PricingContext();

            if (PricingContext != null)
            {
                ctx.OnProgessChanged += (sender, args) =>
                {
                    PricingContext.RaiseOnProgessChanged(sender, args);
                };
            }

            ctx.DisabledSavingSources = noCacheSaving ? "CACHE".AsArray() : new string[0];

            return ctx;
        }

        /// <summary>
        /// Translate tickers if it's an index
        /// </summary>
        /// <param name="tickers"></param>
        /// <returns></returns>
        private string[] GetTickersToTreat(string[] tickers)
        {
            if (PricingContext == null)
            {
                return tickers;
            }

            var res = new List<string>();

            foreach (var ticker in tickers)
            {
                string fullPath;

                if (PricingContext.IndexPaths != null && (fullPath = PricingContext.IndexPaths.FirstOrDefault(p => p.Split(StrategyTree.PathDelimiter).Last() == ticker)) != null)
                {
                    res.Add(fullPath);
                }
                else
                {
                    res.Add(ticker);
                }
            }

            return res.ToArray();
        }

        private void InitializeTreeOnly()
        {
            IDataHandler cacheHandler = new DataHandler("CACHE", new ProviderMono(new MarketDataTreeExecutable(ref tree)));
            entryPoint = cacheHandler;
        }
        /// <summary>
        /// save a IMarketdata, optionally in a basket
        /// </summary>
        /// <param name="date">Value Date</param>
        /// <param name="ticker">Ticker</param>
        /// <param name="field">Field</param>
        /// <param name="value">Value</param>
        /// <param name="basketIndex">Basket where store result for display</param>
        private void InternalSave(string ticker, DataFieldsEnum field, IMarketData value, DateTime? date = null, IBasketIndex basketIndex = null)
        {
            var timeSerieDB = new TimeSerieDB(date ?? PricingContext.ReferenceDate, value, PricingContext.CurrentIndexPath + MarketDataMgr.Trees.MarketDataTree.PathDelimiter + ticker, field);
            entryPoint.Save(timeSerieDB.AsArray(), PricingContext);

            if (basketIndex != null)
            {
                basketIndex[field, ticker] = timeSerieDB;
            }
        }

        private IList<TimeSerieDB> Preload(IDataHandler handler, string[] tickersAsArray, DataFieldsEnum[] fieldsAsArray, DateTime? startDate, DateTime? endDate, ILoadingContext context)
        {
            var preloadStartDate = startDate.GetValueOrDefault();

            if (endDate == null || endDate == DateTime.MinValue)
            {
                // if no endDate
                return handler.Load(tickersAsArray, fieldsAsArray,
                    preloadStartDate, endDate.GetValueOrDefault(), context);
            }
            else
            {
                // There is a endDate: Preload up to 31/12 of that endDate.year 
                // or PricingContext.EndComputationDate if earlier
                var lastEndDateYearDate = new DateTime(endDate.GetValueOrDefault().Year, 12, 31);

                var preloadEnd = Max(endDate.GetValueOrDefault(PricingContext.ReferenceDate),
                                 Min(lastEndDateYearDate, PricingContext.EndComputationDate));

                return handler.Load(tickersAsArray, fieldsAsArray,
                    preloadStartDate, preloadEnd, context);
            }
        }

        #endregion
    }
}