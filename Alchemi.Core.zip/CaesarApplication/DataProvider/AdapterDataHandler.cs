﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class AdapterDataHandler : DataHandler
    {
        private readonly ITickerHandler[] tickerHandlersList;

        public AdapterDataHandler(ITickerHandler[] tickerHandlersList)
        {
            this.tickerHandlersList = tickerHandlersList;
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate, ILoadingContext context,
            bool removeEmptySeries = false)
        {
            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();
            var originalTickers = tickers.ToArray();

            var tickerHandlers = new Dictionary<string, ITickerHandler>();
            var tickersToTreat = GetTickersToTreat(originalTickers, dataFieldsAsArray, tickerHandlers);

            var result = GetResultFromSuccessor(startDate, endDate, tickersToTreat, dataFieldsAsArray, context, false);

            result = AggregateResults(result, originalTickers, dataFieldsAsArray, tickerHandlers);

            return result;
        }

        protected override void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
        }

        private IList<TimeSerieDB> AggregateResults(IList<TimeSerieDB> dataSeries, IEnumerable<string> originalTickers, DataFieldsEnum[] dataFields, Dictionary<string, ITickerHandler> tickerHandlers)
        {
            var result = new List<TimeSerieDB>();

            foreach (var originalTicker in originalTickers)
            {
                if (tickerHandlers.ContainsKey(originalTicker))
                {
                    foreach (var dataField in dataFields)
                    {
                        var tickerHandler = tickerHandlers[originalTicker];

                        if (tickerHandler.ImpactedFields.Contains(dataField))
                        {
                            var calculationMembersTickers = tickerHandler.GetTickersToRequest(originalTicker);

                            var calculationMembers =
                                dataSeries.Where(
                                    ts =>
                                        calculationMembersTickers.Contains(ts.Instrument.ToUpper()) &&
                                        tickerHandler.CalculationFields[dataField].Contains(ts.Field))
                                        .GroupBy(x => x.Instrument)
                                        .ToDictionary(x => x.Key, x => x.ToArray());

                            result.AddRange(tickerHandler.Calculate(originalTicker, dataField, calculationMembers));
                        }
                        else
                        {
                            result.AddRange(dataSeries.Where(x => x.Instrument == originalTicker && x.Field == dataField));
                        }
                    }
                }
                else
                {
                    result.AddRange(dataSeries.Where(x => x.Instrument == originalTicker));
                }
            }

            return result;
        }

        private string[] GetTickersToTreat(string[] originalTickers, DataFieldsEnum[] fields, Dictionary<string, ITickerHandler> handlers)
        {
            var result = new List<string>();

            foreach (var originalTicker in originalTickers)
            {
                if (originalTicker == null || originalTicker =="")
                {
                    //Drop the ticker
                    //AddIfNotExists(result, "");
                    continue;
                }
                var tickerHandler = tickerHandlersList.FirstOrDefault(x => Regex.IsMatch(originalTicker, x.TickerRegex));
                
                if (tickerHandler != null )
                {
                    var impactedFields = fields.Where(f => tickerHandler.ImpactedFields.Contains(f)).ToArray();
                    if (impactedFields.Length > 0)
                    {
                        handlers.Add(originalTicker, tickerHandler);

                        AddIfNotExists(result, tickerHandler.GetTickersToRequest(originalTicker));

                        if (impactedFields.Length != fields.Length)
                        {
                            AddIfNotExists(result, originalTicker);
                        }
                    }
                    else
                    {
                        AddIfNotExists(result, originalTicker);
                    }
                }
                else
                {
                    AddIfNotExists(result, originalTicker);
                }
            }

            return result.ToArray();
        }

        private static void AddIfNotExists(List<string> result, string ticker)
        {
            if (!result.Contains(ticker))
            {
                result.Add(ticker);
            }
        }

        private static void AddIfNotExists(List<string> result, string[] tickers)
        {
            tickers.ForEach(t => AddIfNotExists(result, t));
        }
    }
}
