using GlobalDerivativesApplications.Sophis;
using System;
using System.Linq;
using System.Text.RegularExpressions;
using PricingBase.DataProvider;
using System.Collections.Generic;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public abstract class InstrumentCodeTranscoder
    {
        public virtual string TranscodeInternalToExternal(string internalCode, ILoadingContext context)
        {
            return TranscodeInternalToExternal(internalCode.AsArray(), context)[0];
        }

        public virtual string TranscodeExternalToInternal(string externalCode, ILoadingContext context)
        {
            return TranscodeExternalToInternal(externalCode.AsArray(), context)[0];
        }

        public virtual string[] TranscodeInternalToExternal(string[] internalCodes, ILoadingContext context)
        {
            return internalCodes.Select(c => TranscodeInternalToExternal(c, context)).ToArray();
        }

        public virtual string[] TranscodeExternalToInternal(string[] externalCodes, ILoadingContext context)
        {
            return externalCodes.Select(c => TranscodeExternalToInternal(c, context)).ToArray();
        }

        protected bool IsMissingInstrumentException(Exception ex)
        {
            return ex is SophisManagerException && (ex.Message.Contains("Bad instrument reference") || Regex.IsMatch(ex.Message, "Instrument with Reference (.*) is not found"));
        }
    }
}