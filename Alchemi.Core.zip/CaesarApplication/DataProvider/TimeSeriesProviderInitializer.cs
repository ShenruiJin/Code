﻿using CaesarApplication.DataProvider.Bloomberg;
using CaesarApplication.DataProvider.CSV;
using CaesarApplication.DataProvider.Database;
using CaesarApplication.DataProvider.MarketDataTree;
using CaesarApplication.DataProvider.Prism;
using CaesarApplication.DataProvider.Sophis;
using CaesarApplication.DataProvider.TickerHandlers;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using GlobalDerivativesApplications.DynamicDataExchange.BloombergServices;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using System;
using System.Configuration;
using System.Linq;
using System.Threading;
using CaesarApplication.DataProvider.Database.Converters;
using DealServerInterface.Service;
using FuncFramework.Business;
using OverloadedMarketDataTree = MarketDataMgr.Trees.Ext.OverloadedMarketDataTree;
using CaesarApplication.DataProvider.IndexValues;
using CaesarApplication.DataProvider.CAT;
using CaesarApplication.DataProvider.Derivatives;

namespace CaesarApplication.DataProvider
{
    public class TimeSeriesProviderInitializer : ITimeSeriesProviderInitializer
    {
        private readonly string[] dataHandlersToUse;
        private readonly string[] dataHandlersToExclude;
        private readonly string[] dataHandlersToInclude;
        private readonly string[] specificDBSources;
        private static bool historicBloombergIsAvailable;
        private static ManualResetEvent onHistoricBloombergIsAvailableSettedEvent;

        private bool noFilterSources;

        private static readonly Object historicBloombergIsAvailableLockObj = new Object();

        private string BloombergDataHandlerName = "BBG";
        private bool filterWithHorizonDatesForSave;

        public TimeSeriesProviderInitializer(string[] dataHandlersToUse = null, 
            string[] dataHandlersToExclude = null, string[] specificDBSources = null, bool noFilterSources = false, bool filterWithHorizonDatesForSave = true, string[] dataHandlersToInclude = null)
        {
            this.dataHandlersToUse = dataHandlersToUse ?? GetDataHandlersFromCmdLine("dataHandlersToUse");
            this.dataHandlersToExclude = dataHandlersToExclude ?? GetDataHandlersFromCmdLine("dataHandlersToExclude") ?? new string[0];
            this.dataHandlersToInclude = dataHandlersToInclude ?? GetDataHandlersFromCmdLine("dataHandlersToInclude") ?? new string[0];
            this.specificDBSources = specificDBSources;
            this.noFilterSources = noFilterSources;
            this.filterWithHorizonDatesForSave = filterWithHorizonDatesForSave;
        }

        public static bool HistoricBloombergIsAvailable
        {
            get
            {
                lock (historicBloombergIsAvailableLockObj)
                {
                    if (onHistoricBloombergIsAvailableSettedEvent == null)
                    {
                        CheckHistoricBloombergIsAvailable();
                    }
                }

                onHistoricBloombergIsAvailableSettedEvent.WaitOne(TimeSpan.FromSeconds(30));
                return historicBloombergIsAvailable;

            }
            set
            {
                historicBloombergIsAvailable = value;
                onHistoricBloombergIsAvailableSettedEvent = new ManualResetEvent(true);
            }
        }

        private string[] GetDataHandlersFromCmdLine(string datahandlerstouse)
        {
            string dataHandlersToUseCmdLine = null;

            Environment.GetCommandLineArgs()
                .Consume(datahandlerstouse, (optname, value) => dataHandlersToUseCmdLine = value);

            return dataHandlersToUseCmdLine != null ? dataHandlersToUseCmdLine.Split(';', ',') : null;
        }

        /// <summary>
        /// Constructor - set the Chain of Responsability
        /// </summary>
        public IDataHandler Initialize(OverloadedMarketDataTree tree, bool noDbLoading, bool noCacheLoading, 
            bool isReadOnly, IDataHandler dataHandler, bool saveAsDefault = true, IIndexDBProviderFactory indexDBProviderFactory = null)
        {
            bool markSource = true;
            IDataHandler entryDataHandler = null;

            var dataHandlers = GetDataHandlers(tree, indexDBProviderFactory, noDbLoading, isReadOnly, markSource);
            var databaseHandler = dataHandlers.First(x => x.Name == "DB");

            var filteredDataHandlers = dataHandlers.Where(handler => handler != null && (dataHandlersToUse == null || IsMandatoryDataHandler(handler) || IsDataHandlerToUse(handler)) && !dataHandlersToExclude.Contains(handler.Name)).ToList();

            var sourcesOrderedByPriority = noFilterSources ? null : (specificDBSources ?? filteredDataHandlers.Select(x => x.Name).Distinct().Where(n => n != null).ToArray());


            IDataHandler previousDataHandler = null;
            foreach (var datahandler in filteredDataHandlers)
            {
                if (datahandler != null)
                {
                    if (null != previousDataHandler)
                    {
                        previousDataHandler.SetSuccessor(datahandler);
                    }
                    previousDataHandler = datahandler;

                    if (datahandler is IDataHandlerTechnical)
                    {
                        var dhAsTechnical = (IDataHandlerTechnical)datahandler;

                        var router = dhAsTechnical.Router as IProviderRouterTechnical;

                        if (router != null)
                        {
                            router.GlobalProviderExecutables
                            .Union(router.LocalProviderExecutables)
                                .Select(x => x.Value)
                                .Where(exec => exec is IDatabaseTimeSerieProviderBaseExecutable)
                                .Cast<IDatabaseTimeSerieProviderBaseExecutable>()
                                .ForEach(x =>
                                {
                                    x.HasSourceOverrided = dataHandlersToUse != null || dataHandlersToExclude.Any();
                                    x.SourcePriority = sourcesOrderedByPriority;
                                    x.SaveAsDefault = saveAsDefault;
                                });
                        }
                    }
                }
            }

            entryDataHandler = noCacheLoading ? (filteredDataHandlers.FirstOrDefault(x => x.Name == "DB") ?? filteredDataHandlers.First()) : filteredDataHandlers.First();

            return entryDataHandler;
        }

        public IDataHandler[] GetDataHandlers(OverloadedMarketDataTree tree, IIndexDBProviderFactory indexDBProviderFactory, bool noDbLoading, bool isReadOnly, bool markSource)
        {
            var cacheProvider = new ProviderMono(new MarketDataTreeExecutable(ref tree));
            var emptyTranscoder = new EmptyTranscoder();

            var adapterDataHandler = new AdapterDataHandler(new ITickerHandler[] { new GBpoundTickerHandler()});


            var resultDbProviderRouter = new ProviderRouter(
                new IProviderExecutable[]
                {
                    new DatabaseBasketResultExecutable(indexDBProviderFactory, new BasketResultDTOConverter()),
                    new DatabaseBasketAuditResultExecutable(indexDBProviderFactory, new BasketResultDTOConverter<BasketResultAuditDTO>()),
                    new DatabaseIndexQuoteProviderExecutable(indexDBProviderFactory, new IndexQuoteDtoConverter())
                }, isReadOnly);

            var localDbProviderRouter = CreateDataDBProviderRouter(false, true, new LocalIndexDBProviderFactory());

            var dbProviderRouter = CreateDataDBProviderRouter(isReadOnly, false, indexDBProviderFactory);


            var databaseInstrumentCodeTranscoder = new DatabaseInstrumentCodeTranscoder();

            IDataHandler cacheHandler = new DataHandler("Cache", cacheProvider);

            IDataHandler localCSVHandler = new DataHandler("LOCAL_CSV", new ProviderRouter(
                    new IProviderExecutable[]
                    {
                                    new LocalCSVDataExecutable()
                    }, true), new EmptyTranscoder(), markSource: markSource);

            IDataHandler localDatabaseHandler = new DataHandler("LOCAL_DB", localDbProviderRouter, databaseInstrumentCodeTranscoder, noDbLoading, horizonMaxDays: 0, shouldLoadPredicate: ctx => ctx == null || ctx.LoadInLocal, shouldSavePredicate:(ctx, ts) => !ts.Instrument.Contains(IndexPathHelper.Delimiter));

            IDataHandler databaseHandler = new DataHandler("DB", dbProviderRouter, databaseInstrumentCodeTranscoder, noDbLoading,
                horizonMaxDays: 0, filterWithHorizonDatesForSave: filterWithHorizonDatesForSave );

            IDataHandler resultDatabaseHandler = new DataHandler("DB", resultDbProviderRouter,
                new LocalDatabaseInstrumentCodeTranscoder(), noDbLoading, horizonMaxDays: 0,
                markSource: markSource, filterWithHorizonDatesForSave: false);

            IDataHandler csvHandler = new DataHandler("CSV",
                new ProviderRouter(new IProviderExecutable[] {
                    new OptionDescAndPricesCsvExecutable()
                }, true),
                emptyTranscoder, markSource: markSource);

            IDataHandler comexCsvHandler = new DataHandler("COMEX_CSV",
                    new ProviderRouter(new IProviderExecutable[] {
                                    new OptionDescAndPricesComexExecutable(),
                                    new FuturesComexExecutable()
                    }, true),
                    emptyTranscoder, markSource: markSource);

            IDataHandler derivativesHandler = new DataHandler("DERIVATIVES",
        new ProviderRouter(new IProviderExecutable[] {
                                    new FutureDatesProviderExecutable()
        }, true),
        emptyTranscoder, markSource: markSource);

            IDataHandler ivyHandler = new DataHandler("IVY", new ProviderRouter(new IProviderExecutable[] { new OptionDescAndPricesIvyExecutable() }, true), emptyTranscoder, markSource: markSource);

			IDataHandler csvCalendarHandler = new DataHandler("CSV_CALENDAR", new ProviderRouter(new IProviderExecutable[] { new CalendarCSVExecutable() }, true), emptyTranscoder, markSource: markSource);

            IDataHandler prismHandler = new DataHandler("PRISM", new ProviderRouter(
                new IProviderExecutable[]
                {
                    new OptionDescAndPricesPrismExecutable(),
                    new StringUndatedCustomFieldsPrismExecutable(AppDomain.CurrentDomain.BaseDirectory)
                }, true), new PrismTranscoder(), trusted: true, markSource: markSource);

            IDataHandler prismDividendHandler = new DataHandler("PRISM_DIVIDEND", new ProviderRouter(
    new IProviderExecutable[]
    {
                    new DividendsPrismExecutable(adapterDataHandler)
    }, true), new PrismTranscoder(), trusted: true, markSource: markSource);

            IDataHandler prismOSTHandler = new DataHandler("PRISM_OST", new ProviderRouter(
                 new IProviderExecutable[]
                 {
                        new OSTCollectionPrismExecutable(adapterDataHandler)
                 }, true), new BloombergTranscoder(), markSource: markSource, horizonMaxDays: -500);

            IDataHandler prismPriceHandler = new DataHandler("PRISM_PRICES", new ProviderRouter(
                new IProviderExecutable[] { new PricesPrismExecutable() }, true), new PrismTranscoder(), markSource: markSource);

            IDataHandler prismWebserviceHandler = new DataHandler("PRISM_INSTRUMENT_INFOS", new ProviderRouter(
    new IProviderExecutable[]
    {
                    new InstrumentInfosPrismExecutable()
    }, true), new PrismTranscoder(false), markSource: markSource);

            IDataHandler prismByPollingHandler = new DataHandler("PRISM_POLLING", new ProviderRouter(
                new IProviderExecutable[]
                {
                    new OptionDescAndPricesPrismExecutableByPolling(),
                    new NonAdjustedPricesPrismByPollingExecutable(),
                    new CustomFieldsPrismExecutableByPolling(new DoubleCustomFieldsPrismExecutable()),
                     new CustomFieldsPrismExecutableByPolling(new StringUndatedCustomFieldsPrismExecutable()),
                     new CustomFieldsPrismExecutableByPolling(new DateCustomFieldsPrismExecutable()),
                     new CustomFieldsPrismExecutableByPolling(new TableDataCustomFieldsPrismExecutable()),
                    new IndexComponentsPrismByPollingExecutable(adapterDataHandler)
                }, true), new PrismTranscoder(false), markSource: markSource);

            IDataHandler prismAdjustedByPollingHandler = new DataHandler("PRISM_POLLING_ADJUSTED", new ProviderRouter(
               new IProviderExecutable[]
               {
                    new AdjustedPricesPrismByPollingExecutable(),
               }, true), new EmptyTranscoder(), markSource: markSource);

            IDataHandler sophisHandler = new DataHandler("SOPHIS",
                new ProviderRouter(new IProviderExecutable[]
                {
                    new LastSophisExecutable(),
                    new CalendarSophisExecutable(),
                    new CurrencySophisExecutable(),
                    new IsinSophisExecutable(),
                    new IndexComponentsSophisExecutable(),
                }, true), new SophisTranscoder(), horizonMaxDays: 0, markSource: markSource);

            IDataHandler prismOnDemandHandler = new DataHandler("PRISM_ON_DEMAND",
                    new ProviderRouter(new IProviderExecutable[]
                    {
                    }, true), new BloombergTranscoder(), horizonMaxDays: 0, markSource: markSource);

            IDataHandler mdmPricesHandler = new DataHandler("MDM_PRICES",
                    new ProviderRouter(new IProviderExecutable[]
                    {
                    }, true), new SophisTranscoder(), horizonMaxDays: 0, markSource: markSource);

            IDataHandler indexValuesHandler = new DataHandler("INDEX_VALUES",
              new ProviderRouter(new IProviderExecutable[]
              {
                  new IndexValuesInstrumentInfosExecutable(indexDBProviderFactory)
              }, true), new IndexValuesCodeTranscoder(), horizonMaxDays: 0, markSource: markSource);

            IDataHandler catHandler = new DataHandler("CAT",
  new ProviderRouter(new IProviderExecutable[]
  {
                  new CATCorporateActionExecutable(),
                  new CATDividendExecutable()
  }, true), new EmptyTranscoder(), horizonMaxDays: -500, markSource: markSource);


            IDataHandler prismSnapshotOnDemandHandler = new DataHandler("PRISM_SNAPSHOT_ON_DEMAND",
        new ProviderRouter(new IProviderExecutable[]
        {
        }, true), new BloombergTranscoder(), horizonMaxDays: 0, markSource: markSource);

            IDataHandler filterInternalDataHandler = new FilterInternalDataHandler();
            return new[]
            {
                new DatesAdapterDataHandler(),
                adapterDataHandler,
                cacheHandler,
                resultDatabaseHandler,
              //  IsLocalDatabaseHandlerActivated() ? localDatabaseHandler : null,
                localCSVHandler,
                databaseHandler,
                indexValuesHandler,
                filterInternalDataHandler,
                derivativesHandler,
                comexCsvHandler,
                prismOnDemandHandler,
                mdmPricesHandler,
                prismWebserviceHandler,
                prismSnapshotOnDemandHandler, /* LAST internal, trim internal symbols for the next symbols */
                prismHandler,
                prismDividendHandler,
                prismOSTHandler,
                csvCalendarHandler,
                dataHandlersToUse != null && dataHandlersToUse.Contains("CAT")
                ||
                dataHandlersToInclude != null && dataHandlersToInclude.Contains("CAT") ? catHandler : null,
                CreateBloombergDataHandler(adapterDataHandler, markSource),
                prismAdjustedByPollingHandler,
                sophisHandler,
                prismByPollingHandler,
                csvHandler,
				ivyHandler
            }.Where(x => x != null).ToArray();
        }

        private bool IsLocalDatabaseHandlerActivated()
        {
            var localDatabaseHandlerActivated = ConfigurationManager.AppSettings["LocalDatabaseHandlerActivated"];

            return localDatabaseHandlerActivated != null && bool.Parse(localDatabaseHandlerActivated);
        }

        private static ProviderRouter CreateDataDBProviderRouter(bool isReadOnly, bool isAsync, IIndexDBProviderFactory indexDBProviderFactory)
        {
            var providerExecutables = new IProviderExecutable[]
{
                new DatabaseTimeSerieStringUnDatedProviderExecutable(indexDBProviderFactory, new TimeSerieStringDtoConverter()),
                new DatabaseTimeSerieStringProviderExecutable(indexDBProviderFactory, new TimeSerieStringDtoConverter()),
                new DatabaseTimeSerieStringTableProviderExecutable(indexDBProviderFactory, new XmlTimeSerieStringDtoConverter()), 
                new DatabaseExceptionCalendarProviderExecutable(indexDBProviderFactory, new ExceptionCalendarConverter()),
                new DatabaseDividendProviderExecutable(indexDBProviderFactory, new DividendDtoConverter()),
                new DatabaseLocalDividendProviderExecutable(indexDBProviderFactory, new DividendDtoConverter()),
                new DatabaseLocalTimeSerieProviderExecutable(indexDBProviderFactory, new TimeSerieDtoConverter()),
                new DatabaseTimeSerieProviderExecutable(indexDBProviderFactory, new TimeSerieDtoConverter()),
                new DatabaseTimeSerieBinaryProviderExecutable(indexDBProviderFactory, new ProtoTimeSerieBinaryDtoConverter()),
                new DatabaseUndatedTimeSerieProviderExecutable(indexDBProviderFactory, new TimeSerieDtoConverter())
};

            return isAsync
                ? new ProviderRouterAsyncSave(false, providerExecutables, isReadOnly)
                : new ProviderRouter(providerExecutables, isReadOnly);
        }

        private bool IsDataHandlerToUse(IDataHandler handler)
        {
            return dataHandlersToUse.Contains(handler.Name);
        }

        private static bool IsMandatoryDataHandler(IDataHandler handler)
        {
            return handler.Name == null;
        }

        /// <summary>
        /// try create the bloomberg datahandler, return null if bbg is not installed or if it is disabled.
        /// </summary>
        private IDataHandler CreateBloombergDataHandler(IDataHandler dataHandler, bool markSource)
        {
            IDataHandler bloombergHandler = new DataHandler(BloombergDataHandlerName, new ProviderRouter(
                new IProviderExecutable[]
                {
                        new StringAsTodayBloombergExecutable(),
                        new StringBloombergExecutable(),
                        new ComponentsBloombergExecutable(),
                        new DoubleBloombergExecutable(),
                        new OSTCollectionBloombergExecutable(dataHandler),
                        new DateTimeBloombergExecutable(),
                        new CashflowDescriptionTableBloombergExecutable(),
                        new DoubleAsTodayBloombergExecutable()
                }, true
                ), new BloombergTranscoder(), markSource: markSource, horizonMaxDays: -1, shouldLoadPredicate: x => HistoricBloombergIsAvailable);

            return bloombergHandler;
        }

        /// <summary>
        /// Check if history is available through Bloomberg API
        /// </summary>
        /// <returns></returns>
        public static void CheckHistoricBloombergIsAvailable()
        {
            onHistoricBloombergIsAvailableSettedEvent = new ManualResetEvent(false);

            if (!BloombergDataProvider.IsBloombergInstalled)
            {
                historicBloombergIsAvailable = false;
                onHistoricBloombergIsAvailableSettedEvent.Set();
                return;
            }

            DateTime date = new DateTime(2015, 11, 12);

            var bbgThread = new Thread(() =>
            {
                var provider = SimpleBloombergExecutable.ConfigurationCreateBloombergProvider();

                int nbRetries = 0;

                while (!historicBloombergIsAvailable && nbRetries < 5)
                {
                    try
                    {
                        var result = provider.GetHistoricalData(
                            "FP FP Equity".AsArray(),
                            DataFieldsEnum.Last.AsArray(),
                            date,
                            date);

                        historicBloombergIsAvailable = result != null && result.Count > 0;
                        nbRetries++;
                    }
                    catch
                    {
                        historicBloombergIsAvailable = false;
                        nbRetries++;
                        Thread.Sleep(500);
                    }
                    finally
                    {
                    }
                }

                onHistoricBloombergIsAvailableSettedEvent.Set();
            });

            bbgThread.IsBackground = true;

            bbgThread.Start();
        }
    }

    public interface ITimeSeriesProviderInitializer
    {
        /// <summary>
        /// Constructor - set the Chain of Responsability
        /// </summary>
        IDataHandler Initialize(OverloadedMarketDataTree tree, bool noDbLoading, bool noCacheLoading, bool isReadOnly,
            IDataHandler dataHandler, bool saveAsDefault = true, IIndexDBProviderFactory indexDBProviderFactory = null);
    }
}
