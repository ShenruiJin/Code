﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;

namespace CaesarApplication.DataProvider.CSV
{
    public class DividendFrictionParser
    {
        private static string GetFilePath(string ticker)
        {
            return (ConfigurationManager.AppSettings["DividendFrictionDirectory"] ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, @"Data\DividendFriction")) + "\\" + ticker + "DividendFriction.csv";
        }

        public static DividendFrictionMap Load(string ticker)
        {
            Dictionary<DateTime, double> data = new Dictionary<DateTime, double>();

            foreach (var line in File.ReadAllLines(GetFilePath(ticker)).Skip(1))
            {
                var lineParts = line.Split(';');

                data.Add(DateTime.ParseExact(lineParts[0].ToLower(), "d/MM/yyyy", CultureInfo.InvariantCulture), double.Parse(lineParts[1].Replace("%", String.Empty), CultureInfo.InvariantCulture) / 100.0d);
            }

            return new DividendFrictionMap(data);
        }


        public class DividendFrictionMap
        {
            private readonly Dictionary<DateTime, double> data;

            public DividendFrictionMap(Dictionary<DateTime, double> data)
            {
                this.data = data;
            }

            public double GetFriction(DateTime date)
            {
                return data.First(x => x.Key.Month == date.Month && x.Key.Year == date.Year).Value;
            }
        }
    }
}
