﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using System.Collections;
using System.Text;
using GlobalDerivativesApplications;
using System.Collections.Concurrent;
using System.Threading;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.Data;
using GlobalDerivativesApplications.ExpiriesManagement;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.CSV
{
    public class OptionDescAndPricesCsvExecutable : ProviderExecutable
    {

        public static IEnumerable<string> LineEnumerator(string filePath)
        {
            FileInfo inf = new FileInfo(filePath);

            if (inf.Length < 100L * 1024L * 1024L * 1024L)
            {
                return File.ReadAllLines(filePath);
            }
            else
            {
                return LineEnumeratorBig(filePath);
            }
        }

        public static IEnumerable<string> LineEnumeratorBig(string filePath)
        {
            using (var streamReader = File.OpenText(filePath))
            {
                string line;
                while ((line = streamReader.ReadLine()) != null)
                {
                    yield return line;
                }
            }
        }

        private static string cboeFilesHeaders = "TRADE_DT,UNDLY,CLS,EXPR_DT,STRK_PRC,PC,OIT,VOL,HIGH,LOW,OPEN,LAST,L_BID,L_ASK,UNDL_PRC,S_TYPE,P_TYPE";
        private static string cboeNewVersionFilesHeaders = "underlying_symbol,quote_date,root,expiration,strike,option_type,open,high,low,close,trade_volume,bid_size_1545,bid_1545,ask_size_1545,ask_1545,underlying_bid_1545,underlying_ask_1545,bid_size_eod,bid_eod,ask_size_eod,ask_eod,underlying_bid_eod,underlying_ask_eod,vwap,open_interest,delivery_code";


        public override TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var optionDescs = new List<OptionDescAndPrices>();

            var optionDirectory = ConfigurationManager.AppSettings["OptionFilesDirectoryPath"] ?? AppDomain.CurrentDomain.BaseDirectory;

            var isEurex = new[] { "SX5E", "V2X" }.Contains(ticker);

            var isSX5E = ticker == "SX5E";

            var isCBOE = new[] { "VIX" , "SPX" }.Contains(ticker);

            if (!isCBOE && !isEurex)
                return null;

            string[] tickersToFilter = ticker.AsArray();

            if (isEurex)
            {
                if (isSX5E)
                {
                    tickersToFilter = new[] { "OESX", "OES1", "OES2", "OES4", "OES5" };
                }
                else if (ticker == "V2X")
                {
                    tickersToFilter = new[] { "OVS", "OVS2" };
                }
            }
            else
            {
                tickersToFilter = ("^" + ticker).AsArray();
            }

            var files = (isEurex ? GetFilesToComputeForEurex(optionDirectory, startDate, endDate) : GetFilesToComputeForCBOE(startDate, endDate)).ToArray();

            ICalendar cal = null;
            if (isEurex)
            {
                //if (true)
                //    return new List<TimeSerieDB>();

                cal = SophisHelper.GetCalendarByMarketMnemo("EUR|TGHO");
            }
            else //// SPX prism should be ok
            {
                //if (endDate <= new DateTime(2004, 12, 31))    
                //    return new List<TimeSerieDB>();
            }

            int filenumber = 0;


            var results = files
                .Select(filePath =>
                {
                    var isOldVersion = !Path.GetFileName(filePath).StartsWith("UnderlyingOptionsEODQuotes_");

                    var tickersToFilterByVersion = isOldVersion && isCBOE ? tickersToFilter.Select(x => x.Substring(1)).ToArray() : tickersToFilter;

                    System.Threading.Interlocked.Increment(ref filenumber);
                    if (Console)
                    {
                        Tools.IO.StepConsoleProgressBar(filenumber / (double)files.Length, System.Console.Out, 60, "optioncsv");
                    }

                    Dictionary<string, int> headers = new Dictionary<string, int>();

                    var localOptionDescs = new List<OptionDescAndPrices>();

                    headers = isEurex ? GetOptionHeaders(ReadFirstLine(filePath), ';') : (isOldVersion ? GetOptionHeaders(cboeFilesHeaders, ',') : GetOptionHeaders(cboeNewVersionFilesHeaders, ','));

                    var lines = new BlockingCollection<string[]>();
                    List<Thread> workers = new List<Thread>();

                    workers.Add(new Thread(() =>
                    {
                        foreach (var group in LineEnumerator(filePath).Group(500))
                        {
                            lines.Add(group);
                        }
                        lines.CompleteAdding();
                    }));

                    for (int i = 0; i < 4; ++i)
                    {
                        workers.Add(new Thread(() =>
                        {
                            while (!lines.IsCompleted)
                            {
                                string[] currentBatch;
                                if (lines.TryTake(out currentBatch))
                                {
                                    foreach (var line in currentBatch)
                                    {
                                        if (tickersToFilterByVersion.Any(line.Contains))
                                        {
                                            var optionDescAndPrices = isEurex
                                                ? GetOptionDescAndPricesFromLineEurex(line, headers, cal, tickersToFilterByVersion)
                                                : (isOldVersion ? GetOptionDescAndPricesFromLine(line, headers) : GetOptionDescAndPricesFromLineCBOENewVersion(line, headers, ticker));

                                            if (optionDescAndPrices != null && optionDescAndPrices.SType != "LEAP")
                                            {
                                                lock (((ICollection)optionDescs).SyncRoot)
                                                {
                                                    var existingOption = optionDescs.FirstOrDefault(o =>
                                                        o.ExpirationDate == optionDescAndPrices.ExpirationDate &&
                                                        o.Strike == optionDescAndPrices.Strike &&
                                                        o.TradeDate == optionDescAndPrices.TradeDate &&
                                                        o.Class == optionDescAndPrices.Class &&
                                                        o.ContractSize == optionDescAndPrices.ContractSize &&
                                                        o.UnderlyingPrice == optionDescAndPrices.UnderlyingPrice &&
                                                         o.Underlying == optionDescAndPrices.Underlying &&
                                                        o.Nature == optionDescAndPrices.Nature
                                                        );

                                                    if (existingOption == null)
                                                    {
                                                        localOptionDescs.Add(optionDescAndPrices);
                                                    }
                                                    else
                                                    {

                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }));
                    }

                    workers.ForEach(t => t.Start());
                    workers.ForEach(t => t.Join());

                    return localOptionDescs;
                }).ToArray();
            foreach (var optionBlock in results)
                optionDescs.AddRange(optionBlock);

            optionDescs.ForEach(o =>
                o.Underlying = tickersToFilter.Contains(o.Underlying)
                ? ticker : o.Underlying
            );

            if (!isEurex)
            {
                optionDescs = optionDescs.Where(o =>
                    o.Underlying != "SPX"
                    ||
                    (
                    o.Class != "SPB"
                    && o.PType == "Index")).ToList();
            }

            var selectedOptions =
                optionDescs.Where(
                    d =>
                        ticker == d.Underlying && d.TradeDate >= startDate.GetValueOrDefault() &&
                        d.TradeDate <= endDate.GetValueOrDefault(DateTime.MaxValue)).ToArray();

            var selectedOptionsLists = selectedOptions.GroupBy(x => x.TradeDate).Select(g =>
            {
                var lst = new OptionDescAndPricesList();

                var options = g.GroupBy(x => x.Ticker).Select(x => x.First()).ToArray();
                lst.AddRange(options);

                return new KeyValuePair<DateTime, IMarketData>(g.Key, lst);
            }).ToArray();

            return new TimeSerieDB(selectedOptionsLists, ticker, DataFieldsEnum.OptionDescAndPrices, loadingContext);
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            return tickers.Select(t => Load(t, field, startDate, endDate, loadingContext)).Where(x => x != null).ToArray();
        }

        private string ReadFirstLine(string filePath)
        {
            using (var streamReader = new StreamReader(new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite)))
            {
                return streamReader.ReadLine();
            }
        }

        public static string EurexPathOverride { get; set; }

        private IEnumerable<string> GetFilesToComputeForEurex(string optionDirectory, DateTime? startDate, DateTime? endDate)
        {
            var optionDir = EurexPathOverride ?? @"K:\ED_ExcelTools\Parameters\Caesar\CliqDataFiles\eurex-raw";

            var files = Directory.GetFiles(optionDir).Where(f => f.Contains("index_dc")).ToArray();
            List<string> candidates = new List<string>();

            foreach (var file in files)
            {
                var filename = Path.GetFileNameWithoutExtension(file);
                var dateonly = filename.Replace("index_dc_", string.Empty);

                DateTime file_date = DateTime.ParseExact(dateonly, "yyyyMMdd", CultureInfo.InvariantCulture);
                bool include = true;
                if (startDate != null)
                {
                    if (startDate.Value.Year > file_date.Year
                        || startDate.Value.Year == file_date.Year && startDate.Value.Month > file_date.Month)
                    {
                        include = false;
                    }
                }


                if (endDate != null)
                {
                    if (endDate.Value.Year < file_date.Year
                        || endDate.Value.Year == file_date.Year && endDate.Value.Month < file_date.Month)
                    {
                        include = false;
                    }
                }
                if (include)
                    candidates.Add(file);

            }

            string dailyDirectory = Path.Combine(optionDir, "daily");
            if (Directory.Exists(dailyDirectory))
            {
                foreach (var file in Directory.GetFiles(dailyDirectory)
                    .Where(f => Path.GetFileNameWithoutExtension(f).StartsWith("index_dc")))
                {
                    var filename = Path.GetFileNameWithoutExtension(file);
                    var dateonly = filename.Replace("index_dc_", string.Empty);

                    DateTime file_date = DateTime.ParseExact(dateonly, "yyyyMMdd", CultureInfo.InvariantCulture);
                    if (file_date <= endDate.GetValueOrDefault(DateTime.MaxValue)
                        && file_date >= startDate.GetValueOrDefault(DateTime.MinValue))
                    {
                        candidates.Add(file);
                    }
                }
            }
            return candidates;
        }

        private static IEnumerable<string> GetFilesToComputeForCBOE(DateTime? startDate, DateTime? endDate)
        {
            string optionDirectory = ConfigurationManager.AppSettings["OptionFilesDirectoryCBOEPath"] ??
                                     @"\\cib.net\shareparis\Soft\ED_ExcelTools\Parameters\Caesar\CliqDataFiles\Options";
            var dailyOptionDirectory = Path.Combine(optionDirectory, "daily");

            var prefixes = new[] { "optsum3_", "UnderlyingOptionsEODQuotes_" };
            var datesFormat = new[] { "yyyyMMdd", "yyyy-MM-dd" };
            var extension = ".csv";

            var dailyFiles = Directory.GetFiles(dailyOptionDirectory).Select(Path.GetFileName)
                .Where(x => x.EndsWith(extension) && prefixes.Any(i => x.StartsWith(i)));


            var availableDates =
                dailyFiles.Select(
                    x =>
                    {
                        var prefix = prefixes.Select((p, i) => new { Index = i, Value = p }).First(p => x.StartsWith(p.Value));

                      return new { FileName = x, Date = DateTime.ParseExact(x.Substring(prefix.Value.Length, datesFormat[prefix.Index].Length), datesFormat[prefix.Index], CultureInfo.InvariantCulture) };
                        })
                    .OrderBy(x => x.Date)
                    .ToArray();

            var requestedDates =
                availableDates.Where(
                    d => d.Date >= startDate.GetValueOrDefault() && d.Date <= endDate.GetValueOrDefault(DateTime.MaxValue))
                    .ToArray();

            var yearToRequest = new List<string>();

            var firstDate = availableDates.Select(x => x.Date).Cast<DateTime?>().FirstOrDefault();

            if (firstDate == null || firstDate > startDate)
            {
                var endDateToRequest = endDate <= firstDate ? endDate : (firstDate ?? endDate);

                for (int i = startDate.GetValueOrDefault().Year; i <= endDateToRequest.GetValueOrDefault(DateTime.MaxValue).Year; i++)
                {
                    yearToRequest.Add(i.ToString());
                }
            }

            return GetYearFilesToComputeForCboe(optionDirectory, yearToRequest).Union(requestedDates.Select(d => Path.Combine(dailyOptionDirectory, d.FileName))).ToArray();
        }

        private static IEnumerable<string> GetYearFilesToComputeForCboe(string optionDirectory, List<string> yearToRequest)
        {
            return Directory.GetFiles(optionDirectory).Where(f => f.Contains("Option") && (f.EndsWith(".txt") || f.EndsWith(".csv")) && yearToRequest.Any(f.Contains));
        }

        public static Dictionary<string, int> GetOptionHeaders(string line, char separator)
        {
            return line.Split(separator).Select((x, i) => new KeyValuePair<string, int>(x, i)).ToDictionary(x => x.Key.Replace("\"", ""), x => x.Value);
        }

        public static OptionDescAndPrices GetOptionDescAndPricesFromLine(string line, Dictionary<string, int> headers)
        {
            var lineParts = Split(line, ',');


            var optionDescAndPrices = new OptionDescAndPrices
            {
                Last = ParseValueOrDefault(lineParts[headers["LAST"]]),
                Underlying = lineParts[headers["UNDLY"]],
                Class = lineParts[headers["CLS"]],
                TradeDate =
                    DateTime.ParseExact(lineParts[headers["TRADE_DT"]], "yyyyMMdd",
                        CultureInfo.InvariantCulture),
                ExpirationDate = DateTime.ParseExact(lineParts[headers["EXPR_DT"]],
                    "yyyyMMdd",
                    CultureInfo.InvariantCulture),
                High = ParseValueOrDefault(lineParts[headers["HIGH"]]),
                LastAsk = ParseValueOrDefault(lineParts[headers["L_ASK"]]),
                LastBid = ParseValueOrDefault(lineParts[headers["L_BID"]]),
                Low = ParseValueOrDefault(lineParts[headers["LOW"]]),
                Nature = lineParts[headers["PC"]] == "C" ? OptionNature.Call : OptionNature.Put,
                Open = ParseValueOrDefault(lineParts[headers["OPEN"]]),
                OpenInterest = ParseValueOrDefault(lineParts[headers["OIT"]]),
                PType = lineParts.Length == headers.Count ? lineParts[headers["P_TYPE"]] : string.Empty,
                SType = lineParts[headers["S_TYPE"]],
                Strike = ParseValueOrDefault(lineParts[headers["STRK_PRC"]]),
                UnderlyingPrice = Double.Parse(lineParts[headers["UNDL_PRC"]],
                    CultureInfo.InvariantCulture),
                Volume = ParseValueOrDefault(lineParts[headers["VOL"]]),
            };
            MakeTicker(optionDescAndPrices);
            return optionDescAndPrices;
        }

        public static OptionDescAndPrices GetOptionDescAndPricesFromLineCBOENewVersion(string line, Dictionary<string, int> headers, string underlying)
        {
            var lineParts = Split(line, ',');


            var optionDescAndPrices = new OptionDescAndPrices
            {
                Underlying = underlying,
                Last = ParseValueOrDefault(lineParts[headers["close"]]),
                Class = lineParts[headers["root"]],
                TradeDate =
                    DateTime.ParseExact(lineParts[headers["quote_date"]], "yyyy-MM-dd",
                        CultureInfo.InvariantCulture),
                ExpirationDate = DateTime.ParseExact(lineParts[headers["expiration"]],
                    "yyyy-MM-dd",
                    CultureInfo.InvariantCulture),
                High = ParseValueOrDefault(lineParts[headers["high"]]),
                LastAsk = ParseValueOrDefault(lineParts[headers["ask_eod"]]),
                LastBid = ParseValueOrDefault(lineParts[headers["bid_eod"]]),
                Low = ParseValueOrDefault(lineParts[headers["low"]]),
                Nature = lineParts[headers["option_type"]] == "C" ? OptionNature.Call : OptionNature.Put,
                Open = ParseValueOrDefault(lineParts[headers["open"]]),
                OpenInterest = ParseValueOrDefault(lineParts[headers["open_interest"]]),
                PType = "Index",
                SType = "",
                Strike = ParseValueOrDefault(lineParts[headers["strike"]]),
                Volume = ParseValueOrDefault(lineParts[headers["trade_volume"]]),
            };
            MakeTicker(optionDescAndPrices);
            return optionDescAndPrices;
        }

        private static double ParseValueOrDefault(string linePart)
        {
            return !string.IsNullOrWhiteSpace(linePart) ? Double.Parse(linePart, CultureInfo.InvariantCulture) : 0;
        }

        public static void MakeTicker(OptionDescAndPrices o)
        {
            using (CultureHelper.Culture(CultureInfo.InvariantCulture))
            {
                o.Ticker = new string[] { o.Underlying, o.Class, o.Nature.ToString(), o.Strike.ToString(), o.ExpirationDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture) }.Stringify("_");
            }
        }


        public static OptionDescAndPrices GetOptionDescAndPricesFromLineEurex(string line, Dictionary<string, int> headers, ICalendar cal, string[] eurexContractsNames)
        {
            var lineParts = Split(line, ';');

            int expyear;
            int expmonth;

			/*
            foreach (var alternative in new[] { new { key="PRODUCT_ID" , alternative="#PRODUCT_ID" },
                                                 new { key="OPEN_INTEREST_ADJUSTED" , alternative="OPEN_INTERES_ADJUSTED" }})
            {
                if (!headers.ContainsKey(alternative.key))
                {
                    headers[alternative.key] = headers[alternative.alternative];
                }
            }
			*/

			if (int.TryParse(lineParts[3], out expyear) &&
				int.TryParse(lineParts[2], out expmonth))
			{
				string nature = lineParts[1].Replace("\"", "");
				string product_id = lineParts[0].Replace("\"", "");

				if (nature == "F")
					return null;

				var optionDescAndPrices = new OptionDescAndPrices
				{
					Last = Double.Parse(lineParts[12], CultureInfo.InvariantCulture),
					Underlying = product_id,
					Class = string.Empty,
					TradeDate =
						DateTime.ParseExact(lineParts[15], "yyyyMMdd",
							CultureInfo.InvariantCulture),
					ExpirationDate = ComputeExpiry(product_id, cal, expyear, expmonth, eurexContractsNames),
					High = Double.Parse(lineParts[10],
						CultureInfo.InvariantCulture),

					Low = Double.Parse(lineParts[11], CultureInfo.InvariantCulture),
					Nature = nature == "C" ? OptionNature.Call : OptionNature.Put,
					Open = Double.Parse(lineParts[9],
						CultureInfo.InvariantCulture),
					OpenInterest = Double.Parse(lineParts[14],
						CultureInfo.InvariantCulture),

					Strike = Double.Parse(lineParts[4],
						CultureInfo.InvariantCulture),

					Volume = Double.Parse(lineParts[13],
						CultureInfo.InvariantCulture),
				};
				MakeTicker(optionDescAndPrices);
				return optionDescAndPrices;
			}

			return null;
        }


        /// <summary>
        /// compute the proper expiry depending on ticker for monthly and weekly options
        /// </summary>
        /// <param name="reference"></param>
        /// <param name="calendar"></param>
        /// <param name="expyear"></param>
        /// <param name="expmonth"></param>
        /// <returns></returns>
        private static DateTime ComputeExpiry(string reference, ICalendar calendar, int expyear, int expmonth, string[] eurexContractsNames)
        {
            string[] sx5eOpts = new[] { "OES1", "OES2", "OESX", "OES4", "OES5" };
            string[] v2XOpts = new[] { "OVS", "OVS2" };

            var date = new DateTime(expyear, expmonth, 18).ToMaturity();
            ExpiriesDefinition definition = GetExpiryDefinition(sx5eOpts.Contains(reference) ? "SX5E" : "V2X", "EUR");
            ExpiryDefinitionsManager mngt = new ExpiryDefinitionsManager(definition, calendar);

            if (reference == "OESX")
            {
                return mngt.GetMaturity(date.ToDate(DateTime.Today));
            }
            else if (reference.IsIn(sx5eOpts))
            {
                int week = sx5eOpts.IndexOf(reference) + 1;
                var result = new DateTime(expyear, expmonth, 01);
                for (int i = 0; i < week; ++i)
                {
                    if (i > 0)
                    {
                        result = result.AddDays(1);
                    }
                    while (result.DayOfWeek != definition.ChangingDay)
                    {
                        result = result.AddDays(1);
                    }
                }
                return result;
            }
            else if (reference.IsIn(v2XOpts))
            {
                return mngt.GetMaturity(date.ToDate(DateTime.Today));
            }
            throw new NotImplementedException();
        }


        private static ExpiriesDefinition GetExpiryDefinition(string reference, string v)
        {
            if (reference == "SX5E")
            {
                return new ExpiriesDefinition()
                {
                    YearlyChangingMonth = MonthsOfTheYear.December,
                    LagDays = 0,
                    ChangingDay = DayOfWeek.Friday,
                    MonthlyChangingDayToUse = MonthlyChangingDay.Third,
                };
            }
            else if (reference == "V2X")
            {
                return new ExpiriesDefinition()
                {
                    YearlyChangingMonth = MonthsOfTheYear.December,
                    LagDays = 0,
                    ChangingDay = DayOfWeek.Wednesday,
                    MonthlyChangingDayToUse = MonthlyChangingDay.Third,
                };
            }

            throw new NotImplementedException();
        }


        private static string[] Split2(string strToParse, char charSeparator)
        {
            var res = new List<string>();

            var tmpStr = new StringBuilder();

            int len = strToParse.Length;

            for (int i = 0; i < len; i++)
            {
                if (strToParse[i] == charSeparator)
                {
                    res.Add(tmpStr.ToString());
                    tmpStr.Clear();
                }
                else
                {
                    tmpStr.Append(strToParse[i]);
                }
            }

            res.Add(tmpStr.ToString());

            return res.ToArray();
        }

        private static string[] Split(string strToParse, char charSeparator)
        {
            int index = 0;
            int len = strToParse.Length;
            List<string> tokens = new List<string>();
            while (index < len)
            {
                int tokenStart = index;
                int tokenEnd = index;
                var nextChar = strToParse[index];
                while (nextChar != charSeparator && index < len)
                {
                    index++;
                    tokenEnd = index;
                    nextChar = index < len ? strToParse[index] : charSeparator;
                }
                tokens.Add(strToParse.Substring(tokenStart, tokenEnd - tokenStart));
                //// skip separator
                index++;

            }
            return tokens.ToArray();
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new List<DataFieldsEnum>() { DataFieldsEnum.OptionDescAndPrices }; }
        }

        public bool Console { get; set; }
    }
}
