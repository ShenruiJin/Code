﻿#region <!-- Using Directives -->

using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;

using PricingBase.DataProvider;

using CaesarCommon.Configuration;

using MarketData;

using ProtoBuf;

#endregion

namespace CaesarApplication.DataProvider.CSV
{
	public class OptionDescAndPricesIvyExecutable : ProviderExecutable
	{
		#region <!-- [Prop] SupportedFields -->

		public override IList<DataFieldsEnum> SupportedFields
		{
			get { return new List<DataFieldsEnum>() { DataFieldsEnum.OptionDescAndPrices }; }
		}

		#endregion

		#region <!-- [Prop] Settings -->

		private readonly CaesarSettingsManager m_Settings = new CaesarSettingsManager();

		#endregion

		#region <!-- [Prop] DataPath -->

		//private const String m_DataPathBefore2016August = @"\\cib.net\ShareParis\Salle\Services\OptionMetricsData\IvyDBEurope\v2.2\History";
		//private const String m_DataPathAfter2016August = @"\\cib.net\ShareParis\Salle\Services\OptionMetricsData\IvyDBEurope\v2.2\Update";

		#endregion

		#region <!-- [Func] GetSecId -->

		//> [TODO] Info to get from database
		private Int32? GetSecId(String p_Ticker)
		{
			switch (p_Ticker)
			{
				case "SX5E":
					return 504880;

				case "V2X":
					return 707860;

				case "VIX":
					return 117801;

			}

            return null;
        }

		#endregion

		#region <!-- [Func] GetSecSrc -->

		private Char GetSecSrc(String p_Ticker)
		{
			switch (p_Ticker)
			{
				case "SX5E":
					return 'E';

				case "V2X":
					return 'E';

				case "VIX":
					return 'U';

				default:
					throw new Exception("Not yet ready for other tickers than [SX5E, V2X, VIX]!");
			}
		}

		#endregion

		#region <!-- [Func] GetCcyInfo -->

		private readonly ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, CcyInfo>> GetCcyInfo__cache = new ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, CcyInfo>>();

		private CcyInfo GetCcyInfo(Int32 p_CcyID, DateTime p_Date, Char p_Src)
		{
			var l_CcyID = Convert.ToString(p_CcyID);

			var l_CcyInfo = default(CcyInfo);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					p_Date = new DateTime(2014, 12, 31);

					l_FileName = String.Format(@"ASIA.IVYCURRENCYD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYCURRENCYD.txt");
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYCURRENCY.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					p_Date = new DateTime(2016, 7, 31);

					l_FileName = String.Format(@"INTL.IVYCURRENCYD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYCURRENCYD.txt");
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYCURRENCY.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (GetCcyInfo__cache.ContainsKey(p_CcyID))
			{
				if (GetCcyInfo__cache[p_CcyID].ContainsKey(p_Date))
				{
					return GetCcyInfo__cache[p_CcyID][p_Date];
				}
			}

			if (File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.StartsWith(l_CcyID, StringComparison.Ordinal))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[0] == l_CcyID)
										{
											var l_Info = new CcyInfo();

											l_Info.CcyID = Convert.ToInt32(l_Parts[0]);
											l_Info.CcyCode = Convert.ToString(l_Parts[1]);
											l_Info.CcyDesc = Convert.ToString(l_Parts[2]);

											l_CcyInfo = l_Info;

											break;
										}
									}
								}
							}
						}
					}
				}
			}

			var d1 = GetCcyInfo__cache;

			var d2 = d1.GetOrAdd(p_CcyID, q_CcyID => new ConcurrentDictionary<DateTime, CcyInfo>());

			var d3 = d2.GetOrAdd(p_Date, q_Date => l_CcyInfo);

			return d3;
		}

		#endregion

		#region <!-- [Func] GetExchInfo -->

		private readonly ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, ExchInfo>> GetExchInfo__cache = new ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, ExchInfo>>();

		private ExchInfo GetExchInfo(Int32 p_ExchID, DateTime p_Date, Char p_Src)
		{
			var l_ExchID = Convert.ToString(p_ExchID);

			var l_ExchInfo = default(ExchInfo);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					p_Date = new DateTime(2014, 12, 31);

					l_FileName = String.Format(@"ASIA.IVYEXCHNGD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYEXCHNGD.txt");
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYEXCHNG.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					p_Date = new DateTime(2016, 7, 31);

					l_FileName = String.Format(@"INTL.IVYEXCHNGD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYEXCHNGD.txt");
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYEXCHNG.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (GetExchInfo__cache.ContainsKey(p_ExchID))
			{
				if (GetExchInfo__cache[p_ExchID].ContainsKey(p_Date))
				{
					return GetExchInfo__cache[p_ExchID][p_Date];
				}
			}

			if (File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.StartsWith(l_ExchID, StringComparison.Ordinal))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[0] == l_ExchID)
										{
											var l_Info = new ExchInfo();

											l_Info.ExchID = Convert.ToInt32(l_Parts[0]);
											l_Info.ExchCode = Convert.ToString(l_Parts[1]);
											l_Info.ExchCountry = Convert.ToString(l_Parts[2]);
											l_Info.ExchDesc = Convert.ToString(l_Parts[3]);

											l_ExchInfo = l_Info;

											break;
										}
									}
								}
							}
						}
					}
				}
			}

			var d1 = GetExchInfo__cache;

			var d2 = d1.GetOrAdd(p_ExchID, q_ExchID => new ConcurrentDictionary<DateTime, ExchInfo>());

			var d3 = d2.GetOrAdd(p_Date, q_Date => l_ExchInfo);

			return d3;
		}

		#endregion

		#region <!-- [Func] GetOptionInfo -->

		private readonly ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, OptionInfo>> GetOptionInfo__cache = new ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, OptionInfo>>();

		private OptionInfo GetOptionInfo(Int32 p_OptionID, DateTime p_Date, Char p_Src)
		{
			var l_OptionID = Convert.ToString(p_OptionID);

			var l_OptionInfo = default(OptionInfo);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					p_Date = new DateTime(2014, 12, 31);

					l_FileName = String.Format(@"ASIA.IVYOPINFD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPINFD.txt");
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPINF.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					p_Date = new DateTime(2016, 7, 31);

					l_FileName = String.Format(@"INTL.IVYOPINFD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPINFD.txt");
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPINF.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (GetOptionInfo__cache.ContainsKey(p_OptionID))
			{
				if (GetOptionInfo__cache[p_OptionID].ContainsKey(p_Date))
				{
					return GetOptionInfo__cache[p_OptionID][p_Date];
				}
			}

			if (File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.Contains(l_OptionID))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[1] == l_OptionID)
										{
											var l_Info = new OptionInfo();

											l_Info.SecurityID = Convert.ToInt32(l_Parts[0]);
											l_Info.OptionID = Convert.ToInt32(l_Parts[1]);
											l_Info.ExchangeID = Convert.ToInt32(l_Parts[2]);
											l_Info.Description = Convert.ToString(l_Parts[3]);
											l_Info.CurrencyID = Convert.ToInt32(l_Parts[4]);
											l_Info.Strike = Convert.ToDouble(l_Parts[5]) / 1000;

											l_Info.Expiry = DateTime.ParseExact(l_Parts[6], "yyyyMMdd", CultureInfo.InvariantCulture);

											l_Info.CallPut = Convert.ToChar(l_Parts[7]);
											l_Info.UnderlyingID = Convert.ToInt32(l_Parts[8]);
											l_Info.ContractSize = Convert.ToInt32(l_Parts[9]);
											l_Info.OptionStyle = Convert.ToInt32(l_Parts[10]);
											l_Info.ExerciseStyle = Convert.ToChar(l_Parts[12]);

											l_OptionInfo = l_Info;

											break;
										}
									}
								}
							}
						}
					}
				}
			}

			var d1 = GetOptionInfo__cache;

			var d2 = d1.GetOrAdd(p_OptionID, q_OptionID => new ConcurrentDictionary<DateTime, OptionInfo>());

			var d3 = d2.GetOrAdd(p_Date, q_Date => l_OptionInfo);

			return d3;
		}

		private OptionInfo[] SetCacheOptionInfo(Int32 p_SecurityID, DateTime p_Date, Char p_Src)
		{
			var l_OptionInfo = new Dictionary<Int32, OptionInfo>();

			var l_SecurityID = String.Format("{0}", p_SecurityID);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					p_Date = new DateTime(2014, 12, 31);

					l_FileName = String.Format(@"ASIA.IVYOPINFD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPINFD.txt");
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPINF.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					p_Date = new DateTime(2016, 7, 31);

					l_FileName = String.Format(@"INTL.IVYOPINFD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPINFD.txt");
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPINF.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.StartsWith(l_SecurityID, StringComparison.Ordinal))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[0] == l_SecurityID)
										{
											var i = new OptionInfo();

											i.SecurityID = Convert.ToInt32(l_Parts[0]);
											i.OptionID = Convert.ToInt32(l_Parts[1]);
											i.ExchangeID = Convert.ToInt32(l_Parts[2]);
											i.Description = Convert.ToString(l_Parts[3]);
											i.CurrencyID = Convert.ToInt32(l_Parts[4]);
											i.Strike = Convert.ToDouble(l_Parts[5]) / 1000;

											i.Expiry = DateTime.ParseExact(l_Parts[6], "yyyyMMdd", CultureInfo.InvariantCulture);

											i.CallPut = Convert.ToChar(l_Parts[7]);
											i.UnderlyingID = Convert.ToInt32(l_Parts[8]);
											i.ContractSize = Convert.ToInt32(l_Parts[9]);
											i.OptionStyle = Convert.ToInt32(l_Parts[10]);
											i.ExerciseStyle = Convert.ToChar(l_Parts[12]);

											l_OptionInfo.Add(i.OptionID, i);
										}
									}
								}
							}
						}
					}
				}
			}

			var z = new List<OptionInfo>();

			foreach (var id in l_OptionInfo.Keys)
			{
				var d1 = GetOptionInfo__cache;

				var d2 = d1.GetOrAdd(id, q_OptionID => new ConcurrentDictionary<DateTime, OptionInfo>());

				var d3 = d2.GetOrAdd(p_Date, q_Date => l_OptionInfo[id]);

				z.Add(d3);
			}

			return z.ToArray();
		}

		#endregion

		#region <!-- [Func] GetTickerData -->

		private readonly ConcurrentDictionary<String, ConcurrentDictionary<DateTime, TickerData[]>> GetTickerData__cache = new ConcurrentDictionary<String, ConcurrentDictionary<DateTime, TickerData[]>>();

		private TickerData[] GetTickerData(String p_Ticker, DateTime p_Date, Char p_Src)
		{
			var l_TickerData = new List<TickerData>();

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					p_Date = new DateTime(2014, 12, 31);

					l_FileName = String.Format(@"ASIA.IVYTICKERD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYTICKERD.txt");
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYTICKER.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					p_Date = new DateTime(2016, 7, 31);

					l_FileName = String.Format(@"INTL.IVYTICKERD.zip");

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYTICKERD.txt");
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYTICKER.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (GetTickerData__cache.ContainsKey(p_Ticker))
			{
				if (GetTickerData__cache[p_Ticker].ContainsKey(p_Date))
				{
					return GetTickerData__cache[p_Ticker][p_Date];
				}
			}

			if (File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.Contains(p_Ticker))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[3] == p_Ticker)
										{
											var l_Data = new TickerData();

											l_Data.SecurityID = Int32.Parse(l_Parts[0]);
											l_Data.ExchangeID = Int32.Parse(l_Parts[1]);
											l_Data.EffectiveDate = DateTime.ParseExact(l_Parts[2], "yyyyMMdd", CultureInfo.InvariantCulture);

											l_TickerData.Add(l_Data);
										}
									}
								}
							}
						}
					}
				}
			}

			var d1 = GetTickerData__cache;

			var d2 = d1.GetOrAdd(p_Ticker, q_Ticker => new ConcurrentDictionary<DateTime, TickerData[]>());

			var d3 = d2.GetOrAdd(p_Date, q_Date => l_TickerData.ToArray());

			return d3;
		}

		#endregion

		#region <!-- [Func] GetOptionPriceData -->

		private readonly ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, OptionPriceData[]>> GetOptionPriceData__cache = new ConcurrentDictionary<Int32, ConcurrentDictionary<DateTime, OptionPriceData[]>>();

		private OptionPriceData[] GetOptionPriceData(Int32 p_SecurityID, DateTime p_Date, Char p_Src)
		{
			var l_OptionPriceData = new List<OptionPriceData>();

			var l_SecurityID = String.Format("{0}", p_SecurityID);

			var l_Date = String.Format("{0:yyyyMMdd}", p_Date);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'U')
			{
				if (p_Date < new DateTime(2016, 1, 1))
				{
					l_FileName = String.Format(@"IVYOPPRCD_{0:yyyyMM}.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_US_Before_31DEC15, l_FileName);

					l_EntryName = String.Format(@"IVYOPPRCD_{0:yyyyMM}.txt", p_Date);
				}
				else
				{
					l_FileName = String.Format(@"IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_US_After_01JAN16, l_FileName);

					l_EntryName = String.Format("IVYOPPRC.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else if (p_Src == 'A')
			{
				if (p_Date < new DateTime(2015, 1, 1))
				{
					l_FileName = String.Format(@"ASIA.IVYOPPRCD_{0:yyyyMM}.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPPRCD_{0:yyyyMM}.txt", p_Date);
				}
				else
				{
					l_FileName = String.Format(@"ASIA.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_After_01JAN15, l_FileName);

					l_EntryName = String.Format("ASIA.IVYOPPRC.{0:yyyyMMdd}D.txt", p_Date);
				}
			}
			else
			{
				if (p_Date < new DateTime(2016, 8, 1))
				{
					l_FileName = String.Format(@"INTL.IVYOPPRCD_{0:yyyyMM}.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPPRCD_{0:yyyyMM}.txt", p_Date);
				}
				else
				{
					l_FileName = String.Format(@"INTL.IVYDB.{0:yyyyMMdd}D.zip", p_Date);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_After_01AUG16, l_FileName);

					l_EntryName = String.Format("INTL.IVYOPPRC.{0:yyyyMMdd}D.txt", p_Date);
				}
			}

			if (GetOptionPriceData__cache.ContainsKey(p_SecurityID))
			{
				if (GetOptionPriceData__cache[p_SecurityID].ContainsKey(p_Date))
				{
					return GetOptionPriceData__cache[p_SecurityID][p_Date];
				}
			}

			if (p_SecurityID > 0 && File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.StartsWith(l_SecurityID, StringComparison.Ordinal))
									{
										if (l_Line.Contains(l_Date))
										{
											var l_Parts = l_Line.Split('\t');

											if (l_Parts[1] == l_Date)
											{
												if (l_Parts[0] == l_SecurityID)
												{
													var l_Data = new OptionPriceData();

													if (p_Src == 'U')
													{
														l_Data.OptionInfo = new OptionInfo();

														l_Data.SecurityID = Convert.ToInt32(l_Parts[0]);

														l_Data.Date = DateTime.ParseExact(l_Parts[1], "yyyyMMdd", CultureInfo.InvariantCulture);

														l_Data.OptionInfo.Description = Convert.ToString(l_Parts[2]);

														l_Data.OptionInfo.Strike = Convert.ToDouble(l_Parts[4], CultureInfo.InvariantCulture) / 1000.0;

														l_Data.OptionInfo.Expiry = DateTime.ParseExact(l_Parts[5], "yyyyMMdd", CultureInfo.InvariantCulture);

														l_Data.OptionInfo.CallPut = Convert.ToChar(l_Parts[6]);

														l_Data.LastOptBid = Convert.ToDouble(l_Parts[7], CultureInfo.InvariantCulture);
														l_Data.LastOptAsk = Convert.ToDouble(l_Parts[8], CultureInfo.InvariantCulture);

														l_Data.Volume = Convert.ToInt64(l_Parts[10]);
														l_Data.OpenInterest = Convert.ToInt32(l_Parts[11]);

														l_Data.ImpliedVol = Convert.ToDouble(l_Parts[13], CultureInfo.InvariantCulture);
														l_Data.RiskDelta = Convert.ToDouble(l_Parts[14], CultureInfo.InvariantCulture);
														l_Data.RiskGamma = Convert.ToDouble(l_Parts[15], CultureInfo.InvariantCulture);
														l_Data.RiskVega = Convert.ToDouble(l_Parts[16], CultureInfo.InvariantCulture);
														l_Data.RiskTheta = Convert.ToDouble(l_Parts[17], CultureInfo.InvariantCulture);

														l_Data.OptionID = Convert.ToInt32(l_Parts[18]);
													}
													else
													{
														l_Data.OptionInfo = null;

														l_Data.SecurityID = Convert.ToInt32(l_Parts[0]);

														l_Data.Date = DateTime.ParseExact(l_Parts[1], "yyyyMMdd", CultureInfo.InvariantCulture);

														l_Data.OptionID = Convert.ToInt32(l_Parts[2]);
														l_Data.ExchangeID = Convert.ToInt32(l_Parts[3]);
														l_Data.CurrencyID = Convert.ToInt32(l_Parts[4]);

														l_Data.LastOptBid = Convert.ToDouble(l_Parts[5], CultureInfo.InvariantCulture);
														l_Data.LastOptAsk = Convert.ToDouble(l_Parts[8], CultureInfo.InvariantCulture);
														l_Data.LastOptPrice = Convert.ToDouble(l_Parts[11], CultureInfo.InvariantCulture);
														l_Data.LastUndPrice = Convert.ToDouble(l_Parts[13], CultureInfo.InvariantCulture);
														l_Data.ImpliedVol = Convert.ToDouble(l_Parts[14], CultureInfo.InvariantCulture);
														l_Data.RiskDelta = Convert.ToDouble(l_Parts[15], CultureInfo.InvariantCulture);
														l_Data.RiskGamma = Convert.ToDouble(l_Parts[16], CultureInfo.InvariantCulture);
														l_Data.RiskVega = Convert.ToDouble(l_Parts[17], CultureInfo.InvariantCulture);
														l_Data.RiskTheta = Convert.ToDouble(l_Parts[18], CultureInfo.InvariantCulture);

														l_Data.CalcMethod = Convert.ToChar(l_Parts[19]);
														l_Data.Volume = Convert.ToInt64(l_Parts[20]);
														l_Data.OpenInterest = Convert.ToInt32(l_Parts[21]);
														l_Data.SpecialSettlement = Convert.ToInt32(l_Parts[22]);
														l_Data.ReferenceExchangeID = Convert.ToInt32(l_Parts[23]);
													}

													l_OptionPriceData.Add(l_Data);
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}

			var d1 = GetOptionPriceData__cache;

			var d2 = d1.GetOrAdd(p_SecurityID, q_SecurityID => new ConcurrentDictionary<DateTime, OptionPriceData[]>());

			var d3 = d2.GetOrAdd(p_Date, q_Date => l_OptionPriceData.ToArray());

			return d3;
		}

		private void SetCacheOptionPriceHisto(Int32 p_SecurityID, String p_Month, Char p_Src)
		{
			var l_OptionPriceData = new List<OptionPriceData>();

			var l_SecurityID = String.Format("{0}", p_SecurityID);

			var l_Month = Convert.ToInt32(p_Month);

			var l_FileName = default(String);
			var l_FilePath = default(String);

			var l_EntryName = default(String);
			var l_EntryFile = default(ZipArchiveEntry);

			if (p_Src == 'U')
			{
				if (l_Month <= 201512)
				{
					l_FileName = String.Format(@"IVYOPPRCD_{0}.zip", l_Month);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_US_Before_31DEC15, l_FileName);

					l_EntryName = String.Format(@"IVYOPPRCD_{0}.txt", l_Month);
				}
				else
				{
					return;
				}
			}
			else if (p_Src == 'A')
			{
				if (l_Month <= 201412)
				{
					l_FileName = String.Format(@"ASIA.IVYOPPRCD_{0}.zip", l_Month);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Asia_Before_31DEC14, l_FileName);

					l_EntryName = String.Format(@"ASIA.IVYOPPRCD_{0}.txt", l_Month);
				}
				else
				{
					return;
				}
			}
			else
			{
				if (l_Month <= 201607)
				{
					l_FileName = String.Format(@"INTL.IVYOPPRCD_{0}.zip", l_Month);

					l_FilePath = String.Format(@"{0}\{1}", m_Settings.IVY_Path_Europe_Before_31JUL16, l_FileName);

					l_EntryName = String.Format(@"INTL.IVYOPPRCD_{0}.txt", l_Month);
				}
				else
				{
					return;
				}
			}

			if (p_SecurityID > 0 && File.Exists(l_FilePath))
			{
				using (var l_FileStream = new FileStream(l_FilePath, FileMode.Open, FileAccess.Read, FileShare.Read))
				{
					using (var l_ZipArchive = new ZipArchive(l_FileStream, ZipArchiveMode.Read))
					{
						l_EntryFile = l_ZipArchive.GetEntry(l_EntryName);

						using (var l_ZipStream = l_EntryFile.Open())
						{
							using (var l_ZipReader = new StreamReader(l_ZipStream))
							{
								while (!l_ZipReader.EndOfStream)
								{
									var l_Line = l_ZipReader.ReadLine();

									if (l_Line.StartsWith(l_SecurityID, StringComparison.Ordinal))
									{
										var l_Parts = l_Line.Split('\t');

										if (l_Parts[0] == l_SecurityID)
										{
											var l_Data = new OptionPriceData();

											if (p_Src == 'U')
											{
												l_Data.OptionInfo = new OptionInfo();

												l_Data.SecurityID = Convert.ToInt32(l_Parts[0]);

												l_Data.Date = DateTime.ParseExact(l_Parts[1], "yyyyMMdd", CultureInfo.InvariantCulture);

												l_Data.OptionInfo.Description = Convert.ToString(l_Parts[2]);

												l_Data.OptionInfo.Strike = Convert.ToDouble(l_Parts[4], CultureInfo.InvariantCulture) / 1000.0;

												l_Data.OptionInfo.Expiry = DateTime.ParseExact(l_Parts[5], "yyyyMMdd", CultureInfo.InvariantCulture);

												l_Data.OptionInfo.CallPut = Convert.ToChar(l_Parts[6]);

												l_Data.LastOptBid = Convert.ToDouble(l_Parts[7], CultureInfo.InvariantCulture);
												l_Data.LastOptAsk = Convert.ToDouble(l_Parts[8], CultureInfo.InvariantCulture);

												l_Data.Volume = Convert.ToInt64(l_Parts[10]);
												l_Data.OpenInterest = Convert.ToInt32(l_Parts[11]);

												l_Data.ImpliedVol = Convert.ToDouble(l_Parts[13], CultureInfo.InvariantCulture);
												l_Data.RiskDelta = Convert.ToDouble(l_Parts[14], CultureInfo.InvariantCulture);
												l_Data.RiskGamma = Convert.ToDouble(l_Parts[15], CultureInfo.InvariantCulture);
												l_Data.RiskVega = Convert.ToDouble(l_Parts[16], CultureInfo.InvariantCulture);
												l_Data.RiskTheta = Convert.ToDouble(l_Parts[17], CultureInfo.InvariantCulture);

												l_Data.OptionID = Convert.ToInt32(l_Parts[18]);
											}
											else
											{
												l_Data.OptionInfo = null;

												l_Data.SecurityID = Convert.ToInt32(l_Parts[0]);

												l_Data.Date = DateTime.ParseExact(l_Parts[1], "yyyyMMdd", CultureInfo.InvariantCulture);

												l_Data.OptionID = Convert.ToInt32(l_Parts[2]);
												l_Data.ExchangeID = Convert.ToInt32(l_Parts[3]);
												l_Data.CurrencyID = Convert.ToInt32(l_Parts[4]);

												l_Data.LastOptBid = Convert.ToDouble(l_Parts[5], CultureInfo.InvariantCulture);
												l_Data.LastOptAsk = Convert.ToDouble(l_Parts[8], CultureInfo.InvariantCulture);
												l_Data.LastOptPrice = Convert.ToDouble(l_Parts[11], CultureInfo.InvariantCulture);
												l_Data.LastUndPrice = Convert.ToDouble(l_Parts[13], CultureInfo.InvariantCulture);
												l_Data.ImpliedVol = Convert.ToDouble(l_Parts[14], CultureInfo.InvariantCulture);
												l_Data.RiskDelta = Convert.ToDouble(l_Parts[15], CultureInfo.InvariantCulture);
												l_Data.RiskGamma = Convert.ToDouble(l_Parts[16], CultureInfo.InvariantCulture);
												l_Data.RiskVega = Convert.ToDouble(l_Parts[17], CultureInfo.InvariantCulture);
												l_Data.RiskTheta = Convert.ToDouble(l_Parts[18], CultureInfo.InvariantCulture);

												l_Data.CalcMethod = Convert.ToChar(l_Parts[19]);
												l_Data.Volume = Convert.ToInt64(l_Parts[20]);
												l_Data.OpenInterest = Convert.ToInt32(l_Parts[21]);
												l_Data.SpecialSettlement = Convert.ToInt32(l_Parts[22]);
												l_Data.ReferenceExchangeID = Convert.ToInt32(l_Parts[23]);
											}

											l_OptionPriceData.Add(l_Data);
										}
									}
								}
							}
						}
					}
				}
			}

			foreach (var o in l_OptionPriceData)
			{
				var d1 = GetOptionPriceData__cache;

				var d2 = d1.GetOrAdd(o.SecurityID, q_SecurityID => new ConcurrentDictionary<DateTime, OptionPriceData[]>());

				var d3 = d2.GetOrAdd(o.Date, q_Date => l_OptionPriceData.Where(p => p.Date == o.Date).ToArray());
			}

			var z1 = DateTime.ParseExact(p_Month + "01", "yyyyMMdd", CultureInfo.InvariantCulture);

			var z2 = z1.AddMonths(1).AddDays(-1);

			var n = (z2 - z1).Days + 1;

			foreach (var d in Enumerable.Range(0, n).Select(i => z1.AddDays(i)))
			{
				var d1 = GetOptionPriceData__cache;

				var d2 = d1.GetOrAdd(p_SecurityID, q_SecurityID => new ConcurrentDictionary<DateTime, OptionPriceData[]>());

				var d3 = d2.GetOrAdd(d, q_Date => new OptionPriceData[0]);
			}
		}

		#endregion

		#region <!-- [Meth] Load -->

		public override TimeSerieDB Load(String p_Ticker, DataFieldsEnum p_Field, Nullable<DateTime> p_StartDate = null, Nullable<DateTime> p_EndDate = null, ILoadingContext p_Context = null)
		{
			if (p_StartDate == null) p_StartDate = new DateTime(2002, 1, 1);
			if (p_EndDate == null) p_EndDate = DateTime.Today;

			if (p_StartDate < new DateTime(2002, 1, 1)) p_StartDate = new DateTime(2002, 1, 1);
			if (p_EndDate > DateTime.Today) p_EndDate = DateTime.Today;

            if (GetSecId(p_Ticker).HasValue)
            {
                
                var l_SecurityID = GetSecId(p_Ticker).GetValueOrDefault();


                var l_SecuritySrc = GetSecSrc(p_Ticker);

                var n = (p_EndDate.Value - p_StartDate.Value).Days + 1;
                var dates = Enumerable.Range(0, n).Select(i => p_StartDate.Value.AddDays(i)).ToArray();

                var l = new ConcurrentBag<OptionPriceData>();

                if (l_SecuritySrc == 'A' || l_SecuritySrc == 'E' || l_SecuritySrc == 'U')
                {
                   foreach(var p_Month in dates.GroupBy(d => String.Format("{0:yyyyMM}", d)))
                    { 
                        SetCacheOptionPriceHisto(l_SecurityID, p_Month.Key, l_SecuritySrc);
                    }

                    foreach (var p_Date in dates)
                    {
                        var l_Data = GetOptionPriceData(l_SecurityID, p_Date, l_SecuritySrc);

                        foreach (var d in l_Data)
                        {
                            l.Add(d);
                        }
                    }
                }

                if (l_SecuritySrc == 'A' || l_SecuritySrc == 'E')
                {
                    foreach(var p_Date in dates)
                    {
                        SetCacheOptionInfo(l_SecurityID, p_Date, l_SecuritySrc);
                    }
                }

                var t1 = new Dictionary<DateTime, OptionDescAndPricesList>();
                var t2 = new Dictionary<DateTime, MarketDataDouble>();

                foreach (var d in dates)
                {
                    t1.Add(d, new OptionDescAndPricesList());
                    t2.Add(d, null);
                }

                foreach (var d in l)
                {
                    var o = (d.OptionInfo == null) ? GetOptionInfo(d.OptionID, d.Date, l_SecuritySrc) : d.OptionInfo;

                    var c = (d.OptionInfo == null) ? GetCcyInfo(d.CurrencyID, d.Date, l_SecuritySrc) : null;

                    var p1 = new OptionDescAndPrices();
                    var p2 = new MarketDataDouble();

                    p1.ContractSize = (d.OptionInfo == null) ? Convert.ToDouble(o.ContractSize) : -1;

                    p1.Currency = (d.OptionInfo == null) ? Convert.ToString(c.CcyCode) : "USD";

                    p1.ExerciseStyleCode = (d.OptionInfo == null) ? Convert.ToString(o.ExerciseStyle) : null;

                    p1.ExpirationDate = Convert.ToDateTime(o.Expiry);

                    p1.Last = (d.OptionInfo == null) ? Convert.ToDouble(d.LastOptPrice) : -99.99;

                    p1.LastBid = Convert.ToDouble(d.LastOptBid);
                    p1.LastAsk = Convert.ToDouble(d.LastOptAsk);

                    if (o.CallPut == 'C') p1.Nature = OptionNature.Call;
                    if (o.CallPut == 'P') p1.Nature = OptionNature.Put;

                    p1.OpenInterest = Convert.ToDouble(d.OpenInterest);

                    p1.PType = null;

                    p1.Strike = Convert.ToDouble(o.Strike);

                    p1.SType = null;

                    p1.Ticker = Convert.ToString(p_Ticker);

                    p1.Underlying = null;

                    p1.UnderlyingPrice = (d.OptionInfo == null) ? Convert.ToDouble(d.LastUndPrice) : -99.99;
                    p2.Data = (d.OptionInfo == null) ? Convert.ToDouble(d.LastUndPrice) : -99.99;

                    p1.Volume = Convert.ToDouble(d.Volume);

                    //p.Delta = Convert.ToDouble(d.RiskDelta);

                    //p.Gamma = Convert.ToDouble(d.RiskGamma);

                    //p.Vega = Convert.ToDouble(d.RiskVega);

                    //p.Theta = Convert.ToDouble(d.RiskTheta);

                    p1.Ticker = new string[] { "Ivy", p1.Underlying, p1.Class, p1.Nature.ToString(), p1.Strike.ToString(), p1.ExpirationDate.ToString("yyyyMMdd", CultureInfo.InvariantCulture) }.Stringify("_");
                    p1.TradeDate = d.Date;

                    t1[d.Date].Add(p1);

                    t2[d.Date] = p2;
                }

                var z = new Dictionary<DateTime, IMarketData>();

                if (p_Field == DataFieldsEnum.OptionDescAndPrices)
                {
                    foreach (var d in t1.Keys)
                    {
                        if (t1[d].Any())
                        {
                            z.Add(d, t1[d]);
                        }
                    }
                }

                if (p_Field == DataFieldsEnum.Last)
                {
                    foreach (var d in t2.Keys)
                    {
                        z.Add(d, t2[d]);
                    }
                }

                var s = new TimeSerieDB(z.Where(x => ((OptionDescAndPricesList)x.Value).Any()).ToArray(), p_Ticker, p_Field, p_Context);

                return s;
            }

            return null;
		}

		#endregion

		#region <!-- [Meth] Load -->

		public override IList<TimeSerieDB> Load(IEnumerable<String> p_Tickers, DataFieldsEnum p_Field, Nullable<DateTime> p_StartDate = null, Nullable<DateTime> p_EndDate = null, ILoadingContext p_Context = null)
		{
			return p_Tickers.Select(t => Load(t, p_Field, p_StartDate, p_EndDate, p_Context)).Where(x => x != null).ToArray();
		}

		#endregion

		#region <!-- [Type] CcyInfo -->

		private sealed class CcyInfo
		{
			#region <!-- [Prop] CcyID -->

			private Int32 m_CcyID;

			public Int32 CcyID
			{
				get { return m_CcyID; }
				set { m_CcyID = value; }
			}

			#endregion

			#region <!-- [Prop] CcyCode -->

			private String m_CcyCode;

			public String CcyCode
			{
				get { return m_CcyCode; }
				set { m_CcyCode = value; }
			}

			#endregion

			#region <!-- [Prop] CcyDesc -->

			private String m_CcyDesc;

			public String CcyDesc
			{
				get { return m_CcyDesc; }
				set { m_CcyDesc = value; }
			}

			#endregion
		}

		#endregion

		#region <!-- [Type] ExchInfo -->

		private sealed class ExchInfo
		{
			#region <!-- [Prop] ExchID -->

			private Int32 m_ExchID;

			public Int32 ExchID
			{
				get { return m_ExchID; }
				set { m_ExchID = value; }
			}

			#endregion

			#region <!-- [Prop] ExchCode -->

			private String m_ExchCode;

			public String ExchCode
			{
				get { return m_ExchCode; }
				set { m_ExchCode = value; }
			}

			#endregion

			#region <!-- [Prop] ExchCountry -->

			private String m_ExchCountry;

			public String ExchCountry
			{
				get { return m_ExchCountry; }
				set { m_ExchCountry = value; }
			}

			#endregion

			#region <!-- [Prop] ExchDesc -->

			private String m_ExchDesc;

			public String ExchDesc
			{
				get { return m_ExchDesc; }
				set { m_ExchDesc = value; }
			}

			#endregion
		}

		#endregion

		#region <!-- [Type] OptionInfo -->

		private sealed class OptionInfo
		{
			#region <!-- [Prop] SecurityID -->

			private Int32 m_SecurityID;

			public Int32 SecurityID
			{
				get { return m_SecurityID; }
				set { m_SecurityID = value; }
			}

			#endregion

			#region <!-- [Prop] OptionID -->

			private Int32 m_OptionID;

			public Int32 OptionID
			{
				get { return m_OptionID; }
				set { m_OptionID = value; }
			}

			#endregion

			#region <!-- [Prop] ExchangeID -->

			private Int32 m_ExchangeID;

			public Int32 ExchangeID
			{
				get { return m_ExchangeID; }
				set { m_ExchangeID = value; }
			}

			#endregion

			#region <!-- [Prop] Description -->

			private String m_Description;

			public String Description
			{
				get { return m_Description; }
				set { m_Description = value; }
			}

			#endregion

			#region <!-- [Prop] CurrencyID -->

			private Int32 m_CurrencyID;

			public Int32 CurrencyID
			{
				get { return m_CurrencyID; }
				set { m_CurrencyID = value; }
			}

			#endregion

			#region <!-- [Prop] Strike -->

			private Double m_Strike;

			public Double Strike
			{
				get { return m_Strike; }
				set { m_Strike = value; }
			}

			#endregion

			#region <!-- [Prop] Expiry -->

			private DateTime m_Expiry;

			public DateTime Expiry
			{
				get { return m_Expiry; }
				set { m_Expiry = value; }
			}

			#endregion

			#region <!-- [Prop] CallPut -->

			private Char m_CallPut;

			public Char CallPut
			{
				get { return m_CallPut; }
				set { m_CallPut = value; }
			}

			#endregion

			#region <!-- [Prop] UnderlyingID -->

			private Int32 m_UnderlyingID;

			public Int32 UnderlyingID
			{
				get { return m_UnderlyingID; }
				set { m_UnderlyingID = value; }
			}

			#endregion

			#region <!-- [Prop] ContractSize -->

			private Int32 m_ContractSize;

			public Int32 ContractSize
			{
				get { return m_ContractSize; }
				set { m_ContractSize = value; }
			}

			#endregion

			#region <!-- [Prop] OptionStyle -->

			private Int32 m_OptionStyle;

			public Int32 OptionStyle
			{
				get { return m_OptionStyle; }
				set { m_OptionStyle = value; }
			}

			#endregion

			#region <!-- [Prop] ExerciseStyle -->

			private Char m_ExerciseStyle;

			public Char ExerciseStyle
			{
				get { return m_ExerciseStyle; }
				set { m_ExerciseStyle = value; }
			}

			#endregion
		}

		#endregion

		#region <!-- [Type] TickerData -->

		private sealed class TickerData
		{
			#region <!-- [Prop] SecurityID -->

			private Int32 m_SecurityID;

			public Int32 SecurityID
			{
				get { return m_SecurityID; }
				set { m_SecurityID = value; }
			}

			#endregion

			#region <!-- [Prop] ExchangeID -->

			private Int32 m_ExchangeID;

			public Int32 ExchangeID
			{
				get { return m_ExchangeID; }
				set { m_ExchangeID = value; }
			}

			#endregion

			#region <!-- [Prop] EffectiveDate -->

			private DateTime m_EffectiveDate;

			public DateTime EffectiveDate
			{
				get { return m_EffectiveDate; }
				set { m_EffectiveDate = value; }
			}

			#endregion
		}

		#endregion

		#region <!-- [Type] OptionPriceData -->

		private sealed class OptionPriceData
		{
			#region <!-- [Prop] OptionInfo -->

			private OptionInfo m_OptionInfo;

			public OptionInfo OptionInfo
			{
				get { return m_OptionInfo; }
				set { m_OptionInfo = value; }
			}

			#endregion

			#region <!-- [Prop] SecurityID -->

			private Int32 m_SecurityID;

			public Int32 SecurityID
			{
				get { return m_SecurityID; }
				set { m_SecurityID = value; }
			}

			#endregion

			#region <!-- [Prop] Date -->

			private DateTime m_Date;

			public DateTime Date
			{
				get { return m_Date; }
				set { m_Date = value; }
			}

			#endregion

			#region <!-- [Prop] OptionID -->

			private Int32 m_OptionID;

			public Int32 OptionID
			{
				get { return m_OptionID; }
				set { m_OptionID = value; }
			}

			#endregion

			#region <!-- [Prop] ExchangeID -->

			private Int32 m_ExchangeID;

			public Int32 ExchangeID
			{
				get { return m_ExchangeID; }
				set { m_ExchangeID = value; }
			}

			#endregion

			#region <!-- [Prop] CurrencyID -->

			private Int32 m_CurrencyID;

			public Int32 CurrencyID
			{
				get { return m_CurrencyID; }
				set { m_CurrencyID = value; }
			}

			#endregion

			#region <!-- [Prop] LastOptBid -->

			private Double m_LastOptBid;

			public Double LastOptBid
			{
				get { return m_LastOptBid; }
				set { m_LastOptBid = value; }
			}

			#endregion

			#region <!-- [Prop] LastOptAsk -->

			private Double m_LastOptAsk;

			public Double LastOptAsk
			{
				get { return m_LastOptAsk; }
				set { m_LastOptAsk = value; }
			}

			#endregion

			#region <!-- [Prop] LastOptPrice -->

			private Double m_LastOptPrice;

			public Double LastOptPrice
			{
				get { return m_LastOptPrice; }
				set { m_LastOptPrice = value; }
			}

			#endregion

			#region <!-- [Prop] LastUndPrice -->

			private Double m_LastUndPrice;

			public Double LastUndPrice
			{
				get { return m_LastUndPrice; }
				set { m_LastUndPrice = value; }
			}

			#endregion

			#region <!-- [Prop] ImpliedVol -->

			private Double m_ImpliedVol;

			public Double ImpliedVol
			{
				get { return m_ImpliedVol; }
				set { m_ImpliedVol = value; }
			}

			#endregion

			#region <!-- [Prop] RiskDelta -->

			private Double m_RiskDelta;

			public Double RiskDelta
			{
				get { return m_RiskDelta; }
				set { m_RiskDelta = value; }
			}

			#endregion

			#region <!-- [Prop] RiskGamma -->

			private Double m_RiskGamma;

			public Double RiskGamma
			{
				get { return m_RiskGamma; }
				set { m_RiskGamma = value; }
			}

			#endregion

			#region <!-- [Prop] RiskVega -->

			private Double m_RiskVega;

			public Double RiskVega
			{
				get { return m_RiskVega; }
				set { m_RiskVega = value; }
			}

			#endregion

			#region <!-- [Prop] RiskTheta -->

			private Double m_RiskTheta;

			public Double RiskTheta
			{
				get { return m_RiskTheta; }
				set { m_RiskTheta = value; }
			}

			#endregion

			#region <!-- [Prop] CalcMethod -->

			private Char m_CalcMethod;

			public Char CalcMethod
			{
				get { return m_CalcMethod; }
				set { m_CalcMethod = value; }
			}

			#endregion

			#region <!-- [Prop] Volume -->

			private Int64 m_Volume;

			public Int64 Volume
			{
				get { return m_Volume; }
				set { m_Volume = value; }
			}

			#endregion

			#region <!-- [Prop] OpenInterest -->

			private Int32 m_OpenInterest;

			public Int32 OpenInterest
			{
				get { return m_OpenInterest; }
				set { m_OpenInterest = value; }
			}

			#endregion

			#region <!-- [Prop] SpecialSettlement -->

			private Int32 m_SpecialSettlement;

			public Int32 SpecialSettlement
			{
				get { return m_SpecialSettlement; }
				set { m_SpecialSettlement = value; }
			}

			#endregion

			#region <!-- [Prop] ReferenceExchangeID -->

			private Int32 m_ReferenceExchangeID;

			public Int32 ReferenceExchangeID
			{
				get { return m_ReferenceExchangeID; }
				set { m_ReferenceExchangeID = value; }
			}

			#endregion
		}

		#endregion
	}
}