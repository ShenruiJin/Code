﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.CSV
{
    public class LocalCSVDataExecutable : ProviderExecutable
    {
        private readonly string[] repositoryDirectoryPaths = new []{ Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LocalData"),
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) != "" ? Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) : AppDomain.CurrentDomain.BaseDirectory, "LocalData")};
        private readonly IList<DataFieldsEnum> supportedFields;

        public LocalCSVDataExecutable()
        {
            repositoryDirectoryPaths.ForEach(repositoryDirectoryPath =>
            {
                if (!Directory.Exists(repositoryDirectoryPath))
                {
                    try
                    {
                        Directory.CreateDirectory(repositoryDirectoryPath);
                    }
                    catch (Exception e)
                    {
                        LoggingService.Error(GetType(), e);
                    }
                   
                }
            });

            supportedFields = repositoryDirectoryPaths.SelectMany(d => Directory.GetFiles(d)).SelectMany(x => ReadLockFree(x).Skip(1)).Select(x => x.Split(',', ';')[0])
                .Where(x => !string.IsNullOrEmpty(x))
                .Select(x => (DataFieldsEnum)Enum.Parse(typeof(DataFieldsEnum), x))
                 .Distinct()
                .ToArray();
        }

        private static IEnumerable<string> ReadLockFree(string path)
        {
            return File.ReadAllLines(path);
        }
         
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var filePartsLines = repositoryDirectoryPaths.SelectMany(d => Directory.GetFiles(d)).SelectMany(ReadLockFree).Select(x => x.Split(',', ';')).ToArray();

            var fieldColIndex = 0;
            var instrumentColIndex = 1;
            var dateColIndex = 2;
            var valueColIndex = 3;

            var lines = filePartsLines.Where(x => x[fieldColIndex].Trim() == field.ToString() && tickers.Contains(x[instrumentColIndex])).ToArray();

            var values =
                lines.GroupBy(l => l[instrumentColIndex].Trim()).ToDictionary(x => x.Key,
                l =>
                l.Select(x =>
                        new KeyValuePair<DateTime, IMarketData>(
                            DateTime.ParseExact(x[dateColIndex], "dd/MM/yyyy", CultureInfo.InvariantCulture),
                            ParseValue(field, x[valueColIndex])))
                    .Where(
                        x =>
                        x.Key == DateTime.MinValue ||
                            (x.Key >= startDate.GetValueOrDefault() &&
                            x.Key <= endDate.GetValueOrDefault(DateTime.MaxValue)))).ToArray();

            return values.Select(x => new TimeSerieDB(x.Value.OrderBy(v=> v.Key).ToArray(), x.Key, field)).ToArray();
        }

        private static IMarketData ParseValue(DataFieldsEnum field, string val)
        {
            double dbleVal;

            if (double.TryParse(val, NumberStyles.Any, CultureInfo.InvariantCulture, out dbleVal))
            {
                return field == DataFieldsEnum.Dividend ? (IMarketData)new Dividend { Value = dbleVal } : new MarketDataDouble(dbleVal);
            }

            return new MarketDataString(val);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return supportedFields; }
        }
    }
}
