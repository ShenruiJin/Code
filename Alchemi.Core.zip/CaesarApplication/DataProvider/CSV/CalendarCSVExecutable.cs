﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using CaesarApplication.Service.Logging;
using CaesarCommon.Configuration;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.CSV
{
    public class CalendarCSVExecutable : ProviderExecutable
    {
        private Regex fileRegex = new Regex("^NATXPA.*.txt$");
        private string directoryPath;
        private char _separator = '\t';

        private string[] reccurentHollidayCodes = new string[]
        {
            "34",
            "94",

        };

        public CalendarCSVExecutable(string financialCalendarsDirectory = null)
        {
            directoryPath = financialCalendarsDirectory ?? new CaesarSettingsManager().FinancialCalendarsDirectory;
        }

        CultureInfo FileDateFromat = new CultureInfo("en-US");

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();
            
            try
            {
                foreach (var ticker in tickers)
                {
                    IMarketData calendar = null;

                    if (endDate == DateTime.Today)
                    {
                        var files = GetEligibleFileContent(ticker);

                        Dictionary<DateTime, string> days = new Dictionary<DateTime, string>();
                        foreach (var iterator in files.Zip(files.Skip(1).Concat(new ElligibleFile[] { null }), (current, next) => new { current, next }))
                        {
                            var eligibleFileContent = iterator.current.Value;
                            var readUntil = iterator.next != null ? iterator.next.StartDate : DateTime.MaxValue;

                            if (eligibleFileContent != null)
                            {
                                var lines = eligibleFileContent.Split("\r\n".AsArray(), StringSplitOptions.None);
                                var headers = lines[0].Split(_separator);
                                var tickerHeaderIndex = headers.IndexOf(ticker);


                                foreach (var l in lines.Skip(1))
                                {
                                    if (l.IsNullOrEmpty())
                                    {
                                        continue;
                                    }
                                    var linesParts = l.Split(_separator);
                                    var currentdate = DateTime.Parse(linesParts[0], FileDateFromat);
                                    if (currentdate >= readUntil)
                                    {
                                        //// next files will contains all dates
                                        break;
                                    }

                                    if (!days.ContainsKey(currentdate))
                                    {
                                        days.Add(currentdate, linesParts[tickerHeaderIndex]);
                                    }
                                }

                            }
                        }
                        calendar = days.Count!=0 ? new GlobalDerivativesApplications.Data.MarketData.Calendar(
                                GetRecurrentDays(days),
                                GetNonRecurrentDays(days),
                                GetWeekendDays(days)) : null;
                    }

                    var timeSerieDB = new TimeSerieDB(calendar != null ? new KeyValuePair<DateTime, IMarketData>(DateTime.Today, calendar).AsArray() : new KeyValuePair<DateTime, IMarketData>[0], ticker, field);

                    timeSerieDB.StartDate = startDate;
                    timeSerieDB.EndDate = endDate;
                    timeSerieDB.IsConsideredAsComplete = calendar != null;

                    output.Add(timeSerieDB);
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Error loading Calendar", ex);
            }


            return output;
        }

        private List<DayOfWeek> GetWeekendDays(Dictionary<DateTime, string> days)
        {
            return days.Where(x => x.Value == "w").Select(x => x.Key.DayOfWeek).Distinct().ToList();
        }

        private List<DateTime> GetNonRecurrentDays(Dictionary<DateTime, string> days)
        {
            return days.Where(d => 
            d.Value != "g"
            && d.Value != "w"
            && !reccurentHollidayCodes.Contains(d.Value)
            ).Select(x => x.Key).ToList();
        }

        private List<DateTime> GetRecurrentDays(Dictionary<DateTime, string> days)
        {
            return days.GroupBy(x => x.Value).Where(g => reccurentHollidayCodes.Contains(g.Key)).Select(x => x.Last().Key).Select(x => new DateTime(1900, x.Month, x.Day)).ToList();
        }

        public class ElligibleFile
        {
            public FileInfo Key { get; set; }
            public string Value { get; set; }
            public bool Ok { get; set; }
            public DateTime? StartDate { get; set; }
        }

        private IList<ElligibleFile> GetEligibleFileContent(string ticker)
        {
            var files = Directory.GetFiles(directoryPath, "*.txt", SearchOption.AllDirectories).Where(f => fileRegex.IsMatch(Path.GetFileName(f))).ToArray();

            var filesContent = new List<KeyValuePair<FileInfo, string>>();
                
             foreach(var p in  files)
             {
                var content = ReadLockFree(p);
                if (content == string.Empty)
                    continue;
                filesContent.Add(new KeyValuePair<FileInfo, string>(new FileInfo(p), content));
            }

            ///filter by access time, only files containing the required calendar
            var orderedEnumerable = filesContent.Select(x =>
               {
                   var endLineIndex = x.Value.IndexOf("\r\n");
                   var secondLineIndex = x.Value.IndexOf("\r\n", 2 + endLineIndex);

                   bool ok = endLineIndex != -1
                   && secondLineIndex != -1
                   && x.Value.Substring(0, endLineIndex).Split(_separator).Contains(ticker);

                   string secondLine = x.Value.Substring(endLineIndex + 2, secondLineIndex - (endLineIndex + 2));

                   DateTime? start = null;
                   if (ok)
                   {
                       start = DateTime.Parse(secondLine.Split('\t').First(), FileDateFromat);
                   }
                   return new ElligibleFile() { Key = x.Key, Value = x.Value, Ok = ok, StartDate = start };
               })
               .Where(_ => _.Ok)
               .OrderBy(x => x.Key.LastAccessTimeUtc).ToArray();

            return orderedEnumerable.ToArray();
        }

        private string ReadLockFree(string path)
        {
            try
            {
                using (var stream = File.Open(path, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    using (var streamReader = new StreamReader(stream))
                    {
                        return streamReader.ReadToEnd();
                    }
                }
            }
            catch(Exception e)
            {
                LoggingService.Error(this.GetType(), "Unable to open file "+path+"\n"+e.Message);
                return string.Empty;
            }
        }

        /// <summary>
        /// answers the calendar field
        /// </summary>
        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new[] { DataFieldsEnum.Calendar }; }
        }

        public string[] GetAllAvailableCalendars()
        {
            var files = Directory.GetFiles(directoryPath, "*.txt", SearchOption.AllDirectories).Where(f => fileRegex.IsMatch(Path.GetFileName(f))).ToArray();
            var fileContents = files.Select(p => ReadLockFree(p)).Where(i => i != string.Empty);
                
             return fileContents.SelectMany(p => p.Substring(0, p.IndexOf("\r\n"))
             .Split('\t').Skip(1).ToArray()).Distinct().ToArray();
        }
    }
}
