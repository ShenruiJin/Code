﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using CaesarCommon.Configuration;
using System.Text.RegularExpressions;
using System.IO;
using System.Globalization;
using GlobalDerivativesApplications.Data.MarketData;
using CaesarCommon.Utils;
using MarketData;
using CaesarApplication.Utilities;
using GlobalDerivativesApplications.Date;

namespace CaesarApplication.DataProvider.CSV
{
    public abstract class ComexExecutable : ProviderExecutable
    {
        protected string directoryPath;

        protected char delimiter = ',';
        private static string[] localFiles;

        public ComexExecutable(string directory = null)
        {
            directoryPath = directory ?? new CaesarSettingsManager().ComexDataFilesDirectoryPath;
        }

        public abstract Regex FileRegex { get; }

        protected double? GetDoubleDataForLineIfExists(string[] line, string[] headers, string header)
        {
            var str = GetStringDataForLine(line, headers, header);

            if (!string.IsNullOrEmpty(str))
            {
                return GetDoubleDataForLine(line, headers, header);
            }

            return null;
        }

        protected string GetStringDataForLine(string[] line, string[] headers, string header)
        {
            return line[headers.IndexOf(header)];
        }

        protected double GetDoubleDataForLine(string[] line, string[] headers, string header)
        {
            return double.Parse(GetStringDataForLine(line, headers, header), CultureInfo.InvariantCulture);
        }

        protected int GetIntDataForLine(string[] line, string[] headers, string header)
        {
            return int.Parse(GetStringDataForLine(line, headers, header), CultureInfo.InvariantCulture);
        }

        protected DateTime GetFileDateFromName(string fileName)
        {
            return DateTime.ParseExact(Path.GetFileNameWithoutExtension(fileName).Substring(0, 8), "yyyyMMdd", CultureInfo.InvariantCulture);
        }


        protected string[] GetFilesForInterval(DateTime startDate, DateTime endDate)
        {
            var files = localFiles = (localFiles ?? Directory.GetFiles(directoryPath));

            return files.Where(x => FileRegex.IsMatch(Path.GetFileName(x))).Select(x => new { Date = GetFileDateFromName(x), FileName = x })
                .Where(x => x.Date >= startDate && x.Date <= endDate)
                .GroupBy(x => x.Date)
                .Select(x => x.OrderBy(v => new[] { "f", "p", "e" }.IndexOf(Path.GetFileNameWithoutExtension(v.FileName).Last().ToString())).First().FileName)
                .ToArray();
        }
    }

    public class OptionDescAndPricesComexExecutable : ComexExecutable
    {
        private ICalendar goldCalendar;
        private string calendarDirectory;

        public override Regex FileRegex
        {
            get => new Regex("^.*EOD_xcec_og_opt_0.*eth_.*.csv$");
        }

        private Dictionary<string, string> underlyingMappings = new Dictionary<string, string>
        {
            { "OG", "GC"}
        };

        public OptionDescAndPricesComexExecutable(string directory = null, string calendarDirectory = null) : base(directory)
        {
            goldCalendar = new GlobalDerivativesApplications.Data.MarketData.Calendar(new List<DateTime>(), IOTools.ReadLockFree(Path.Combine(directory ?? directoryPath, "GCOptionCalendar.csv")).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries)
                .Select(x => DateTime.ParseExact(x, "dd/MM/yyyy", CultureInfo.InvariantCulture)).ToList());
            this.calendarDirectory = calendarDirectory;
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = default(DateTime?), DateTime? endDate = default(DateTime?), ILoadingContext loadingContext = null)
        {
            var files = GetFilesForInterval(startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.MaxValue));

            if (files.Any())
            {
                var fileContents = files.Select(x => IOTools.ReadLockFree(x).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries).Select(l => l.Replace("\"", "").Split(delimiter)).ToArray()).ToArray();
                
                var options = new List<OptionDescAndPrices>();

                foreach (var fileContent in fileContents)
                {
                    var headers = fileContent[0];

                    foreach (var line in fileContent.Skip(1))
                    {
                        var tradeDate = DateTime.ParseExact(GetStringDataForLine(line, headers, "Trade Date"), "yyyyMMdd", CultureInfo.InvariantCulture);
                        string underlying = GetStringDataForLine(line, headers, "Product Code");

                        var udl = underlyingMappings.ContainsKey(underlying)  ? underlyingMappings[underlying]
                            :
                            underlying;

                        if (tickers.Contains(udl))
                        {
                            var opt = new OptionDescAndPrices
                            {
                                Nature = GetStringDataForLine(line, headers, "Put/Call") == "C" ? OptionNature.Call : OptionNature.Put,
                                Strike = GetIntDataForLine(line, headers, "Strike Price"),
                                Last = GetDoubleDataForLine(line, headers, "Settlement"),
                                Underlying = FutureConventions.GetFutureTickerForGoldOption(tradeDate, GetIntDataForLine(line, headers, "Contract Year"), GetIntDataForLine(line, headers, "Contract Month")),
                                TradeDate = tradeDate,
                                ExerciseStyleCode = "American",
                                Settlement = GetDoubleDataForLine(line, headers, "Settlement"),
                                OpenInterest = GetDoubleDataForLineIfExists(line, headers, "Open Interest").GetValueOrDefault(),
                                Currency = "USD",
                                LastBid = GetDoubleDataForLine(line, headers, "Settlement"),
                                LastAsk = GetDoubleDataForLine(line, headers, "Settlement"),
                                ExpirationDate = FutureConventions.GetGoldOptionExpirationDate(goldCalendar, GetIntDataForLine(line, headers, "Contract Year"), GetIntDataForLine(line, headers, "Contract Month")),
                                Low = GetDoubleDataForLineIfExists(line, headers, "Globex Low Price").GetValueOrDefault(GetDoubleDataForLineIfExists(line, headers, "Floor Low Price").GetValueOrDefault())
                            };

                            opt.Ticker = string.Format("COMEX|{0}|{1}|{2}|{3}|{4}", opt.TradeDate.ToString("ddMMyyyy"), opt.Underlying, opt.Nature, opt.ExpirationDate.ToString("ddMMyyyy"), opt.Strike.ToString(CultureInfo.InvariantCulture));

                            options.Add(opt);
                        }
                    }
                }

                var futureTickers = options.Select(x => x.Underlying).Distinct().ToArray();

                var priceExec = new FuturesComexExecutable(directoryPath, calendarDirectory);

                var optionsByUnderlying = tickers.ToDictionary(x => FutureConventions.GetUnderlyingFromTicker(x), x => options.Where(i => FutureConventions.GetUnderlyingFromTicker(i.Underlying) == x).ToArray()).ToArray();

                var priceSeries = priceExec.Load(futureTickers, DataFieldsEnum.Last, startDate, endDate)
                    .ToDictionary(x => x.Instrument, x => x);

                options.GroupBy(x => x.Underlying)
                    .ForEach(grp =>
                    {
                        var price = priceSeries[grp.Key];

                        grp.ForEach(o => o.UnderlyingPrice = price.Evaluate(o.TradeDate));
                    });

                return optionsByUnderlying.Select(x => new TimeSerieDB(x.Value.GroupBy(v => v.TradeDate)
                    .Select(v => new KeyValuePair<DateTime, IMarketData>(v.Key, new OptionDescAndPricesList(v.ToArray()))).ToArray(), x.Key, field))
                    .ToArray();
            }

            return tickers.Select(x => new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], x, field)).ToArray();
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return DataFieldsEnum.OptionDescAndPrices.AsArray();
            }

        }
    }

    public class FuturesComexExecutable : ComexExecutable
    {
        private ICalendar goldCalendar;

        public override Regex FileRegex { get => new Regex("^.*-EOD_xcec_gc_fut_0-eth_f.csv"); }

        public FuturesComexExecutable(string directory = null, string calendarDirectory = null) : base(directory)
        {
            goldCalendar = new GlobalDerivativesApplications.Data.MarketData.Calendar(new List<DateTime>(), IOTools.ReadLockFree(Path.Combine(calendarDirectory ?? directoryPath, "GCOptionCalendar.csv")).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries)
                .Select(x => DateTime.ParseExact(x, "dd/MM/yyyy", CultureInfo.InvariantCulture)).ToList());
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = default(DateTime?), DateTime? endDate = default(DateTime?), ILoadingContext loadingContext = null)
        {
            var files = GetFilesForInterval(startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.MaxValue));

            if (files.Any())
            {
                var fileContents = files.Select(x => IOTools.ReadLockFree(x).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries).Select(l => l.Replace("\"", "").Split(delimiter)).ToArray()).ToArray();

                var headers = fileContents[0][0].Select(x => x.Replace("\"", "")).ToArray();

                var marketData = new Dictionary<string, Dictionary<DateTime, IMarketData>>();

                foreach (var fileContent in fileContents)
                {
                    foreach (var line in fileContent.Skip(1))
                    {
                        var tradeDate = DateTime.ParseExact(GetStringDataForLine(line, headers, "Trade Date"), "yyyyMMdd", CultureInfo.InvariantCulture);

                        var contractDates = tickers.Select(x => new { Ticker = x, Year = FutureConventions.GetYearFromTicker(x, tradeDate), Month = FutureConventions.GetMonthFromTicker(x) }).ToArray();

                        var udl = GetStringDataForLine(line, headers, "Product Code");
                        var year = GetIntDataForLine(line, headers, "Contract Year");
                        var month = GetIntDataForLine(line, headers, "Contract Month");

                        var ticker = FutureConventions.GetFutureTicker(tradeDate, udl, year, month);

                        var requestedTicker = contractDates.FirstOrDefault(x => x.Year == year && x.Month == month);

                        if (tickers.Select(x => x.Substring(0, 2)).Contains(udl) && requestedTicker != null)
                        {
                            if (!marketData.ContainsKey(ticker))
                            {
                                marketData.Add(ticker, new Dictionary<DateTime, IMarketData>());
                            }

                            marketData[ticker][tradeDate] = new MarketDataDouble(GetDoubleDataForLine(line, headers, "Settlement"));

                            if (!marketData.ContainsKey(requestedTicker.Ticker))
                            {
                                marketData.Add(requestedTicker.Ticker, new Dictionary<DateTime, IMarketData>());
                            }

                            marketData[requestedTicker.Ticker][tradeDate] = new MarketDataDouble(GetDoubleDataForLine(line, headers, "Settlement"));
                        }
                    }
                }

                return marketData.Keys.Union(tickers.Where(x => !marketData.ContainsKey(x))).Select(x => new TimeSerieDB(marketData.Where(i => i.Key == x).SelectMany(u => u.Value).ToArray(), x, DataFieldsEnum.SettlementPrice))
                    .ToArray();
            }

            return tickers.Select(x => new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], x, field)).ToArray();
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return DataFieldsEnum.SettlementPrice.AsArray();
            }
        }
    }
}