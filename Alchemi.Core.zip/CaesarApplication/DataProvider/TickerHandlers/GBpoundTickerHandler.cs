﻿using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Maths;
using GlobalDerivativesApplications.Data.MarketData;
using System;
using MarketData;

namespace CaesarApplication.DataProvider.TickerHandlers
{
    [Serializable]
    public class GBpoundTickerHandler : ITickerHandler
    {
        public string[] GetTickersToRequest(string ticker)
        {
            var finalTicker = ticker.ToUpper();

            return finalTicker.AsArray();
        }

        public TimeSerieDB[] Calculate(string ticker, DataFieldsEnum field, Dictionary<string, TimeSerieDB[]> calculationMembers)
        {
            if(field == DataFieldsEnum.QuoteFactor)
            {
                var timeSeries = calculationMembers.SelectMany(x => x.Value).Where(x => x.Field == DataFieldsEnum.QuoteFactor && x.Instrument == ticker.ToUpper()).ToArray();

                return timeSeries.Select(timeSerie => new TimeSerieDB(timeSerie.GetElements(), ticker, DataFieldsEnum.QuoteFactor)).ToArray();
            }

            var firstCurrency = ticker.Substring(0, 3);
            var secondCurrency = ticker.Substring(3, 3);

            var factor = firstCurrency.Last().ToString() != firstCurrency.Last().ToString().ToUpper() ? 0.01 : 1;
            factor *= secondCurrency.Last().ToString() != secondCurrency.Last().ToString().ToUpper() ? 100 : 1;

            if (!calculationMembers.ContainsKey(ticker.ToUpper()))
            {
                return new TimeSerieDB[0];
            }
            var dataSerie = calculationMembers[ticker.ToUpper()].FirstOrDefault(x => x.Field == DataFieldsEnum.Last);

            if (string.Equals(firstCurrency, secondCurrency, System.StringComparison.CurrentCultureIgnoreCase))
            {
                var dates = Enumerable.Range(0, (int)(dataSerie.EndDate.GetValueOrDefault() - dataSerie.StartDate.GetValueOrDefault()).TotalDays + 1)
                    .Select(i => dataSerie.StartDate.GetValueOrDefault().AddDays(i)).ToArray();

                return new TimeSerieDB(dates.Select(d => new KeyValuePair<DateTime, IMarketData>(d, new MarketDataDouble(factor))).ToArray(), ticker, DataFieldsEnum.Last).AsArray();
            }

            var ts = CaesarMaths.MultipliedBy(dataSerie, factor, ticker);

            ts.Field = field;
            ts.Instrument = ticker;

            return ts.AsArray();
        }

        public string TickerRegex
        {
            get { return @"^([A-Z]{2}[a-z]{1}[A-Z]{2}[A-z]{1})|([A-Z]{2}[A-z]{1}[A-Z]{2}[a-z]{1}).*$"; }
        }

        public Dictionary<DataFieldsEnum, DataFieldsEnum[]> CalculationFields
        {
            get
            {
                return new Dictionary<DataFieldsEnum, DataFieldsEnum[]>
                {
                    {DataFieldsEnum.Last, new []{ DataFieldsEnum.Last }},
                    {DataFieldsEnum.QuoteFactor, new []{ DataFieldsEnum.QuoteFactor }}
                };
            }
        }

        public DataFieldsEnum[] ImpactedFields
        {
            get { return new[] { DataFieldsEnum.Last, DataFieldsEnum.QuoteFactor }; }
        }
    }
}
