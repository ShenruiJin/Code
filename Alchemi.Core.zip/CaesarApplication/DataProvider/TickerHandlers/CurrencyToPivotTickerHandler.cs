﻿using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Maths;

namespace CaesarApplication.DataProvider.TickerHandlers
{
    public class CurrencyToPivotTickerHandler : ITickerHandler
    {
        public string[] GetTickersToRequest(string ticker)
        {
            return new string[] { ticker, GetInversedTicker(ticker) };
        }

        private static string GetInversedTicker(string ticker)
        {
            return ticker.Substring(3, 3) + ticker.Substring(0, 3) + ticker.Substring(6);
        }

        public TimeSerieDB[] Calculate(string ticker, DataFieldsEnum field, Dictionary<string, TimeSerieDB[]> calculationMembers)
        {
            var ts = GetTimeSerie(ticker, field, calculationMembers) ?? GetTimeSerieForReverse(ticker, field, calculationMembers);

            return ts != null ? ts.AsArray() : new TimeSerieDB[0];
        }

        private static TimeSerieDB GetTimeSerieForReverse(string ticker, DataFieldsEnum field, Dictionary<string, TimeSerieDB[]> calculationMembers)
        {
            var ts = GetTimeSerie(GetInversedTicker(ticker), field, calculationMembers);

            return ts != null ? CaesarMaths.Pow(ts, -1.0d, ts.FieldName) : null;
        }

        private static TimeSerieDB GetTimeSerie(string ticker, DataFieldsEnum field, Dictionary<string, TimeSerieDB[]> calculationMembers)
        {
            return calculationMembers.Where(x => x.Key == ticker).Select(x => x.Value.FirstOrDefault(t => t.Field == field))
                .FirstOrDefault();
        }

        public string TickerRegex
        {
            get { return @"^(USD[A-Z]{3}).*$"; }
        }

        public Dictionary<DataFieldsEnum, DataFieldsEnum[]> CalculationFields
        {
            get
            {
                return new Dictionary<DataFieldsEnum, DataFieldsEnum[]>
                {
                    {DataFieldsEnum.Last, new []{ DataFieldsEnum.Last }}
                };
            }
        }

        public DataFieldsEnum[] ImpactedFields
        {
            get { return new[] { DataFieldsEnum.Last }; }
        }
    }
}