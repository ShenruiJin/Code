using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using FuncFramework.Business;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class DatabaseInstrumentCodeTranscoder : InstrumentCodeTranscoder
    {
        public override string[] TranscodeInternalToExternal(string[] internalCodes, ILoadingContext context)
        {
            var sophisSicovamsAsInts = new List<int>();
            var stringCodes = new List<string>();
            var localStringCodes = new List<string>();

            foreach (var internalCode in internalCodes)
            {
                int code;
                if (!IsLocalData && int.TryParse(internalCode, out code))
                {
                    sophisSicovamsAsInts.Add(code);
                }
                else
                {
                    if (context != null && context.IndexPaths != null && context.IndexPaths.Any(x => internalCode.StartsWith(IndexPathHelper.Combine(context.ProjectName, x))))
                    {
                        localStringCodes.Add(internalCode);
                    }
                    else
                    {
                        stringCodes.Add(internalCode);
                    }
                }
            }

            var references = SophisHelper.GetReferences(sophisSicovamsAsInts.ToArray());

            return internalCodes.Select(c =>
            {
                if (localStringCodes.Contains(c))
                {
                    return GetLocalFromExternalCode(c);
                }
                else if (!stringCodes.Contains(c) && references.ContainsKey(int.Parse(c)))
                {
                    return references[int.Parse(c)];
                }
                else
                {
                    return c;
                }
            }).ToArray();
        }

        private static string GetLocalFromExternalCode(string internalCode)
        {
            return IndexPathHelper.Combine(IndexPathHelper.Split(internalCode).Skip(1).ToArray());
        }

        public override string[] TranscodeExternalToInternal(string[] externalCodes, ILoadingContext context)
        {
            //externalCodes.ForEach(res => LoggingService.DebugFormatted(typeof(DatabaseInstrumentCodeTranscoder), "Database transco to transcode : {0}", res));

            var externalCodesToSophis =
                externalCodes.Where(c => !IsLocalData && !c.Contains(MarketDataMgr.Trees.MarketDataTree.PathDelimiter)).ToArray();

            var internalCodes = externalCodes.Where(c => c.Contains(MarketDataMgr.Trees.MarketDataTree.PathDelimiter)).ToArray();

            var internalCodesTranscoded = internalCodes.Distinct().ToDictionary(c => c, c =>
            {
                if (context != null && context.IndexPaths != null && context.IndexPaths.Any(prefix => c.StartsWith(prefix)))
                {
                    return IndexPathHelper.Combine(context.ProjectName, c);
                }

                return c;
            });

            var references = SophisHelper.GetSicovams(externalCodesToSophis);

            var result = externalCodes.Select(c => references.ContainsKey(SophisHelper.AdaptTickerForSophis(c)) ? references[SophisHelper.AdaptTickerForSophis(c)].ToString() : (internalCodesTranscoded.ContainsKey(c) ? internalCodesTranscoded[c] : c)).ToArray();

            //result.ForEach(res => LoggingService.DebugFormatted(typeof(DatabaseInstrumentCodeTranscoder), "Database transco result : {0}", res));

            return result;
        }

        public virtual bool IsLocalData
        {
            get { return false; }
        }
    }
}