using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    public interface IProviderRouterTechnical
    {
        /// <summary>
        /// Providers for global operations
        /// </summary>
        IDictionary<DataFieldsEnum, IProviderExecutable> GlobalProviderExecutables { get; }

        /// <summary>
        /// Providers for local operations
        /// </summary>
        IDictionary<DataFieldsEnum, IProviderExecutable> LocalProviderExecutables { get; }
    }
}