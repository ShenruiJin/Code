using System;

namespace CaesarApplication.DataProvider
{
    public class CalculationException : Exception
    {
        public CalculationException(string message)
            : base(message)
        {}
    }
}