using System.Collections.Generic;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    public class TimeSeriesUtils
    {
    }
}