using System;
using System.Linq;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class BloombergTranscoder : InstrumentCodeTranscoder
    {
        public override string TranscodeInternalToExternal(string internalCode, ILoadingContext context)
        {
            var codeParts = internalCode.Split(new []{ " " }, StringSplitOptions.None);
            return string.Join(" ", codeParts.Take(codeParts.Count() - 1));
        }

        public override string[] TranscodeExternalToInternal(string[] externalCodes, ILoadingContext context)
        {
            var tickers = SophisHelper.GetBloombergTickers(externalCodes);

            return externalCodes.Select(x => tickers[x]).ToArray();
        }
    }
}