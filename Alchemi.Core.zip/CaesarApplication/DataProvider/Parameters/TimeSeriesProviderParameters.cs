﻿
namespace CaesarApplication.DataProvider.Parameters
{
    public class TimeSeriesProviderParameters
    {
        public TimeSeriesProviderParameters(string[] dataHandlersToUse = null, string[] specificDBSources = null, bool readOnly = true)
        {
            ReadOnly = readOnly;
            SaveAsDefault = true;
            DataHandlersToUse = dataHandlersToUse;
            SpecificDBSources = specificDBSources;
        }
        public bool ReadOnly { get; set; }
        public bool NoDBLoading { get; set; }
        public bool IsTreeOnly { get; set; }
        public bool NoCacheLoading { get; set; }
        public bool SaveAsDefault { get; set; }
        public string[] DataHandlersToUse { get; set; }
        public string[] SpecificDBSources { get; set; }
        public bool NoFilterSources { get; set; }
    }
}
