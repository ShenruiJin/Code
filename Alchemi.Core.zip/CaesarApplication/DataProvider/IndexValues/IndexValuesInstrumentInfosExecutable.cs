﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using System.Linq;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Data.MarketData;
using MarketData;
using DealServerInterface.Service;

namespace CaesarApplication.DataProvider.IndexValues
{
    public class IndexValuesInstrumentInfosExecutable : ProviderExecutable
    {
        private IIndexDBProviderFactory indexDBProviderFactory;

        public IndexValuesInstrumentInfosExecutable(IIndexDBProviderFactory indexDBProviderFactory)
        {
            this.indexDBProviderFactory = indexDBProviderFactory;
        }

        private IIndexDBProvider IndexDBProvider
        {
            get
            {
                return (indexDBProviderFactory = indexDBProviderFactory ?? new IndexDBProviderFactory()).Create();
            }
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = default(DateTime?), DateTime? endDate = default(DateTime?), ILoadingContext loadingContext = null)
        {
            var indexInfosByTicker = tickers.Where(x => !x.StartsWith(IndexValuesCodeTranscoder.UnknownPrefix)).ToDictionary(x => x, x => IndexDBProvider.GetIndexFromCode(x, UserService.CaesarSession));

            return indexInfosByTicker.Select(x => new TimeSerieDB(DateTime.MinValue, GetValueFromIndexInfos(field, x.Value), x.Key, field)).ToArray();
        }

        private IMarketData GetValueFromIndexInfos(DataFieldsEnum field, IndexDTO value)
        {
            switch(field)
            {
                case DataFieldsEnum.Currency:
                    return new MarketDataString(value.currency_code);
            }

            throw new ArgumentException(field + " not managed");
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[] { DataFieldsEnum.Currency };
            }
        }
    }
}
