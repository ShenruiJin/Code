﻿using FuncFramework.Business;
using PricingBase.DataProvider;
using System.Linq;

namespace CaesarApplication.DataProvider.IndexValues
{
    public class IndexValuesCodeTranscoder : InstrumentCodeTranscoder
    {
        public const string UnknownPrefix = "Unknown$";

        public override string[] TranscodeExternalToInternal(string[] externalCodes, ILoadingContext context)
        {
            return externalCodes.Select(externalCode => (externalCode.Contains(IndexPathHelper.Delimiter.ToString()) || (externalCode.StartsWith("NXS") && !externalCode.Trim().Contains(" ")) ? externalCode : UnknownPrefix + externalCode)).ToArray();
        }
    }
}
