using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    public interface IDataHandlerTechnical
    {
        /// <summary>
        /// Provides implementations to each market data
        /// </summary>
        IProviderRouter Router { get; }
    }
}