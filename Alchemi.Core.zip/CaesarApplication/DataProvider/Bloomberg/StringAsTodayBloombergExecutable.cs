using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public class StringAsTodayBloombergExecutable : AsTodayBloombergExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public StringAsTodayBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Currency,
                DataFieldsEnum.Isin,
                DataFieldsEnum.DividendCurrency,
                DataFieldsEnum.CountryIssue,
                DataFieldsEnum.CountryFullName,
                DataFieldsEnum.CountryOfIncorporation,
                DataFieldsEnum.DirtyClean,
                DataFieldsEnum.PriceFlag,
                DataFieldsEnum.FirstSettlementDate,
                DataFieldsEnum.NextDividendCurrency
            };
        }


        /// <summary>
        /// Converts a double to a MarketDataDouble object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IMarketData ConvertToMarketData(object value)
        {
            TreeNode tn = value as TreeNode;
            if (null != tn)
            {
                var str = tn.Cast<string>();
                return new MarketDataString(str);
            }
            return new MarketDataString((string)value);
        }
    }
}