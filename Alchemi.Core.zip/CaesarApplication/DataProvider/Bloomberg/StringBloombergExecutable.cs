﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public class StringBloombergExecutable : SimpleBloombergExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public StringBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Sector,
                DataFieldsEnum.Country,
                DataFieldsEnum.ICB_INDUSTRY_NAME,
                DataFieldsEnum.ICB_SECTOR_NAME,
                DataFieldsEnum.ICB_SUBSECTOR_NAME,
                DataFieldsEnum.FUT_CUR_GEN_TICKER
            };
        }

        /// <summary>
        /// Converts a double to a MarketDataDouble object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IMarketData ConvertToMarketData(object value)
        {
            TreeNode tn = value as TreeNode;
            if (null != tn)
            {
                 var str = tn.Cast<string>();
                return new MarketDataString(str);
            }
            return new MarketDataString((string)value);
        }

        public override bool IsUndated()
        {
            return true;
        }
    }
}
