﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.BloombergServices;
using GlobalDerivativesApplications.DynamicDataExchange.Provider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Resultat;
using PricingBase.DataProvider;
using PricingBase.MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    [Serializable]
    public abstract class TableBloombergExecutable : ProviderExecutable
    {
        /// <summary>
        /// Bloomberg provider
        /// </summary>
        private IDataProvider _provider;
        public IDataProvider Provider
        {
            get { return _provider = _provider ?? new BloombergDataProvider(); }
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var ddeResult = RequestDdeResult(tickers, field);
            var timeSeries = new List<TimeSerieDB>();

            foreach (var ticker in tickers)
            {
                if (ddeResult.ContainsReference(ticker))
                {
                    var dataForTicker = ddeResult[ticker].First();

                    timeSeries.Add(new TimeSerieDB(endDate.GetValueOrDefault(), new TableData(((IEnumerable<object>)dataForTicker.Value).Select(x => (List<object>)x).ToList()), ticker, field));
                }
            }

            return timeSeries;
        }

        protected virtual DDEResult RequestDdeResult(IEnumerable<string> tickers, DataFieldsEnum field, Dictionary<string, string> overrides = null)
        {
            DDEResult ddeResult = Provider.Get(tickers.ToList(), new List<DataFieldsEnum> {field}, overrides);
            return ddeResult;
        }
    }
}