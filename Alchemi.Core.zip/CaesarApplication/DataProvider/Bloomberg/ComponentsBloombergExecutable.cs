﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Index;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.BloombergDataProvider;
using GlobalDerivativesApplications.Data.BloombergData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.BloombergWrapper;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for index composition
    /// </summary>
    [Serializable]
    public class ComponentsBloombergExecutable : ProviderExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public ComponentsBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.IndexcomponentsWeightsAndPrices,
                DataFieldsEnum.IndexComponents
            };
        }


        private Lazy<AppBBGWrapper> _appbbgwrapper = new Lazy<AppBBGWrapper>(() =>
        {
            AppBBGWrapper large = new AppBBGWrapper();
            return large;
        });

        /// <summary>
        /// provider
        /// </summary>
        protected AppBBGWrapper Provider { get { return _appbbgwrapper.Value;  } }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null,
                                                            DateTime? endDate = null, ILoadingContext loadingContext = null)
        {

            IList<TimeSerieDB> output = new List<TimeSerieDB>();

            InitializeDates(ref startDate, ref endDate);

            if (endDate == DateTime.Today &&
                startDate == DateTime.Today)
            {
                foreach (var ticker in tickers)
                {
                    IDictionary<string, string> overrides = new Dictionary<string, string>();

                    DateTime date = endDate.Value;

                    var results = Provider.GetBasketComposition(ticker, date);

                    IIndexComponentList data = CreateIndexComponents(ticker, field, results);

                    output.Add(new TimeSerieDB(new List<DateTime> { DateTime.Today },
                                                                        new List<IMarketData> { data },
                                                                        ticker, field));
                }

                return output;
            }

            IList<DateTime> dates = GenerateDates(startDate.Value, endDate.Value);
            IList<IList<IMarketData>> compositions = new List<IList<IMarketData>>();
            compositions.AddRange(tickers.Select(x => new List<IMarketData>()));

            var dico = new Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>();

            for (int i = 0; i < dates.Count; i++)
            {
                var date = dates[i];
                IDictionary<string, string> overrides = new Dictionary<string, string>();

                overrides.Add("end dt", dates[i].ToString("yyyyMMdd"));
                BBGBasketComposition results = null;
                for (int j = 0; j < tickers.Count(); j++)
                {
                    try
                    {
                        results = Provider.GetBasketComposition(tickers.ElementAt(j), date);
                    }
                    catch (Exception ex)
                    {
                        LoggingService.Error(GetType(), "Error loading IndexComponents", ex);
                    }


                    var ticker = tickers.ToArray()[j];
                    IIndexComponentList data = CreateIndexComponents(tickers.ElementAt(j), field, results);
                    compositions[j].AddRange(data.Components);

                    if (!dico.ContainsKey(ticker))
                    {
                        dico.Add(ticker, new List<KeyValuePair<DateTime, IMarketData>>());
                    }

                    dico[ticker].Add(new KeyValuePair<DateTime, IMarketData>(date, data));
                }
            }

            foreach (var kv in dico)
            {
                output.Add(new TimeSerieDB(kv.Value.Select(x => x.Key).ToArray(), kv.Value.Select(x => x.Value).ToArray(), kv.Key, field));
            }

            return output;
        }

        private IIndexComponentList CreateIndexComponents(string ticker, DataFieldsEnum field, BBGBasketComposition results)
        {
            IIndexComponentList index = new IndexComponents(ticker, IndexComponentWeight_Type.Percentage, 1.0, "");

            double totPerc = results.Stocks.Sum(o => o.PercentWeight);

            if (results != null)
                foreach (var o in results.Stocks)
                {
                    index.Components.Add(new IndexComponent(o.Reference, o.PercentWeight / totPerc, o.Price, o.ActualWeight));
                }

            return index;
        }
    }
}