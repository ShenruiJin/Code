using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for only live data
    /// </summary>
    [Serializable]
    public abstract class AsTodayBloombergExecutable : SimpleBloombergExecutable
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, PricingBase.DataProvider.ILoadingContext loadingContext = null)
        {
            return base.Load(tickers, field, DateTime.Today, DateTime.Today, loadingContext);
        }

        public override bool IsUndated()
        {
            return true;
        }
    }
}