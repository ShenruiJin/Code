﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public class DoubleBloombergExecutable : SimpleBloombergExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public DoubleBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Ask,
                DataFieldsEnum.Bid,
                DataFieldsEnum.Close,
                DataFieldsEnum.Last,
                DataFieldsEnum.RealizedVolatility10d,
                DataFieldsEnum.RealizedVolatility30d,
                DataFieldsEnum.RealizedVolatility60d,
                DataFieldsEnum.RealizedVolatility90d,
                DataFieldsEnum.RealizedVolatility180d,
                DataFieldsEnum.MarketCapitalization,
                DataFieldsEnum.MarketCap,
                DataFieldsEnum.EarningYield,
                DataFieldsEnum.BookToMarketRatio,
                DataFieldsEnum.Volume,
                DataFieldsEnum.VolumeAverage6Months,
                DataFieldsEnum.FreeCashFlowYield,
                DataFieldsEnum.SettlementPrice,
                DataFieldsEnum.DirtyMidPrice,
                DataFieldsEnum.Dividend12MYield,
                DataFieldsEnum.ContractValue
            };
        }

        /// <summary>
        /// Converts a double to a MarketDataDouble object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IMarketData ConvertToMarketData(object value)
        {

            //// new implem is a treenode
            var treenode = value as TreeNode;
            if (treenode != null)
            {
                return new MarketDataDouble(treenode);
            }
            else
            {
                return new MarketDataDouble((double)value);
            }
        }

        public override bool IsUndated()
        {
            return false;
        }
    }
}
