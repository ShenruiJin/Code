﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public class DateTimeBloombergExecutable : AsTodayBloombergExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public DateTimeBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Expiry,
                DataFieldsEnum.FirstFutureDeliveryDate,
                DataFieldsEnum.LastTradeableDate,
                DataFieldsEnum.SettlementDate
            };
        }

        /// <summary>
        /// Converts a double to a MarketDataDouble object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IMarketData ConvertToMarketData(object value)
        {
            TreeNode tn = value as TreeNode;
            DateTime? date = value as DateTime?;

            if (null != tn)
            {
                date = tn.Cast<DateTime?>();
            }
            if (date.HasValue)
            {
                return new MarketDataString((string)(date.Value).ToString("O"));
            }
            throw new InvalidOperationException("Cannot cast value to date <{0}>".Formatted(value));
        }

        public override bool IsUndated()
        {
            return true;
        }
    }
}
