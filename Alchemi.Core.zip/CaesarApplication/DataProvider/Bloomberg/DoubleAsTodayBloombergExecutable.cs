using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public class DoubleAsTodayBloombergExecutable : AsTodayBloombergExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public DoubleAsTodayBloombergExecutable()
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.Notional,
                DataFieldsEnum.QuoteFactor,
                DataFieldsEnum.FUT_INIT_SPEC_ML
            };
        }

        /// <summary>
        /// Converts a double to a MarketDataDouble object
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        public override IMarketData ConvertToMarketData(object value)
        {

            //// new implem is a treenode
            var treenode = value as TreeNode;
            if (treenode != null)
            {
                return new MarketDataDouble(treenode.Cast<double>());
            }
            else
            {
                return new MarketDataDouble((double)value);
            }
        }
    }
}