﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using GlobalDerivativesApplications.Controls;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using CorporateAction = MarketData.CorporateAction;

namespace CaesarApplication.DataProvider.Bloomberg
{
    public class BloombergParser
    {
        private const string StartOfDataLine = "START-OF-DATA";
        private const string EndOfDataLine = "END-OF-DATA";
        private const string EndOfFileLine = "END-OF-FILE";
        private const string DelimiterPrefix = "DELIMITER=";
        private const string DateformatPrefix = "DATEFORMAT=";

        private const string DateRangePrefix = "DATERANGE=";

        public static Dictionary<string, CorporateAction[]> ParseCorporateActions(string dataAsString)
        {
            int expectedPartsSize = 8;
            var rawLines = dataAsString.Split(new[] { "\r\n" }, StringSplitOptions.None);

            var delimiter = rawLines.First(l => l.StartsWith(DelimiterPrefix)).Substring(DateformatPrefix.Length - 1);

            var dataLines = rawLines.SkipWhile(l => l.Contains(StartOfDataLine)).Where(l => !l.StartsWith("#")).TakeWhile(l => !l.Contains(EndOfFileLine)).ToArray();

            var result = dataLines.Select(l => l.Split(delimiter.AsArray(), StringSplitOptions.None))
                .Where(lineParts => lineParts.Length == expectedPartsSize)
                .Select(lineParts =>
                {
                    var data = lineParts.Skip(1).Select(InterpretValue).ToArray();

                    return new KeyValuePair<string, CorporateAction>(TrimSpaceAndTab(lineParts.First()),
                        new CorporateAction(new List<Object>
                        {
                            data[0] is DateTime ? data[0] : DateTime.MinValue,
                            data[1] is DateTime ? data[1] : DateTime.MinValue,
                            data[2] is DateTime ? data[2] : DateTime.MinValue,
                            data[3] is DateTime ? data[3] : DateTime.MinValue,
                            data[4] is double ? data[4] : 0.0d,
                            data[5],
                            data[6],
                        }));
                }).GroupBy(g => g.Key).ToDictionary(x => x.Key, x => x.Select(v => v.Value).ToArray());

            return result;
        }


        public static IList<TimeSerieDB> ParsePricesFile(DataFieldsEnum field, string fileContent, bool isUnDated = false)
        {
            if (string.IsNullOrEmpty(fileContent))
                return new List<TimeSerieDB>();

            var fileLines = fileContent.Split("\n".AsArray(), StringSplitOptions.None);

            var dateFormat = fileLines.First(x => x.StartsWith(DateformatPrefix)).Split('=')[1].Replace("mm", "MM");

            var dateRange = fileLines.FirstOrDefault(x => x.StartsWith(DateRangePrefix));

            var dateStrings = dateRange != null ? dateRange.Split('=')[1].Split('|') : null;

            var startDate = dateStrings != null ? DateTime.ParseExact(dateStrings[0], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;
            var endDate = dateStrings != null ? DateTime.ParseExact(dateStrings[1], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;

            var dataLines = fileLines.SkipWhile(l => l != StartOfDataLine).Skip(1).TakeWhile(x => x != EndOfDataLine).ToArray();

            return dataLines.Select(l =>
            {
                var lineParts = l.Split('|');
                if (lineParts[3].IsNullOrEmpty() || lineParts[3].Trim() == string.Empty || lineParts[3].IsNullOrEmpty() ||
                    lineParts[3].Trim() == string.Empty)
                {
                    return null;
                }
                var result = new TimeSpan();
                bool isTime = TimeSpan.TryParse(lineParts[3], out result);
                return
                    new
                    {
                        Ticker = lineParts[0],
                        Date = isTime || isUnDated ? (isUnDated ? DateTime.MinValue : DateTime.Today) : DateTime.ParseExact(lineParts[3], dateFormat, CultureInfo.InvariantCulture),
                        Value = lineParts[4]
                    };
            }).Where(x => x != null).GroupBy(x => x.Ticker)
                .Select(x =>
                    new TimeSerieDB(x.Where(v => v.Value != null && v.Value.Trim() != string.Empty).Select(v =>
                                new KeyValuePair<DateTime, IMarketData>(v.Date, new MarketDataDouble(double.Parse(v.Value, CultureInfo.InvariantCulture)))).ToArray()
                            , x.Key, field)
                    { StartDate = startDate, EndDate = endDate }).ToArray();
        }

        public static IList<TimeSerieDB> ParseDatesFile(DataFieldsEnum field, string fileContent, bool isUnDated = false)
        {
            if (string.IsNullOrEmpty(fileContent))
                return new List<TimeSerieDB>();

            var fileLines = fileContent.Split("\n".AsArray(), StringSplitOptions.None);

            var dateFormat = fileLines.First(x => x.StartsWith(DateformatPrefix)).Split('=')[1].Replace("mm", "MM");

            var dateRange = fileLines.FirstOrDefault(x => x.StartsWith(DateRangePrefix));

            var dateStrings = dateRange != null ? dateRange.Split('=')[1].Split('|') : null;

            var startDate = dateStrings != null ? DateTime.ParseExact(dateStrings[0], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;
            var endDate = dateStrings != null ? DateTime.ParseExact(dateStrings[1], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;

            var dataLines = fileLines.SkipWhile(l => l != StartOfDataLine).Skip(1).TakeWhile(x => x != EndOfDataLine).ToArray();

            return dataLines.Select(l =>
            {
                var lineParts = l.Split('|');
                if (lineParts[3].IsNullOrEmpty() || lineParts[3].Trim() == string.Empty || lineParts[3].IsNullOrEmpty() ||
                    lineParts[3].Trim() == string.Empty)
                {
                    return null;
                }
                var result = new TimeSpan();
                bool isTime = TimeSpan.TryParse(lineParts[3], out result);
                return
                    new
                    {
                        Ticker = lineParts[0],
                        Date = isTime ? (isUnDated ? DateTime.MinValue : DateTime.Today) : DateTime.ParseExact(lineParts[3], dateFormat, CultureInfo.InvariantCulture),
                        Value = lineParts[4]
                    };
            }).Where(x => x != null).GroupBy(x => x.Ticker)
                .Select(x =>
                    new TimeSerieDB(x.Select(v =>
                                new KeyValuePair<DateTime, IMarketData>(v.Date, ConvertToDateMarketData(v.Value))).ToArray()
                            , x.Key, field)
                    { StartDate = startDate, EndDate = endDate }).ToArray();
        }

        public static IList<TimeSerieDB> ParseFile(DataFieldsEnum field, string fileContent, Func<string, IMarketData> getMktDataFunc, bool isUndated = false)
        {
            if (string.IsNullOrEmpty(fileContent))
                return new List<TimeSerieDB>();

            var fileLines = fileContent.Split("\n".AsArray(), StringSplitOptions.None);

            var dateFormat = fileLines.First(x => x.StartsWith(DateformatPrefix)).Split('=')[1].Replace("mm", "MM");

            var dateRange = fileLines.FirstOrDefault(x => x.StartsWith(DateRangePrefix));

            var dateStrings = dateRange != null ? dateRange.Split('=')[1].Split('|') : null;

            var startDate = dateStrings != null ? DateTime.ParseExact(dateStrings[0], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;
            var endDate = dateStrings != null ? DateTime.ParseExact(dateStrings[1], dateFormat, CultureInfo.InvariantCulture) : (DateTime?)null;

            var dataLines = fileLines.SkipWhile(l => l != StartOfDataLine).Skip(1).TakeWhile(x => x != EndOfDataLine).ToArray();

            return dataLines.Select(l =>
            {
                var lineParts = l.Split('|');
                if (lineParts[3].IsNullOrEmpty() || lineParts[3].Trim() == string.Empty || lineParts[3].IsNullOrEmpty() ||
                    lineParts[3].Trim() == string.Empty)
                {
                    return null;
                }
                var result = new TimeSpan();
                bool isTime = TimeSpan.TryParse(lineParts[3], out result);
                return
                    new
                    {
                        Ticker = lineParts[0],
                        Date = isTime ? DateTime.Today : DateTime.ParseExact(lineParts[3], dateFormat, CultureInfo.InvariantCulture),
                        Value = lineParts[4]
                    };
            }).Where(x => x != null).GroupBy(x => x.Ticker)
                .Select(x =>
                    new TimeSerieDB(x.Select(v =>
                                new KeyValuePair<DateTime, IMarketData>(isUndated ? DateTime.MinValue : v.Date, getMktDataFunc(v.Value))).Where((it, i) => !isUndated || i == 0).ToArray()
                            , x.Key, field)
                    { StartDate = startDate, EndDate = endDate }).ToArray();
        }

        private static MarketDataString ConvertToDateMarketData(string value)
        {
            int timevalue;
            if (int.TryParse(value, out timevalue))
            {
                if (timevalue > 10000)
                {
                    int year = timevalue / 10000;
                    int month = (timevalue % 10000) / 100;
                    int day = timevalue % 100;
                    return new MarketDataString(new DateTime(year, month, day).ToString("O"));
                }
                else
                {
                    return new MarketDataString(timevalue.ToString());
                }
            }

            return new MarketDataString(value);
        }
        public static Dictionary<string, AdjustmentFactor[]> ParseAdjustmentFactors(string dataAsString)
        {
            int expectedPartsSize = 5;
            var rawLines = dataAsString.Split(new[] { "\r\n" }, StringSplitOptions.None);

            var delimiter = rawLines.First(l => l.StartsWith(DelimiterPrefix)).Substring(DateformatPrefix.Length - 1);

            var dataLines = rawLines.SkipWhile(l => l.Contains(StartOfDataLine)).Where(l => !l.StartsWith("#")).TakeWhile(l => !l.Contains(EndOfFileLine)).ToArray();

            return dataLines.Select(l => l.Split(delimiter.AsArray(), StringSplitOptions.None))
                .Where(lineParts => lineParts.Length == expectedPartsSize && lineParts.All(x => !string.IsNullOrEmpty(TrimSpaceAndTab(x))))
                .Select(lineParts =>
                {
                    return new KeyValuePair<string, AdjustmentFactor>(TrimSpaceAndTab(lineParts.First()),
                        new AdjustmentFactor(lineParts.Skip(1).Select(InterpretValue).ToList()));
                }).GroupBy(g => g.Key).ToDictionary(x => x.Key, x => x.Select(v => v.Value).ToArray());
        }

        private static string TrimSpaceAndTab(string str)
        {
            return str.Trim().Trim('\t');
        }

        private static Object InterpretValue(string x)
        {
            var trimmedStr = TrimSpaceAndTab(x);

            {
                double val;

                if (double.TryParse(trimmedStr, NumberStyles.Any, CultureInfo.InvariantCulture, out val))
                {
                    return val;
                }
            }

            {
                int val;

                if (int.TryParse(trimmedStr, NumberStyles.Any, CultureInfo.InvariantCulture, out val))
                {
                    return val;
                }
            }

            {
                DateTime val;

                if (DateTime.TryParseExact(trimmedStr, "MM/dd/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out val))
                {
                    return val;
                }
            }

            return trimmedStr;
        }
    }
}
