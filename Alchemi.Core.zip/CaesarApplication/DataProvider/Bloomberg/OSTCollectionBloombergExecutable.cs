﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.DataProvider.Database;
using CaesarApplication.DataProvider.Helpers;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloombergServices;
using GlobalDerivativesApplications.DynamicDataExchange.Provider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Resultat;
using MarketData;
using PricingBase.DataProvider;
using PricingBase.OST;
using CorporateAction = MarketData.CorporateAction;

namespace CaesarApplication.DataProvider.Bloomberg
{
    [Serializable]
    public class OSTCollectionBloombergExecutable : ProviderExecutable
    {
        /// <summary>
        /// Bloomberg provider
        /// </summary>
        private IDataProvider _provider;

        /// <summary>
        /// Dependency to main DataHandler to fetch LAST curves used to compute cash dividend factors
        /// </summary>
        private IDataHandler _dataHandler;

        private IProviderExecutable tsProvider;
        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="timeSeriesProvider"></param>
        public OSTCollectionBloombergExecutable(IDataHandler dataHandler)
        {
            _dataHandler = dataHandler;
            tsProvider = new DatabaseTimeSerieProviderExecutable();
        }

        public IDataProvider Provider
        {
            get { return _provider = _provider ?? new BloombergDataProvider(); }
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var output = new List<TimeSerieDB>();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            var corporateActionsByTicker = GetCorporateActionsByTicker(tickersAsArray);

            var factorsByTicker = GetFactorsByTicker(tickersAsArray);


            var lastLoadingContext = loadingContext != null ? (ILoadingContext)loadingContext.Clone() : null;

            if (lastLoadingContext != null)
            {
                lastLoadingContext.DisabledSources = new[] { "PRISM_POLLING", "PRISM" };
            }

            var cActions =
                corporateActionsByTicker.Values.SelectMany(i => i)
                    .Where(i => { return endDate != null && (startDate != null && (i.ExDate >= startDate.Value && i.ExDate <= endDate.Value)); });
            var enumerable = cActions as CorporateAction[] ?? cActions.ToArray();

            if (enumerable.Length == 0)
                return output;

            var maxExdate = enumerable.Max(i=>i.ExDate);
            var minExdate = enumerable.Min(i => i.ExDate);
            var start = (DateTime?) minExdate.AddDays(-7);
            var end = (DateTime?) maxExdate.AddDays(-1);

            var tickersWithoutSuffix = tickersAsArray.Select(BloombergHelper.GetTickerWithoutSuffix).ToArray();
            var tSeries = new TimeSeries(_dataHandler.Load(tickersWithoutSuffix, DataFieldsEnum.Last.AsArray(), start, end, lastLoadingContext));

            var allLast = new TimeSeries(tSeries);

            foreach (string ticker in tickersAsArray)
            {
                var tickerWithoutSuffix = BloombergHelper.GetTickerWithoutSuffix(ticker);

                var corporateActions = corporateActionsByTicker.ContainsKey(ticker)
                    ?
                    corporateActionsByTicker[ticker]
                    .Where(o => o.ExDate >= startDate.GetValueOrDefault()
                    && o.ExDate <= endDate.GetValueOrDefault(DateTime.MaxValue))
                    .ToArray()
                    :
                    new CorporateAction[0];

                var factors = factorsByTicker.ContainsKey(ticker) ? factorsByTicker[ticker] : new AdjustmentFactor[0];

                var corporateActionsToConvert = corporateActions.Where(o => (OSTCollection.IsCashDividend(o.DividendType) || o.DividendType == "Return of Capital") 
                && (o.ExDate >= startDate.GetValueOrDefault() && o.ExDate <= endDate.GetValueOrDefault(DateTime.MaxValue))).ToArray();

                foreach (var corporateAction in corporateActionsToConvert)
                {
                    var ts = allLast[tickerWithoutSuffix, DataFieldsEnum.Last];

                    var previousDate = ts.GetPreviousDate(corporateAction.ExDate); 

                    
                    if (OSTCollection.IsCashDividend(corporateAction.DividendType))
                    {
                        if (ts.Count != 0
                            && previousDate != DateTime.MinValue)
                        {
                            corporateAction.Factor = 1 - corporateAction.Amount / ts.Evaluate(previousDate);
                        }
                        else
                        {
                            log4net.LogManager.GetLogger(GetType()).Error("Quotation missing to compute factor for the Cash Dividend " + ticker + " ExDate " + corporateAction.ExDate + " value " + corporateAction.Amount);
                        }
                    }
                    else if (corporateAction.DividendType == "Return of Capital" && ts.Count != 0
                            && previousDate != DateTime.MinValue)
                    {
                        double previousValue = ts.Evaluate(previousDate);
                        corporateAction.Factor = (previousValue - corporateAction.Amount) / previousValue;
                    }
                }

                var corporateActionsList = corporateActions.ToList();

                corporateActionsList.Remove(o => o.DividendType == "Return of Capital" && o.ExDate == o.PaymentDate);

                AddOSTCollection(corporateActionsByTicker.ContainsKey(ticker), output, corporateActionsList, factors, ticker);
            }
            output.ForEach(ts => ts.StartDate = startDate);
            output.ForEach(ts => ts.EndDate = endDate);

            CorporateActionHelper.AddCancellingCoporateActions(_dataHandler, output.Select(x => x.Instrument).ToArray(), startDate, endDate, output, lastLoadingContext, DataFieldsEnum.OSTCollection, date => new OSTCollection());

            return output;
        }

        protected virtual void AddOSTCollection(bool hasData, List<TimeSerieDB> output, List<CorporateAction> corporateActionsList,
            AdjustmentFactor[] factors, string ticker)
        {
            output.Add(
                new TimeSerieDB(
                    corporateActionsList.GroupBy(x => x.ExDate)
                        .Select(a => new KeyValuePair<DateTime, IMarketData>(a.Key, new OSTCollection(a.ToArray(), factors)))
                        .ToArray(), ticker, DataFieldsEnum.OSTCollection));
        }

        protected virtual Dictionary<string, CorporateAction[]> GetCorporateActionsByTicker(string[] tickersAsArray)
        {
            DDEResult corporatesActionsResult = Provider.Get(tickersAsArray.ToList(),
                new List<DataFieldsEnum> { DataFieldsEnum.DividendHistoryGross });

            var corporateActionsByTicker = tickersAsArray.ToDictionary(t => t,
                t => GetCorporateActions((IList<object>)corporatesActionsResult.First(x => x.Reference == t).Value).ToArray());
            return corporateActionsByTicker;
        }

        protected virtual Dictionary<string, AdjustmentFactor[]> GetFactorsByTicker(string[] tickersAsArray)
        {
            DDEResult factorsResult = Provider.Get(tickersAsArray.ToList(),
                new List<DataFieldsEnum> { DataFieldsEnum.DividendAdjustementFactor });
            var factorsByTicker = tickersAsArray.ToDictionary(t => t,
                t => GetFactors((IList<object>)factorsResult.First(x => x.Reference == t).Value).ToArray());
            return factorsByTicker;
        }

        private IEnumerable<AdjustmentFactor> GetFactors(IList<object> values)
        {
            var res = new List<AdjustmentFactor>();

            foreach (var value in values)
            {
                res.Add(new AdjustmentFactor((List<object>)value));
            }

            return res;
        }

        private IEnumerable<CorporateAction> GetCorporateActions(IList<object> values)
        {
            var res = new List<CorporateAction>();

            foreach (List<object> value in values)
            {
                res.Add(new CorporateAction(value));
            }

            return res;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new[] { DataFieldsEnum.OSTCollection }; }
        }
    }
}