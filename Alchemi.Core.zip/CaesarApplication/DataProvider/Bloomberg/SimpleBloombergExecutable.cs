﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange;
using GlobalDerivativesApplications.DynamicDataExchange.BloombergServices;
using GlobalDerivativesApplications.DynamicDataExchange.Provider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Resultat;
using MarketData;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.BloombergWrapper.Internal;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.BloombergWrapper;
using GlobalDerivativesApplications.DynamicDataExchange.BloomV2.Bloomberg.TreeNode;

namespace CaesarApplication.DataProvider.Bloomberg
{
    /// <summary>
    /// Bloomberg provider for double fields
    /// </summary>
    [Serializable]
    public abstract class SimpleBloombergExecutable : ProviderExecutable
    {
        /// <summary>
        /// Bloomberg provider
        /// </summary>
        private IBBGWrapper _provider;

        public IBBGWrapper Provider
        {
            get
            {
                return _provider = _provider ?? CreateBloombergProvider();
            }
        }

        public static IBBGWrapper ConfigurationCreateBloombergProvider()
        {
            return ((BPipeApp == null || BPipeServer == null) ?
                                  new BBGWrapper()
                                : new BBGWrapper(host: BPipeServer, applicationName: BPipeApp));
        }


        public IBBGWrapper CreateBloombergProvider()
        {
            return (DisableBPipe || (CurrentBPipeApp == null && BPipeApp == null || CurrentBPipeServer == null && BPipeServer == null) ?
                                  new BBGWrapper()
                                : new BBGWrapper(host: CurrentBPipeServer ?? BPipeServer, applicationName: CurrentBPipeApp ?? BPipeApp));
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();

            InitializeDates(ref startDate, ref endDate);

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            if (endDate == DateTime.Today &&
                startDate == DateTime.Today)
            {
                var results = GetLiveData(tickersAsArray, field, null);
                var missingTickers = tickersAsArray.Where(t => !results.Any(x => x.Instrument == t)).ToArray();
                results = results.Union(GetLiveData(missingTickers, field)).ToList();

                output.AddRange(results);
            }
            else
            {
                var results = GetHistoricalData(tickersAsArray, field, startDate, endDate).Where(x => x != null).ToList();

                var missingTickers = tickersAsArray.Where(t => !results.Any(x => x.Reference == t)).ToArray();
                results = results.Union(GetHistoricalData(GetNewTickers(missingTickers), field, startDate, endDate)).ToList();

                foreach (var resultElement in results)
                {
                    if (resultElement != null)
                    {
                        var result = resultElement.Value as DDETimeSerie<object>;
                        var treenode = resultElement.Value as TreeNode;
                        string instrument = string.Empty;

                        List<DateTime> keys = null;
                        IList<IMarketData> data = null;
                        if (treenode != null && treenode.Length > 0)
                        {
                            instrument = treenode.Ticker;
                            try
                            {
                                keys = treenode.Childs.Select(c => c["date"].Cast<DateTime>()).ToList();
                                var treenodeData = treenode[field];
                                data = treenodeData.Select(ConvertToMarketData).ToList();
                            }
                            catch(Exception e)
                            {
                                log4net.LogManager.GetLogger("SimpleBloombergExecutable").Error("error parsing {0}".Formatted(treenode.Ticker), e);  
                            }
                        }
                        //// legacy DDETimeSerie
                        else if (result != null && result.Y != null)
                        {
                            keys = result.X.ToList();
                            data = result.Y.Select(ConvertToMarketData).ToList();
                            instrument = result.Instrument;
                        }
                        TimeSerieDB res;

                        if (data != null)
                        {
                            res = new TimeSerieDB(keys, data, instrument, field);
                            SetCompleteDates(startDate, endDate, loadingContext, res);
                        }
                        else //// size 0
                        {
                            res = CreateEmptyAndCompleteTimeSerie(instrument, field, startDate, endDate);
                        }
                        
                        output.Add(res);
                    }
                }
            }

            var missing = tickers.Except(output.Select(o => o.Instrument)).ToArray();
            foreach (var miss in missing)
            {
                var res = CreateEmptyAndCompleteTimeSerie(miss, field, startDate, endDate);
                output.Add(res);
            }

            return output;
        }

        private static TimeSerieDB CreateEmptyAndCompleteTimeSerie(string ticker, DataFieldsEnum field, DateTime? startDate, DateTime? endDate)
        {
            return new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0] ,ticker, field) { StartDate = startDate, EndDate = endDate, IsConsideredAsComplete = true };
        }

        private static void SetCompleteDates(DateTime? startDate, DateTime? endDate, ILoadingContext loadingContext, TimeSerieDB res)
        {
            DateTime t2 = endDate.GetValueOrDefault(DateTime.Today);
            DateTime t1 = (startDate == null) ? t2 : startDate.GetValueOrDefault(DateTime.Today);
            res.SetToCompleteSerie(t1, t2, loadingContext, DateTime.Today);
        }

        private IList<TimeSerieDB> GetLiveData(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? versionDate = null)
        {
            return GetLiveData(tickers.ToDictionary(x => x), field, versionDate);
        }

        private IList<TimeSerieDB> GetLiveData(Dictionary<string, string> tickers, DataFieldsEnum field, DateTime? versionDate = null)
        {
            IList<TimeSerieDB> output = new List<TimeSerieDB>();
            if (tickers.Any())
            {
                DateTime currentDate = DateTime.Today;
                if (versionDate != null)
                {
                    currentDate = versionDate.Value;
                }

                var tickersToRequest = tickers.Select(x => x.Key).ToArray();
                DDEResult values = Provider.Get(tickersToRequest.ToList(), new List<DataFieldsEnum> { field });

                foreach (string ticker in tickersToRequest)
                {
                    IMarketData data = ConvertToMarketData(values[ticker, field].Value);
                    output.Add(new TimeSerieDB(new List<DateTime> { IsUndated() ? DateTime.MinValue : currentDate },
                                                                        new List<IMarketData> { data },
                                                                        tickers[ticker], field));
                }
            }

            return output;
        }

        /// <summary>
        /// bpipe server address
        /// </summary>
        public static string BPipeServer { get; set; }

        /// <summary>
        /// bpipe application name
        /// </summary>
        public static string BPipeApp { get; set; }
        /// <summary>
        /// bpipe server address
        /// </summary>
        public string CurrentBPipeServer { get; set; }

        /// <summary>
        /// bpipe application name
        /// </summary>
        public string CurrentBPipeApp { get; set; }


        /// <summary>
        /// 
        /// </summary>
        public bool DisableBPipe { get; set; }


        /// <summary>
        /// configure bpipe settings
        /// </summary>
        /// <param name="commandline"></param>
        public static void ParseOptions(string[] commandline)
        {
            commandline.Consume("bpipe-server", (optname, value) => BPipeServer = value)
             .Consume("bpipe-app", (optname, value) => BPipeApp = value);
        }

        private DDEResult GetHistoricalData(IEnumerable<string> tickers, DataFieldsEnum field,
            DateTime? startDate = null, DateTime? endDate = null)
        {
            return GetHistoricalData(tickers.ToDictionary(x => x), field, startDate, endDate);
        }

        /// <summary>
        /// Get historical data
        /// Be careful by default data is unadjusted
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        private DDEResult GetHistoricalData(Dictionary<string, string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
        {
            DDEResult results = new DDEResult();

            if (tickers.Any())
            {
                try
                {
                    results = Provider.GetHistoricalData(tickers.Select(x => x.Key).ToList(), field.AsArray(),
                       startDate.Value, endDate.Value, null, false, false, false);

                    results.Where(r => r != null).ForEach(r => r.Reference = tickers[r.Reference]);
                }
                catch (Exception ex)
                {
                    LoggingService.Error(GetType(), "Error loading historical values", ex);
                }
            }

            return results;
        }

        private Dictionary<string, string> GetNewTickers(string[] oldTickers)
        {
            var result = new Dictionary<string, string>();

            foreach (var oldTicker in oldTickers)
            {
                try
                {
                    DDEResult values = Provider.Get(oldTicker.AsArray(), new List<DataFieldsEnum> { DataFieldsEnum.EquityFundTicker });

                    if (values != null)
                    {
                        var value = values[oldTicker, DataFieldsEnum.EquityFundTicker];

                        if (value != null)
                        {
                            var valueAsString = value.Value as string;

                            if (valueAsString != null)
                            {
                                var newTicker = valueAsString + " Equity";

                                if (oldTicker != newTicker)
                                {
                                    result.Add(newTicker, oldTicker);
                                }
                            }
                        }
                    }
                }
                catch (Exception e)
                {
                   LoggingService.Error(this.GetType(),"Error while retrieving tickers from bloomberg: "+e.Message);
                }
                
            }

            return result;
        }

        public abstract IMarketData ConvertToMarketData(object value);

        public abstract bool IsUndated();
    }
}