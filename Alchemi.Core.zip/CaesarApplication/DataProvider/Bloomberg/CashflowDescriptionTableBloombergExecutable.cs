using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    [Serializable]
    public class CashflowDescriptionTableBloombergExecutable : TableBloombergExecutable
    {
        private StringAsTodayBloombergExecutable stringAsTodayBloombergExecutable = new StringAsTodayBloombergExecutable();

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var firstSettlementDates = stringAsTodayBloombergExecutable.Load(tickersAsArray, DataFieldsEnum.FirstSettlementDate);

            var timeSeries = new List<TimeSerieDB>();

            foreach (var ticker in tickersAsArray)
            {
                var firstSettlementDate = firstSettlementDates.First(x => x.Instrument == ticker).EvaluateAsDateTime();

                var ddeResult = RequestDdeResult(ticker.AsArray(), field, new Dictionary<string, string> { { "SETTLE_DT", firstSettlementDate.ToString("yyyyMMdd") } });

                if (ddeResult.ContainsReference(ticker))
                {
                    var dataForTicker = ddeResult[ticker].First();

                    timeSeries.Add(new TimeSerieDB(endDate.GetValueOrDefault(), new TableData(((IEnumerable<object>)dataForTicker.Value).Select(x => (List<object>)x).ToList()), ticker, field));
                }
            }

            return timeSeries;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[] { DataFieldsEnum.CashflowDescription };
            }
        }
    }
}