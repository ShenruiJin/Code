﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaesarApplication.DataProvider.Prism;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Bloomberg
{
    public static class BloombergHelper
    {
        public static string GetBBGSuffixUpperCase(string ticker)
        {
            return ticker.Split(new string[] { " " }, StringSplitOptions.None).Last().ToUpper();
        }

        public static string GetTickerWithoutSuffix(string originalTicker)
        {
            var suffix = GetBBGSuffixUpperCase(originalTicker);

            if (new[] { PrismConstants.ProductEquity, PrismConstants.ProductIndex, SophisHelper.BbgCurrencySuffix.ToUpper() }.Contains(suffix) && originalTicker.Length > suffix.Length)
            {
                return originalTicker.Substring(0, originalTicker.Length - suffix.Length - 1);
            }

            return originalTicker;
        }
    }
}
