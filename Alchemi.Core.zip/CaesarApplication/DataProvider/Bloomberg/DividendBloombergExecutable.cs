using System;
using System.Collections.Generic;
using System.Linq;
using Caesar.Pricing.MarketData;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.BloombergServices;
using GlobalDerivativesApplications.DynamicDataExchange.Provider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Resultat;
using PricingBase.DataProvider;
using PricingBase.MarketData;
using CorporateAction = MarketData.CorporateAction;
using PricingBase.OST;
using MarketData;

namespace CaesarApplication.DataProvider.Bloomberg
{
    [Serializable]
    public class DividendBloombergExecutable : ProviderExecutable
    {
        /// <summary>
        /// Bloomberg provider
        /// </summary>
        private IDataProvider _provider;


        /// <summary>
        /// Dependency to main DataHandler to fetch LAST curves used to compute cash dividend factors
        /// </summary>
        private IDataHandler _dataHandler;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="timeSeriesProvider"></param>
        public DividendBloombergExecutable(IDataHandler dataHandler)
        {
            _dataHandler = dataHandler;
        }

        public IDataProvider Provider
        {
            get { return _provider = _provider ?? new BloombergDataProvider(); }
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var output = new List<TimeSerieDB>();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            DDEResult corporatesActionsResult = Provider.Get(tickersAsArray.ToList(), new List<DataFieldsEnum> { DataFieldsEnum.DividendHistoryGross });
            var dividendCurrenciesByTicker = _dataHandler.Load(tickersAsArray, DataFieldsEnum.DividendCurrency.AsArray(), startDate, endDate, loadingContext).ToDictionary(x => x.Instrument, x => x.EvaluateString());


            var dividendsByTickerList = tickersAsArray.ToDictionary(t => t, t => GetDividends((IList<object>)corporatesActionsResult.First(x => x.Reference == t).Value, t, dividendCurrenciesByTicker[t]).ToArray());

            foreach (var dividendsByTicker in dividendsByTickerList)
            {
                output.Add(new TimeSerieDB(dividendsByTicker.Value
                    .Where(x => x.Date >= startDate.GetValueOrDefault() && x.Date <= endDate.GetValueOrDefault(DateTime.MaxValue))
                    .ToDictionary(k => k.Date, v => (IMarketData)v)
                    .ToArray(),
                    dividendsByTicker.Key,
                    DataFieldsEnum.Dividend));
            }

            return output;
        }

        private IEnumerable<DividendList> GetDividends(IList<object> values, string ticker, string currency)
        {
            var res = new List<Dividend>();
            var corporateActions = values.Select(x => new KeyValuePair<CorporateAction, List<object>>(new CorporateAction((List<object>)x), (List<object>)x)).OrderBy(x => x.Key.ExDate).ToArray();

            var ostCollection = (OSTCollection)_dataHandler.Load(ticker.AsArray(), DataFieldsEnum.OSTCollection.AsArray(), null, null)[0].Y.Last();

            foreach (var corporateActionKv in corporateActions)
            {
                var corporateAction = corporateActionKv.Key;
                var rawData = corporateActionKv.Value;

                if ((string)rawData[5] != "Suspend" && !new string[] { "poison pill rights", "spinoff", "split" }.Any(x => corporateAction.DividendType.ToLower().Contains(x)))
                {
                    var monetaryUnit = GetMonetaryUnit(corporateAction.DividendType);

                    var dividendStatus = corporateAction.DeclaredDate > DateTime.Today
                        ? DividendStatus.Estimated
                        : DividendStatus.Announced;

                    double factor = corporateAction.Factor;

                    if (monetaryUnit == DividendUnit.Percent && corporateAction.ExDate < DateTime.Today)
                    {
                        var lastSerie = _dataHandler.Load(ticker.AsArray(), DataFieldsEnum.Last.AsArray(), corporateAction.ExDate.AddDays(-10), corporateAction.ExDate.AddDays(-1)).FirstOrDefault();

                        if (lastSerie != null)
                        {
                            var last = lastSerie.EvaluateLast();

                            if (!double.IsNaN(last))
                            {
                                if (corporateAction.DividendType == "Return of Capital")
                                {
                                    factor = (last - factor) / last;
                                }
                                else if(corporateAction.DividendType == "Stock Dividend")
                                {
                                    factor = (factor - 1.0d) * last;
                                }
                                else
                                {
                                    factor *= last;
                                }

                                monetaryUnit = DividendUnit.MonetaryUnit;
                            }
                        }
                    }

                    var ajustByOSTFactor = (1.0d / ostCollection.Normalize(new TimeSerieDB(corporateAction.ExDate, new MarketDataDouble(1), ticker, DataFieldsEnum.Other)
                        {
                            EndDate = DateTime.Today
                        }, true, true, ostTypedToApply: new []{ "Stock Split", "Stock Dividend" }).EvaluateLast());

                    var adjustedValue = factor * ajustByOSTFactor;


                    res.Add(new Dividend(corporateAction.PaymentDate.Year, corporateAction.DividendType, currency,
                        corporateAction.RecordDate, corporateAction.ExDate, corporateAction.PaymentDate,
                        dividendStatus, DividendType.Dividend,
                        monetaryUnit, adjustedValue, 1));
                }
            }

            return res.GroupBy(x => x.ExDividendDate).Select(g => new DividendList(g)).ToArray();
        }

        private static DividendUnit GetMonetaryUnit(string dividendType)
        {
            if (dividendType == "Stock Dividend")
            {
                return DividendUnit.Percent;
            }

            return DividendUnit.MonetaryUnit;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new[] { DataFieldsEnum.Dividend }; }
        }
    }
}