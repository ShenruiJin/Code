using System;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class LocalDatabaseInstrumentCodeTranscoder : DatabaseInstrumentCodeTranscoder
    {
        public override bool IsLocalData
        {
            get { return true; }
        }
    }
}