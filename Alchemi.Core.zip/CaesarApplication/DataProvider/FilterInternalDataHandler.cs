﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// filter any ticker that contains an internal path delimiter.
    /// Those tickers should be only Marketdatatree/ caesardatabase
    /// </summary>
    [Serializable]
    public class FilterInternalDataHandler : DataHandler
    {
        public FilterInternalDataHandler()
        {
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate,
            ILoadingContext loadingContext, bool removeEmptySeries = false)
        {
            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();
            var originalTickers = tickers.ToArray();

            var tickersToTreat = originalTickers.Where(t => !t.Contains(GlobalDerivativesApplications.Data.DataTree<object>.PathDelimiter))
                                                .ToArray();

            var result = GetResultFromSuccessor(startDate, endDate, tickersToTreat, dataFieldsAsArray, loadingContext, false);
            return result;
        }

        protected override void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
        }
    }
}
