﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.DynamicDataExchange.MDM;
using GlobalDerivativesApplications.Data.MarketData;
using System.Linq;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.MDM
{
    public class MDMLastProviderExecutable : ProviderExecutable
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = default(DateTime?), DateTime? endDate = default(DateTime?), ILoadingContext loadingContext = null)
        {
            var dataManager = new MDMDataProvider();
            var res = new List<TimeSerieDB>();

            foreach (var ticker in tickers)
            {
                int sicovam;
                List<KeyValuePair<DateTime, IMarketData>> values = new List<KeyValuePair<DateTime, IMarketData>>();

                if (int.TryParse(ticker, out sicovam))
                {
                    var instrument = SophisHelper.GetInstrumentInfo(SophisHelper.GetReference(sicovam));

                    var mdmValues = dataManager.GetSpot(sicovam, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), mdmClosing: new[] { "CAD", "USD" }.Contains(instrument.MarketGoverningCurrency) ? "NY" : "PARIS");

                    if (mdmValues.ContainsKey(sicovam))
                    {
                        values.AddRange(mdmValues[sicovam].Select(mValue => new KeyValuePair<DateTime, IMarketData>(mValue.Key, mValue.Value.OrderBy(x => x.Key).Last().Value)));
                    }
                }

                res.Add(new TimeSerieDB(values, ticker, field));
            }

            return res;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[] { DataFieldsEnum.Last };
            }
        }
    }
}
