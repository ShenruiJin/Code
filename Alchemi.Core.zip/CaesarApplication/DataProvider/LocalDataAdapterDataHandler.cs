﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

//Obsolete
namespace CaesarApplication.DataProvider
{
//    /// <summary>
//    /// Executable used to override Market data by localized data
//    /// </summary>
//    public class LocalDataAdapterDataHandler : DataHandler
//    {
//        private readonly IProviderRouter providerRouter;
//
//        public LocalDataAdapterDataHandler(IProviderRouter providerRouter,
//            InstrumentCodeTranscoder instrumentCodeTranscoder)
//        {
//            this.providerRouter = providerRouter;
//            this.instrumentCodeTranscoder = instrumentCodeTranscoder;
//        }
//
//        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields,
//            DateTime? startDate, DateTime? endDate,
//            ILoadingContext loadingContext, bool removeEmptySeries = false)
//        {
//            var tickersAsArray = tickers.ToArray();
//            var dataFieldsAsArray = fields.ToArray();
//
//            var result = GetResultFromSuccessor(startDate, endDate, tickersAsArray, dataFieldsAsArray, loadingContext,
//                false);
//
//            var internalResults =
//                loadingContext != null
//                    ? loadingContext.IndexPaths.Except(loadingContext.CurrentIndexPath.AsArray())
//                        .Union(loadingContext.CurrentIndexPath.AsArray())
//                        .SelectMany(
//                            prefix =>
//                                InternalLoad(providerRouter, startDate, endDate, tickersAsArray, dataFieldsAsArray,
//                                    removeEmptySeries, null, prefix + MarketDataMgr.Trees.MarketDataTree.PathDelimiter))
//                        .ToArray()
//                    : new TimeSerieDB[0];
//
//            return MergeResults(new IList<TimeSerieDB>[] {result.ToArray(), internalResults});
//        }
//
//        private IList<TimeSerieDB> MergeResults(IList<TimeSerieDB>[] resultsToMerge)
//        {
//            var result = new List<TimeSerieDB>(resultsToMerge[0]);
//
//            foreach (var resultToMerge in resultsToMerge)
//            {
//                foreach (var ts in resultToMerge)
//                {
//                    TimeSerieDB timeSerieForMerge;
//
//                    if ((timeSerieForMerge =
//                        result.FirstOrDefault(t => ts.Instrument == t.Instrument && ts.Field == t.Field)) != null)
//                    {
//                        timeSerieForMerge.Merge(ts);
//                    }
//                    else
//                    {
//                        result.Add(ts);
//                    }
//                }
//            }
//
//            return result;
//        }
//
//        protected override void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
//        {
//        }
//    }
}