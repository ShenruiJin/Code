using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.DataProvider.CalculationEngine;
using GlobalDerivativesApplications.Data.MarketData;
using MarketData;
using PricingBase.DataProvider;
using PricingBase.Index;

namespace CaesarApplication.DataProvider
{
    public abstract class HorizonCalcul : Calcul
    {
        private const string PeriodSuffix = "([0-9]{0,3})D{1}";

        protected abstract string IndicatorPrefix { get; }

        public override string IndicatorRegex
        {
            get
            {
                return "^" + IndicatorPrefix + PeriodSuffix + "$";
            }
        }

        protected override List<KeyValuePair<DateTime, IMarketData>> Calculate(IBasketIndex basket, string indicatorName, string ticker, DateTime? startDate, DateTime? endDate)
        {
            var res = new List<KeyValuePair<DateTime, IMarketData>>();

            var timeSeries = new List<TimeSerieDB>();
            int horizon = GetHorizon(indicatorName);
            var dataSerieHorizon = GetDataSerieHorizon(indicatorName);

            foreach (var field in DataComponentsAsString)
            {
                var dataSerie = basket[field, ticker];

                if (dataSerie.Y.FirstOrDefault() is MarketDataDouble)
                {
                    timeSeries.Add(GetSubTimeSerie(startDate, endDate, dataSerie, dataSerieHorizon));
                }
                else
                {
                    timeSeries.Add(dataSerie);
                }
            }

            for (int i = dataSerieHorizon; i < timeSeries[0].Count; i++)
            {
                res.Add(CalculateForPeriod(timeSeries.ToDictionary(x => x.FieldName), i, horizon));
            }

            return res;
        }

        private TimeSerieDB GetSubTimeSerie(DateTime? startDate, DateTime? endDate, TimeSerieDB dataSerie, int dataSerieHorizon)
        {
            var firstSerieDate = dataSerie.First(x => x.Key >= startDate);
            var lastSerieDate = dataSerie.Last(x => x.Key <= endDate);

            var firstIndex = dataSerie.X.IndexOf(x => x == firstSerieDate.Key);
            var lastIndex = dataSerie.X.IndexOf(x => x == lastSerieDate.Key);

            if (IsInvalidSerie(dataSerieHorizon, firstIndex))
            {
                throw new CalculationException(String.Format("Missing data for horizon [{0}] only [{1}] found", dataSerieHorizon,
                    firstIndex + 1));
            }

            var values = new List<KeyValuePair<DateTime, IMarketData>>();

            for (int i = firstIndex - dataSerieHorizon; i <= lastIndex; i++)
            {
                values.Add(dataSerie[i]);
            }

            return new TimeSerieDB(values, dataSerie.Instrument, dataSerie.Field);
        }

        protected virtual bool IsInvalidSerie(int horizon, int firstIndex)
        {
            return firstIndex < horizon;
        }

        protected abstract KeyValuePair<DateTime, IMarketData> CalculateForPeriod(Dictionary<string, TimeSerieDB> dataSerie, int i, int horizon);

        protected int GetHorizon(string indicatorName)
        {
            var periodSuffix = indicatorName.Substring(IndicatorPrefix.Length);

            periodSuffix = periodSuffix.Substring(0, periodSuffix.Length - 1);

            return int.Parse(periodSuffix);
        }

        protected virtual int GetDataSerieHorizon(string indicatorName)
        {
            return GetHorizon(indicatorName);
        }

        protected override int GetDayLag(string indicatorName)
        {
            var horizon = GetHorizon(indicatorName);

            return horizon + 10;
        }
    }
}