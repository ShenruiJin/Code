using System;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class EmptyTranscoder : InstrumentCodeTranscoder
    {

        public override string TranscodeInternalToExternal(string internalCode, ILoadingContext context)
        {
            return internalCode;
        }

        public override string TranscodeExternalToInternal(string externalCode, ILoadingContext context)
        {
            return externalCode;
        }
    }
}