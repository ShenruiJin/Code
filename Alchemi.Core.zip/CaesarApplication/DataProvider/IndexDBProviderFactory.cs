﻿using System;
using CaesarApplication.Service.Persistance;
using DealServerInterface.Service;
using DealServerLocalIndex.Provider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class IndexDBProviderFactory : IIndexDBProviderFactory
    {
        private readonly IIndexDBProvider indexDbProvider;

        public IndexDBProviderFactory(IIndexDBProvider indexDbProvider)
        {
            this.indexDbProvider = indexDbProvider;
        }

        public IndexDBProviderFactory()
        {
            
        }


        public IIndexDBProvider Create()
        {
            return indexDbProvider ?? PersistanceService.IndexProvider;
        }
    }

    public class LocalIndexDBProviderFactory : IIndexDBProviderFactory
    {
        public IIndexDBProvider Create()
        {
            return PersistanceService.LocalIndexProvider;
        }
    }
}
