using System;
using System.Collections.Generic;
using System.Linq;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class SophisTranscoder : InstrumentCodeTranscoder
    {
        public const string UnknownPrefix = "Unknown$";

        /// <summary>
        /// Key = Bloomberg reference, Value = Source identifier (Sophis Sicovam, Bloomberg ticker, Reuters RIC...)
        /// </summary>
        protected static IDictionary<string, string> externalMappingTranscode;


        static SophisTranscoder()
        {
            SetExternalMapping();
        }

        public override string[] TranscodeExternalToInternal(string[] externalCodes, ILoadingContext context)
        {
            var externalCodesToSophis = externalCodes.Where(c => !c.Contains(MarketDataMgr.Trees.MarketDataTree.PathDelimiter)).ToArray();

            var references = SophisHelper.GetSicovams(externalCodesToSophis);

            if(externalMappingTranscode != null && externalMappingTranscode.Count > 0)
            {
                int sicovam = 0;
                externalMappingTranscode.ToList().ForEach(o =>
                {
                    int.TryParse(o.Value, out sicovam);
                    if (sicovam > 0)
                    {
                        references.Add(o.Key, sicovam);
                    }
                });
            }

            return externalCodes.Select(c => references.ContainsKey(SophisHelper.AdaptTickerForSophis(c)) ? references[SophisHelper.AdaptTickerForSophis(c)].ToString() : string.Format("{1}{0}", c, UnknownPrefix)).ToArray();
        }

        public override string[] TranscodeInternalToExternal(string[] internalCodes, ILoadingContext context)
        {
            var sophisSicovamsAsInts = new List<int>();
            var stringCodes = new List<string>();

            foreach (var internalCode in internalCodes)
            {
                int code;
                if (int.TryParse(internalCode, out code))
                {
                    sophisSicovamsAsInts.Add(code);
                }
                else
                {
                    stringCodes.Add(internalCode);
                }
            }

            var references = SophisHelper.GetReferences(sophisSicovamsAsInts.ToArray());

            return internalCodes.Select(c => !stringCodes.Contains(c) && references.ContainsKey(int.Parse(c)) ? references[int.Parse(c)] : c.Substring(UnknownPrefix.Length)).ToArray();
        }

        private static void SetExternalMapping()
        {
            externalMappingTranscode = new Dictionary<string, string>();
            externalMappingTranscode["NXSHARPE"] = "84467355";
            externalMappingTranscode["NXSHARPU"] = "84467358";

            SophisHelper.AddInstrumentToCache(SophisHelper.GetInstrumentInfo(externalMappingTranscode["NXSHARPE"], GlobalDerivativesApplications.Data.Booking.EnumSophisRefCodeType.Sicovam), "NXSHARPE", true);

            SophisHelper.AddInstrumentToCache(SophisHelper.GetInstrumentInfo(externalMappingTranscode["NXSHARPU"], GlobalDerivativesApplications.Data.Booking.EnumSophisRefCodeType.Sicovam), "NXSHARPU", true);
        }

        public int TranscodeExternalToInternalIfNotSicovam(string externalCode)
        {
            int sico;

            if(int.TryParse(externalCode, out sico))
            {
                return sico;
            }

            return int.Parse(TranscodeExternalToInternal(externalCode, null));
        }
    }
}