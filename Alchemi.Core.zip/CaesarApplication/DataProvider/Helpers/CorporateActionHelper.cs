﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Helpers
{
    internal class CorporateActionHelper
    {
        internal static void AddCancellingCoporateActions(IDataHandler dataHandler, string[] tickers, DateTime? startDate, DateTime? endDate, List<TimeSerieDB> output, ILoadingContext loadingContext, DataFieldsEnum dataFieldsEnum, Func<DateTime, IMarketData> getCorporateAction)
        {

            var lastLoadingContext = loadingContext != null ? (ILoadingContext)loadingContext.Clone() : new PricingContext();

            lastLoadingContext.LoadingSources = new[] { "DB" };

            var tickersWithoutSuffix = tickers.Select(BloombergHelper.GetTickerWithoutSuffix).ToArray();

            var corporateActionsTimeSeries = dataHandler.Load(tickersWithoutSuffix,
                                                                                    dataFieldsEnum.AsArray(),
                                                                                    startDate,
                                                                                    endDate, lastLoadingContext);

            foreach (var ticker in tickers)
            {
                var corporateActionTs = output.FirstOrDefault(x => x != null && x.Instrument == ticker);

                var corporateActionsTs = corporateActionsTimeSeries != null
                    ? corporateActionsTimeSeries.FirstOrDefault(
                        x => x.Instrument == BloombergHelper.GetTickerWithoutSuffix(ticker))
                    : null;

                var corporateActions = corporateActionsTs != null
                    ? corporateActionsTs.GetElements()
                    : new KeyValuePair<DateTime, IMarketData>[0];

                if (corporateActionsTs != null)
                {
                    foreach (var corporateAction in corporateActions)
                    {
                        if (corporateActionTs == null ||
                            !corporateActionTs.Select(x => x.Key).Contains(corporateAction.Key))
                        {
                            corporateActionTs = corporateActionTs ??
                                                new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(), ticker,
                                                    dataFieldsEnum);

                            var source = corporateActionsTs.GetSource(corporateAction.Key);

                            if (source != "DB")
                            {
                                corporateActionTs.Merge(
                                    new TimeSerieDB(corporateAction.Key, getCorporateAction(corporateAction.Key),
                                        corporateActionTs.Instrument, dataFieldsEnum)
                                    {Source = source});
                            }
                        }
                    }

                    if (!output.Contains(corporateActionTs))
                    {
                        output.Add(corporateActionTs);
                    }
                }
            }

        }

    }
}