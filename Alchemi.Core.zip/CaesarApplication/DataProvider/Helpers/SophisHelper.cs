﻿using System;
using System.Collections;
using System.Linq;
using GlobalDerivativesApplications.Data.Booking;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Sophis;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using CaesarApplication.Service.Logging;
using System.Collections.Generic;
using EDAProto;
using GlobalDerivativesApplications.Data.EdaProto;
using GlobalDerivativesApplications.EdaProto;
using PricingBase.DataProvider;
using MarketDataMgr;
using System.Collections.Concurrent;
using System.Configuration;
using System.IO;
using System.Net;
using System.Threading;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Serialization;
using GDAInstrument = GlobalDerivativesApplications.Data.MarketData.Instrument;

namespace CaesarApplication.DataProvider.Helpers
{
    /// <summary>
    /// Helper for Sophis
    /// </summary>
    public static class SophisHelper
    {
        public static string BbgCurrencySuffix = "Curncy";

        public static readonly string BloombergSuffixCommo = "Comdty";

        public static readonly string BloombergSuffixCorp = "Corp";

        public static readonly string BloombergSuffixEquity = "Equity";

        public static readonly string BloombergSuffixIndex = "Index";

        /// <summary>
        /// Sophis session
        /// </summary>
        private static readonly ISophisManager2 sophisManager;
        public static readonly MarketDataWrapper wrapper;

        /// <summary>
        /// Calendar cache
        /// </summary>
        private static IDictionary<string, ICalendar> calendarCache = new ConcurrentDictionary<string, ICalendar>();

        private static string[] currencies;

        /// <summary>
        /// Storing instruments
        /// </summary>
        private static ConcurrentDictionary<string, IInstrument> instrumentCache = new ConcurrentDictionary<string, IInstrument>();
        private static string[] ValidBbgSuffixes =  { BloombergSuffixEquity,
            BloombergSuffixIndex,
            BloombergSuffixCommo,
            BloombergSuffixCorp,
            BbgCurrencySuffix
        };
        /// <summary>
        /// get calendar by code
        /// </summary>
        /// <param name="code"></param>
        /// <returns></returns>
        public static ICalendar GetCalendarByCode(string code)
        {
            return code.Contains("|") ? GetCalendarByMarketMnemo(code) : GetCalendarByCurrency(code);
        }

        /// <summary>
        /// get calendar by currency
        /// </summary>
        /// <param name="currency"></param>
        /// <returns></returns>
        public static ICalendar GetCalendarByCurrency(string currency)
        {
            ICalendar calendar;

            if (calendarCache.ContainsKey(currency))
            {
                calendar = calendarCache[currency];
            }
            else
            {
                calendar = sophisManager.Calendar.Get(new CalendarInput(currency, CalendarType.ForCurrency)).FirstOrDefault();

                calendarCache[currency] = calendar;
            }
            return calendar;
        }

        /// <summary>
        /// Static constructor
        /// </summary>
        static SophisHelper()
        {
            sophisManager = SophisManager2Factory.CreateSophisManager("Prod", "APP_SOPHIS_FO", "TOP");
            wrapper = new MarketDataWrapper(sophisManager);

            var currenciesCacheFilePath = new FileInfo(CurrenciesCacheFilePath);
            var instrumentsCacheFilePath = new FileInfo(InstrumentsCacheFilePath);

            if (!LoadIfRecent(currenciesCacheFilePath, 1, f => LoadCurrencies(f.FullName)) ||
                !LoadIfRecent(instrumentsCacheFilePath, 1, f => LoadInstrumentsAsFile(f.FullName)))
            {
                LauchSophisConnectivity();
            }
        }

        public static string CurrenciesCacheFilePath
        {
            get
            {
                return ConfigurationManager.AppSettings["CurrenciesCacheFilePath"] ??
                       @"C:\Temp\CurrenciesCache.txt";
            }
        }

        public static string InstrumentsCacheFilePath
        {
            get
            {
                return ConfigurationManager.AppSettings["InstrumentsCacheFilePath"] ??
                       @"C:\Temp\InstrumentsCache.txt";
            }
        }

        public static void AddInstrumentToCache(IInstrument instrument, string reference, bool insertGivenReference = false)
        {
            if (!(instrument is MarketDataError) && !insertGivenReference)
            {
                instrumentCache[instrument.Reference] = instrument;
            }
            else
            {
                instrumentCache[reference] = instrument;
            }
        }

        /// <summary>
        /// Converter HistorizedVolatility to EdaVol
        /// </summary>
        /// <param name="volatility"></param>
        /// <param name="instrumentReference"></param>
        /// <param name="volatilityDate"></param>
        /// <returns></returns>
        public static EdaVol Convert(IVolatilityMatrix volatility, string instrumentReference, DateTime volatilityDate)
        {
            int sico = GetSicovam(instrumentReference);

            IList<ICalendar> calendar = GetCalendarBySicovam(sico.ToString());

            var vol = new EdaVol(volatilityDate, volatility,
                new Basis(BasisType.E_Parametric, 1.0, 1.0),
                calendar[0], 1.0, false, false);

            EdaStock stock = new EdaStock(1.0, volatilityDate, vol);
            vol.SetStock(stock);

            //var volSurface = vol.EdaProtoVolatility as CVolSurface;
            //volSurface.OStock = new CStock() { DPricingDate = volatility.Date.ToOADate() };

            var matrix = vol.EdaProtoVolatility.convertVol(new CBasis(EBasis.E_bus252, 0.0, 0.0));

            EdaVol volConverted = new EdaVol(vol.CalculationDate,
                vol.Strikes,
                vol.Maturities,
                matrix,
                new Basis(BasisType.E_bus252, 0.0, 0.0),
                calendar[0],
                1.0,
                false,
                false);

            EdaStock stockConverted = new EdaStock(1.0, volConverted.CalculationDate, volConverted);
            vol.SetStock(stockConverted);

            return volConverted;
        }

        /// <summary>
        /// Get Bloomberg ticker
        /// </summary>
        /// <param name="referenceSophis"></param>
        public static string GetBloombergTicker(string referenceSophis)
        {
            IInstrument instrument;

            if (!GetFromCache(referenceSophis, EnumSophisRefCodeType.Reference, out instrument))
            {
                try
                {
                    if (instrument == null)
                    {
                        instrument =
                            sophisManager.
                                Instrument.Get(new InstrumentInput(referenceSophis, EnumSophisRefCodeType.Reference));

                        AddInstrumentToCache(instrument, referenceSophis);
                    }
                }
                catch (Exception ex)
                {
                    LoggingService.Error(typeof(SophisHelper),
                        "Instrument with reference code " + referenceSophis + " was not found", ex);
                }
            }

            return GetBloombergTickerValue(referenceSophis, instrument);
        }

        public static IList<IMarket> GetMarketsByCode(string marketCode)
        {
            try
            {
                return sophisManager.Markets.Get(new MarketsInput(marketCode));
            }
            catch (Exception ex)
            {
                LoggingService.Error(typeof(SophisHelper), ex.Message, ex);

                throw new SophisManagerException(ex.Message);
            }
        }

        /// <summary>
        /// Get Sicovam from Sophis reference (truncated Bloomberg code)
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static Dictionary<string, string> GetBloombergTickers(string[] referenceSophis)
        {
            try
            {
                var cachedInstruments = instrumentCache.Where(i => referenceSophis.Contains(i.Key)).ToArray();
                var missingReferences = referenceSophis.Except(cachedInstruments.Select(x => x.Key)).ToArray();

                IList<IInstrument> requestedInstruments = GetMissingInstrumentsFromReferences(missingReferences);

                var allInstruments = cachedInstruments.Select(x => x.Value).Union(requestedInstruments).Where(x => !(x is MarketDataError)).ToArray();
                return referenceSophis.Distinct().ToDictionary(x => x, x => GetBloombergTickerValue(x, allInstruments.FirstOrDefault(i => i.Reference == x)));
            }
            catch (Exception ex)
            {
                LoggingService.Error(typeof(SophisHelper), ex.Message, ex);

                throw new SophisManagerException(ex.Message);
            }
        }

        /// <summary>
        /// get calendar by market
        /// </summary>
        /// <param name="markettarget"></param>
        /// <returns></returns>
        public static ICalendar GetCalendarByMarketMnemo(string markettarget)
        {
            ICalendar calendar;

            if (calendarCache.ContainsKey(markettarget))
            {
                calendar = calendarCache[markettarget];
            }
            else
            {
                ///{ccy}|{mnemo} format string
                var parts = markettarget.Split('|');
                calendar = sophisManager.Calendar.Get(new CalendarInput(parts[1], parts[0], true)).FirstOrDefault();

                calendarCache[markettarget] = calendar;
            }
            return calendar;
        }

        /// <summary>
        /// Get Calendar from Sicovam 
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static IList<ICalendar> GetCalendarBySicovam(string referenceSophis)
        {
            ICalendar calendar;

            if (calendarCache.ContainsKey(referenceSophis))
            {
                calendar = calendarCache[referenceSophis];
            }
            else
            {
                calendar = sophisManager.Calendar.Get(new CalendarInput(referenceSophis, CalendarType.ForInstrument)).FirstOrDefault();

                calendarCache.Add(referenceSophis, calendar);
            }
            return calendar.AsArray().ToList();
        }

        /// <summary>
        /// Get Basket from Sicovam 
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static IBasket GetCompoositionsBySicovam(int referenceSophis)
        {
            return sophisManager.IndexComposition.Get(new CompositionInput(referenceSophis));
        }

        /// <summary>
        /// Get currency from sicovam
        /// </summary>
        /// <param name="sicovam"></param>
        /// <returns></returns>
        public static string GetCurrency(int sicovam)
        {
            var reference = GetReference(sicovam);

            if (!string.IsNullOrWhiteSpace(reference))
            {
                var instrument = GetInstrumentInfo(reference);

                if (instrument != null)
                {
                    return instrument.Currency;
                }
            }

            return null;
        }

        /// <summary>
        /// Get currency from sicovam
        /// </summary>
        /// <param name="sicovam"></param>
        /// <returns></returns>
        public static double GetTradingUnit(int sicovam)
        {
            var reference = GetReference(sicovam);

            if (!string.IsNullOrWhiteSpace(reference))
            {
                var instrument = GetInstrumentInfo(reference);

                if (instrument != null)
                {
                    return instrument.TradingUnit;
                }
            }

            return 1;
        }

        /// <summary>
        /// Search in local Sophis cache
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <param name="type"></param>
        /// <param name="instr"></param>
        /// <returns></returns>
        public static bool GetFromCache(string referenceSophis, EnumSophisRefCodeType type, out IInstrument instr)
        {
            if (type == EnumSophisRefCodeType.Sicovam)
            {
                instr = instrumentCache.Values.Where(x => !(x is MarketDataError)).FirstOrDefault(x => x.Code == int.Parse(referenceSophis));

                return instr != null;
            }


            if (instrumentCache.ContainsKey(referenceSophis))
            {
                instr = instrumentCache[referenceSophis];

                if (instr == null)
                {
                    return true;
                }

                return true;
            }

            instr = null;
            return false;
        }

        /// <summary>
        /// Search in local Sophis cache
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static IInstrument GetFromCache(int sophisSicovam)
        {
            IInstrument instr = null;

            try
            {
                instr = instrumentCache.Values.FirstOrDefault(o => o != null && !(o is MarketDataError) && o.Code == sophisSicovam);
            }
            catch (Exception ex)
            {
                LoggingService.Warn(typeof(SophisHelper), sophisSicovam + " not found in cache");
            }

            if (instr == null)
            {
                throw new Exception(string.Format("Instrument with sicovam [{0}] is not found", sophisSicovam));
            }

            return instr;
        }

        /// <summary>
        /// Get Histories from Sicovams
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static IList<IHistories> GetHistories(int[] sicovams, DateTime startDate, DateTime endDate)
        {
            if (!sicovams.Any())
            {
                return new List<IHistories>();
            }

            return sophisManager.History.GetList(sicovams.Select(sicovam => new HistoryInput(sicovam, startDate, endDate)).ToArray());
        }

        public static IInstrument GetInstrumentInfo(string code, EnumSophisRefCodeType type = EnumSophisRefCodeType.Reference)
        {
            IInstrument instrument;
            if (!GetFromCache(code, type, out instrument))
            {
                instrument =
                    sophisManager.
                        Instrument.Get(new InstrumentInput(code, type));

                AddInstrumentToCache(instrument, code);
            }

            return instrument;
        }

        public static string GetIsin(string code, EnumSophisRefCodeType type = EnumSophisRefCodeType.Reference)
        {
            IInstrument instrument;
            if (!GetFromCache(code, type, out instrument))
            {
                instrument =
                    sophisManager.
                        Instrument.Get(new InstrumentInput(code, type));

                AddInstrumentToCache(instrument, code);
            }

            return instrument.Mnemo;
        }

        /// <summary>
        /// Get Sophis reference from Sophis sicovam
        /// </summary>
        /// <param name="sophisSicovam"></param>
        /// <returns></returns>
        public static string GetReference(int sophisSicovam)
        {
            try
            {
                IInstrument instrument = GetFromCache(sophisSicovam);

                if (instrument == null)
                {
                    instrument = sophisManager.
                            Instrument.Get(new InstrumentInput(sophisSicovam));

                    if (!(instrument is MarketDataError) && !string.IsNullOrWhiteSpace(instrument.Reference))
                        AddInstrumentToCache(instrument, instrument.Reference);
                }

                return instrument.Reference;
            }
            catch (Exception ex)
            {
                LoggingService.Error(typeof(SophisHelper), "Instrument with Sophis sicovam " + sophisSicovam + " was not found", ex);
            }

            return null;
        }

        /// <summary>
        /// Get Sophis reference from Sophis sicovam
        /// </summary>
        /// <param name="sophisSicovams"></param>
        /// <returns></returns>
        public static Dictionary<int, string> GetReferences(int[] sophisSicovams)
        {
            try
            {
                var cachedInstruments = instrumentCache.Where(i => sophisSicovams.Any(sicovam => i.Value != null && !(i.Value is MarketDataError) && sicovam == i.Value.Code)).ToArray();
                var missingReferences = sophisSicovams.Except(cachedInstruments.Select(x => x.Value.Code)).ToArray();

                IList<IInstrument> instruments = new IInstrument[0];
                if (missingReferences.Any())
                {
                    instruments =
                        sophisManager.Instrument.GetList(
                            missingReferences.Select(
                                x => new InstrumentInput(x.ToString(), EnumSophisRefCodeType.Sicovam)).ToList()).Where(i => !(i is MarketDataError)).ToList();

                    foreach (var instr in instruments)
                    {
                        if (instr is MarketDataError)
                            continue;
                        AddInstrumentToCache(instr, instr.Reference);

                        LoggingService.DebugFormatted(typeof(SophisHelper), "Found in Sophis : {0}", instr.Reference);
                    }
                }

                return cachedInstruments.Select(x => x.Value).Union(instruments).ToDictionary(x => x.Code, x => x.Reference);
            }
            catch (Exception ex)
            {
                LoggingService.Error(typeof(SophisHelper), ex.Message, ex);

                throw new SophisManagerException(ex.Message);
            }
        }

        /// <summary>
        /// Get Sicovam from Sophis reference (truncated Bloomberg code)
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static int GetSicovam(string referenceSophis)
        {
            try
            {
                IInstrument instrument;

                instrument = GetInstrumentInfo(referenceSophis);

                return instrument.Code;
            }
            catch (Exception ex)
            {
                var message = "Instrument with reference code " + referenceSophis + " was not found";
                LoggingService.Error(typeof(SophisHelper), message, ex);

                throw new SophisManagerException(message);
            }
        }

        public static int? GetSicovamOrNaN(string referenceSophis)
        {
            try
            {
                return GetSicovam(referenceSophis);
            }
            catch
            {
                return null;
            }
        }

        /// <summary>
        /// Get Sicovam from Sophis reference (truncated Bloomberg code)
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <returns></returns>
        public static Dictionary<string, int> GetSicovams(string[] referenceSophis)
        {
            try
            {
                var cachedInstruments = instrumentCache.Where(i => referenceSophis.Contains(i.Key)).ToArray();
                var missingReferences = referenceSophis.Except(cachedInstruments.Select(x => x.Key)).ToArray();

                IList<IInstrument> instruments = GetMissingInstrumentsFromReferences(missingReferences);

                return cachedInstruments.Select(x => x.Value)
                    .Union(instruments)
                    .Where(i => !(i is MarketDataError))
                    .GroupBy(x => x.Reference)
                    .Select(x => x.First())
                    .ToDictionary(x => x.Reference, x => x.Code);
            }
            catch (Exception ex)
            {
                LoggingService.Error(typeof(SophisHelper), ex.Message, ex);

                throw new SophisManagerException(ex.Message);
            }
        }

        public static Dictionary<int, string> GetTickerOverrides(int optionSicovam)
        {
            return sophisManager.FundComposition.Get(new FundComponentsInput(optionSicovam.ToString())).Components.Where(c => !string.IsNullOrEmpty(c.FixingRic)).ToDictionary(x => x.Sicovam, x => x.FixingRic);
        }

        /// <summary>
        /// Sophis type to Bloomberg suffix
        /// </summary>
        /// <param name="sophisType"></param>
        /// <returns></returns>
        public static string GetSophisTypeToBloombergSuffix(string sophisType)
        {
            switch (sophisType)
            {
                case "A":
                    return BloombergSuffixEquity;
                case "E":
                    return BbgCurrencySuffix;
                case "F":
                    return BloombergSuffixIndex;
                case "I":
                    return BloombergSuffixIndex;
                case "O":
                    return "Corp";
                case "P":
                    return "Loan";
                case "R":
                    return "Rate";
                case "S":
                    return "Swap";
                default:
                    return BloombergSuffixEquity;
            }
        }

        public static bool LoadCurrencies(string filePath)
        {
            if (!File.Exists(filePath))
            {
                return false;
            }

            currencies = File.ReadAllText(filePath).FromSerializedString<string[]>();

            return true;
        }

        public static bool LoadInstrumentsAsFile(string filePath)
        {
            if (!File.Exists(filePath))
            {
                return false;
            }

            var instruments = File.ReadAllText(filePath).FromSerializedString<Instrument[]>();

            instruments.ForEach(i => instrumentCache.GetOrAdd(i.Reference, Instrument.CopyToGda(i)));

            return true;
        }

        public static void SaveCurrencies(string filePath)
        {
            var curs = (currencies ?? sophisManager.Currency.GetAllCurrencies().Names.ToArray());

            File.WriteAllText(filePath, curs.ToSerializedString());
        }

        public static void SaveInstruments(string filePath, string[] references)
        {
            var instruments = GetMissingInstrumentsFromReferences(references).Where(i => i is GDAInstrument).Cast<GDAInstrument>().ToArray();

            File.WriteAllText(filePath, instruments.Select(x => new Instrument(x)).ToArray().ToSerializedString());
        }

        internal static Dictionary<string, ICalendar> GetCalendarByReference(string[] tickers)
        {
            return calendarCache[tickers.First()].AsArray().ToDictionary(x => tickers.First(), x => x);
        }
        private static string GetBloombergTickerValue(string reference, IInstrument instrument)
        {
            string instrumentType = instrument == null || instrument is MarketDataError ? string.Empty : instrument.InstrumentType;

            if (IsCurrencyTicker(reference))
            {
                return reference + " " + BbgCurrencySuffix;
            }

            foreach (var suffix in ValidBbgSuffixes)
            {
                if (reference.EndsWith(suffix))
                {
                    return reference;
                }
            }

            return reference + " " + GetSophisTypeToBloombergSuffix(instrumentType);
        }

        private static IList<IInstrument> GetMissingInstrumentsFromReferences(string[] missingReferences)
        {
            IList<IInstrument> requestedInstruments = new List<IInstrument>();
            if (missingReferences.Any())
            {
                //// KEEP marketdata error, we do not want to request sophis for unknown underlying again and again.
                var missingReferencesClean = missingReferences.ToList().Remove(o => string.IsNullOrWhiteSpace(o)).Select(x => new InstrumentInput(AdaptTickerForSophis(x), EnumSophisRefCodeType.Reference)).ToList();
                if (missingReferencesClean.Any())
                {
                    requestedInstruments =
                        sophisManager.Instrument.GetList(missingReferencesClean).ToList();

                    for (int i = 0; i < requestedInstruments.Count; ++i)
                    {
                        var instr = requestedInstruments[i];
                        AddInstrumentToCache(instr, missingReferences[i]);
                    }
                }
            }
            return requestedInstruments;
        }

        public static string AdaptTickerForSophis(string x)
        {
            if(x.Contains("@"))
            {
                return x.Split(" ".AsArray(), StringSplitOptions.RemoveEmptyEntries).First();
            }

            return x;
        }

        public static bool IsCurrencyTicker(string ticker)
        {
            currencies = currencies ?? sophisManager.Currency.GetAllCurrencies().Names.ToArray();

            if (!string.IsNullOrWhiteSpace(ticker))
            {
                var parts = ticker.Split(" ".AsArray(), StringSplitOptions.None);

                var currencyPart = parts[0];

                if (currencyPart.Length == 6)
                {
                    var firstCurrency = currencyPart.Substring(0, 3);
                    var secondCurrency = currencyPart.Substring(3);

                    if (currencies.Contains(firstCurrency) && currencies.Contains(secondCurrency))
                    {
                        return true;
                    }
                }
            }

            return false;
        }

        /// <summary>
        /// Test if Sophis is available, if not load cache with no date test
        /// </summary>
        private static void LauchSophisConnectivity()
        {
            Thread isUpThread = new Thread(() =>
            {
                int nbMaxTries = 5;
                int nbTries = 0;
                bool isUp = false;

                while (nbTries < nbMaxTries)
                {
                    try
                    {
                        sophisManager.Instrument.Get(new InstrumentInput("SPX", EnumSophisRefCodeType.Reference));
                        isUp = true;
                        break;
                    }
                    catch (Exception ex)
                    {
                        LoggingService.Error(typeof(SophisHelper), ex.Message, ex);
                    }

                    nbTries++;
                }

                if (!isUp)
                {
                    LoadCurrencies(CurrenciesCacheFilePath);
                    LoadInstrumentsAsFile(InstrumentsCacheFilePath);
                }
            });

            isUpThread.IsBackground = true;
            isUpThread.Start();
        }
        private static bool LoadIfRecent(FileInfo fileInfo, int daysLag, Predicate<FileInfo> loadAction)
        {
            if (fileInfo.Exists && fileInfo.LastWriteTime >= DateTime.Today.AddDays(-daysLag))
            {
                return loadAction(fileInfo);
            }

            return false;
        }
    }
}
