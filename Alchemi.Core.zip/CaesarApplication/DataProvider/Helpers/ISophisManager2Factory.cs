﻿using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Settings.SophisSettings;
using GlobalDerivativesApplications.Sophis;

namespace CaesarApplication.DataProvider.Helpers
{
    public interface ISophisManager2Factory
    {
        ISophisManager2 CreateDefaultSophisManager();
        ISophisManager2 CreateSophisManager(string environmentId, string user, string password);
        ISophisManager2 CreateSophisManager(string environmentId, SophisTable sophisContext, string user, string password);
        ISophisManager2 CreateSophisManagerUsingDefaultUser(string environmentId);
        ISophisManager2 CreateSophisManagerUsingDefaultUser(string environmentId, SophisTable sophisContext);
        ISophisManager2 CreateSophisManagerWithCurrentConfiguration();
    }
}