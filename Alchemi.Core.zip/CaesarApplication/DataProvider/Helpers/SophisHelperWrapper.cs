﻿using GlobalDerivativesApplications.Data.Booking;
using GlobalDerivativesApplications.Data.Instrument;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.EdaProto;
using System;
using System.Collections.Generic;

namespace CaesarApplication.DataProvider.Helpers
{
    public class SophisHelperWrapper
    {

        #region Properties
        public string CurrenciesCacheFilePath
        {
            get
            {
                return SophisHelper.CurrenciesCacheFilePath;
            }
        }
        public  string InstrumentsCacheFilePath
        {
            get
            {
                return SophisHelper.InstrumentsCacheFilePath;
            }
        }

        #endregion

        public ICalendar GetCalendarByCode(string code)
        {
            return SophisHelper.GetCalendarByCode(code);
        }
        public ICalendar GetCalendarByCurrency(string currency)
        {
            return SophisHelper.GetCalendarByCurrency(currency);
        }
        public void AddInstrumentToCache(IInstrument instrument, string reference, bool insertGivenReference = false)
        {
            SophisHelper.AddInstrumentToCache(instrument, reference, insertGivenReference);
        }
        public EdaVol Convert(IVolatilityMatrix volatility, string instrumentReference, DateTime volatilityDate)
        {
            return SophisHelper.Convert(volatility, instrumentReference, volatilityDate);
        }
        public string GetBloombergTicker(string referenceSophis)
        {
            return SophisHelper.GetBloombergTicker(referenceSophis);
        }
        public IList<IMarket> GetMarketsByCode(string marketCode)
        {
            return SophisHelper.GetMarketsByCode(marketCode);
        }
        public Dictionary<string, string> GetBloombergTickers(string[] referenceSophis)
        {
            return SophisHelper.GetBloombergTickers(referenceSophis);
        }
        public ICalendar GetCalendarByMarketMnemo(string markettarget)
        {
            return SophisHelper.GetCalendarByMarketMnemo(markettarget);
        }
        public IList<ICalendar> GetCalendarBySicovam(string referenceSophis)
        {
            return SophisHelper.GetCalendarBySicovam(referenceSophis);
        }
        public IBasket GetCompositionsBySicovam(int referenceSophis)
        {
            return SophisHelper.GetCompoositionsBySicovam(referenceSophis);
        }
        public string GetCurrency(int sicovam)
        {
            return SophisHelper.GetCurrency(sicovam);
        }
        public bool GetFromCache(string referenceSophis, out IInstrument instr)
        {
            return SophisHelper.GetFromCache(referenceSophis, EnumSophisRefCodeType.Reference,  out instr);
        }
        public IInstrument GetFromCache(int sophisSicovam)
        {
            return SophisHelper.GetFromCache(sophisSicovam);
        }
        public IList<IHistories> GetHistories(int[] sicovams, DateTime startDate, DateTime endDate)
        {
            return SophisHelper.GetHistories(sicovams, startDate, endDate);
        }
        public IInstrument GetInstrumentInfo(string code, EnumSophisRefCodeType type = EnumSophisRefCodeType.Reference)
        {
            return SophisHelper.GetInstrumentInfo(code, type);
        }
        public string GetIsin(string code, EnumSophisRefCodeType type = EnumSophisRefCodeType.Reference)
        {
            return SophisHelper.GetIsin(code, type);
        }
        public string GetReference(int sophisSicovam)
        {
            return SophisHelper.GetReference(sophisSicovam);
        }
        public Dictionary<int, string> GetReferences(int[] sophisSicovams)
        {
            return SophisHelper.GetReferences(sophisSicovams);
        }
        public int GetSicovam(string referenceSophis)
        {
            return SophisHelper.GetSicovam(referenceSophis);
        }
        public Dictionary<string, int> GetSicovams(string[] referenceSophis)
        {
            return SophisHelper.GetSicovams(referenceSophis);
        }
        public string GetSophisTypeToBloombergSuffix(string sophisType)
        {
            return SophisHelper.GetSophisTypeToBloombergSuffix(sophisType);
        }
        public bool LoadCurrencies(string filePath)
        {
            return SophisHelper.LoadCurrencies(filePath);
        }
        public bool LoadInstrumentsAsFile(string filePath)
        {
            return SophisHelper.LoadInstrumentsAsFile(filePath);
        }
        public void SaveCurrencies(string filePath)
        {
            SophisHelper.SaveCurrencies(filePath);
        }
        public void SaveInstruments(string filePath, string[] references)
        {
            SophisHelper.SaveInstruments(filePath, references);
        }
        internal Dictionary<string, ICalendar> GetCalendarByReference(string[] tickers)
        {
            return SophisHelper.GetCalendarByReference(tickers);
        }

    }
}
