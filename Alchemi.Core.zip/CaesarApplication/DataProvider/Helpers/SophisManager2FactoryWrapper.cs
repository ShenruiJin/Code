﻿using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Settings.SophisSettings;
using GlobalDerivativesApplications.Sophis;

namespace CaesarApplication.DataProvider.Helpers
{
    public class SophisManager2FactoryWrapper : ISophisManager2Factory
    {
        public ISophisManager2 CreateDefaultSophisManager()
        {
            return SophisManager2Factory.CreateDefaultSophisManager();
        }
        public ISophisManager2 CreateSophisManager(string environmentId, string user, string password)
        {
            return SophisManager2Factory.CreateSophisManager(environmentId, user, password);
        }
        public ISophisManager2 CreateSophisManager(string environmentId, SophisTable sophisContext, string user, string password)
        {
            return SophisManager2Factory.CreateSophisManager(environmentId, sophisContext, user, password);
        }
        public ISophisManager2 CreateSophisManagerUsingDefaultUser(string environmentId)
        {
            return SophisManager2Factory.CreateSophisManagerUsingDefaultUser(environmentId);
        }
        public ISophisManager2 CreateSophisManagerUsingDefaultUser(string environmentId, SophisTable sophisContext)
        {
            return SophisManager2Factory.CreateSophisManagerUsingDefaultUser(environmentId, sophisContext);
        }
        public ISophisManager2 CreateSophisManagerWithCurrentConfiguration()
        {
            return SophisManager2Factory.CreateSophisManagerWithCurrentConfiguration();
        }
    }
}
