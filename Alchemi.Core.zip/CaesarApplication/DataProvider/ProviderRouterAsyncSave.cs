using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using FuncFramework.Business;
using GlobalDerivativesApplications.Threading;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public class ProviderRouterAsyncSave : ProviderRouter
    {
        private readonly bool saveLocal;
        TaskFactory factory = new TaskFactory(new MonoThreadTaskScheduler("ProviderRouterAsyncSave"));

        public ProviderRouterAsyncSave(bool saveLocal, IProviderExecutable[] providers, bool readOnly = false) : base(providers, readOnly)
        {
            this.saveLocal = saveLocal;
        }

        public override void Save(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            var timeSerieDbs = timeSeries.Select(ts => new TimeSerieDB(ts.GetElements().ToArray(), ts.Instrument, ts.Field)
            {
                Source = ts.Source,
                SourceSegments = ts.SourceSegments
                
            }).Where(x => saveLocal || context == null || !IndexPathHelper.IsLocalPath(context, x.Instrument)).ToArray();

            if (timeSerieDbs.Any())
            {
                Action run = () =>
                {
                    base.Save(timeSerieDbs, context);
                };

                factory.StartNew(run);
            }
        }
    }
}