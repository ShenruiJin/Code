﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    [Serializable]
    public abstract class ProviderExecutable : IProviderExecutable
    {
        /// <summary>
        /// List of all managed fields
        /// </summary>
        protected IList<DataFieldsEnum> _fields;

        /// <summary>
        /// Generic method
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public virtual TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null,
                                                                DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            var result = Load(new List<string> { ticker }, field, startDate, endDate, loadingContext);

            if(result != null && result.Count != 0)
            {
                return result[0];
            }
            
            return null;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public abstract IList<TimeSerieDB> Load(   IEnumerable<string> tickers, DataFieldsEnum field, 
                                                                        DateTime? startDate = null, DateTime? endDate = null, 
                                                                        ILoadingContext loadingContext = null);

        /// <summary>
        /// Save method
        /// </summary>
        /// <param name="timeSeries"></param>
        public virtual void Save(IList<TimeSerieDB> timeSeries)
        {
        }

        /// <summary>
        /// Save method
        /// </summary>
        /// <param name="timeSeries"></param>
        /// <param name="loadingContext"></param>
        public virtual void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
        }

        /// <summary>
        /// Field to query
        /// </summary>
        public virtual IList<DataFieldsEnum> SupportedFields
        {
            get { return _fields; }
        }

        /// <summary>
        /// Source type
        /// </summary>
        public DataTypeEnum SourceType 
        {
            get { return DataTypeEnum.Global; }
        }

        /// <summary>
        /// returns a list containing all dates between the two given dates
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        protected IList<DateTime> GenerateDates(DateTime startDate, DateTime endDate)
        {
            IList<DateTime> dates = new List<DateTime>();
            DateTime date = startDate;

            while (date <= endDate)
            {
                dates.Add(date);
                date = date.AddDays(1);
            }

            return dates;
        }

        /// <summary>
        /// Initializes the given dates with default values if needed
        /// if endDate is null, default value is today 
        /// if startDate is null, default value is endDate
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        protected void InitializeDates(ref DateTime? startDate, ref DateTime? endDate)
        {
            if (endDate == null)
            {
                endDate = DateTime.Today;
            }

            if (startDate == null)
            {
                startDate = endDate;
            }
        }
    }
}
