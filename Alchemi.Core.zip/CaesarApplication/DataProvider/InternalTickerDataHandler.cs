﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Path delimiter used by client it's not the same as the internal
    /// </summary>
    [Serializable]
    public class InternalTickerDataHandler : DataHandler
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate,
            ILoadingContext loadingContext, bool removeEmptySeries = false)
        {
            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var tickersToTranscode = tickersAsArray.Where(t => t.Contains(TimeSeriesProviderConstants.ClientDelimiter)).ToArray();
            var tickersNonTranscoded = tickersAsArray.Where(t => !t.Contains(TimeSeriesProviderConstants.ClientDelimiter)).ToArray();
            var transcodedTickers = tickersToTranscode.Select(t => t.Replace(TimeSeriesProviderConstants.ClientDelimiter, GlobalDerivativesApplications.Data.DataTree<object>.PathDelimiter)).ToArray();

            var result = GetResultFromSuccessor(startDate, endDate, tickersNonTranscoded.Union(transcodedTickers).ToArray(), dataFieldsAsArray, loadingContext, false);

            result.Where(ts => transcodedTickers.Contains(ts.Instrument)).ForEach(r => r.Instrument = r.Instrument.Replace(GlobalDerivativesApplications.Data.DataTree<object>.PathDelimiter, TimeSeriesProviderConstants.ClientDelimiter));

            return result;
        }

        protected override void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
        }
    }
}