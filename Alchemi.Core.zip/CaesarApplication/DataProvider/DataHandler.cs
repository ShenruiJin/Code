﻿using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using FuncFramework;
using GlobalDerivativesApplications.Date;
using PricingBase.DataProvider;
using PricingBase.Dates;
using System.Text;
using System.Diagnostics;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Handle MarketData requests
    /// It is an element in the Chain of Reponsability
    /// </summary>
    [Serializable]
    public class DataHandler : IDataHandler, IDataHandlerTechnical, IDataHandlerExtensible
    {
        /// <summary>
        /// DataHandler name
        /// </summary>
        private readonly string name;

        /// <summary>
        /// Next handler to be called
        /// </summary>
        private IDataHandler _nextHandler;

        /// <summary>
        /// Provides implementations to each market data
        /// </summary>
        private readonly IProviderRouter _providerRouter;

        /// <summary>
        /// Transcoder for InstrumentCode if null no transcoding
        /// </summary>
        protected InstrumentCodeTranscoder instrumentCodeTranscoder;

        private bool filterWithHorizonDatesForSave;
        private bool disableLoading;
        private readonly int? horizonMaxDays;
        private readonly bool markSource;
        //private bool trusted;

        private Predicate<ILoadingContext> shouldLoadPredicate;
        private Func<ILoadingContext, TimeSerieDB, bool> shouldSavePredicate;

        /// <summary>
        /// Fields managed
        /// </summary>
        public IEnumerable<DataFieldsEnum> ManagedFields
        {
            get
            {
                if (_providerRouter == null)
                    return null;

                return _providerRouter.ManagedFields;
            }
        }

        /// <summary>
        /// Managed fields with its sucessors
        /// </summary>
        public IEnumerable<DataFieldsEnum> ManagedFieldsWithSuccessors
        {
            get
            {
                IEnumerable<DataFieldsEnum> successorFields;

                if (_nextHandler == null)
                {
                    successorFields = new List<DataFieldsEnum>();
                }
                else
                {
                    successorFields = _nextHandler.ManagedFieldsWithSuccessors;
                }

                return _providerRouter != null ? _providerRouter.ManagedFields.Union(successorFields) : new List<DataFieldsEnum>().Union(successorFields);
            }
        }

        protected DataHandler()
        {
        }

        /// <summary>
        /// Constructor - set the MarketData Provider
        /// </summary>
        public DataHandler(string name, IProviderRouter provider, InstrumentCodeTranscoder instrumentCodeTranscoder = null, bool disableLoading = false, bool trusted = false, int? horizonMaxDays = null, bool markSource = false, Predicate<ILoadingContext> shouldLoadPredicate = null, bool filterWithHorizonDatesForSave = true, Func<ILoadingContext, TimeSerieDB, bool> shouldSavePredicate = null)
        {
            this.name = name;
            _providerRouter = provider;
            this.instrumentCodeTranscoder = instrumentCodeTranscoder;
            this.disableLoading = disableLoading;
            this.horizonMaxDays = horizonMaxDays;
            this.markSource = markSource;
            this.shouldLoadPredicate = shouldLoadPredicate;
            this.filterWithHorizonDatesForSave = filterWithHorizonDatesForSave;
            this.shouldSavePredicate = shouldSavePredicate;
            //this.trusted = trusted;
        }

        /// <summary>
        /// Horizon date
        /// </summary>
        private DateTime HorizonDate
        {
            get
            {
                var horizonMaxDays = this.horizonMaxDays.GetValueOrDefault(-1);
                var refDate = PricingReference.ReferenceDate == default(DateTime)
                    ? DateTime.Today
                    : PricingReference.ReferenceDate;
                var horizonDate = refDate.AddDays(-horizonMaxDays);

                while ((horizonDate.DayOfWeek == DayOfWeek.Sunday
                        || horizonDate.DayOfWeek == DayOfWeek.Saturday))
                {
                    horizonDate = horizonDate.AddDays(-1);
                }

                return horizonDate;
            }
        }

        /// <summary>
        /// Next handler to be called
        /// </summary>
        public IDataHandler NextHandler
        {
            get { return _nextHandler; }
        }

        /// <summary>
        /// DataHandler name
        /// </summary>
        public string Name
        {
            get { return name; }
        }

        public bool ShouldLoadPredicate(ILoadingContext context)
        {
            return shouldLoadPredicate == null || shouldLoadPredicate(context);
        }

        /// <summary>
        /// Provides implementations to each market data
        /// </summary>
        IProviderRouter IDataHandlerTechnical.Router
        {
            get { return _providerRouter; }
        }

        /// <summary>
        /// Provides implementations to each market data
        /// </summary>
        public IProviderRouter ProviderRouter
        {
            get { return _providerRouter; }
        }

        /// <summary>
        /// Set the next provider to be requested
        /// </summary>
        /// <param name="nextHandler"></param>
        public void SetSuccessor(IDataHandler nextHandler)
        {
            _nextHandler = nextHandler;
        }

        public IList<TimeSerieDB> RemoveEmptyTimeSeries(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            if (_nextHandler == null)
            {
                return timeSeries;
            }

            if (timeSeries == null)
            {
                return null;
            }

            return timeSeries.Where(timeserie => timeserie.Count > 0 || timeserie.IsConsideredAsComplete || !HasNextHandler(timeserie.Field, context)).ToList();
        }

        /// <summary>
        /// Load calling upon the provider
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="removeEmptySeries"></param>
        /// <returns></returns>
        public virtual IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate, bool removeEmptySeries = false)
        {
            return Load(tickers, fields, startDate, endDate, null, removeEmptySeries);
        }

        /// <summary>
        /// Load with context
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <param name="removeEmptySeries"></param>
        /// <returns></returns>
        public virtual IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate,
            ILoadingContext loadingContext, bool removeEmptySeries = false)
        {
            StringBuilder fieldsTostring = new StringBuilder();

            fields.ForEach(f => fieldsTostring.Append(f + "|"));
            var message = string.Format("Loading time series of type(s) {0} from data handler [{1}] from {2} to {3}", fieldsTostring.ToString(),this.Name,startDate,endDate);
            LoggingService.Info(this.GetType(), message);
            Stopwatch stopwatch = Stopwatch.StartNew();


            IList<TimeSerieDB> result = null;

            var dataFieldsAsArray = fields as DataFieldsEnum[] ?? fields.ToArray();
            var tickersAsArray = tickers.ToArray();

            result = InternalLoad(_providerRouter, startDate, endDate, tickersAsArray, dataFieldsAsArray, removeEmptySeries, loadingContext);

            result = CallSuccessor(startDate, endDate, removeEmptySeries, tickersAsArray, dataFieldsAsArray, loadingContext, result);

            stopwatch.Stop();
            var durationInfo = "Operation took " + stopwatch.ElapsedMilliseconds + "ms";
            message = string.Format("Finished loading {0} time series of type {1} from data handler [{2}] from {3} to {4}. \n{5}",
                (result != null ?result.Count:0) ,fieldsTostring.ToString(), this.Name, startDate, endDate, durationInfo);
            LoggingService.Info(this.GetType(), message);

            return (result != null && result.Count !=0) ? result.Distinct().ToList() : result;
        }

        private static void CheckCancellationState(ILoadingContext loadingContext)
        {
            if (loadingContext != null)
            {
                loadingContext.CancellationToken.ThrowIfCancellationRequested();
            }
        }

        protected IList<TimeSerieDB> CallSuccessor(DateTime? startDate, DateTime? endDate, bool removeEmptySeries, string[] tickers, DataFieldsEnum[] dataFieldsAsArray, ILoadingContext context, IList<TimeSerieDB> result)
        {
            var dataFieldsWithNextHandlers = dataFieldsAsArray.Where(x => HasNextHandler(x, context)).ToArray();
            var dataFieldsWithoutNextHandlers = dataFieldsAsArray.Except(dataFieldsWithNextHandlers).ToArray();

            if (dataFieldsWithNextHandlers.Any())
            {
                var missingDataSeriesToRequest = GetMissingDataSeries(tickers, dataFieldsWithNextHandlers, result);

                if (result == null)
                {
                    result = new List<TimeSerieDB>();
                }

                var missingSeries = CallSuccessorForMissingSeries(startDate, endDate, missingDataSeriesToRequest, result, context, removeEmptySeries);

                VerifyIfSerieIsComplete(tickers, dataFieldsWithNextHandlers, startDate, endDate, context, missingSeries, result);
            }

            if (result != null && dataFieldsWithoutNextHandlers.Any())
            {
                result.Where(ts => dataFieldsWithoutNextHandlers.Contains(ts.Field)).ForEach(ts =>
                {
                    ts.SetToCompleteSerie(startDate.GetValueOrDefault(), endDate.GetValueOrDefault(HorizonDate), context, HorizonDate);
                });
            }
            return result;
        }

        private bool HasNextHandler(DataFieldsEnum dataFieldsEnum, ILoadingContext context)
        {
            var nextHandler = _nextHandler;

            do
            {
                //if (nextHandler != null && (nextHandler.ManagedFields == null || 
                //    (nextHandler.ManagedFields.Contains(dataFieldsEnum) && 
                //    (nextHandler.ShouldLoadPredicate(context)))))
                if (nextHandler != null && (nextHandler.ManagedFields != null &&
                    (nextHandler.ManagedFields.Contains(dataFieldsEnum) &&
                    (nextHandler.ShouldLoadPredicate(context)))))
                {
                    return true;
                }

                nextHandler = nextHandler != null ? nextHandler.NextHandler : null;
            } while (nextHandler != null);

            return false;
        }

        private IList<TimeSerieDB> CallSuccessorForMissingSeries(DateTime? startDate, DateTime? endDate, Dictionary<DataFieldsEnum, List<string>> missingDataSeries, IList<TimeSerieDB> result, ILoadingContext context, bool removeEmptySeries)
        {
            IList<TimeSerieDB> res = new List<TimeSerieDB>();

            foreach (var dataSeries in missingDataSeries)
            {

                res.AddRange(CallSuccessor(startDate, endDate, dataSeries.Value.ToArray(), dataSeries.Key.AsArray(), context));

                var emptyTimeSeries = new List<TimeSerieDB>();

                foreach (var instr in dataSeries.Value)
                {
                    //Successors don't have data for this serie and we store it in the cache for the requested period
                    if (!removeEmptySeries && !res.Any(r => r.Instrument == instr && r.Field == dataSeries.Key))
                    {
                        var ts = new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], instr, dataSeries.Key);
                        ts.SetLimitDates(startDate, endDate);
                        emptyTimeSeries.Add(ts);
                    }
                }

                if (res != null)
                {
                    result.AddRange(res);
                }
                Save(emptyTimeSeries, context);

                result.AddRange(emptyTimeSeries);
            }

            return res;
        }

        protected IList<TimeSerieDB> InternalLoad(IProviderRouter providerRouter, DateTime? startDate, DateTime? endDate, string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray, bool removeEmptySeries, ILoadingContext context, string prefix = "")
        {
            CheckCancellationState(context);

            if ((disableLoading && !IsInForcedSources(context)) || (HasForcedSourcesDefined(context) && !IsInForcedSources(context)) || (!HasManagedFields(providerRouter, dataFieldsAsArray)) || 
                (shouldLoadPredicate != null && !shouldLoadPredicate(context)) || 
                (context != null && context.DisabledSources != null && context.DisabledSources.Contains(Name)))
            {
                return new List<TimeSerieDB>();
            }

            var trancodingDico = TranscodeToInternal(tickersAsArray, prefix, context);

            var internalTickers = trancodingDico.Keys.ToArray();

            IList<TimeSerieDB> result;
            try
            {
                var horizonDate = HorizonDate;

                if (startDate != null && startDate > horizonDate)
                {
                    LoggingService.Warn(GetType(), "Period is further than horizon date");
                    return null;
                }

                if (filterWithHorizonDatesForSave && endDate != null && endDate > horizonDate)
                {
                    endDate = horizonDate;
                }

                result = providerRouter.Load(internalTickers, dataFieldsAsArray, startDate, endDate, context);

                if (filterWithHorizonDatesForSave && result != null)
                {
                    result.ForEach(r => r.GetElements().Where(x => x.Key > horizonDate).ForEach(e => r.Remove(e)));
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Cannot load", ex);

                return null;
            }

            if (removeEmptySeries /* && !trusted*/ && _nextHandler != null)
            {
                result = RemoveEmptyTimeSeries(result, context);
            }

            //if (trusted && result != null)
            //{
            //    result.ForEach(ts =>
            //    {
            //        ts.StartDate = startDate;
            //        ts.EndDate = endDate;
            //    });
            //}

            TranscodeToExternal(result, trancodingDico);
            CheckCancellationState(context);

            if (markSource && result != null)
            {
                result.ForEach(ts => ts.Source = Name);
            }

            return result;
        }

        private bool IsInForcedSources(ILoadingContext context)
        {
            return context != null && context.LoadingSources != null && context.LoadingSources.Contains(Name);
        }

        private bool HasForcedSourcesDefined(ILoadingContext context)
        {
            return context != null && context.LoadingSources != null;
        }

        private bool HasManagedFields(IProviderRouter providerRouter, DataFieldsEnum[] dataFieldsAsArray)
        {
            return IsProviderMono() || dataFieldsAsArray.Any(f => providerRouter.ManagedFields.Contains(f));
        }

        private Dictionary<string, string> TranscodeToInternal(string[] tickersAsArray, string prefix, ILoadingContext context)
        {
            if (instrumentCodeTranscoder == null)
            {
                return tickersAsArray.ToDictionary(x => x, x => x);
            }

            var internalTickers = instrumentCodeTranscoder.TranscodeExternalToInternal(tickersAsArray, context);

            Dictionary<string, string> trancodingDico = new Dictionary<string, string>();

            for (int i = 0; i < tickersAsArray.Length; i++)
            {
                trancodingDico[prefix + internalTickers[i].Trim()] = tickersAsArray[i];
            }

            return trancodingDico;
        }

        private static Dictionary<DataFieldsEnum, List<string>> GetMissingDataSeries(string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray, IList<TimeSerieDB> result)
        {
            var missingDataSeries = new Dictionary<DataFieldsEnum, List<string>>();

            foreach (var field in dataFieldsAsArray)
            {
                var missingTickers = new List<String>();

                foreach (var ticker in tickersAsArray)
                {
                    if (result == null || !result.Any(r => r.Instrument == ticker && r.Field == field))
                    {
                        missingTickers.Add(ticker);
                    }
                }

                if (missingTickers.Count > 0)
                {
                    missingDataSeries.Add(field, missingTickers);
                }
            }

            return missingDataSeries;
        }

        private IList<TimeSerieDB> CallSuccessor(DateTime? startDate, DateTime? endDate, string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray, ILoadingContext context, bool removeEmptySeries = true)
        {
            // Load from successor
            var result = GetResultFromSuccessor(startDate, endDate, tickersAsArray, dataFieldsAsArray, context, removeEmptySeries);
            //result = RemoveEmptyTimeSeries(result, context);

            if (result != null)
            {
                SetLimitDates(result, startDate, endDate);
            }
            return result;
        }

        protected IList<TimeSerieDB> GetResultFromSuccessor(DateTime? startDate, DateTime? endDate, string[] tickersAsArray, DataFieldsEnum[] dataFieldsAsArray, ILoadingContext context, bool removeEmptySeries)
        {
            if (_nextHandler == null)
            {
                return new List<TimeSerieDB>();
            }
            if (endDate < startDate)
            {
                return new List<TimeSerieDB>();
            }
            return _nextHandler.Load(tickersAsArray, dataFieldsAsArray, startDate, endDate, context, removeEmptySeries);
        }

        private void SetLimitDates(IList<TimeSerieDB> result, DateTime? startDate, DateTime? endDate)
        {
            if (result != null)
            {
                result.ForEach(ts =>
                {
                    ts.StartDate = startDate;
                    ts.EndDate = endDate;
                });
            }
        }

        private void TranscodeToExternal(IList<TimeSerieDB> result, Dictionary<string, string> transcoDico)
        {
            if (result != null && instrumentCodeTranscoder != null)
            {
                foreach (var ts in result)
                {
                    if (transcoDico.ContainsKey(ts.Instrument.Trim()))
                    {
                        ts.Instrument = transcoDico[ts.Instrument.Trim()];
                    }
                }
            }
        }

        private void TranscodeToExternal(IList<TimeSerieDB> result, ILoadingContext context)
        {
            if (result != null && instrumentCodeTranscoder != null)
            {
                var instruments = result.Select(x => x.Instrument).ToArray();

                var codes = instrumentCodeTranscoder.TranscodeInternalToExternal(instruments, context);

                for (int i = 0; i < result.Count; i++)
                {
                    result[i].Instrument = codes[i];
                }
            }
        }

        private void VerifyIfSerieIsComplete(string[] tickers, DataFieldsEnum[] dataFields, DateTime? startDate, DateTime? endDate, ILoadingContext context, IList<TimeSerieDB> missingSeries, IList<TimeSerieDB> result)
        {
            if (result != null && startDate != null && endDate != null)
            {
                IList<TimeSerieDB> missingResult = new List<TimeSerieDB>();

                var startDateMissingSeries = result.Where(ts =>
                    IsNotUnDatedDataTs(ts)
                    && !ts.IsConsideredAsComplete
                    && tickers.Contains(ts.Instrument)
                    && dataFields.Contains(ts.Field)
                    && startDate < ts.StartDate
                    && startDate != DateTime.MinValue
                ).ToArray();
                var endDateMissingSeries = result.Where(ts =>
                    IsNotUnDatedDataTs(ts)
                    && !ts.IsConsideredAsComplete
                    && tickers.Contains(ts.Instrument)
                    && dataFields.Contains(ts.Field)
                    && endDate > ts.EndDate
                    && endDate != DateTime.MinValue)
                    .ToArray();

                foreach (var fieldGroup in startDateMissingSeries.GroupBy(x => x.Field))
                {
                    var requestedEndDate = TimeSerieDB.DateUtils.AddDays(fieldGroup.Max(x => x.StartDate).GetValueOrDefault(DateTime.MinValue), -1);
                    var timeSeriesToTreat = fieldGroup.Where(x => ShouldCalculate(x, startDate, requestedEndDate, context)).ToArray();

                    if (timeSeriesToTreat.Any())
                    {
                        var missingDateResults = _nextHandler.Load(
                            timeSeriesToTreat.Select(x => x.Instrument).ToArray(),
                            new[] {fieldGroup.Key}, startDate, requestedEndDate, context, true);
                        missingDateResults.Where(ts => ts.IsConsideredAsComplete)
                            .ForEach(
                                ts =>
                                    ts.AddGap(new TimeSerieDB.TimeSerieGap()
                                    {
                                        StartDate = ts.StartDate.GetValueOrDefault(),
                                        EndDate = ts.EndDate.GetValueOrDefault(),
                                        IsJustified = true
                                    }));
                        if (missingDateResults != null)
                        {
                            missingResult.AddRange(missingDateResults);
                        }
                    }
                }

                foreach (var fieldGroup in endDateMissingSeries.GroupBy(x => x.Field))
                {
                    var requestedStartDate = TimeSerieDB.DateUtils.AddDays(fieldGroup.Min(x => x.EndDate).GetValueOrDefault(DateTime.MaxValue), +1);

                    requestedStartDate = requestedStartDate > startDate.GetValueOrDefault()
                        ? requestedStartDate
                        : startDate.GetValueOrDefault();

                    var timeSeriesToTreat = fieldGroup.Where(x => ShouldCalculate(x, requestedStartDate, endDate, context)).ToArray();

                    if (timeSeriesToTreat.Any())
                    {
                        var missingDateResults = _nextHandler.Load(
                            timeSeriesToTreat.Select(x => x.Instrument).ToArray(),
                            new[] {fieldGroup.Key}, requestedStartDate, endDate, context, true);

                        if (missingDateResults != null)
                        {
                            missingDateResults.Where(ts => ts.IsConsideredAsComplete)
                            .ForEach(
                                ts =>
                                    ts.AddGap(new TimeSerieDB.TimeSerieGap()
                                    {
                                        StartDate = ts.StartDate.GetValueOrDefault(),
                                        EndDate = ts.EndDate.GetValueOrDefault(),
                                        IsJustified = true
                                    }));
                            missingResult.AddRange(missingDateResults);
                        }
                    }
                }

                // Missing values returned, save them
                if (missingResult.Count > 0)
                {
                    MergeNewResult(result, missingResult, context == null ? null : context.QuotationCalendar);
                }

                var gapMissingSeries = VerifyIfNoGaps(tickers, dataFields, startDate, endDate, context, result, missingResult);

                var seriesToSave = GetSeriesToSave(startDateMissingSeries.Union(endDateMissingSeries).Union(gapMissingSeries).ToArray(), missingResult);

                SetLimitDates(seriesToSave, startDate, endDate);
                SetLimitDates(missingResult, startDate, endDate);
                SaveLocal(seriesToSave.Union(missingSeries).ToList() ?? new List<TimeSerieDB>(), context);
                Save(seriesToSave, context);
            }
        }

        private static bool IsNotUnDatedDataTs(TimeSerieDB ts)
        {
            return !(ts.X.IsNotEmpty() && ts.X.FirstOrDefault() == default(DateTime));
        }

        private bool ShouldCalculate(TimeSerieDB ts, DateTime? startDate, DateTime? endDate, ILoadingContext context)
        {
            if (context == null || context.QuotationCalendar == null)
                return true;

            if (context.QuotationCalendar is OpenDaysCalendar &&
                !((OpenDaysCalendar)context.QuotationCalendar).OpenDays.Any())
            {
                return true;
            }

            var businessDays = context.QuotationCalendar.GetBusinessDays(startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.MaxValue));
            var justifiedGaps = ts.Gaps.Where(g => g.IsJustified).ToArray();

            return businessDays.Where(x => !justifiedGaps.Any(g => x >= g.StartDate && x <= g.EndDate)).Any();
        }

        private TimeSerieDB[] VerifyIfNoGaps(string[] tickers, DataFieldsEnum[] dataFields, DateTime? startDate, DateTime? endDate, ILoadingContext context, IList<TimeSerieDB> result, IList<TimeSerieDB> gapMissingResult)
        {
            //IList<TimeSerieDB> gapMissingResult = new List<TimeSerieDB>();

            if (context != null && context.QuotationCalendar != null && result.Count > 0)
            {
                //if (!this.trusted )
                //{
                FillGapsGivenCalendar(tickers, dataFields, startDate, endDate, context, result);
                //}
            }

            var gapMissingSeries = result.Where(ts => tickers.Contains(ts.Instrument) && dataFields.Contains(ts.Field) && ts.Gaps.Any(g => !g.IsJustified)).ToArray();

            //// flatten gaps per instrument/field/start/end
            var gaps = gapMissingSeries.Select(s => s.Gaps.Where(x => !x.IsJustified).Select(g => new { s.Instrument, s.Field, gap = g, g.StartDate, g.EndDate }))
                                       .SelectMany(s => s.ToArray()).ToArray();

            ///// group gaps.
            var grouppedCall = gaps.GroupBy(g => new { g.Field, g.StartDate, g.EndDate });

            foreach (var group in grouppedCall)
            {
                var missingDateResults = _nextHandler.Load(group.Select(g => g.Instrument).ToArray(), group.Key.Field.AsArray(), group.Key.StartDate, group.Key.EndDate, context, true);

                if (missingDateResults != null)
                {
                    gapMissingResult.AddRange(missingDateResults);
                }
            }

            // Missing values returned, save them
            if (gapMissingResult.Count > 0)
            {
                MergeNewResult(result, gapMissingResult);
            }
            return gapMissingSeries;
        }

        public static TimeSerieDB.TimeSerieGap[] GroupByDates(TimeSerieDB.TimeSerieGap[] gaps, IPricingCalendar calendar)
        {
            var newGaps = new List<TimeSerieDB.TimeSerieGap>();
            if (!gaps.Any())
            {
                return gaps;
            }

            var orderedGaps = gaps.OrderBy(x => x.StartDate).ToArray();

            TimeSerieDB.TimeSerieGap currentGap = null;

            for (int i = 0; i < orderedGaps.Length; i++)
            {
                var timeSerieGap = orderedGaps[i];
                if (currentGap == null)
                {
                    currentGap = timeSerieGap.Clone();
                }
                else
                {
                    var nbDays = GetOpenDaysBetweenDates(calendar, currentGap.EndDate, timeSerieGap.StartDate);

                    if (nbDays > 2)
                    {
                        newGaps.Add(currentGap);
                        currentGap = timeSerieGap.Clone();
                    }
                    else
                    {
                        currentGap.EndDate = timeSerieGap.EndDate;
                    }
                }
            }

            if (!newGaps.Contains(currentGap))
            {
                newGaps.Add(currentGap);
            }

            return newGaps.ToArray();
        }

        private static int GetOpenDaysBetweenDates(IPricingCalendar calendar, DateTime startDate, DateTime endDate)
        {
            if (calendar == null)
            {
                return (int)(endDate - startDate).TotalDays;
            }

            return calendar.GetBusinessDays(startDate, endDate).Count;
        }

        //// search for gaps in the current results given the user start date and end date and the business calendar (from thecontext)
        private static void FillGapsGivenCalendar(string[] tickers, DataFieldsEnum[] dataFields, DateTime? startDate, DateTime? endDate, ILoadingContext context, IList<TimeSerieDB> result)
        {
            foreach (var serieWithPoentialGaps in result.Where(ts => tickers.Contains(ts.Instrument) /*&& !ts.IsConsideredAsComplete */&& dataFields.Contains(ts.Field)))
            {
                //// for now, exclude timeless timeseries
                if (!IsNotUnDatedDataTs(serieWithPoentialGaps) || IsFieldWithGaps(serieWithPoentialGaps))
                    continue;

                if (serieWithPoentialGaps.StartDate.HasValue && serieWithPoentialGaps.EndDate.HasValue)
                {
                    DateTime gapsearchstart = serieWithPoentialGaps.StartDate.Value;
                    DateTime gapsearchend = serieWithPoentialGaps.EndDate.Value;
                    if (startDate.HasValue && gapsearchstart < startDate.Value)
                        gapsearchstart = startDate.Value;
                    if (endDate.HasValue && gapsearchend > endDate.Value)
                        gapsearchend = endDate.Value;

                    var businessDays = context.QuotationCalendar.GetBusinessDays(gapsearchstart, gapsearchend).OrderBy(d => d);

                    var found = serieWithPoentialGaps.X.ToList();
                    var filter = businessDays.Except(found).ToList();
                    var missing = filter.Where(d => !IsInAJustifiedGap(d, serieWithPoentialGaps.Gaps.ToArray())).ToList();

                    List<TimeSerieDB.TimeSerieGap> newGaps = new List<TimeSerieDB.TimeSerieGap>();
                    if (missing.Count > 0)
                    {
                        if (found.Count == 0)
                        {
                            newGaps.Add(new TimeSerieDB.TimeSerieGap()
                            {
                                StartDate = missing.Min(),
                                EndDate = missing.Max(),
                                IsJustified = serieWithPoentialGaps.IsConsideredAsComplete
                            });
                        }
                        else
                        {
                            var gapGroups = missing.GroupBy(m => found.InferiorBound(DateTime.Compare, m));
                            newGaps = gapGroups.Select(g => new TimeSerieDB.TimeSerieGap()
                            {
                                StartDate = g.Min(),
                                EndDate = g.Max(),
                                IsJustified = serieWithPoentialGaps.IsConsideredAsComplete
                            }).ToList();
                        }
                    }

                    var disjointNewgap = new List<TimeSerieDB.TimeSerieGap>();
                    foreach (var gap in newGaps)
                    {
                        var overlapping = serieWithPoentialGaps.Gaps.FirstOrDefault(old =>
                            old.StartDate <= gap.StartDate && old.EndDate >= gap.StartDate
                        || old.StartDate >= gap.StartDate && old.EndDate >= gap.EndDate);

                        if (overlapping == null)
                        {
                            serieWithPoentialGaps.AddGap(gap);
                        }
                        else if (!(overlapping.StartDate <= gap.StartDate && overlapping.EndDate >= gap.EndDate))
                        {
                            if (overlapping.StartDate > gap.StartDate)
                            {
                                overlapping.StartDate = gap.StartDate;
                            }
                            if (overlapping.EndDate < gap.EndDate)
                            {
                                overlapping.EndDate = gap.EndDate;
                            }
                        }
                    }
                }
            }
        }

        private static bool IsFieldWithGaps(TimeSerieDB serieWithPoentialGaps)
        {
            return serieWithPoentialGaps.Field == DataFieldsEnum.Dividend || serieWithPoentialGaps.Field == DataFieldsEnum.OSTCollection;
        }

        private static bool IsInAJustifiedGap(DateTime d, TimeSerieDB.TimeSerieGap[] list)
        {
            if (list.Where(g => g.IsJustified).Any(g => g.StartDate <= d && d <= g.EndDate))
                return true;

            return false;
        }

        private void MergeNewResult(IList<TimeSerieDB> result, IList<TimeSerieDB> seriesToMerge, IPricingCalendar calendar = null)
        {
            if (seriesToMerge != null)
            {
                foreach (var serieToMerge in seriesToMerge)
                {
                    var existingTs =
                        result.FirstOrDefault(
                            x => x.Instrument == serieToMerge.Instrument && x.FieldName == serieToMerge.FieldName);

                    if (existingTs != null)
                    {
                        existingTs.Merge(serieToMerge, calendar, true);
                    }
                    else
                    {
                        result.Add(serieToMerge);
                    }
                }
            }
        }

        private static List<TimeSerieDB> GetSeriesToSave(TimeSerieDB[] series, IList<TimeSerieDB> missingResult)
        {
            var seriesToSave = new List<TimeSerieDB>();

            foreach (var serie in series)
            {
                var missingSerie =
                    missingResult.FirstOrDefault(x => x.Field == serie.Field && x.Instrument == serie.Instrument);

                if (missingSerie != null)
                {
                    seriesToSave.Add(missingSerie);
                }
                else
                {
                    seriesToSave.Add(new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], serie.Instrument, serie.Field));
                }
            }

            return seriesToSave;
        }

        /// <summary>
        /// Load data from a schedule
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="schedule"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, IList<DateTime> schedule)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Save TimeSeries
        /// </summary> 
        /// <param name="timeSeries"></param>
        /// <param name="loadingContext"></param>
        public void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            SaveLocal(timeSeries, loadingContext);

            SaveExternal(timeSeries, loadingContext);
        }

        /// <summary>
        /// Save TimeSeries
        /// </summary> 
        /// <param name="timeSeries"></param>
        /// <param name="loadingContext"></param>
        public void SaveExternal(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            if (_nextHandler != null)
            {
                _nextHandler.Save(timeSeries, loadingContext);
            }
        }

        protected virtual void SaveLocal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            CheckCancellationState(context);

            if (!_providerRouter.IsReadOnly && (context == null || context.DisabledSavingSources == null || !context.DisabledSavingSources.Contains(Name)))
            {
                var timeSeriesToSave = timeSeries.Where(ts => ShouldHandlerSave(context, ts) && (IsProviderMono() || _providerRouter.ManagedFields.Contains(ts.Field)))
                    .Select(ts =>
                    {
                        return ts.GetFilterHorizonDates(filterWithHorizonDatesForSave, HorizonDate);
                        //var timeSerie = new TimeSerieDB(ts.GetElements().Where(x => !filterWithHorizonDatesForSave || x.Key <= HorizonDate).ToArray(),
                        //    ts.Instrument, ts.Field)
                        //{ IsConsideredAsComplete = ts.IsConsideredAsComplete, StartDate = ts.StartDate, EndDate = ts.EndDate, SourceSegments = ts.SourceSegments, Source = ts.Source, FieldName = ts.FieldName };

                        //timeSerie.AddGaps(ts.Gaps);

                        //return timeSerie;

                    })
                    .ToArray();

                TranscodeToInternal(timeSeriesToSave, context);

                timeSeriesToSave.ForEach(o => { if (context != null) { o.Context = context; o.Calendar = context.QuotationCalendar; } });

                _providerRouter.Save(timeSeriesToSave, context);

                TranscodeToExternal(timeSeriesToSave, context);
            }
        }

        private bool ShouldHandlerSave(ILoadingContext context, TimeSerieDB ts)
        {
            return (shouldSavePredicate == null || shouldSavePredicate(context, ts));
        }

        private bool IsProviderMono()
        {
            return _providerRouter is ProviderMono;
        }

        private void TranscodeToInternal(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            if (timeSeries != null && instrumentCodeTranscoder != null)
            {
                var instruments = timeSeries.Select(x => x.Instrument).ToArray();

                var codes = instrumentCodeTranscoder.TranscodeExternalToInternal(instruments, context);

                for (int i = 0; i < timeSeries.Count; i++)
                {
                    //LoggingService.DebugFormatted(GetType(), "Transcode {0}->{1}", codes[i], timeSeries[i].Instrument);

                    timeSeries[i].Instrument = codes[i];
                }
            }
        }
    }
}