using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    public class ValueScoreCalcul : Calcul
    {
        public override string Indicator
        {
            get { return "ValueScore"; }
        }

        protected override DataFieldsEnum[] DataComponents
        {
            get
            {
                return new[]
            {
                DataFieldsEnum.EarningYield,
                DataFieldsEnum.BookToMarketRatio, 
                DataFieldsEnum.FreeCashFlowYield
            };
            }
        }

        protected override List<KeyValuePair<DateTime, IMarketData>> Calculate(IBasketIndex basket, string indicatorName, string ticker, DateTime? startDate, DateTime? endDate)
        {
            var res = new List<KeyValuePair<DateTime, IMarketData>>();

            foreach (var date in GetDatesWhenDataAvailable(basket, ticker))
            {
                var indicatorComponents = new List<double>
                {
                    GetValueIfExists(basket, ticker, date, DataFieldsEnum.EarningYield).GetValueOrDefault(),
                    GetValueIfExists(basket, ticker, date, DataFieldsEnum.BookToMarketRatio).GetValueOrDefault(),
                    GetValueIfExists(basket, ticker, date, DataFieldsEnum.FreeCashFlowYield).GetValueOrDefault()
                };

                res.Add(new KeyValuePair<DateTime, IMarketData>(date, new MarketDataDouble(indicatorComponents.Sum() / indicatorComponents.Count(x => x != 0.0d))));
            }

            return res;
        }
    }
}