﻿using System;
using System.Collections.Generic;
using PricingBase.DataProvider;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    public interface ICalcul
    {
        ITimeSeriesProvider TimeSeriesProvider { get; set; }
        string IndicatorRegex { get; }
        IList<TimeSerieDB> ExecuteCalculationWithData(IBasketIndex basket, string indicatorName, IEnumerable<string> tickers, DateTime? startDate, DateTime? endDate);
    }
}