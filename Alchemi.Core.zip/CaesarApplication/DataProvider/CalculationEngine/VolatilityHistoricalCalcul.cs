﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    public class VolatilityHistoricalCalcul : HorizonCalcul
    {
        protected override DataFieldsEnum[] DataComponents {
            get
            {
                return new []
                {
                    DataFieldsEnum.Close
                };
            }}

        protected override string IndicatorPrefix
        {
            get { return "VolatilityHistorical"; }
        }

        protected override KeyValuePair<DateTime, IMarketData> CalculateForPeriod(Dictionary<string, TimeSerieDB> dataSeries, int i, int horizon)
        {
            var closeTs = dataSeries[DataFieldsEnum.Close.ToString()];
            
            var values = new List<double>();

            for (int j = 0; j < horizon; j++)
            {
                var index = i - horizon + j;

                values.Add(closeTs.Performance(TimeSerieDB.PerformanceType.Ln, closeTs[index].Key, closeTs[index - 1].Key));
            }

            var vol = Math.Pow(values.Average(x => Math.Pow(x - values.Average(), 2)), 0.5);

            return new KeyValuePair<DateTime, IMarketData>(closeTs[i].Key, new MarketDataDouble(vol));
        }

        protected override int GetDataSerieHorizon(string indicatorName)
        {
            return GetHorizon(indicatorName) + 1;
        }
    }
}