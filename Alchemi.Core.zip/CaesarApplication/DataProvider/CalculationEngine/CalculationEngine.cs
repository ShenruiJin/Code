﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using PricingBase.DataProvider;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    [Serializable]
    public class CalculationEngine
    {
        private readonly ITimeSeriesProvider timeSeriesProvider;
        private Dictionary<string, ICalcul> calculs;

        public CalculationEngine(ITimeSeriesProvider timeSeriesProvider)
        {
            this.timeSeriesProvider = timeSeriesProvider;
        }

        public Dictionary<string, ICalcul> Calculs
        {
            get
            {
                if (calculs == null)
                {
                    LoadCalculs();
                }

                return calculs;
            }
        }

        private void LoadCalculs()
        {
            var res = new List<ICalcul>();

            foreach (var calculType in GetType().Assembly.GetTypes().Where(t => t.GetInterfaces().Any(x => x == typeof(ICalcul)) && !t.IsAbstract))
            {
                var calcul = (ICalcul)Activator.CreateInstance(calculType);
                calcul.TimeSeriesProvider = timeSeriesProvider;

                res.Add(calcul);
            }

            calculs = res.ToDictionary(x => x.IndicatorRegex);
        }

        public IList<TimeSerieDB> Load(IBasketIndex basket, IEnumerable<string> tickers, string indicatorName, DateTime? startDate = null, DateTime? endDate = null)
        {
            var calcul = GetCalculFromName(indicatorName);

            return calcul.ExecuteCalculationWithData(basket, indicatorName, tickers, startDate, endDate);
        }

        public bool IsSupportedIndicator(string indicatorName)
        {
            return GetCalculFromName(indicatorName) != null;
        }

        private ICalcul GetCalculFromName(string indicatorName)
        {
            return Calculs.Keys.Where(x => Regex.IsMatch(indicatorName, x)).Select(x => Calculs[x]).FirstOrDefault();
        }
    }
}
