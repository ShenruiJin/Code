﻿using System;
using System.Collections.Generic;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    public class MomentumCalcul : HorizonCalcul
    {
        protected override string IndicatorPrefix
        {
            get { return "Momentum"; }
        }

        protected override KeyValuePair<DateTime, IMarketData> CalculateForPeriod(Dictionary<string, TimeSerieDB> dataSeries, int i, int horizon)
        {
            var dataSerie = dataSeries[DataFieldsEnum.Close.ToString()];

            var previousValue = GetDoubleValue(dataSerie[i - horizon]);
            var actualVal = dataSerie[i];
            var actualValue = GetDoubleValue(actualVal);

            var calcRes = (actualValue/previousValue) - 1.0d;

            return new KeyValuePair<DateTime, IMarketData>(actualVal.Key, new MarketDataDouble(calcRes));
        }

        protected override DataFieldsEnum[] DataComponents
        {
            get { return new []
            {
                DataFieldsEnum.Close
            };}
        }
    }
}