﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using PricingBase.Index;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    [Serializable]
    public abstract class Calcul : ICalcul
    {
        #region Properties

        public ITimeSeriesProvider TimeSeriesProvider { get; set; }

        public virtual string Indicator
        {
            get { return String.Empty; }
        }

        public virtual string IndicatorRegex
        {
            get { return "^" + Indicator + "$"; }
        }

        protected virtual DataFieldsEnum[] DataComponents
        {
            get
            {
                return new DataFieldsEnum[0];
            }
        }

        protected virtual string[] DataComponentsAsString
        {
            get { return DataComponents.Select(x => x.ToString()).ToArray(); }
        }

        #endregion

        #region Loading Data

        protected virtual void LoadDataComponents(IBasketIndex basket, string indicatorName, IEnumerable<string> tickers, DateTime? startDate = null, DateTime? endDate = null, int dayLag = 0)
        {
            foreach (var dataComponent in GetDataComponents(indicatorName))
            {
                TimeSeriesProvider.Load(basket, tickers, dataComponent.AsArray(), startDate.HasValue ? (DateTime?)startDate.GetValueOrDefault().AddDays(-dayLag) : null, endDate);
            }
        }

        protected virtual string[] GetDataComponents(string indicatorName)
        {
            return DataComponentsAsString;
        }

        protected virtual int GetDayLag(string indicatorName)
        {
            return 0;
        }

        #endregion


        public IList<TimeSerieDB> ExecuteCalculationWithData(IBasketIndex basket, string indicatorName,
            IEnumerable<string> tickers, DateTime? startDate, DateTime? endDate)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            LoadDataComponents(basket, indicatorName, tickersAsArray, startDate, endDate, GetDayLag(indicatorName));
            return Calculate(basket, indicatorName, tickersAsArray, startDate, endDate);
        }

        public IList<TimeSerieDB> ExecuteCalculation(IBasketIndex basket, string indicatorName, IEnumerable<string> tickers, DateTime? startDate, DateTime? endDate)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            return Calculate(basket, indicatorName, tickersAsArray, startDate, endDate);
        }

        protected double? GetValueIfExists(IBasketIndex basket, string ticker, DateTime date,
            DataFieldsEnum dataFieldsEnum)
        {
            var timeSerie = basket[dataFieldsEnum, ticker];
            if (timeSerie.X.Contains(date))
            {
                return (MarketDataDouble)timeSerie[date];
            }

            return null;
        }

        protected List<DateTime> GetDatesWhenDataAvailable(IBasketIndex basket, string ticker)
        {
            var dates = new List<DateTime>();

            foreach (var dataComponent in DataComponents)
            {
                dates.AddRange(basket[dataComponent, ticker].X);
            }

            return dates.Distinct().ToList();
        }

        protected static double GetDoubleValue(KeyValuePair<DateTime, IMarketData> value)
        {
            return (MarketDataDouble)value.Value;
        }

        public virtual IList<TimeSerieDB> Calculate(IBasketIndex basket, string indicatorName, IEnumerable<string> tickers, DateTime? startDate, DateTime? endDate)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var res = new Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>();

            foreach (var ticker in tickersAsArray)
            {
                res.Add(ticker, Calculate(basket, indicatorName, ticker, startDate, endDate));
            }

            return res.Select(r => new TimeSerieDB(r.Value, r.Key, indicatorName)).ToList();
        }

        protected abstract List<KeyValuePair<DateTime, IMarketData>> Calculate(IBasketIndex basket, string indicatorName, string ticker, DateTime? startDate, DateTime? endDate);
    }
}