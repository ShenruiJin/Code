﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.CalculationEngine
{
    public class VolatilityHistoricalAnnualizedCalcul : HorizonCalcul
    {
        protected override DataFieldsEnum[] DataComponents {
            get
            {
                return new []
                {
                    DataFieldsEnum.Close,
                    DataFieldsEnum.Calendar
                };
            }}

        protected override string IndicatorPrefix
        {
            get { return "VolatilityHistoricalAnnualized"; }
        }

        protected override KeyValuePair<DateTime, IMarketData> CalculateForPeriod(Dictionary<string, TimeSerieDB> dataSeries, int i, int horizon)
        {
            var closeTs = dataSeries[DataFieldsEnum.Close.ToString()];
            
            var values = new List<double>();

            var startDate = closeTs[i - horizon - 1].Key;
            var endDate = closeTs[i - 2].Key;

            for (int j = 0; j < horizon; j++)
            {
                var index = i - horizon + j;

                values.Add(closeTs.Performance(TimeSerieDB.PerformanceType.Ln, closeTs[index].Key, closeTs[index - 1].Key));
            }

            double nbBusinessDays = ((Calendar)dataSeries[DataFieldsEnum.Calendar.ToString()].Y.Last()).GetBusinessDays(startDate, endDate).Count;
            var vol = Math.Sqrt((252.0d / nbBusinessDays) * values.Average(x => Math.Pow(x - values.Average(), 2)));

            return new KeyValuePair<DateTime, IMarketData>(closeTs[i].Key, new MarketDataDouble(vol));
        }

        protected override int GetDataSerieHorizon(string indicatorName)
        {
            return GetHorizon(indicatorName) + 1;
        }
    }
}