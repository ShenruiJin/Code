﻿using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using log4net;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Route query to its implementation
    /// </summary>
    [Serializable]
    public class ProviderRouter : IProviderRouter, IProviderRouterTechnical, IProviderRouterExtensible
    {
        /// <summary>
        /// Providers for global operations
        /// </summary>
        private readonly IDictionary<DataFieldsEnum, IProviderExecutable> globalProviderExecutables = new Dictionary<DataFieldsEnum, IProviderExecutable>();

        /// <summary>
        /// Providers for local operations
        /// </summary>
        private readonly IDictionary<DataFieldsEnum, IProviderExecutable> localProviderExecutables = new Dictionary<DataFieldsEnum, IProviderExecutable>();

        /// <summary>
        /// Enable or disable save
        /// </summary>
        private bool _isReadOnly;

        /// <summary>
        /// Constructor - setting executables dictionaries
        /// </summary>
        /// <param name="providers"></param>
        public ProviderRouter(IProviderExecutable[] providers, bool readOnly = false)
        {
            _isReadOnly = readOnly;

            IList<IProviderExecutable> globalProviders = providers.Where(o => o.SourceType == DataTypeEnum.Global).ToList();

            for (int i = 0; i < globalProviders.Count(); i++)
            {
                foreach (DataFieldsEnum field in globalProviders[i].SupportedFields)
                {
                    globalProviderExecutables.Add(field, globalProviders[i]);
                }
            }

            IList<IProviderExecutable> localProviders = providers.Where(o => o.SourceType == DataTypeEnum.Local).ToList();

            for (int i = 0; i < localProviders.Count(); i++)
            {
                foreach (DataFieldsEnum field in localProviders[i].SupportedFields)
                {
                    localProviderExecutables.Add(field, localProviders[i]);
                }
            }
        }

        /// <summary>
        /// Enable or disable save
        /// </summary>
        public bool IsReadOnly
        {
            get { return _isReadOnly; }
        }

        public DataFieldsEnum[] ManagedFields
        {
            get
            {
                return globalProviderExecutables.Keys.Union(localProviderExecutables.Keys).ToArray();
            }
        }

        /// <summary>
        /// Providers for global operations
        /// </summary>
        IDictionary<DataFieldsEnum, IProviderExecutable> IProviderRouterTechnical.GlobalProviderExecutables
        {
            get { return globalProviderExecutables; }
        }

        /// <summary>
        /// Providers for local operations
        /// </summary>
        IDictionary<DataFieldsEnum, IProviderExecutable> IProviderRouterTechnical.LocalProviderExecutables
        {
            get { return localProviderExecutables; }
        }

        /// <summary>
        /// Execute query
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="fields"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="context"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate, ILoadingContext context)
        {

            IList<TimeSerieDB> results = new List<TimeSerieDB>();

            if (globalProviderExecutables.Values.Count > 0)
            {
                foreach (DataFieldsEnum field in fields)
                {
                    if (globalProviderExecutables.ContainsKey(field))
                    {
                        var implementation = globalProviderExecutables[field];

                        try
                        {
                            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

                            ProviderRouterUtils.LogStartLoading(startDate, endDate, implementation, tickersAsArray, field);

                            var series = implementation.Load(tickersAsArray, field, startDate, endDate, context);

                            foreach (var serie in series)
                            {
                                if(serie != null)
                                    serie.Sort();
                            }

                            results.AddRange(series);
                            ProviderRouterUtils.LogEndLoading(series, implementation);
                        }
                        catch (Exception ex)
                        {
                            LoggingService.Error(GetType(), string.Format("Fail to load data from {0}", implementation.GetType().Name), ex);

                            if (ex.InnerException != null)
                            {
                                LoggingService.Error(GetType(), ex.InnerException);
                            }

                            throw;
                        }
                    }
                }
            }

            return results;
        }


        /// <summary>
        /// Save query result
        /// </summary>
        /// <param name="timeSeries"></param>
        /// <param name="context"></param>
        public virtual void Save(IList<TimeSerieDB> timeSeries, ILoadingContext context)
        {
            if (_isReadOnly)
            {
                LoggingService.Info(GetType(), "ReadOnly mode activated, save is disabled");
                return;
            }

            var dico = timeSeries.GroupBy(o => o.Field, o => o).ToDictionary(o => o.Key, o => o.ToList());

            foreach (var key in dico.Keys)
            {
                IProviderExecutable impl = null;

                if (globalProviderExecutables.TryGetValue(key, out impl))
                {
                    try
                    {
                        impl.Save(dico[key], context);
                    }
                    catch (Exception ex)
                    {
                        LoggingService.Error(GetType(), "Cannot save", ex);
                        throw;
                    }
                }
                else
                {
                    // Log : warning no save method attached to this field
                }
            }
        }

        /// <summary>
        /// Add executable
        /// </summary>
        /// <param name="executable"></param>
        public void AddExecutable(IProviderExecutable executable)
        {
            executable.SupportedFields.ForEach(f =>
            {
                if (globalProviderExecutables.ContainsKey(f))
                {
                    LoggingService.ErrorFormatted(GetType(), "Field {0} try to be declared twice by {1}", f, executable.GetType().FullName);
                }
                else
                {
                    globalProviderExecutables.Add(f, executable);
                }
            });
        }
    }

    public static class ProviderRouterUtils
    {
        private static ILog logger = LogManager.GetLogger(typeof(ProviderRouter));
        
        public static void LogEndLoading(IList<TimeSerieDB> series, IProviderExecutable implementation)
        {
            if (series != null)
            {
                foreach (var serie in series)
                {
                    if (serie == null) continue;
                    logger.Debug(
                        string.Format("{0}Data loaded for {1} on {2} for [{3}-{4}]",
                            implementation.GetType().Name,
                            serie.Instrument, serie.Field,
                            serie.StartDate.GetValueOrDefault().ToShortDateString(),
                            serie.EndDate.GetValueOrDefault(DateTime.MaxValue).ToShortDateString()));
                }
            }
            else
            {
                logger.Debug(string.Format("{0}Null Data loaded", implementation.GetType().Name));
            }
        }

        public static void LogStartLoading(DateTime? startDate, DateTime? endDate, IProviderExecutable implementation,
            string[] tickersAsArray, DataFieldsEnum field)
        {
            logger.Debug(
                string.Format("{0}Start load data for {1} on {2} for [{3}-{4}]", implementation.GetType().Name,
                    string.Join(",", tickersAsArray), field, startDate.GetValueOrDefault().ToShortDateString(),
                    endDate.GetValueOrDefault(DateTime.MaxValue).ToShortDateString()));
        }
    }
}
