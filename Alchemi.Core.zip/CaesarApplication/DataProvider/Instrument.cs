using System;
using GlobalDerivativesApplications.Data.Booking;
using GlobalDerivativesApplications.Data.MarketData;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Instrument
    /// </summary>
    [Serializable]
    public class Instrument
    {
        #region Instrument
        /// <summary>
        /// Default constructor
        /// </summary>
        public Instrument()
        {
        }

        /// <summary>
        /// Main Constructor
        /// </summary>
        public Instrument(DateTime accountingRefDate, double beta, double cashDivRefSpot,
            int code, string comment, string currency, short fid, string gl, string instrumentType,
            bool isAvailable, string issueIsin, string issuerCountryCurrency, string issuerName,
            string issuerReference, string market, string marketOHLC, string marketGoverningCurrency,
            string marketShortName, string mnemo, string model,
            string name, string originalCCY, double outStandingShares, string reference,
            string reuter, string sectorCode, string sedol, double tradingUnit,
            string typeDR, bool vol57, double issuerspread, double repo, double volatility,
            double spreadinpercent, double spreadPriceTheo, bool volCashDiv)
        {
            AccountingRefDate = accountingRefDate;
            Beta = beta;
            CashDivRefSpot = cashDivRefSpot;
            Code = code;
            Comment = comment;
            Currency = currency;
            Fid = fid;
            GL = gl;
            InstrumentType = instrumentType;
            IsAvailable = isAvailable;
            IssuerIsin = issueIsin;
            IssuerCountryCurrency = issuerCountryCurrency;
            IssuerName = issuerName;
            IssuerReference = issuerReference;
            Market = market;
            MarketOHLC = marketOHLC;
            MarketGoverningCurrency = marketGoverningCurrency;
            MarketShortName = marketShortName;
            Mnemo = mnemo;
            Model = model;
            Name = name;
            OriginalCCY = originalCCY;
            OutStandingShares = outStandingShares;
            Reference = reference;
            Reuter = reuter;
            SectorCode = sectorCode;
            Sedol = sedol;
            TradingUnit = tradingUnit;
            TypeDR = typeDR;
            Vol57 = vol57;
            IssuerSpread = issuerspread;
            Repo = repo;
            Volatility = volatility;
            SpreadInPercent = spreadinpercent;
            SpreadPriceTheo = spreadPriceTheo;
            VolCashDiv = volCashDiv;
        }

        /// <summary>
        /// Copy ctor
        /// </summary>
        public Instrument(IInstrument other)
        {
            Allotment = other.Allotment;
            AccountingRefDate = other.AccountingRefDate;
            Beta = other.Beta;
            CashDivRefSpot = other.CashDivRefSpot;
            Code = other.Code;
            Comment = other.Comment;
            Currency = other.Currency;
            Fid = other.Fid;
            GL = other.GL;
            InflationCurrency = other.InflationCurrency;
            InstrumentType = other.InstrumentType;
            IsAvailable = other.IsAvailable;
            IssuerIsin = other.IssuerIsin;
            IssuerCountryCurrency = other.IssuerCountryCurrency;
            IssuerName = other.IssuerName;
            IssuerReference = other.IssuerReference;
            Market = other.Market;
            MarketOHLC = other.MarketOHLC;
            MarketGoverningCurrency = other.MarketGoverningCurrency;
            MarketShortName = other.MarketShortName;
            Mnemo = other.Mnemo;
            Model = other.Model;
            Name = other.Name;
            OriginalCCY = other.OriginalCCY;
            OutStandingShares = other.OutStandingShares;
            Reference = other.Reference;
            Reuter = other.Reuter;
            SectorCode = other.SectorCode;
            Sedol = other.Sedol;
            TradingUnit = other.TradingUnit;
            QuotationType = other.QuotationType;
            TypeDR = other.TypeDR;
            Vol57 = other.Vol57;
            IssuerSpread = other.IssuerSpread;
            Repo = other.Repo;
            Volatility = other.Volatility;
            SpreadInPercent = other.SpreadInPercent;
            SpreadPriceTheo = other.SpreadPriceTheo;
            VolCashDiv = other.VolCashDiv;
        }

        public static GlobalDerivativesApplications.Data.MarketData.Instrument CopyToGda(Instrument other)
        {
            var instr = new GlobalDerivativesApplications.Data.MarketData.Instrument();

            instr.Allotment = other.Allotment;
            instr.AccountingRefDate = other.AccountingRefDate;
            instr.Beta = other.Beta;
            instr.CashDivRefSpot = other.CashDivRefSpot;
            instr.Code = other.Code;
            instr.Comment = other.Comment;
            instr.Currency = other.Currency;
            instr.Fid = other.Fid;
            instr.GL = other.GL;
            instr.InflationCurrency = other.InflationCurrency;
            instr.InstrumentType = other.InstrumentType;
            instr.IsAvailable = other.IsAvailable;
            instr.IssuerIsin = other.IssuerIsin;
            instr.IssuerCountryCurrency = other.IssuerCountryCurrency;
            instr.IssuerName = other.IssuerName;
            instr.IssuerReference = other.IssuerReference;
            instr.Market = other.Market;
            instr.MarketOHLC = other.MarketOHLC;
            instr.MarketGoverningCurrency = other.MarketGoverningCurrency;
            instr.MarketShortName = other.MarketShortName;
            instr.Mnemo = other.Mnemo;
            instr.Model = other.Model;
            instr.Name = other.Name;
            instr.OriginalCCY = other.OriginalCCY;
            instr.OutStandingShares = other.OutStandingShares;
            instr.Reference = other.Reference;
            instr.Reuter = other.Reuter;
            instr.SectorCode = other.SectorCode;
            instr.Sedol = other.Sedol;
            instr.TradingUnit = other.TradingUnit;
            instr.QuotationType = other.QuotationType;
            instr.TypeDR = other.TypeDR;
            instr.Vol57 = other.Vol57;
            instr.IssuerSpread = other.IssuerSpread;
            instr.Repo = other.Repo;
            instr.Volatility = other.Volatility;
            instr.SpreadInPercent = other.SpreadInPercent;
            instr.SpreadPriceTheo = other.SpreadPriceTheo;
            instr.VolCashDiv = other.VolCashDiv;

            return instr;
        }
        #endregion

        #region IInstrument Members
        /// <summary>
        /// gets or sets the allotment name
        /// </summary>
        public string Allotment { get; set; }

        /// <summary>
        /// Sophis accounting reference date
        /// </summary>
        public DateTime AccountingRefDate { get; set; }

        /// <summary>
        /// instrument beta
        /// </summary>
        public double Beta { get; set; }

        /// <summary>
        /// reference spot for the cash dividends model
        /// </summary>
        public double CashDivRefSpot { get; set; }

        /// <summary>
        /// sophis internal code
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// comments
        /// </summary>
        public string Comment { get; set; }

        /// <summary>
        /// instrument currency
        /// </summary>
        public string Currency { get; set; }

        /// <summary>
        /// expiry for future like instruments
        /// </summary>
        public DateTime? Expiry { get; set; }

        /// <summary>
        /// ???
        /// </summary>
        public short Fid { get; set; }

        /// <summary>
        /// name of the curve used in the forward computation
        /// </summary>
        public string FamilyCurveName { get; set; }

        /// <summary>
        /// GL instrument code
        /// </summary>
        public string GL { get; set; }

        /// <summary>
        /// Inflation currency
        /// </summary>
        public string InflationCurrency { get; set; }

        /// <summary>
        /// Sophis instrument type
        /// </summary>
        public string InstrumentType { get; set; }

        /// <summary>
        /// return true if this instrument is marked as available in database
        /// otherwise return false
        /// </summary>
        public bool IsAvailable { get; set; }

        /// <summary>
        /// Issuer Isin code
        /// </summary>
        public string IssuerIsin { get; set; }

        /// <summary>
        /// Issuer currency
        /// </summary>
        public string IssuerCountryCurrency { get; set; }

        /// <summary>
        /// Issuer name
        /// </summary>
        public string IssuerName { get; set; }

        /// <summary>
        /// Issuer Sophis reference
        /// </summary>
        public string IssuerReference { get; set; }

        /// <summary>
        /// instrument market
        /// </summary>
        public string Market { get; set; }

        /// <summary>
        /// instrument market ohlc
        /// </summary>
        public string MarketOHLC { get; set; }

        /// <summary>
        /// market governing currency
        /// </summary>
        public string MarketGoverningCurrency { get; set; }

        /// <summary>
        /// market short name
        /// </summary>
        public string MarketShortName { get; set; }

        /// <summary>
        /// sophis mnemo field
        /// </summary>
        public string Mnemo { get; set; }

        /// <summary>
        /// sophis model
        /// </summary>
        public string Model { get; set; }

        /// <summary>
        /// instrument name
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// original currency
        /// </summary>
        public string OriginalCCY { get; set; }

        /// <summary>
        /// outstanding shares
        /// </summary>
        public double OutStandingShares { get; set; }

        /// <summary>
        /// sophis reference
        /// </summary>
        public string Reference { get; set; }

        /// <summary>
        /// Reuter code
        /// </summary>
        public string Reuter { get; set; }

        /// <summary>
        /// returns true if the RIC is actovated (RT mode)
        /// </summary>
        public bool RICable { get; set; }

        /// <summary>
        /// return the price type : In amount, In percent, In rate...
        /// </summary>
        public PriceUnitType QuotationType { get; set; }

        /// <summary>
        /// sector code
        /// </summary>
        public string SectorCode { get; set; }

        /// <summary>
        /// Sedol code
        /// </summary>
        public string Sedol { get; set; }

        /// <summary>
        /// trading unit
        /// </summary>
        public double TradingUnit { get; set; }

        /// <summary>
        /// DR type
        /// </summary>
        public string TypeDR { get; set; }

        /// <summary>
        /// return true if the vol 5/7 flag is activated
        /// otherwise return false
        /// </summary>
        public bool Vol57 { get; set; }

        /// <summary>
        /// return CB Stock Spread
        /// </summary>       
        public double IssuerSpread { get; set; }

        /// <summary>
        /// return CB Repo
        /// </summary>       
        public double Repo { get; set; }

        /// <summary>
        /// return CB Volatility
        /// </summary>       
        public double Volatility { get; set; }

        /// <summary>
        /// return CB Issuer Spread
        /// </summary>       
        public double SpreadInPercent { get; set; }

        /// <summary>
        /// return spread between market price and theoritical price.
        /// </summary>       
        public double SpreadPriceTheo { get; set; }

        /// <summary>
        /// return true if the vol CashDiv flag is activated
        /// otherwise return false
        /// </summary>
        public bool VolCashDiv { get; set; }

        #endregion


    }
}