﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    public class LiquidityCalcul : HorizonCalcul
    {
        protected override DataFieldsEnum[] DataComponents
        {
            get { return new[] { DataFieldsEnum.Volume, DataFieldsEnum.Close }; }
        }

        protected override string IndicatorPrefix
        {
            get { return "Liquidity"; }
        }

        protected override KeyValuePair<DateTime, IMarketData> CalculateForPeriod(Dictionary<string, TimeSerieDB> dataSeries, int currentIndex, int horizon)
        {
            var closeTs = dataSeries[DataFieldsEnum.Close.ToString()];
            var volumeTs = dataSeries[DataFieldsEnum.Volume.ToString()];
            var values = new List<double>();

            for (int h = 0; h < horizon; h++)
            {
                var index = currentIndex - horizon + h - 1;
                values.Add(GetDoubleValue(closeTs[index]) * GetDoubleValue(volumeTs[index]));
            }

            return new KeyValuePair<DateTime, IMarketData>(closeTs[currentIndex].Key, new MarketDataDouble(values.Average()));
        }
    }
}