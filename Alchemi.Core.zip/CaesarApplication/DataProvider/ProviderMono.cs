﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider
{
    /// <summary>
    /// Provider with only one executable
    /// </summary>
    [Serializable]
    public class ProviderMono : IProviderRouter
    {
        private IProviderExecutable Executable;

        public ProviderMono(IProviderExecutable executable)
        {
            Executable = executable;
        }

        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, IEnumerable<DataFieldsEnum> fields, DateTime? startDate, DateTime? endDate, ILoadingContext context)
        {
            IList<TimeSerieDB> result = new List<TimeSerieDB>();
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            foreach (DataFieldsEnum field in fields)
            {
                ProviderRouterUtils.LogStartLoading(startDate, endDate, Executable, tickersAsArray, field);

                var series = Executable.Load(tickersAsArray, field, startDate, endDate, context);
                result.AddRange(series);

                ProviderRouterUtils.LogEndLoading(series, Executable);
            }

            return result;
        }

        public DataFieldsEnum[] ManagedFields { get { return new List<DataFieldsEnum>().ToArray(); } }

        public void Save(IList<TimeSerieDB> data, ILoadingContext context)
        {
            Executable.Save(data);
        }

        public bool IsReadOnly { get { return false; } }
    }
}
