﻿using CaesarCommon.Configuration;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using Newtonsoft.Json.Linq;
using PricingBase.DataProvider;
using PricingBase.OST;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CaesarApplication.DataProvider.CAT
{
    public class CATCorporateActionExecutable : CATExecutable
    {
        private static double apiTimeout = 60;

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var settingsManager = new CaesarSettingsManager();
            var parisTZ = TimeZoneInfo.GetSystemTimeZones().First(tz => tz.Id == "Romance Standard Time");

            var securityIdByTickerDico =
                tickers.AsParallel().Select(x => new KeyValuePair<string, string>(GetSecurityId(settingsManager.CatWebServiceUrl, x), x)).Where(x => x.Key != null).ToDictionary(x => x.Key, x => x.Value);

            var token = GetToken(settingsManager.CatWebServiceLogin, settingsManager.CatWebServicePassword, settingsManager.CatWebServiceUrl, "token");

            var ostDico = new Dictionary<string, Dictionary<DateTime, Dictionary<string, List<IOST>>>>();

            foreach (var docLine in GetInfosetTokenByTicker(token.Value, settingsManager.CatWebServiceUrl, securityIdByTickerDico.Where(x => x.Value != null).Select(x => x.Key).ToArray()))
            {
                var ostId = docLine["caType"].Value<string>("id");

                if (ostId != "CashDividend" && docLine["status"].Value<string>("id") == "InProcess" && docLine.Value<DateTime?>("exDate").HasValue)
                {
                    var exDate = TimeZoneInfo.ConvertTime(docLine.Value<DateTime>("exDate"), parisTZ);

                    IOST ost = null;
                    string ostTypeName = null;

                    if (ostId == "BonusStkDvd")
                    {
                        ost = new StockDividendOST(MarketData.ApplicationFlag.Both, exDate, "None", GetRatio(docLine).GetValueOrDefault());
                        ostTypeName = "Stock Dividend";
                    }
                    else if (ostId == "StockSplit")
                    {
                        ost = new FactorOST(MarketData.ApplicationFlag.Both, exDate, GetRatio(docLine).GetValueOrDefault(), docLine["caType"].Value<string>("name"))
                        {
                            Source = CorporateActionSource.CAT
                        };

                        ostTypeName = "Stock Split";
                    }
                    else if (ostId == "ReverseStockSplit")
                    {

                        ost = new FactorOST(MarketData.ApplicationFlag.Both, exDate, GetRatio(docLine).GetValueOrDefault(), docLine["caType"].Value<string>("name"))
                        {
                            Source = CorporateActionSource.CAT
                        };

                        ostTypeName = "Stock Split";
                    }

                    if (ostTypeName != null && exDate >= startDate && exDate <= endDate)
                    {
                        var securityId = securityIdByTickerDico[docLine["security"]["ticker"].Value<string>()];

                        if (!ostDico.ContainsKey(securityId))
                        {
                            ostDico.Add(securityId, new Dictionary<DateTime, Dictionary<string, List<IOST>>>());
                        }

                        if (!ostDico[securityId].ContainsKey(exDate))
                        {
                            ostDico[securityId].Add(exDate, new Dictionary<string, List<IOST>>());
                        }

                        if (!ostDico[securityId][exDate].ContainsKey(ostTypeName))
                        {
                            ostDico[securityId][exDate].Add(ostTypeName, new List<IOST>());
                        }

                        ostDico[securityId][exDate][ostTypeName].Add(ost);
                    }
                }
            }

            return tickers.Select(x => new TimeSerieDB(ostDico.ContainsKey(x) ? ostDico[x].ToDictionary(kv => kv.Key, kv => (IMarketData)GetOSTCollection(kv.Value)).ToArray() : new Dictionary<DateTime, IMarketData>().ToArray(), x, DataFieldsEnum.OSTCollection)).ToArray();
        }

        private double? GetRatio(JToken docLine)
        {
            return docLine["mandatoryBlock"]["security"].Value<double?>("parityIn").HasValue
                                    ?
                                    docLine["mandatoryBlock"]["security"].Value<double>("parityIn") / docLine["mandatoryBlock"]["security"].Value<double>("parityOut")
                                    :
                                    docLine["mandatoryBlock"]["security"].Value<double?>("ratio");
        }

        private OSTCollection GetOSTCollection(Dictionary<string, List<IOST>> osts)
        {
            var ostCollection = new OSTCollection();

            foreach (var ostKv in osts)
            {
                ostCollection.OstsByTypes.Add(ostKv.Key, ostKv.Value);
            }

            return ostCollection;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return DataFieldsEnum.OSTCollection.AsArray(); }
        }
    }
}
