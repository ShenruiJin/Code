﻿using CaesarApplication.DataProvider.Helpers;
using Newtonsoft.Json.Linq;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Web;

namespace CaesarApplication.DataProvider.CAT
{
    public abstract class CATExecutable : ProviderExecutable
    {
        private static double apiTimeout = 60;

        protected static Token GetToken(string login, string password, string baseUrl, string tokenEndPoint)
        {
            Token token = null;

            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(apiTimeout);
                HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, string.Format("{0}/{1}", baseUrl, tokenEndPoint))
                {

                    Content = new StringContent(string.Format("scope={0}&grant_type={1}", WebUtility.UrlEncode("")
                        , "client_credentials"), Encoding.UTF8, "application/x-www-form-urlencoded")
                };

                byte[] credentialsBytes = Encoding.ASCII.GetBytes(string.Format("{0}:{1}", login, password));
                string credentials64 = Convert.ToBase64String(credentialsBytes);

                message.Headers.Authorization = new AuthenticationHeaderValue("Basic", credentials64);

                HttpResponseMessage response = client.SendAsync(message).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    var json = JObject.Parse(result);
                    token = new Token { Value = json.Value<string>("access_token"), ExpirationTime = DateTime.Now.AddSeconds(json.Value<int>("expires_in")) };
                }
                else
                {
                    throw new HttpException((int)response.StatusCode, "Error when getting token on " + message.RequestUri.AbsoluteUri);
                }
            }
            return token;
        }

        protected static IJEnumerable<JToken> GetInfosetToken(string token, string baseUrl, string[] securityIds)
        {
            if (securityIds != null && securityIds.All(x => x == null))
            {
                return new JArray();
            }

            string result;
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(apiTimeout);
                HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, string.Format("{0}/{1}", baseUrl, "api/ca-repositories/search"))
                {
                    Content = new StringContent(@"{" +
                                                (securityIds == null ? string.Empty : @"""securitiesIds"":[" + securityIds.Distinct().Take(500).Stringify(",") + @"],") +
                                                @"""options"": {
    ""PageIndex"": 0,
    ""PageSize"": 1000000
  }
}", Encoding.UTF8, "application/json")
                };

                message.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = client.SendAsync(message).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    var json = JObject.Parse(result);

                    return json["data"].Children();
                }
                else
                {
                    throw new HttpException((int)response.StatusCode, "Error when getting token on " + message.RequestUri.AbsoluteUri);
                }
            }
        }

        protected static IJEnumerable<JToken> GetInfosetTokenByTicker(string token, string baseUrl, string[] securityIds)
        {
            if (securityIds != null && securityIds.All(x => x == null))
            {
                return new JArray();
            }

            string result;
            using (var client = new HttpClient())
            {
                var contentString = @"{" +
                                                (securityIds == null ? string.Empty : @"""securities"":[" + securityIds.Distinct().Select(x => @"{""value"":""" + x + @""",""seekMode"":""" + "Ticker" + @"""}").Stringify(",") + @"],") +
                                                @"""options"": {
    ""PageIndex"": 0,
    ""PageSize"": 1000000
  }
}";

                client.Timeout = TimeSpan.FromSeconds(apiTimeout);
                HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Post, string.Format("{0}/{1}", baseUrl, "api/ca-repositories/search"))
                {
                    Content = new StringContent(contentString, Encoding.UTF8, "application/json")
                };

                message.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token);

                HttpResponseMessage response = client.SendAsync(message).Result;

                if (response.IsSuccessStatusCode)
                {
                    result = response.Content.ReadAsStringAsync().Result;
                    var json = JObject.Parse(result);

                    return json["data"].Children();
                }
                else
                {
                    throw new HttpException((int)response.StatusCode, "Error when getting token on " + message.RequestUri.AbsoluteUri);
                }
            }
        }

        protected static string GetSecurityId(string baseUrl, string ticker)
        {
            var isIndex = SophisHelper.GetBloombergTicker(ticker).EndsWith(" " + SophisHelper.BloombergSuffixIndex);

            if (isIndex)
                return null;

            return ticker;

            try
            {
                using (var client = new HttpClient())
                {
                    client.Timeout = TimeSpan.FromSeconds(apiTimeout);
                    HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Get, string.Format("{0}/{1}", baseUrl, "api/referential/securities/search?query=" + WebUtility.UrlEncode(ticker) + "&pageSize=1"));


                    HttpResponseMessage response = client.SendAsync(message).Result;

                    if (response.IsSuccessStatusCode)
                    {
                        var result = response.Content.ReadAsStringAsync().Result;
                        var array = JArray.Parse(result);
                        return array.Count == 1 ? array[0].Value<string>("id") : null;
                    }
                    else
                    {
                        throw new HttpException((int)response.StatusCode, "Error when getting token on " + message.RequestUri.AbsoluteUri);
                    }
                }
            }
            catch
            {
                return null;
            }
        }

        private static string GetCorporateActionDetails(string baseUrl, int docId, Token token)
        {
            using (var client = new HttpClient())
            {
                client.Timeout = TimeSpan.FromSeconds(apiTimeout);
                HttpRequestMessage message = new HttpRequestMessage(HttpMethod.Get, string.Format("{0}/{1}", baseUrl, "api/ca-repositories/" + docId));

                message.Headers.Authorization = new AuthenticationHeaderValue("Bearer", token.Value);

                HttpResponseMessage response = client.SendAsync(message).Result;

                if (response.IsSuccessStatusCode)
                {
                    var result = response.Content.ReadAsStringAsync().Result;
                    return result;
                }
                else
                {
                    throw new HttpException((int)response.StatusCode, "Error when getting token on " + message.RequestUri.AbsoluteUri);
                }
            }
        }
    }

    public class Token
    {
        public DateTime ExpirationTime { get; set; }

        public string Value { get; set; }
    }
}
