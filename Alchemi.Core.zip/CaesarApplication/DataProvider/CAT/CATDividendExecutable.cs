﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarCommon.Configuration;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using Newtonsoft.Json.Linq;
using PricingBase.DataProvider;
using PricingBase.MarketData;

namespace CaesarApplication.DataProvider.CAT
{
    public class CATDividendExecutable : CATExecutable
    {
        private static double apiTimeout = 60;

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var settingsManager = new CaesarSettingsManager();
            var parisTZ = TimeZoneInfo.GetSystemTimeZones().First(tz => tz.Id == "Romance Standard Time");

            var securityIdByTickerDico =
                tickers.AsParallel().ToDictionary(x => x, x => GetSecurityId(settingsManager.CatWebServiceUrl, x));

            var token = GetToken(settingsManager.CatWebServiceLogin, settingsManager.CatWebServicePassword, settingsManager.CatWebServiceUrl, "token");

            var dividendDico = new Dictionary<string, List<Dividend>>();

            foreach (var docLine in GetInfosetTokenByTicker(token.Value, settingsManager.CatWebServiceUrl, securityIdByTickerDico.Where(x => x.Value != null).Select(x => x.Key).ToArray()))
            {
                //var docDetails = GetCorporateActionDetails(settingsManager.CatWebServiceUrl, docLine["id"].Value<int>(), token);
                //
                //Console.WriteLine(JObject.Parse(docDetails));

                //var ost = JObject.Parse(docDetails).ToString();

                if (new[] { "CashDividend", "ScripDividend", "ReturnOfCapital" }.Contains(docLine["caType"].Value<string>("id")) && docLine["status"].Value<string>("id") == "InProcess")
                {
                    var exDate = TimeZoneInfo.ConvertTime(docLine.Value<DateTime>("exDate"), parisTZ);
                    var dividend = new Dividend
                    {
                        AccountReferenceYear = exDate.Year,
                        Date = exDate,
                        Currency = docLine["mandatoryBlock"]["dividend"].Value<string>("currencyId"),
                        ExDividendDate = exDate,
                        PaymentDate = docLine.Value<DateTime>("paymentDate"),
                        Type = GetDividendType(docLine["caType"].Value<string>("id")),
                        Status = DividendStatus.Announced,
                        Unit = DividendUnit.MonetaryUnit,
                        Value = docLine["mandatoryBlock"]["dividend"].Value<double>("grossAmount"),
                       
                    };

                    var securityId = docLine["security"]["ticker"].Value<string>();

                    if (!dividendDico.ContainsKey(securityId))
                    {
                        dividendDico.Add(securityId, new List<Dividend>());
                    }

                    dividendDico[securityId].Add(dividend);
                }
            }

            return dividendDico.Select(x => new TimeSerieDB(x.Value
                .Where(d => d.Date >= startDate && d.Date <= endDate)
                .GroupBy(i => i.Date).ToDictionary(kv => kv.Key, kv => kv.Count() == 1 ? kv.First() : (IMarketData)new DividendList(kv.Cast<Dividend>().ToArray())).ToArray(), securityIdByTickerDico.FirstOrDefault(kv => kv.Value == x.Key).Key, DataFieldsEnum.Dividend))
                .Where(x => x.Instrument != null).ToArray();
        }

        private DividendType GetDividendType(string caType)
        {
            if(caType == "CashDividend")
            {
                return DividendType.Dividend;
            }
            else if (caType == "ScripDividend")
            {
                return DividendType.OptionalDividend;
            }
            else if (caType == "ReturnOfCapital")
            {
                return DividendType.ReturnOfCapital;
            }

            return DividendType.Dividend;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return DataFieldsEnum.Dividend.AsArray(); }
        }
    }
}
