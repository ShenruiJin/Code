﻿using System.Collections.Generic;
using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Prism
{
    public class StringPrismSnapshotOnDemandExecutable : PrismSnapshotOnDemandExecutable
    {
        protected override IList<TimeSerieDB> GetSeries(DataFieldsEnum field, string fileContent)
        {
            return BloombergParser.ParseFile(field, fileContent, s => new MarketDataString(s), true);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.PriceFlag,
                    DataFieldsEnum.Currency,
                    DataFieldsEnum.CountryOfIncorporation,
                    DataFieldsEnum.CountryIssue
                };
            }
        }
    }
}