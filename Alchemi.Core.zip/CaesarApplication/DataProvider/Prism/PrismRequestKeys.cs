namespace CaesarApplication.DataProvider.Prism
{
    public class PrismRequestKeys
    {
        public PrismRequestKeys()
        { }

        public PrismRequestKeys(string service, string product, bool withBBGSuffix)
        {
            Service = service;
            Product = product;
            WithBBGSuffix = withBBGSuffix;
        }

        public string Service { get; set; }

        public string Product { get; set; }

        public bool WithBBGSuffix { get; set; }

        public override bool Equals(object obj)
        {
            var objAsKeys = obj as PrismRequestKeys;

            return objAsKeys != null && objAsKeys.WithBBGSuffix == WithBBGSuffix && objAsKeys.Product == Product && objAsKeys.Service == Service;
        }

        protected bool Equals(PrismRequestKeys other)
        {
            return string.Equals(Service, other.Service) && string.Equals(Product, other.Product) && WithBBGSuffix == other.WithBBGSuffix;
        }

        public override int GetHashCode()
        {
            unchecked
            {
                var hashCode = (Service != null ? Service.GetHashCode() : 0);
                hashCode = (hashCode*397) ^ (Product != null ? Product.GetHashCode() : 0);
                hashCode = (hashCode*397) ^ WithBBGSuffix.GetHashCode();
                return hashCode;
            }
        }
    }
}