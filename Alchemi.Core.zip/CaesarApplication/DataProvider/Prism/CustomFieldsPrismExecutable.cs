﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml.Linq;
using CaesarApplication.Service.Configuration;
using CaesarCommon.Configuration;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism.Polling;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Reflection;
using GlobalDerivativesApplications.Serialization;
using MarketData;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Providers;
using System.Collections.Concurrent;
using FuncFramework.Helpers;
using PricingBase.MarketData;

namespace CaesarApplication.DataProvider.Prism
{
    public abstract class CustomFieldsPrismExecutable : ProviderExecutable, IPrismExecutable
    {
        const string FileRegexString = @".*(" + PrismConstants.DateRegexPattern + @")" + PrismConstants.SuffixCustom + "\\.xml$";
        static readonly Regex FileRegex = new Regex(FileRegexString, RegexOptions.Compiled);

        private string repositoryDirectory;

        public CustomFieldsPrismExecutable(string repositoryDirectory = null)
        {
            this.repositoryDirectory = repositoryDirectory ?? new CaesarSettingsManager().PrismDirectoryPath;
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.MaxValue);

            var eligibleFiles = PrismHelper.GetEligibleFiles(FileRegex, repositoryDirectory, startDateOrDefault, endDateOrDefault);

            var dataItems = LoadMarketDatas(tickers.ToArray(), eligibleFiles, field, startDateOrDefault, endDateOrDefault, loadingContext);

            var timeSerieDbs = dataItems.SelectMany(d =>
                d.Value.Select(x => new TimeSerieDB(x.Value.ToArray(), x.Key, d.Key)))
                .ToArray();

            return ArrangeResult(timeSerieDbs);
        }

        protected virtual TimeSerieDB[] ArrangeResult(TimeSerieDB[] timeSerieDbs)
        {
            return timeSerieDbs;
        }

        public Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> LoadMarketDatas(string[] tickers, string[] eligibleFiles, DataFieldsEnum field, DateTime startDate, DateTime endDate, ILoadingContext loadingContext)
        {
            var result = new Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>>();

            foreach (var eligibleFile in eligibleFiles)
            {
                using (var sr = File.OpenText(eligibleFile))
                {
                    LoadFile(tickers, field, startDate, endDate, sr, result);
                }
            }

            return result;
        }

        public void LoadFile(string[] tickers, DataFieldsEnum field, DateTime startDate, DateTime endDate, TextReader streamReader, Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> result)
        {
            string line;

            while ((line = streamReader.ReadLine()) != null)
            {
                if (Regex.IsMatch(line, "\\<element .*code\\=\\\".*\\\"\\/>"))
                {
                    var element = XElement.Parse(line.Trim());
                    var ticker = element.Attribute("code").Value;

                    var code = tickers.Contains(ticker) ? ticker : tickers.FirstOrDefault(t => t.Equals(ticker + " Index"));
                    if (tickers.Contains(code))
                    {
                        var date = GetDate(element);

                        if (IsDateToGet(startDate, endDate, date))
                        {
                            var attribute = element.Attributes().FirstOrDefault(a => string.Compare(a.Name.LocalName, GetAttributeName(field), StringComparison.InvariantCultureIgnoreCase) == 0);

                            if (attribute != null)
                            {
                                var value = attribute.Value;

                                var mktData = ConvertToMarketData(value);

                                AddDataToResult(result, code, field, date, mktData);
                            }
                        }
                    }
                }
            }
        }

        protected virtual bool IsDateToGet(DateTime startDate, DateTime endDate, DateTime date)
        {
            return date >= startDate && date <= endDate;
        }

        private void AddDataToResult(
            Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> result,
            string ticker, DataFieldsEnum field, DateTime date, IMarketData mktData)
        {
            lock (((ICollection)result).SyncRoot)
            {
                if (!result.ContainsKey(field))
                {
                    result.Add(field, new Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>());
                }

                if (!result[field].ContainsKey(ticker))
                {
                    result[field].Add(ticker, new List<KeyValuePair<DateTime, IMarketData>>());
                }

                if (result[field][ticker].All(x => x.Key != date))
                {
                    result[field][ticker].Add(new KeyValuePair<DateTime, IMarketData>(date, mktData));
                }
            }
        }

        protected abstract DateTime GetDate(XElement element);
        protected abstract IMarketData ConvertToMarketData(string value);

        public string GetAttributeName(DataFieldsEnum field)
        {
            return BloombergProvider.ConvertDataFieldsEnum(field);
        }

        public string FileSuffix
        {
            get { return PrismConstants.SuffixCustom; }
        }
    }

    public interface IPrismExecutable : IProviderExecutable
    {
        void LoadFile(string[] tickers, DataFieldsEnum field, DateTime startDate, DateTime endDate, TextReader streamReader, Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> result);
        string FileSuffix { get; }
        string GetAttributeName(DataFieldsEnum field);
        Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> LoadMarketDatas(string[] tickers, string[] eligibleFiles, DataFieldsEnum field, DateTime startDate, DateTime endDate, ILoadingContext loadingContext);
    }

    public class DoubleCustomFieldsPrismExecutable : CustomFieldsPrismExecutable
    {
        public DoubleCustomFieldsPrismExecutable(string repositoryDirectory = null) : base(repositoryDirectory)
        {

        }

        protected override DateTime GetDate(XElement element)
        {
            return DateTime.ParseExact(element.Attribute("date").Value, "yyyy-MM-dd HH:mm:ss.f",
                CultureInfo.InvariantCulture);
        }

        protected override IMarketData ConvertToMarketData(string value)
        {
            double returnValue;
            if (double.TryParse(value, NumberStyles.Number, CultureInfo.InvariantCulture, out returnValue))
                return new MarketDataDouble(returnValue);

            return new MarketDataDouble(double.NaN);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
               DataFieldsEnum.Ask,
                DataFieldsEnum.Bid,
                DataFieldsEnum.RealizedVolatility10d,
                DataFieldsEnum.RealizedVolatility30d,
                DataFieldsEnum.RealizedVolatility60d,
                DataFieldsEnum.RealizedVolatility90d,
                DataFieldsEnum.RealizedVolatility180d,
                //DataFieldsEnum.MarketCap,
                DataFieldsEnum.EarningYield,
                DataFieldsEnum.BookToMarketRatio,
                DataFieldsEnum.FreeCashFlowYield,
                DataFieldsEnum.AvgDailyValueTraded6m,
                DataFieldsEnum.SettlementPrice,
                DataFieldsEnum.Notional,
                DataFieldsEnum.PriceFlag,
                DataFieldsEnum.DirtyMidPrice
                };
            }
        }
    }

    /// <summary>
    /// parses a Bloomberg sequence saved as a string
    /// the format is ;2;rownum;colnum;ty0;val0;ty1;val1; ...; tyN; valN
    /// example ;2;2;3;5;20170421;2;6250.000;2;.0005;20170421;2;6250.000;2;.000
    /// represents the folloinw 2 row, 3 column matrix
    /// 20170421 6250.000 .000
    /// 20180421 6250.000 .000
    /// </summary>
    public class TableDataCustomFieldsPrismExecutable : CustomFieldsPrismExecutable
    {
        public TableDataCustomFieldsPrismExecutable(string repositoryDirectory = null) : base(repositoryDirectory)
        {

        }

        protected override DateTime GetDate(XElement element)
        {
            return DateTime.ParseExact(element.Attribute("date").Value, "yyyy-MM-dd HH:mm:ss.f",
                CultureInfo.InvariantCulture);
        }

        /// <summary>
        /// bloomberg datatype enum / from bloomberg blp
        /// </summary>
        public enum Datatype
        {
            BOOL,
            BYTEARRAY = 256,
            CHAR = 1,
            DATE,
            DATETIME,
            ENUMERATION = 257,
            FLOAT32 = 5,
            FLOAT64,
            INT32,
            INT64,
            STRING,
            TIME,
            SEQUENCE = 258,
            CHOICE
        }

        static Lazy<Dictionary<string, Func<string, object>>> Parsers = new Lazy<Dictionary<string, Func<string, object>>>(initializeParsers, LazyThreadSafetyMode.ExecutionAndPublication);

        private static Dictionary<string, Func<string, object>> initializeParsers()
        {
            return new Dictionary<string, Func<string, object>>()
            {
                {"5" /*date*/, new Func<string, object>(input => DateTime.ParseExact(input, "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None))},
                {"2" /*floating*/,new Func<string, object>(input => double.Parse(input, CultureInfo.InvariantCulture))},

            };
        }

        protected override IMarketData ConvertToMarketData(string value)
        {

            double returnValue;

            var split = value.Split(';');
            int rowcount = 0;
            int colcount = 0;

            //// a valid sequence starts with ;2;rowcount;colcount;
            if (!value.StartsWith(";2;")
                || split.Length < 4
                || !int.TryParse(split[2], out rowcount)
                || !int.TryParse(split[3], out colcount))
                return new GlobalDerivativesApplications.Data.MarketData.MarketDataError("Value is not of the bloomberg sequence string format: ;2;rownum;colnum;[ty;values]* <" + value + ">");

            var values = split.Skip(4).ToArray();

            values = values.Take(values.Length - 1).ToArray();

            //   List<List<object>> data = new List<List<object>>(
            //           Enumerable.Range(0, rowcount).Select(_ => new List<object>(colcount))
            //       );
            //   
            //   for (int i = 0; i < (values.Length  / 2 - 1); ++i)
            //   {
            //       int row = i / colcount;
            //
            //       string tyIntValue = values[i * 2];
            //       string valuetext = values[i * 2 + 1];
            //
            //       var boxedValue = GetBoxedValue(valuetext, tyIntValue);
            //       data[row].Add(boxedValue);
            //   }



            var typeRows = values.Where((r, i) => i % 2 == 0).Group(colcount).Where(x => x.Length == colcount).ToArray();
            var dataRows = values.Where((r, i) => i % 2 != 0).Group(colcount).Where(x => x.Length == colcount).ToArray();

            var data = dataRows.Select((row, rowIndex) => row.Select((r, i) => GetBoxedValue(r, typeRows[rowIndex][i])).ToList())
                .ToList();

            return new TableData(data);
        }

        private static object GetBoxedValue(string valuetext, string tyIntValue)
        {
            Func<string, object> parser = null;
            object boxedValue = valuetext;
            if (Parsers.Value.TryGetValue(tyIntValue, out parser))
            {
                boxedValue = parser(valuetext);
            }
            return boxedValue;
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
               DataFieldsEnum.CashflowDescription
                };
            }
        }
    }


    public class CustomFieldsPrismExecutableByPolling : ProviderExecutable
    {
        private readonly IPrismExecutable prismExecutable;

        public CustomFieldsPrismExecutableByPolling(IPrismExecutable prismExecutable)
        {
            this.prismExecutable = prismExecutable;
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            var startDateOrDefault = startDate.GetValueOrDefault(new DateTime(1970, 1, 1));
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.Today);

            var tickersAsArray = tickers.ToArray();

            var res = LoadInternal(tickersAsArray, field, startDateOrDefault, endDateOrDefault, loadingContext);

            if (TimeSerieDB.UnDatedFields.Contains(field) && (res.Count != tickersAsArray.Length || res.Any(x => !x.X.Any())))
            {
                res = LoadInternal(tickersAsArray, field, new DateTime(1970, 1, 1), DateTime.Today, loadingContext);
                startDateOrDefault = new DateTime(1970, 1, 1);
            }

            return tickers.Select(t => res.FirstOrDefault(r => r.Instrument == t) ?? new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], t, field) { StartDate = startDate, EndDate = endDate }).ToArray();
        }

        private IList<TimeSerieDB> LoadInternal(IEnumerable<string> tickers, DataFieldsEnum field, DateTime startDate, DateTime endDate,
            ILoadingContext loadingContext)
        {
            var id = Guid.NewGuid();

            string requestName = string.Format("{0}{1:yyyyMMdd}{2:yyyyMMdd}{3}", id, startDate, endDate,
                prismExecutable.FileSuffix);

            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing: true))
            {
                var tickersAsArray = tickers as string[] ?? tickers.ToArray();

                var request = prismPollingManager.SendRequestSync(requestName,
                    GetRequest(tickersAsArray, field, startDate, endDate),
                    (int)TimeSpan.FromSeconds(120).TotalMilliseconds,
                    cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None);

                if (request == null || request.ResultContent == null)
                {
                    return new List<TimeSerieDB>();
                }

                var dataItems = LoadMarketDatas(tickersAsArray, request.ResultContent, field, startDate,
                    endDate, loadingContext);

                return dataItems.SelectMany(d =>
                    d.Value.Select(x => new TimeSerieDB(x.Value.ToArray(), x.Key, d.Key)))
                    .ToArray();
            }
        }

        private Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> LoadMarketDatas(string[] tickers, string resultContent, DataFieldsEnum field, DateTime startDate, DateTime endDate, ILoadingContext loadingContext)
        {
            var result = new Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>>();

            using (var sr = new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(resultContent))))
            {
                prismExecutable.LoadFile(tickers, field, startDate, endDate, sr, result);
            }

            return result;
        }

        public string GetRequest(string[] tickers, DataFieldsEnum field, DateTime startDate, DateTime endDate)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                Service = PrismConstants.ServiceParametrable,
                Product = PrismConstants.ProductEquity,
                RequestTime = DateTime.Today,
                Fields = prismExecutable.GetAttributeName(field).AsArray(),
                Codes = tickers
            };

            return prismRequest.ToSerializedString();
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return prismExecutable.SupportedFields; }
        }
    }

    public class StringCustomFieldsPrismExecutable : CustomFieldsPrismExecutable
    {
        public StringCustomFieldsPrismExecutable(string repositoryDirectory = null) : base(repositoryDirectory)
        {

        }

        protected override DateTime GetDate(XElement element)
        {
            return DateTime.ParseExact(element.Attribute("date").Value, "yyyy-MM-dd HH:mm:ss.f",
                CultureInfo.InvariantCulture);
        }

        protected override IMarketData ConvertToMarketData(string value)
        {
            return new MarketDataString(value);
        }
    }

    public class StringUndatedCustomFieldsPrismExecutable : StringCustomFieldsPrismExecutable
    {
        public StringUndatedCustomFieldsPrismExecutable(string repositoryDirectory = null) : base(repositoryDirectory)
        {

        }

        protected override bool IsDateToGet(DateTime startDate, DateTime endDate, DateTime date)
        {
            return true;
        }

        protected override IMarketData ConvertToMarketData(string value)
        {
            return new MarketDataString(value);
        }

        protected override TimeSerieDB[] ArrangeResult(TimeSerieDB[] timeSerieDbs)
        {
            timeSerieDbs.ForEach(ts =>
            {
                ts.StartDate = DateTime.MinValue;
                ts.EndDate = DateTime.MinValue;
            });

            return timeSerieDbs;
        }


        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.ICB_INDUSTRY_NAME,
                    DataFieldsEnum.Currency,
                    DataFieldsEnum.CountryIssue
                };
            }
        }
    }

    public class DateCustomFieldsPrismExecutable : StringCustomFieldsPrismExecutable
    {
        public DateCustomFieldsPrismExecutable(string repositoryDirectory = null) : base(repositoryDirectory)
        {

        }

        protected override bool IsDateToGet(DateTime startDate, DateTime endDate, DateTime date)
        {
            return true;
        }

        protected override IMarketData ConvertToMarketData(string value)
        {
            int timevalue;
            if (int.TryParse(value, out timevalue))
            {
                int year = timevalue / 10000;
                int month = (timevalue % 10000) / 100;
                int day = timevalue % 100;
                return new MarketDataString(new DateTime(year, month, day).ToString("O"));
            }

            return new MarketDataString(value);
        }

        protected override TimeSerieDB[] ArrangeResult(TimeSerieDB[] timeSerieDbs)
        {
            timeSerieDbs.ForEach(ts =>
            {
                ts.StartDate = DateTime.MinValue;
                ts.EndDate = DateTime.MinValue;
            });

            return timeSerieDbs;
        }


        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.LastTradeableDate,
                    DataFieldsEnum.FirstFutureDeliveryDate,
                    DataFieldsEnum.SettlementDate
                };
            }
        }
    }
}