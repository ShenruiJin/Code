using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.Prism.Polling;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using MarketData;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using System.Linq;

namespace CaesarApplication.DataProvider.Prism
{
    public class OptionDescAndPricesPrismExecutableByPolling : OptionDescAndPricesPrismExecutable
    {
        protected override List<OptionDescAndPrices> LoadOptions(string[] tickers, DateTime startDate, DateTime endDate, ILoadingContext loadingContext, Dictionary<string, List<DateTime>> datesByUnderlying)
        {
            var id = Guid.NewGuid();

            //Request all maturities on 10 years
            var descEndDate = endDate.AddYears(2);

            string requestNameDesc = string.Format("{0}{1:yyyyMMdd}{2:yyyyMMdd}Desc", id, startDate, descEndDate);
            string requestNameOHLC = string.Format("{0}{1:yyyyMMdd}{2:yyyyMMdd}OHLC", id, startDate, endDate);

            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing: true))
            {
                var descRequest = prismPollingManager.SendRequestSync(requestNameDesc,
                    GetDescRequestContent(tickers, startDate, descEndDate), (int)TimeSpan.FromMinutes(10).TotalMilliseconds, cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None);
                var ohlcRequest = prismPollingManager.SendRequestSync(requestNameOHLC,
                    GetOHLCRequestContent(tickers, startDate, endDate), (int)TimeSpan.FromMinutes(10).TotalMilliseconds, cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None);

                if (descRequest == null || ohlcRequest == null)
                {
                    return new List<OptionDescAndPrices>();
                }

                var descriptions = LoadDescFile(descRequest.ResultContent.AsArray(), tickers);
                var calendars = GetCalendars(tickers);

                return LoadOHLCFile(ohlcRequest.ResultContent.AsArray(), startDate, endDate, descriptions, calendars, datesByUnderlying);
            }
        }

        private List<OptionDescAndPrices> LoadOHLCFile(IEnumerable<string> fileStrings, DateTime startDate, DateTime endDate, Dictionary<string, List<OptionDescAndPrices>> descriptions, Dictionary<string, ICalendar> calendars, Dictionary<string, List<DateTime>> datesByUnderlying)
        {
            Dictionary<string, List<DateTime>> ricCodeTradeDateDico = descriptions.ToDictionary(x => x.Key, d => new List<DateTime>());
     
            var optionDescs = new List<OptionDescAndPrices>();

            foreach (var fileString in fileStrings)
            {
                using (var streamReader = new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(fileString))))
                {
                    base.LoadOHLCFile(startDate, endDate, descriptions, streamReader, optionDescs, calendars, datesByUnderlying, ricCodeTradeDateDico);
                }
            }

            return optionDescs;
        }

        private Dictionary<string, List<OptionDescAndPrices>> LoadDescFile(IEnumerable<string> fileStrings, string[] tickers)
        {
            Dictionary<string, List<OptionDescAndPrices>> optionDescs = new Dictionary<string, List<OptionDescAndPrices>>();

            foreach (var fileString in fileStrings)
            {
                using (var streamReader = new StreamReader(new MemoryStream(System.Text.Encoding.UTF8.GetBytes(fileString))))
                {
                    LoadDescFile(tickers, streamReader, optionDescs);
                }
            }
            return optionDescs;
        }

        private string GetDescRequestContent(string[] tickers, DateTime startDate, DateTime endDate)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                Service = PrismConstants.ServiceIndexOption,
                Product = PrismConstants.ProductIndex,
                RequestTime = DateTime.Today,
                IncludeNullVolume = true,
                Codes = tickers
            };

            return prismRequest.ToSerializedString();
        }

        private string GetOHLCRequestContent(string[] tickers, DateTime startDate, DateTime endDate)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                Service = PrismConstants.ServiceUnadjustedPrice,
                Product = PrismConstants.ProductOptions,
                RequestTime = DateTime.Today,
                IncludeNullVolume = true,
                Codes = tickers
            };

            return prismRequest.ToSerializedString();
        }

#if DEBUG

        public override IList<GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum> SupportedFields
        {
            get {
                if (DateTime.Today.DayOfWeek == DayOfWeek.Saturday)
                {
                    return new DataFieldsEnum[] { };
                }
                return new List<GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum>() { GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum.OptionDescAndPrices };
            }
        }
#endif
    }
}