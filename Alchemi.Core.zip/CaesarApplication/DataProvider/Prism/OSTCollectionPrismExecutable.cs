﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using CaesarApplication.DataProvider.Bloomberg;
using CaesarCommon.Configuration;
using MarketData;
using PricingBase.DataProvider;
using System.Configuration;

namespace CaesarApplication.DataProvider.Prism
{
    public class OSTCollectionPrismExecutable : OSTCollectionBloombergExecutable
    {
        private Regex dataFileRegex;
        private string prismOstCollectionFileRegex = ConfigurationManager.AppSettings["PrismOstCollectionFileRegex"] ?? "^response.*_EQY_DVD_HIST_GROSS$";
        private readonly CaesarSettingsManager caesarSettingsManager = new CaesarSettingsManager();

        string[] eligibleFiles;

        public OSTCollectionPrismExecutable(IDataHandler dataHandler) : base(dataHandler)
        {
            dataFileRegex = new Regex(prismOstCollectionFileRegex);
        }

        private string[] GetEligibleFiles()
        {
            if (eligibleFiles == null)
            {
                var directory = Path.Combine(caesarSettingsManager.PrismDirectoryPath ?? AppDomain.CurrentDomain.BaseDirectory, "Poller");
                var files = Directory.GetFiles(directory);

                eligibleFiles = files
                    .Where(x =>
                    dataFileRegex.IsMatch(Path.GetFileName(x))
                    ).ToArray();
            }

            return eligibleFiles;
        }

        protected override Dictionary<string, CorporateAction[]> GetCorporateActionsByTicker(string[] tickersAsArray)
        {
            var items =
                GetEligibleFiles()
                    .SelectMany(f => BloombergParser.ParseCorporateActions(
                        GetStringFromFile(f).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries).Distinct()
                    .Stringify(Environment.NewLine))
                    )
                    .Where(kv => tickersAsArray.Contains(kv.Key))
                    .GroupBy(x => x.Key)
                    .Select(x => x.First(g => g.Value.Length == x.Max(v => v.Value.Length)))
                    .ToDictionary(x => x.Key, x => x.Value);

            //Take only continuous data test date element
            return items.ToDictionary(x => x.Key,
                x => x.Value.Select((it, i) => new { Index = i, Item = it }).ToArray().TakeWhile(i => x.Value.ToArray().IndexOf(i.Item) == 0 || x.Value.ElementAt(x.Value.ToArray().IndexOf(i.Item) - 1).ExDate >= i.Item.ExDate).Select(i => i.Item).ToArray());
        }

        private static string GetStringFromFile(string f)
        {
            using (var fs = new StreamReader(File.Open(f, FileMode.Open, FileAccess.Read, FileShare.Read)))
            {
                return fs.ReadToEnd();
            }
        }

        protected override Dictionary<string, AdjustmentFactor[]> GetFactorsByTicker(string[] tickersAsArray)
        {
            var items = GetEligibleFiles()
                    .SelectMany(f => BloombergParser.ParseAdjustmentFactors(GetStringFromFile(f).Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries).Distinct()
                    .Stringify(Environment.NewLine)))
                     .Where(kv => tickersAsArray.Contains(kv.Key))
                    .GroupBy(x => x.Key)
                    .Select(v => v.First(g => g.Value.Length == v.Max(y => y.Value.Length)))
                    .ToDictionary(x => x.Key, x => x.Value);

            //Take only continuous data test date element
            return items.ToDictionary(x => x.Key,
                x => x.Value.Select((it, i) => new { Index = i, Item = it }).ToArray().TakeWhile(i => x.Value.ToArray().IndexOf(i.Item) == 0 || (x.Value.ElementAt(x.Value.ToArray().IndexOf(i.Item) - 1).Date >= i.Item.Date)).Select(i => i.Item).ToArray());
        }

        protected override void AddOSTCollection(bool hasData, List<TimeSerieDB> output, List<CorporateAction> corporateActionsList, AdjustmentFactor[] factors, string ticker)
        {
            if (hasData)
            {
                base.AddOSTCollection(hasData, output, corporateActionsList, factors, ticker);
            }
        }
    }
}
