using System.Collections.Generic;
using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Prism
{
    public class DoublePrismSnapshotOnDemandExecutable : PrismSnapshotOnDemandExecutable
    {
        protected override IList<TimeSerieDB> GetSeries(DataFieldsEnum field, string fileContent)
        {
            return BloombergParser.ParsePricesFile(field, fileContent);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.Notional
                };
            }
        }
    }
}