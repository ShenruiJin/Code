﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Threading;
using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Providers;
using GlobalDerivativesApplications.Prism.Polling;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Prism
{
    public class PrismOnDemandExecutable : ProviderExecutable
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing:true))
            {
                var tickersAsArray = tickers.ToArray();

                string fileContent = Request(field, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), loadingContext, GetRequestName(startDate.GetValueOrDefault(), endDate.GetValueOrDefault()), prismPollingManager, tickersAsArray);

                var series = GetSeries(field, fileContent);


                return series;
            }
        }
        protected virtual IList<TimeSerieDB> GetSeries(DataFieldsEnum field, string fileContent)
        {
            return BloombergParser.ParsePricesFile(field, fileContent, IsUndated);
        }

        private string Request(DataFieldsEnum field, DateTime startDate, DateTime endDate, ILoadingContext loadingContext, string requestName, PrismPollingManager prismPollingManager, string[] tickersFiltered)
        {
            var request = prismPollingManager.SendRequestSync(requestName,
                GetRequest(field, tickersFiltered, startDate, endDate), (int)TimeSpan.FromSeconds(240).TotalMilliseconds, cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None, responseFileExtension: ".csv");


            if (request == null)
            {
                return null;
            }

            return request.ResultContent;
        }

        protected virtual string GetRequest(DataFieldsEnum field, string[] tickers, DateTime startDate, DateTime endDate)
        {
            var bbgUserNumber = ConfigurationManager.AppSettings["BbgUserNumber"];

            PrismRequest prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                BbgUserNumber = !string.IsNullOrEmpty(bbgUserNumber) ? int.Parse(bbgUserNumber) : 0,
                //Feature to fix PRISM bug that store all indexes as AdjustedPrices
                Service = PrismConstants.ServicePerSec,
                Product = PrismConstants.ProductIndex,
                RequestTime = DateTime.Now,
                Codes = tickers,
                Fields = BloombergProvider.ConvertDataFieldsEnum(field).AsArray()
            };

            return prismRequest.ToSerializedString();
        }

        private static string GetRequestName(DateTime startDate, DateTime endDate)
        {
            var id = Guid.NewGuid();

            return string.Format("{0}{1:yyyyMMdd}{2:yyyyMMdd}OnDemand", id, startDate, endDate);
        }

        public virtual bool IsUndated
        {
            get
            {
                return false;
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
            {
                DataFieldsEnum.Last,
                DataFieldsEnum.SettlementPrice,
                DataFieldsEnum.DirtyMidPrice,
                DataFieldsEnum.ContractValue
            };
            }
        }
    }
}
