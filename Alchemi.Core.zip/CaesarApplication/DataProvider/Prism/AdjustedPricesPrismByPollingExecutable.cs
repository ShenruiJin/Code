﻿using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using System.Collections.Generic;
namespace CaesarApplication.DataProvider.Prism
{
    public class AdjustedPricesPrismByPollingExecutable : NonAdjustedPricesPrismByPollingExecutable
    {
        protected override string PrismService
        {
            get
            {
                return PrismConstants.ServiceAdjustedPrice;
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new []{ DataFieldsEnum.LastAdjustedDividend };
            }
        }
    }
}
