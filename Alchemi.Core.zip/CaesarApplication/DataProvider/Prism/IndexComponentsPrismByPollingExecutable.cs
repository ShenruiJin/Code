﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using GlobalDerivativesApplications.Prism.Polling;
using System.Threading;

namespace CaesarApplication.DataProvider.Prism
{
    /// <summary>
    /// Prism provider for index composition
    /// </summary>
    [Serializable]
    public class IndexComponentsPrismByPollingExecutable : IndexComponentsPrismExecutable
    {
        /// <summary>
        /// Main Ctor.
        /// </summary>
        public IndexComponentsPrismByPollingExecutable(IDataHandler providerDataHandler) : base(providerDataHandler)
        {
        }

        /// <summary>
        /// Main load
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null,
                                                            DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            var id = Guid.NewGuid();

            string requestIndexComposition = string.Format("{0}{1:yyyyMMdd}{2:yyyyMMdd}IndexComposition", id, startDate, endDate);

            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing:true))
            {

                var indexCompositionRequest = prismPollingManager.SendRequestSync(requestIndexComposition,
                    GetIndexDescriptionRequestContent(tickers.ToArray(), startDate.GetValueOrDefault(), endDate.GetValueOrDefault()), (int)TimeSpan.FromSeconds(90).TotalMilliseconds, cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None);

                if (indexCompositionRequest == null)
                {
                    return null;
                }

                var indexComponents = ParseIndexXml(tickers.ToList(), startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), indexCompositionRequest.ResultContent);

                IList<TimeSerieDB> priceTimeSeries = new List<TimeSerieDB>();

                if (field == DataFieldsEnum.IndexcomponentsWeightsAndPrices)
                {

                    // All tickers in compositions
                    var indexTickers = indexComponents.Values.SelectMany(
                            o => o.Values.SelectMany(
                                p => p.Components.Select(
                                    q => q.Reference)))
                                    .Distinct().ToList();

                    // Load spots
                    priceTimeSeries = ProviderDataHandler.Load(
                        indexTickers,
                        DataFieldsEnum.Last.AsArray(),
                        startDate,
                        endDate,
                        loadingContext);
                }

                return SetDataComponent(indexComponents, priceTimeSeries, field, loadingContext);
            }
        }
    }
}
