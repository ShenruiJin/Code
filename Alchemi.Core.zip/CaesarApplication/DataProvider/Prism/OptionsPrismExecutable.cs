﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Xml.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Sophis;
using GlobalDerivativesApplications.Sophis.Parameters.Input;
using MarketData;
using CaesarApplication.Service.Configuration;
using PricingBase.DataProvider;
using System.Collections.Concurrent;
using CaesarCommon.Configuration;

namespace CaesarApplication.DataProvider.Prism
{
    public class OptionDescAndPricesPrismExecutable : ProviderExecutable
    {
        protected virtual KeyValuePair<DateTime, IMarketData>[] GetKeyValuePairs(string ticker, DateTime startDate, DateTime endDate, List<OptionDescAndPrices> dataItems)
        {
            var selectedOptions =
        dataItems.Where(
            d =>
                ticker == d.Underlying && d.TradeDate >= startDate &&
                d.TradeDate <= endDate).ToArray();

            return selectedOptions.GroupBy(x => x.TradeDate).Select(g =>
            {
                var lst = new OptionDescAndPricesList();
                var options = g.ToArray().OrderBy(x => x.ExpirationDate)
                    .ThenBy(x => x.Strike)
                    .ThenBy(x => x.Class)
                    .ThenBy(x => x.Nature).ToArray();

                lst.AddRange(options);

                return new KeyValuePair<DateTime, IMarketData>(g.Key, lst);
            }).ToArray();
        }

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            Dictionary<string, List<DateTime>> datesByUnderlying = new Dictionary<string, List<DateTime>>();
            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.MaxValue);

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            List<OptionDescAndPrices> marketDatas = LoadOptions(tickersAsArray, startDateOrDefault, endDateOrDefault, loadingContext, datesByUnderlying);

            return tickersAsArray.Select(ticker => new TimeSerieDB(
                GetKeyValuePairs(ticker, startDateOrDefault, endDateOrDefault, marketDatas).Where(kv => datesByUnderlying[ticker].Contains(kv.Key)).ToArray(), 
                ticker, field,
                CanBeConsideredAsComplete(ticker, datesByUnderlying, startDateOrDefault, endDateOrDefault), loadingContext)).ToArray();
        }

        private bool CanBeConsideredAsComplete(string ticker, Dictionary<string, List<DateTime>> datesByUnderlying, DateTime startDate, DateTime endDate)
        {
            if (!datesByUnderlying.ContainsKey(ticker))
                return false;
            var dateList = datesByUnderlying[ticker].OrderBy(d => d);

            return dateList.Count() > 0 && startDate != default(DateTime) && endDate != default(DateTime) &&
                endDate != DateTime.MaxValue && startDate >= dateList.First() && endDate <= dateList.Last();
        }

        protected virtual List<OptionDescAndPrices> LoadOptions(string[] tickers, DateTime startDate, DateTime endDate, ILoadingContext loadingContext, Dictionary<string, List<DateTime>> datesByUnderlying)
        {
            var optionDirectory = new CaesarSettingsManager().OptionFilesDirectoryPath ??
                                  AppDomain.CurrentDomain.BaseDirectory;


            var elligibleFiles = GetElligibleFiles(optionDirectory.Split(','), startDate, endDate);

            if (!elligibleFiles.Any())
            {
                return new List<OptionDescAndPrices>();
            }

            var descriptions = LoadDescFile(elligibleFiles, tickers);

            if (!descriptions.Any())
            {
                return new List<OptionDescAndPrices>();
            }

            var calendars = GetCalendars(tickers);

            var res = LoadOHLCFile(elligibleFiles, startDate, endDate, descriptions, calendars, datesByUnderlying);

            return res;
        }


        static ConcurrentDictionary<string, ICalendar> _calendars_cache = new ConcurrentDictionary<string, ICalendar>();

        protected static Dictionary<string, ICalendar> GetCalendars(string[] tickers)
        {
            var sm2 = new Lazy<ISophisManager2>(() => SophisManager2Factory.CreateSophisManager("PROD", "APP_SOPHIS_FO", "TOP"));

            return tickers.ToDictionary(t => t,
                t =>
                {
                    ICalendar cal;
                    if (!_calendars_cache.TryGetValue(t, out cal))
                    {

                        var instr = sm2.Value.Instrument.Get(new InstrumentInput(t));
                        cal = sm2.Value.Calendar.Get(new CalendarInput(instr.Code.ToString(), CalendarType.ForInstrument))
                                .FirstOrDefault();
                        _calendars_cache[t] = cal;
                    }
                    return cal;
                });
        }

        private static OptionFile[] GetElligibleFiles(string[] optionDirectories, DateTime startDateOrDefault, DateTime endDateOrDefault)
        {
            var files = optionDirectories.SelectMany(d => Directory.GetFiles(d)).ToArray();

            var optionFiles = files
                .Where(f => Path.GetFileName(f).StartsWith("response"))
                .Select(f => OptionFile.ParseName(f))
                .Where(x => x != null)
                .ToArray();

            var elligibleFiles = optionFiles.Where(f => f.Contains(startDateOrDefault, endDateOrDefault)).ToArray();
            return elligibleFiles;
        }

        public class OptionFile
        {
            const string FileOhlcDescRegexString = @".*(" + PrismConstants.DateRegexPattern + @")Desc\.xml$";
            static readonly Regex FileOhlcDescRegex = new Regex(FileOhlcDescRegexString, RegexOptions.Compiled);
            public static OptionFile ParseName(string path)
            {
                var matchResult = FileOhlcDescRegex.Match(path);

                string ohlcFile = Regex.Replace(path, @"Desc\.xml$", "OHLC.xml");
                if (matchResult.Success && File.Exists(ohlcFile))
                {

                    return new OptionFile()
                    {
                        StartDate = DateTime.ParseExact(matchResult.Groups[2].Value, "yyyyMMdd",
                                    CultureInfo.InvariantCulture),
                        EndDate = DateTime.ParseExact(matchResult.Groups[3].Value, "yyyyMMdd",
                                    CultureInfo.InvariantCulture),
                        DescriptionFile = path,
                        OHLCFile = ohlcFile
                    };
                }
                else
                {
                    return null;
                }
            }
            public DateTime StartDate { get; set; }
            public DateTime EndDate { get; set; }
            public string DescriptionFile { get; set; }
            public string OHLCFile { get; set; }
            public string[] Underlyings { get; set; }

            public bool Contains(DateTime startDateRequested, DateTime endDateRequested)
            {
                return (startDateRequested >= StartDate && startDateRequested <= EndDate)
               ||
               (endDateRequested >= StartDate && endDateRequested <= EndDate)
               || (StartDate >= startDateRequested && StartDate <= endDateRequested)
               || (EndDate <= endDateRequested && EndDate >= startDateRequested)
               ;
            }
        }

        private List<OptionDescAndPrices> LoadOHLCFile(IEnumerable<OptionFile> files, DateTime startDate, DateTime endDate, Dictionary<string, List<OptionDescAndPrices>> descriptions, Dictionary<string, ICalendar> calendars, Dictionary<string, List<DateTime>> datesByUnderlying)
        {
            var optionDescs = new List<OptionDescAndPrices>();
            Dictionary<string, List<DateTime>> ricCodeTradeDateDico = descriptions.ToDictionary(d => d.Key, d => new List<DateTime>());

            foreach (var file in files)
            {
                using (var streamReader = new StreamReader(File.Open(file.OHLCFile, FileMode.Open, FileAccess.Read, FileShare.Read)))
                {
                    var datesByUnderlyingDico = new Dictionary<string, List<DateTime>>();
                    LoadOHLCFile(startDate, endDate, descriptions, streamReader, optionDescs, calendars, datesByUnderlyingDico, ricCodeTradeDateDico);
                    file.Underlyings = datesByUnderlyingDico.Keys.ToArray();
                    datesByUnderlyingDico.ForEach(x => x.Value.ForEach(d => AddToDatesByUnderlying(datesByUnderlying, x.Key, d)));
                }
            }

            return optionDescs;
        }

        protected void LoadOHLCFile(DateTime startDate, DateTime endDate, Dictionary<string, List<OptionDescAndPrices>> descriptions, StreamReader streamReader, List<OptionDescAndPrices> optionDescs, Dictionary<string, ICalendar> calendars, Dictionary<string, List<DateTime>> datesByUnderlying, Dictionary<string, List<DateTime>> ricCodeTradeDateDico)
        {
            string line;
            while ((line = streamReader.ReadLine()) != null)
            {
                if (Regex.IsMatch(line, "\\<optionPrice .*\\/\\>"))
                {
                    var ohlcXmlNode = XElement.Parse(line);

                    var optionTypeAttribute = ohlcXmlNode.Attribute("optionType");
                    if (optionTypeAttribute != null && optionTypeAttribute.Value == "LEAP")
                        continue;

                    var ricCode = ohlcXmlNode.Attribute("code").Value;
                    DateTime tradeDate;
                    if (!DateTime.TryParseExact(ohlcXmlNode.Attribute("date").Value, "yyyyMMdd",
                        CultureInfo.InvariantCulture, DateTimeStyles.None, out tradeDate))
                        continue;

                    OptionDescAndPrices desc = null;
                    if (descriptions.ContainsKey(ricCode))
                    {
                        desc = descriptions[ricCode].OrderBy(x => x.ExpirationDate).First();
                    }

                    if (tradeDate >= startDate && tradeDate <= endDate && descriptions.ContainsKey(ricCode))
                    {
                        var descriptionsOrdered = descriptions[ricCode].OrderBy(x => x.ExpirationDate);
                        if (!descriptionsOrdered.Any(d => d.ExpirationDate >= tradeDate))
                            continue;
                        desc = descriptionsOrdered.First(d => d.ExpirationDate >= tradeDate);

                        if (IsAlreadyExistsOptionDescAndPricesOnTradeDate(ricCodeTradeDateDico, ricCode, tradeDate))
                            continue;

                        var description = CreateOptionFromDescription(desc, calendars[desc.Underlying]);
                        var optionDescAndPrices = CreateOptionDescAndPricesOHLC(ohlcXmlNode,
                            tradeDate, description);

                        if (!double.IsNaN(optionDescAndPrices.Last) && optionDescAndPrices.Last != 0)
                        {
                            AddToDatesByUnderlying(datesByUnderlying, desc.Underlying, tradeDate);
                        }

                        lock (((ICollection)optionDescs).SyncRoot)
                        {
                            optionDescs.Add(optionDescAndPrices);
                        }
                    }
                }
            }
        }

        private void AddToDatesByUnderlying(Dictionary<string, List<DateTime>> datesByUnderlying, string underlying, DateTime tradeDate)
        {
            if (!datesByUnderlying.ContainsKey(underlying))
            {
                datesByUnderlying.Add(underlying, new List<DateTime>());
            }

            if (!datesByUnderlying[underlying].Contains(tradeDate))
            {
                datesByUnderlying[underlying].Add(tradeDate);
            }
        }

        private static bool IsAlreadyExistsOptionDescAndPricesOnTradeDate(Dictionary<string, List<DateTime>> ricCodeTradeDateDico, string ricCode, DateTime tradeDate)
        {
            if (!ricCodeTradeDateDico[ricCode].Contains(tradeDate))
                ricCodeTradeDateDico[ricCode].Add(tradeDate);
            else
                return true;

            return false;
        }

        private Dictionary<string, List<OptionDescAndPrices>> LoadDescFile(IEnumerable<OptionFile> files, string[] tickers)
        {
            var optionDescs = new Dictionary<string, List<OptionDescAndPrices>>();

            foreach (var file in files)
            {
                using (var streamReader = File.OpenText(file.DescriptionFile))
                {
                    LoadDescFile(tickers, streamReader, optionDescs);
                }
            }
            return optionDescs;
        }

        protected void LoadDescFile(string[] tickers, StreamReader streamReader, Dictionary<string, List<OptionDescAndPrices>> optionDescs)
        {
            string currentScope = null;

            string line;

            while ((line = streamReader.ReadLine()) != null)
            {
                if (Regex.IsMatch(line, "\\<index code\\=\\\".*\\\"\\>"))
                {
                    currentScope = line.Substring(line.IndexOf("\"", StringComparison.Ordinal) + 1,
                        line.LastIndexOf("\"", StringComparison.Ordinal) - line.IndexOf("\"", StringComparison.Ordinal) - 1);
                }
                else if (tickers.Contains(currentScope) && Regex.IsMatch(line, "\\<option.*\\/\\>"))
                {
                    var optionDescAndPricesBySymbol = CreateOptionDescAndPricesDescription(currentScope, line);

                    lock (((ICollection)optionDescs).SyncRoot)
                    {
                        if (!optionDescs.ContainsKey(optionDescAndPricesBySymbol.Key))
                        {
                            optionDescs.Add(optionDescAndPricesBySymbol.Key, new List<OptionDescAndPrices>());
                        }

                        optionDescs[optionDescAndPricesBySymbol.Key].Add(optionDescAndPricesBySymbol.Value);
                    }
                }
            }
        }

        private static KeyValuePair<string, OptionDescAndPrices> CreateOptionDescAndPricesDescription(string underlying, string line)
        {
            var referentialXmlNode = XElement.Parse(line);

            var optionDescAndPrices = new OptionDescAndPrices
            {
                Underlying = underlying,
                ContractSize = (int)double.Parse(referentialXmlNode.Attribute("contractSize").Value, CultureInfo.InvariantCulture),
                //Class = lineParts[headers["CLS"]],Indisponible
                ExpirationDate =
                    DateTime.ParseExact(referentialXmlNode.Attribute("expirationDay").Value, "yyyy-MM-ddTHH:mm:sszzz",
                        CultureInfo.InvariantCulture),
                //LastAsk = Double.Parse(lineParts[headers["L_ASK"]], CultureInfo.InvariantCulture),//Indisponible
                //LastBid = Double.Parse(lineParts[headers["L_BID"]], CultureInfo.InvariantCulture),//Indisponible
                Nature = referentialXmlNode.Attribute("putCallIndicator").Value == "C" ? OptionNature.Call : OptionNature.Put,

                //OpenInterest = Double.Parse(lineParts[headers["OIT"]], CultureInfo.InvariantCulture),Indisponible
                //PType = lineParts[headers["P_TYPE"]],Indisponible
                SType = referentialXmlNode.Attribute("optionType") != null ? referentialXmlNode.Attribute("optionType").Value : "Standard",
                Strike = Double.Parse(referentialXmlNode.Attribute("strikePrice").Value, CultureInfo.InvariantCulture),
                //UnderlyingPrice = Double.Parse(lineParts[headers["UNDL_PRC"]], CultureInfo.InvariantCulture),//OHLC
                //Volume = Double.Parse(lineParts[headers["VOL"]], CultureInfo.InvariantCulture),//OHLC
                Currency = referentialXmlNode.Attribute("currencyIsoCode").Value,
                ExerciseStyleCode = referentialXmlNode.Attribute("exerciseStyleCode").Value,
                Ticker = referentialXmlNode.Attribute("ricCode").Value,
            };
            return new KeyValuePair<string, OptionDescAndPrices>(referentialXmlNode.Attribute("ricCode").Value, optionDescAndPrices);
        }

        private static OptionDescAndPrices CreateOptionDescAndPricesOHLC(XElement node, DateTime tradeDate, OptionDescAndPrices optionDescAndPrices)
        {
            var settlementPriceValue = GetDoubleValueOptionnal(node, "settlementPrice", optionDescAndPrices.Last);

            optionDescAndPrices.Last = node.Attributes().Any(a => a.Name == "closingPrice") ? Double.Parse(node.Attribute("closingPrice").Value, CultureInfo.InvariantCulture) : double.NaN;
            optionDescAndPrices.Last = settlementPriceValue != 0 ? settlementPriceValue : optionDescAndPrices.Last;

            if (!node.Attributes().Any(a => a.Name == "closingPrice") && !node.Attributes().Any(a => a.Name == "settlementPrice"))
            {
                throw new ArgumentException("No price defined for line : " + node.ToString());
            }

            optionDescAndPrices.TradeDate = tradeDate;
            optionDescAndPrices.High = GetDoubleValueOptionnal(node, "highPrice");
            optionDescAndPrices.Low = GetDoubleValueOptionnal(node, "lowPrice");
            

            optionDescAndPrices.Open = GetDoubleValueOptionnal(node, "openingPrice");

            optionDescAndPrices.LastBid = GetDoubleValueOptionnal(node, "bidPrice");
            optionDescAndPrices.LastAsk = GetDoubleValueOptionnal(node, "askPrice");

            optionDescAndPrices.Volume = node.Attributes().Any(x => x.Name.LocalName == "volume") ? Double.Parse(node.Attribute("volume").Value, CultureInfo.InvariantCulture) : 0.0d;

            var classAttribute = node.Attribute("optionClass");
            if (classAttribute != null)
            {
                optionDescAndPrices.Class = classAttribute.Value;
            }

            return optionDescAndPrices;
        }

        private static double GetDoubleValueOptionnal(XElement node, string nodeName, double? defaultValue = null)
        {
            return node.Attributes().Any(a => a.Name == nodeName) ? Double.Parse(node.Attribute(nodeName).Value, CultureInfo.InvariantCulture) : defaultValue.GetValueOrDefault(double.NaN);
        }

        private static OptionDescAndPrices CreateOptionFromDescription(OptionDescAndPrices description, ICalendar calendar)
        {
            return new OptionDescAndPrices
            {
                ExerciseStyleCode = description.ExerciseStyleCode,
                Currency = description.Currency,
                Class = description.Class,
                ExpirationDate = description.ExpirationDate,
                Nature = description.Nature,
                PType = description.PType,
                SType = description.SType,
                Strike = description.Strike,
                Underlying = description.Underlying,
                Ticker = description.Ticker
            };
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get { return new List<DataFieldsEnum>() { DataFieldsEnum.OptionDescAndPrices }; }
        }
    }
}
