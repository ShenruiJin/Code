﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism;
using log4net;
using PricingBase.DataProvider;
using PrismWS.Mfd;
using FuncFramework.Helpers;
using MarketData;
using GlobalDerivativesApplications.Data.MarketData;

namespace CaesarApplication.DataProvider.Prism
{
    /// <summary>
    /// Prism provider for dividends
    /// </summary>
    [Serializable]
    public class InstrumentInfosPrismExecutable : ProviderExecutable
    {
        private readonly IDataHandler _dataHandler;
        private ILog Logger = LogManager.GetLogger(typeof(InstrumentInfosPrismExecutable));

        /// <summary>
        /// Prism manager
        /// </summary>
        private PrismManager prismManager
        {
            get
            {
                return new PrismManager();
            }
        }

        /// <summary>
        /// returns a list of dividends time serie for a given list of stocks over a period
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field,
                                                            DateTime? startDate = null, DateTime? endDate = null,
                                                            ILoadingContext loadingContext = null)
        {
            var result = new List<TimeSerieDB>();

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            var mfds = (MarketFinancialDataWebService)prismManager.GetFieldValue("mfds");

            var dataList = mfds.getMarketFinancialData("BLOOM_CODE", tickers.Select(t => new MarketFinancialDataParameters { bbg = t }).ToArray());

            foreach (var ticker in tickers)
            {
                var data = dataList.FirstOrDefault(x => x.bbgCode == ticker);

                if (data != null && data.currency != string.Empty)
                {
                    result.Add(new TimeSerieDB(DateTime.MinValue, GetMarketData(field, data), ticker, field));
                }
                else
                {
                    result.Add(new TimeSerieDB(new KeyValuePair<DateTime, IMarketData>[0], ticker, field));
                }
            }

            return result;
        }

        private IMarketData GetMarketData(DataFieldsEnum field, MarketFinancialData instr)
        {
            if (field == DataFieldsEnum.Currency)
            {
                return new MarketDataString(instr.currency);
            }
            else if (field == DataFieldsEnum.CountryOfIncorporation)
            {
                return new MarketDataString(instr.countryOfIncorporation);
            }

            throw new NotImplementedException(string.Format("Field {0} not managed", field));
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.Currency,
                    DataFieldsEnum.CountryOfIncorporation
                };
            }
        }
    }
}
