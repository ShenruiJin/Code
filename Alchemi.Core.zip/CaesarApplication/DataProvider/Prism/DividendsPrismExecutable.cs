﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.DataProvider.Bloomberg;
using CaesarApplication.DataProvider.Helpers;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism;
using log4net;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;
using PricingBase.OST;
using Dividend = GlobalDerivativesApplications.Data.Prism.Dividend;
using DividendGda = GlobalDerivativesApplications.Data.MarketData.Dividend;

namespace CaesarApplication.DataProvider.Prism
{
    /// <summary>
    /// Prism provider for dividends
    /// </summary>
    [Serializable]
    public class DividendsPrismExecutable : ProviderExecutable
    {
        private readonly IDataHandler _dataHandler;
        private ILog Logger = LogManager.GetLogger(typeof (DividendsPrismExecutable));

        /// <summary>
        /// Prism manager
        /// </summary>
        private PrismManager prismManager
        {
            get
            {
                return new PrismManager();
            }
        }

        /// <summary>
        /// Main Ctor.
        /// </summary>
        public DividendsPrismExecutable(IDataHandler dataHandler)
        {
            _dataHandler = dataHandler;
            _fields = new List<DataFieldsEnum> { DataFieldsEnum.Dividend };
        }

        /// <summary>
        /// returns a list of dividends time serie for a given list of stocks over a period
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, 
                                                            DateTime? startDate = null, DateTime? endDate = null, 
                                                            ILoadingContext loadingContext = null)
        {
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();

            InitializeDates(ref startDate, ref endDate);

            var divsByTicker = new Dictionary<string, List<DividendGda>>();

            var groupedTickers = Group(tickersAsArray, 10);

            var knownTickers = new List<string>();

            foreach (var group in groupedTickers)
            {
                try
                {
                    AddToDico(divsByTicker, RequestDivs(startDate, endDate, @group));
                    knownTickers.AddRange(divsByTicker.Keys);
                }
                catch
                {
                    foreach (var item in group)
                    {
                        try
                        {
                            AddToDico(divsByTicker, RequestDivs(startDate, endDate, item.AsArray()));
                            knownTickers.Add(item);
                        }
                        catch (Exception ex)
                        {
                            Console.WriteLine("Prism can't retrieve dividends for [{0}]", item);
                            Logger.Error(ex);
                        }
                    }
                }
            }
            var output = GetDivs(tickersAsArray, field, divsByTicker);


            CorporateActionHelper.AddCancellingCoporateActions(_dataHandler, knownTickers.ToArray(), startDate, endDate, output, loadingContext, DataFieldsEnum.Dividend, date => new DividendGda { ExDividendDate = date });

            output.ForEach(ts =>
            {
                ts.StartDate = startDate;
                ts.EndDate = endDate;
            });
            return output;
        }

 
        private void AddToDico(Dictionary<string, List<DividendGda>> divsByTicker, Dictionary<string, DividendGda[]> divsToAdd)
        {
            foreach (var divKv in divsToAdd)
            {
                if (!divsByTicker.ContainsKey(divKv.Key))
                {
                    divsByTicker.Add(divKv.Key, new List<DividendGda>());
                }

                divsByTicker[divKv.Key].AddRange(divKv.Value);
            }
        }

        private Dictionary<string, DividendGda[]> RequestDivs(DateTime? startDate, DateTime? endDate, IList<string> @group)
        {
            return prismManager.GetStockDividends(@group, startDate.GetValueOrDefault(),
                endDate.GetValueOrDefault(DateTime.Today)).Where(d => !string.IsNullOrEmpty(d.ExDate)).GroupBy(g => g.BloombergCode).ToDictionary(x => x.Key, x => x.Select(CreateDividend).ToArray());
        }

        private List<TimeSerieDB> GetDivs(IEnumerable<string> tickers, DataFieldsEnum field, Dictionary<string, List<DividendGda>> stockDividends)
        {
            List<TimeSerieDB> output = new List<TimeSerieDB>();

            foreach (string tickerDiv in tickers)
            {
                var dividendPrisms = stockDividends.ToArray().Where(o => o.Key == tickerDiv).SelectMany(x => x.Value).ToArray();
                var markitDivs = dividendPrisms.Select(d => new CaesarMarkitDividend(d));
                TimeSerieDB div = new TimeSerieDB(markitDivs.Select(x => x.ExDividendDate).ToArray(), markitDivs.Cast<IMarketData>().ToArray(), tickerDiv, field, true);
                if (div.MultipleSameDates())
                    output.Add(div.ConsolidateDates());
                else
                    output.Add(div);
            }

            return output;
        }

        private List<IList<string>> Group(string[] dataToGroup, int count)
        {
            var res = new List<IList<string>>();

            var sum = 0;

            while (sum < dataToGroup.Length)
            {
                res.Add(dataToGroup.Skip(sum).Take(count).ToList());

                sum = res.Select(x => x.Count).Sum();
            }

            return res;
        }

        /// <summary>
        /// Collection of Prism Dividend to GDA Dividends
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="date"></param>
        /// <param name="dividends"></param>
        /// <returns></returns>
        private IList<GlobalDerivativesApplications.Data.MarketData.Dividend> CreateDividends(string ticker,
            DateTime date, IList<Dividend> dividends)
        {
            string temp = date.ToString("yyyy-MM-dd");
            return dividends.Where(x => x.BloombergCode == ticker && x.ExDate == temp).
                                                Select(y => CreateDividend(y)).ToList();
        }

        /// <summary>
        /// Converts a Prism dividend to a GDA one
        /// </summary>
        /// <param name="dividend"></param>
        /// <returns></returns>
        private GlobalDerivativesApplications.Data.MarketData.Dividend CreateDividend(Dividend div)
        {
            // Converting each Prism dividend as GF IMarketData Dividend
            return new GlobalDerivativesApplications.Data.MarketData.Dividend(
                                DateTime.Parse(div.FinancialYearEndDate).Year, 
                                div.DividendComments, 
                                div.RawGrossAmountCurrency /*div.GrossAmountCurrency*/ ,
                                DateTime.Parse(div.AnnouncementDate), 
                                DateTime.Parse(div.ExDate), 
                                DateTime.Parse(div.PayDate), 
                                DividendStatus.None,
                                DividendType.Dividend, 
                                DividendUnit.MonetaryUnit, 
                                div.RawGrossAmount, /*div.GrossAmount,*/
                                1.0);
        }
    }
}
