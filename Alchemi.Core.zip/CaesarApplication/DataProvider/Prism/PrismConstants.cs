﻿namespace CaesarApplication.DataProvider.Prism
{
    public static class PrismConstants
    {
        public const string DateRegexPattern =
            "([0-9][0-9][0-9][0-9][0-1][0-9][0-3][0-9])([0-9][0-9][0-9][0-9][0-1][0-9][0-3][0-9])";

        public const string DateTimeRegexPattern = "[0-9][0-9][0-9][0-9][0-1][0-9][0-3][0-9][0-2][0-9][0-9][0-9][0-6][0-9]";

        public const string CallingAppName = "Caesar";

        public const string CodeTypeBloomberg = "BBG_CODE";

        public const string ServiceAdjustedPrice = "ADJUSTED_PRICE";
        public const string ServiceUnadjustedPrice = "UNADJUSTED_PRICE";
        public const string ServiceIndexComponents = "INDEX_COMPO";
        public const string ServiceIndexOption = "INDEX_OPTION";
        public const string ServiceCurrency = "CURRENCY";
        public const string ServiceParametrable = "PARAMETRABLE";
        public const string ServicePerSec = "BLOOM_PERSEC";

        public const string ProductIndex = "INDEX";
        public const string ProductOptions = "OPTIONS";
        public const string ProductEquity = "EQUITY";
        public const string ProductCurve = "CURVE";
        public const string ProductForex = "FOREX";
        public const string ProductCurrency = "CURRENCY";

        public const string SuffixCustom = "Custom";

        public const string ServiceMarketListing = "GET_LISTING";
        public const string TICKER = "TICKER";

        public const string LAST_SNAPSHOTDATAONLY = "PX_LAST";
        public const string LASTUPDATE_SNAPSHOTDATAONLY = "LAST_UPDATE";
    }
}
