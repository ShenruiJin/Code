using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism.Polling;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using PricingBase.DataProvider;
using System.Text;
using System.Text.RegularExpressions;
using CaesarApplication.DataProvider.Bloomberg;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Prism
{
    public class NonAdjustedPricesPrismByPollingExecutable : PricesPrismExecutable
    {
        protected virtual string PrismService
        {
            get
            {
                return PrismConstants.ServiceUnadjustedPrice;
            }
        }

        protected BloombergTranscoder instrumentCodeTranscoder  = new BloombergTranscoder();
        private string regexPatternForexRateWithFixing = @"^[A-Z]{5}[A-Z]{1}|[a-z]{1}\s{1}F{1}\d{3}$";
        private string regexPatternForexRate = @"(^[A-Z]{5}([A-Z]{1}|[a-z]{1})$)";
        protected override Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> LoadMarketDatas(IEnumerable<string> tickers, DateTime startDate, DateTime endDate, ILoadingContext loadingContext)
        {
            using (var prismPollingManager = new PrismPollingManager(deleteAfterProcessing: true))
            {
                var tickersAsArray = tickers as string[] ?? tickers.ToArray();
                var tickersAsArrayTransco = instrumentCodeTranscoder.TranscodeExternalToInternal(tickersAsArray, loadingContext);

                var prismDirectoryEntries =
                    PersistanceService.IndexProvider.GetPrismServiceByTickerEntries(tickersAsArray);

                var group = tickersAsArrayTransco.GroupBy(s => GetKeyForTicker(s, prismDirectoryEntries));

                var requestContent = new Dictionary<PrismRequestKeys, string>();
                group.ForEach(o => requestContent.Add(o.Key, Request(startDate, endDate, loadingContext, GetRequestName(startDate, endDate, o.Key.Product), prismPollingManager, o.ToArray(), o.Key)));

                return GetMarketDatasFromStrings(requestContent.ToArray(), tickersAsArray.ToArray(), startDate, endDate);
            }
        }

        private PrismRequestKeys GetKeyForTicker(string ticker, PrismServiceByTicker[] prismDirectoryEntries)
        {
            var suffixUpperCase = BloombergHelper.GetBBGSuffixUpperCase(ticker);
            var normalizedTicker = BloombergHelper.GetTickerWithoutSuffix(ticker);


            if (prismDirectoryEntries.Any(p => p.Ticker == normalizedTicker))
            {
                var prismDirectoryEntryPoint = prismDirectoryEntries.FirstOrDefault(e => normalizedTicker == BloombergHelper.GetTickerWithoutSuffix(e.Ticker));
                return GetKeysFromPrismDirectoryEntry(suffixUpperCase, prismDirectoryEntryPoint) ?? 
                    new PrismRequestKeys(PrismConstants.ServiceAdjustedPrice, suffixUpperCase, false);
            }

            if (Regex.IsMatch(normalizedTicker, regexPatternForexRateWithFixing) || Regex.IsMatch(normalizedTicker, regexPatternForexRate))
            {
                var prismDirectoryEntryPoint = prismDirectoryEntries.FirstOrDefault(e => normalizedTicker == BloombergHelper.GetTickerWithoutSuffix(e.Ticker) && e.Service == CurrentPrismService)
                    ??
                    prismDirectoryEntries.FirstOrDefault(e => normalizedTicker == BloombergHelper.GetTickerWithoutSuffix(e.Ticker));

                if (prismDirectoryEntryPoint != null && prismDirectoryEntryPoint.Service == PrismServiceByTickerService.Forex)
                    return new PrismRequestKeys(PrismConstants.ProductCurrency, PrismConstants.ProductForex, false);
            }

            if (suffixUpperCase == SophisHelper.BbgCurrencySuffix.ToUpper())
            {
                return new PrismRequestKeys(PrismConstants.ProductCurrency, PrismConstants.ProductForex, false);
            }

            if (suffixUpperCase == PrismConstants.ProductEquity)
            {
                return new PrismRequestKeys(PrismService, PrismConstants.ProductEquity, true);
            }

            var prismDirectoryEntry = prismDirectoryEntries.FirstOrDefault(e => normalizedTicker == BloombergHelper.GetTickerWithoutSuffix(e.Ticker) && e.Service == CurrentPrismService)
            ??
            prismDirectoryEntries.FirstOrDefault(e => normalizedTicker == BloombergHelper.GetTickerWithoutSuffix(e.Ticker));

            return GetKeysFromPrismDirectoryEntry(suffixUpperCase, prismDirectoryEntry) ??
                   new PrismRequestKeys(PrismConstants.ServiceAdjustedPrice, suffixUpperCase, false);
        }

        private PrismServiceByTickerService CurrentPrismService
        {
            get
            {
                return PrismService == PrismConstants.ServiceUnadjustedPrice
                    ? PrismServiceByTickerService.Unadjustedprices
                    : PrismServiceByTickerService.Adjustedprices;
            }
        }

        private PrismRequestKeys GetKeysFromPrismDirectoryEntry(string suffixUpperCase, PrismServiceByTicker prismDirectoryEntry)
        {
            if (prismDirectoryEntry == null)
            {
                return new PrismRequestKeys(PrismConstants.ServiceAdjustedPrice, PrismConstants.ProductEquity, false);
            }

            if (prismDirectoryEntry.Service == PrismServiceByTickerService.Curves)
            {
                return new PrismRequestKeys(PrismConstants.ServiceCurrency, PrismConstants.ProductCurve, false);
            }

            if (prismDirectoryEntry.Service == PrismServiceByTickerService.Index)
            {
                return new PrismRequestKeys(PrismConstants.ServiceUnadjustedPrice, PrismConstants.ProductIndex, false);
            }
            if (prismDirectoryEntry.Service == PrismServiceByTickerService.Forex)
            {
                return new PrismRequestKeys(PrismConstants.ProductCurrency, PrismConstants.ProductForex, false);
            }
            return new PrismRequestKeys
                (
                prismDirectoryEntry.Service == PrismServiceByTickerService.Adjustedprices ? PrismConstants.ServiceAdjustedPrice : PrismConstants.ServiceUnadjustedPrice,
                 PrismConstants.ProductEquity,
                false
                );
        }

        private static string GetRequestName(DateTime startDate, DateTime endDate, string productType)
        {
            var id = Guid.NewGuid();

            string requestName = string.Format("{0}{2:yyyyMMdd}{3:yyyyMMdd}Prices", id, productType,startDate, endDate);
            return requestName;
        }

        private string Request(DateTime startDate, DateTime endDate, ILoadingContext loadingContext, string requestName, PrismPollingManager prismPollingManager, string[] tickersFiltered, PrismRequestKeys keys)
        {
            var request = prismPollingManager.SendRequestSync(requestName,
                GetRequest(tickersFiltered, startDate, endDate, keys), (int)TimeSpan.FromSeconds(60).TotalMilliseconds, cancelationToken: loadingContext != null ? loadingContext.CancellationToken : CancellationToken.None);

            if (request == null)
            {
                return  null;
            }

            return request.ResultContent;
        }

        public string GetRequest(string[] tickers, DateTime startDate, DateTime endDate, PrismRequestKeys keys)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                //Feature to fix PRISM bug that store all indexes as AdjustedPrices
                Service = keys.Service,
                Product = keys.Product,
                RequestTime = DateTime.Today,
                Codes = keys.WithBBGSuffix ? tickers : tickers.Select(BloombergHelper.GetTickerWithoutSuffix).ToArray()
            };

            return prismRequest.ToSerializedString();
        }

#if DEBUG
        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                if (DateTime.Today.DayOfWeek == DayOfWeek.Saturday)
                {
                    return new DataFieldsEnum[] { };
                }
                return new[]
                {
                    DataFieldsEnum.Last,
                    DataFieldsEnum.Close,
                    DataFieldsEnum.Open
                };
            }
        }
#endif
    }
}
