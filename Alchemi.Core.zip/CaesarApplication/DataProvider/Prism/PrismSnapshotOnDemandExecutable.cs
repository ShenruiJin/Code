﻿using System;
using System.Configuration;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Providers;
using System.Collections.Generic;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Bloomberg;


namespace CaesarApplication.DataProvider.Prism
{
    public class PrismSnapshotOnDemandExecutable : PrismOnDemandExecutable
    {
        protected override string GetRequest(DataFieldsEnum field, string[] tickers, DateTime startDate, DateTime endDate)
        {
            var bbgUserNumber = ConfigurationManager.AppSettings["BbgUserNumber"];

            return new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                BbgUserNumber = !string.IsNullOrEmpty(bbgUserNumber) ? int.Parse(bbgUserNumber) : 0,
                //Feature to fix PRISM bug that store all indexes as AdjustedPrices
                Service = PrismConstants.ServicePerSec,
                Product = PrismConstants.ProductIndex,
                RequestTime = DateTime.Now,
                Codes = tickers,
                Fields = new[] { PrismConstants.LASTUPDATE_SNAPSHOTDATAONLY, GetPrismField(field) }
            }.ToSerializedString();
        }

        private static string GetPrismField(DataFieldsEnum field)
        {
            return field == DataFieldsEnum.Last ? PrismConstants.LAST_SNAPSHOTDATAONLY : BloombergProvider.ConvertDataFieldsEnum(field);
        }
    }

    public class DatePrismSnapshotOnDemandExecutable : PrismSnapshotOnDemandExecutable
    {
        protected override IList<TimeSerieDB> GetSeries(DataFieldsEnum field, string fileContent)
        {
            return BloombergParser.ParseDatesFile(field, fileContent, IsUndated);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.LastTradeableDate,
                    DataFieldsEnum.FirstFutureDeliveryDate,
                    DataFieldsEnum.SettlementDate
                };
            }
        }

        public override bool IsUndated
        {
            get
            {
                return true;
            }
        }
    }


    public class DoubleUnDatedSnapshotOnDemandExecutable : PrismSnapshotOnDemandExecutable
    {
        public override bool IsUndated
        {
            get
            {
                return true;
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.QuoteFactor,
                    DataFieldsEnum.FUT_INIT_SPEC_ML
                };
            }
        }
    }
}