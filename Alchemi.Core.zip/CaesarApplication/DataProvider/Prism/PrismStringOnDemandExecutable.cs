﻿using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketData;
using PricingBase.DataProvider;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CaesarApplication.DataProvider.Prism
{
    public class PrismStringOnDemandExecutable : PrismOnDemandExecutable
    {
        protected override IList<TimeSerieDB> GetSeries(DataFieldsEnum field, string fileContent)
        {
            return BloombergParser.ParseFile(field, fileContent, s => new MarketDataString(s), IsUndated);
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.FUT_CUR_GEN_TICKER
                };
            }
        }

        public override bool IsUndated
        {
            get
            {
                return false;
            }
        }
    }
}