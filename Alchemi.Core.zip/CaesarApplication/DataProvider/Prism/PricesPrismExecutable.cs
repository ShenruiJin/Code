﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using CaesarApplication.DataProvider.Bloomberg;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using MarketData;
using PricingBase.DataProvider;
using PrismWS.Dividends;
using CaesarApplication.Service.Configuration;
using CaesarCommon.Configuration;

namespace CaesarApplication.DataProvider.Prism
{
    public class PricesPrismExecutable : ProviderExecutable
    {
        const string FileRegexString = @".*(" + PrismConstants.DateRegexPattern + @")Prices\.xml$";
        static readonly Regex FileRegex = new Regex(FileRegexString, RegexOptions.Compiled);

        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.MaxValue);


            var dataItems = LoadMarketDatas(tickers, startDateOrDefault, endDateOrDefault, loadingContext);
            bool canFlagSeriesAsComplete = this is NonAdjustedPricesPrismByPollingExecutable;
            return dataItems.SelectMany(d =>
                d.Value.Select(x => new TimeSerieDB(x.Value.ToArray(), x.Key, d.Key, loadingContext, null, "PRISM_POLLING", startDate, endDate, 
                CanConsideredSeriesAsComplete(x.Value.Select(v => v.Key).ToArray(), startDate, endDate, canFlagSeriesAsComplete)))).ToArray();
            //return dataItems.SelectMany(d =>
            //    d.Value.Select(x => new TimeSerieDB(x.Value.ToArray(), x.Key, d.Key, CanConsideredSeriesAsComplete(x.Value.Select(v => v.Key).ToArray(), startDate, endDate, canFlagSeriesAsComplete))))
            //    .ToArray();
        }

        private bool CanConsideredSeriesAsComplete(DateTime[] dates, DateTime? startDate, DateTime? endDate, bool canFlagSeriesAsComplete)
        {
            if (!canFlagSeriesAsComplete || !dates.Any())
                return false;

            return dates.Min() <= startDate.GetValueOrDefault() && dates.Max() >= endDate.GetValueOrDefault(DateTime.MaxValue);
        }

        protected virtual Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> LoadMarketDatas(IEnumerable<string> tickers, DateTime startDate, DateTime endDate, ILoadingContext loadingContext)
        {
            var directory = new CaesarSettingsManager().PrismDirectoryPath ?? AppDomain.CurrentDomain.BaseDirectory;
            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            var eligibleFiles = PrismHelper.GetEligibleFiles(FileRegex, directory, startDate, endDate).Where(x => tickersAsArray.Any(x.Contains)).ToArray();

            var fileContents = eligibleFiles.Select(File.ReadAllText).ToArray();

            return GetMarketDatasFromStrings(fileContents.Select(c => new KeyValuePair<PrismRequestKeys, string>(new PrismRequestKeys { WithBBGSuffix = false }, c)), tickersAsArray.ToArray(), startDate, endDate);
        }

        protected Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> GetMarketDatasFromStrings(IEnumerable<KeyValuePair<PrismRequestKeys, string>> fileContents, string[] tickers, DateTime startDate, DateTime endDate)
        {
            Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> dataItems = new Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>>();

            SupportedFields.ForEach(f =>
            {
                dataItems.Add(f, new Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>());
                tickers.ForEach(t => dataItems[f].Add(t, new List<KeyValuePair<DateTime, IMarketData>>()));
            });

            foreach (var fileContentKv in fileContents)
            {
                var fileContent = fileContentKv.Value;

                if (fileContent == null)
                    continue;

                ExtractDataFromFile(startDate, endDate, fileContent, tickers, fileContentKv, dataItems);
            }

            return dataItems;
        }

        private void ExtractDataFromFile(DateTime startDate, DateTime endDate, string fileContent, string[] tickers,
            KeyValuePair<PrismRequestKeys, string> fileContentKv, Dictionary<DataFieldsEnum, Dictionary<string, List<KeyValuePair<DateTime, IMarketData>>>> dataItems)
        {
            var parisTZ = TimeZoneInfo.GetSystemTimeZones().First(tz => tz.Id == "Romance Standard Time");

            var prismTickers = tickers.ToDictionary(x => x, BloombergHelper.GetTickerWithoutSuffix);

            if (fileContent.Substring(0, fileContent.Length < 200 ? fileContent.Length : 200).Contains("currencyResponse"))
            {
                var prismResponse = fileContent.FromSerializedString<PrismCurrencyResponse>();

                if (prismResponse != null && prismResponse.Rates != null && prismResponse.Rates.Rate != null)
                {
                    prismTickers
                        .ForEach(t =>
                        {
                            var items = prismResponse.Rates.Rate.Where(x => x.Code == t.Value)
                            .Select(x => new KeyValuePair<DateTime, IMarketData>(TimeZoneInfo.ConvertTime(x.GetDateTime(), parisTZ),
                            new MarketDataDouble(x.Value))).Where(x => x.Key >= startDate && x.Key <= endDate).ToArray();

                            new[] { DataFieldsEnum.Last, DataFieldsEnum.Close }.ForEach(f => dataItems[f][t.Key].AddRange(items));
                        });
                }
            }
            else
            {
                var prismResponse = fileContent.FromSerializedString<PrismResponse>();

                if (prismResponse != null && prismResponse.Prices != null && prismResponse.Prices.PriceProducts != null)
                {
                    prismTickers
                        .ForEach(t =>
                        {
                            {
                                var items = prismResponse.Prices.PriceProducts.Where(x => x.Code == t.Value)
                                    .Select(x => new KeyValuePair<DateTime, IMarketData>(x.GetDateTime(),
                                        new MarketDataDouble(x.ClosingPrice)))
                                    .Where(x => x.Key >= startDate && x.Key <= endDate).ToArray();

                                //new[] { DataFieldsEnum.Last, DataFieldsEnum.Close }.ForEach(f => dataItems[f][t.Key]
                                //      .AddRange(items));
                                if (dataItems.Keys.Contains(DataFieldsEnum.Last))
                                {
                                    dataItems[DataFieldsEnum.Last][t.Key].AddRange(items);
                                }
                                else
                                {

                                }
                                if (dataItems.Keys.Contains(DataFieldsEnum.Close))
                                {
                                    dataItems[DataFieldsEnum.Close][t.Key].AddRange(items);
                                }
                                else
                                {

                                }
                            }
                            if (dataItems.Keys.Contains(DataFieldsEnum.Open))
                            {
                                var items = prismResponse.Prices.PriceProducts.Where(x => x.Code == t.Value)
                                    .Select(x => new KeyValuePair<DateTime, IMarketData>(x.GetDateTime(),
                                        new MarketDataDouble(x.OpeningPrice)))
                                    .Where(x => x.Key >= startDate && x.Key <= endDate).ToArray();

                                new[] {DataFieldsEnum.Open }.ForEach(f => dataItems[f][t.Key]
                                    .AddRange(items));
                            }
                            if (dataItems.Keys.Contains(DataFieldsEnum.Volume))
                            {
                                var items = prismResponse.Prices.PriceProducts.Where(x => x.Code == t.Value && x.Volume > 0)
                                    .Select(x => new KeyValuePair<DateTime, IMarketData>(x.GetDateTime(),
                                        new MarketDataDouble(x.Volume)))
                                    .Where(x => x.Key >= startDate && x.Key <= endDate).ToArray();

                                new[] { DataFieldsEnum.Volume }.ForEach(f => dataItems[f][t.Key]
                                     .AddRange(items));
                            }
                        });
                }
            }
        }

        public override IList<DataFieldsEnum> SupportedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.Last,
                    DataFieldsEnum.Close,
                    DataFieldsEnum.Open,
                    DataFieldsEnum.Volume
                };
            }
        }
    }
}
