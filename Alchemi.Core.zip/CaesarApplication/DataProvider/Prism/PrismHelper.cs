using GlobalDerivativesApplications.Prism;
using PricingBase.DataProvider;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using GlobalDerivativesApplications.Prism.RequestApi;

namespace CaesarApplication.DataProvider.Prism
{
    public static class PrismHelper
    {
        public static DateRange GetNormalizeDateRange(DateTime startDate, DateTime endDate)
        {
            return new DateRange(new [] {new DateTime(1970, 1, 1), startDate }.Max(),
                new []{DateTime.Today.AddYears(10), endDate }.Min());
        }

        public static string[] GetEligibleFiles(Regex fileRegex, string directory, DateTime startDate, DateTime endDate)
        {
            return Directory.GetFiles(directory).Where(f =>
            {
                var matchResult = fileRegex.Match(f);

                if (matchResult.Success)
                {
                    var fstartDate = DateTime.ParseExact(matchResult.Groups[2].Value, "yyyyMMdd", CultureInfo.InvariantCulture);
                    var fendDate = DateTime.ParseExact(matchResult.Groups[3].Value, "yyyyMMdd", CultureInfo.InvariantCulture);

                    if (!(startDate > fendDate) && !(endDate < fstartDate) && f.Contains("response"))
                    {
                        return true;
                    }
                }

                return false;
            }).ToArray();
        }

        /// <summary>
        /// Get eligible files containing the tickers
        /// </summary>
        /// <param name="fileRegex"></param>
        /// <param name="directory"></param>
        /// <param name="tickers"></param>
        /// <returns></returns>
        public static string[] GetEligibleFilesOnTickers(Regex fileRegex, string directory, DateTime startDate, DateTime endDate, IEnumerable<string> tickers)
        {
            return Directory.GetFiles(directory).Where(f =>
            {
                var matchResult = fileRegex.Match(f);

                if (matchResult.Success)
                {
                    var fstartDate = DateTime.ParseExact(matchResult.Groups[1].Value, "yyyyMMdd", CultureInfo.InvariantCulture);
                    var fendDate = DateTime.ParseExact(matchResult.Groups[2].Value, "yyyyMMdd", CultureInfo.InvariantCulture);

                    if (!(startDate > fendDate) && !(endDate < fstartDate))
                    {
                        return true;
                    }
                }

                return false;
            }).ToArray();
        }

        private static readonly Dictionary<string, bool> knownTickers = new Dictionary<string, bool>();

        /// <summary>
        /// Check if ticker exists in Prism
        /// </summary>
        /// <param name="reference"></param>
        /// <returns></returns>
        public static bool ReferenceExists(string reference)
        {
            if (knownTickers.ContainsKey(reference))
            {
                return knownTickers[reference];
            }

            PrismManager prism = new PrismManager();

            try
            {
                var data = prism.GetStockDividends(reference.AsArray(), DateTime.Today.AddYears(-5), DateTime.Today);
                if (data.Count > 0)
                {
                    knownTickers.Add(reference, true);
                    return true;
                }
            }
            catch (Exception)
            {
                knownTickers.Add(reference, false);
                return false;
            }

            knownTickers.Add(reference, false);
            return false;
        }
    }
}