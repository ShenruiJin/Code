﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Serialization;
using MarketDataMgr.Trees.Ext;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;
using PrismWS.IndexAlgoFeedService;
using IndexAlgoFeedService = PrismWS.IndexAlgoFeedService.IndexAlgoFeedService;
using PrismWS.Index;
using CaesarApplication.Booking;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Configuration;
using FuncFramework.Business;
using DealIndexDataTransferObject;
using CaesarApplication.DataProvider.Helpers;

namespace CaesarApplication.DataProvider.Prism
{
    public class PrismBookingManager
    {

        public string WebServiceUrlFeedProd = @"http://production-prism:19999/publish-api/feed?wsdl";
        public string WebServiceUrlIndexProd = @"http://production-prism:19999/publish-api/index?wsdl";
        public string WebServiceUrlIndexForwardProd = @"http://production-prism:19999/publish-api/indexForward?wsdl";


        public string WebServiceUrl = @"http://swdafrt07app02:19999/publish-api/feed?wsdl";
        public string WebServiceUrlIndexForward = @"http://swdafrt07app02:19999/publish-api/indexForward?wsdl";

        public Index RequestComposition(string bbgCode, DateTime date)
        {
            var requestService = new IndexPrismPublishService();

            requestService.Url = WebServiceUrlIndexProd;

            var compo = requestService.getIndexComposition(new IndexCompositionRequest
            {
                bloombergTicker = bbgCode,
                compositionDate = date.ToString("yyyy-MM-dd"),
                requestType = requestType.BBG_TICKER,
                requestTypeSpecified = true,
                publishOhlcSpecified = false
            });

            return compo;
        }

        public Index GetIndex(string bbgCode)
        {
            var requestService = new IndexPrismPublishService();

            requestService.Url = WebServiceUrlIndexProd;

            return requestService.getAllIndexes().FirstOrDefault(x => x.marketIndexProduct.bloombergCode == bbgCode);
        }

        public void Insert(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote, DateTime dataDate, Dictionary<string, TimeSerieDB> fx = null, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodeCompo = true, bool testMode = false, bool fxHedge = false, bool removeNullWeights = false)
        {
            Dictionary<string, double> ajustmentFactors = new Dictionary<string, double>();
            var composition = GetComposition(bbgCode, currency, basketIndex, currentQuote, dataDate, fx, ref ajustmentFactors, isForward, fieldUseAsLast, auditBasket, compositionDate, explodedCompo: explodeCompo, fxHedged:fxHedge);


            if(removeNullWeights)
            {
                composition.component = composition.component.Where(x => x.basketWeight != 0.0d).ToArray();
            }

            //var directoryPath = @"\\swpafrt07app01\applog2$\ext\idx_custom"/* settingsManager.PrismBasketBookingServiceDirectoryPath*/;
            var directoryPath = @"\\swpafrt07app01\applog2$\ext\idx_custom";

            var proxy = new IndexAlgoFeedService();
            proxy.Url = WebServiceUrlFeedProd;

            var xml = composition.ToSerializedString();

            var compoValuation = composition.component.Sum(x => x.priceWeight * x.closingPrice * x.forexValue * ajustmentFactors[x.listing.bloombergCode]);

            if (Math.Abs(compoValuation - currentQuote) > 1E-2)
            {
                throw new Exception(string.Format("Composition valuation is different as calculated quotes {0}/{1}", compoValuation, currentQuote));
            }

            var newFilePath = Path.Combine(directoryPath,
                string.Format((testMode ? "TEST" : "") + "request_" + composition.indexProduct.bloombergTicker + "_" + Guid.NewGuid() + "_IndexComposition.xml"));

            File.WriteAllText(newFilePath, xml);


            if (!testMode)
            {
                var res = proxy.feedIndex(composition);

                var errors = res.errors;

                if (!errors.IsNullOrEmpty())
                {
                    try
                    {
                        File.AppendAllLines(string.Format(@"K:\ED_ExcelTools\Log\CaesarIndexBatchPricer\PRISM\error_{0}.txt", DateTime.Now.ToString("yyyy-MM-dd")), errors.Select(x => x.message));
                    }
                    catch
                    {
                    }
                    
                    throw new Exception(string.Format("Failed to insert composition in PRISM [{0}] for [{1}] with errors\r\n{2}", bbgCode, composition.compositionDate, string.Join("\r\n", errors.Select(x => x.message))));
                }
                if (!res.warnings.IsNullOrEmpty())
                {
                    LoggingService.Warn(this.GetType(), string.Format("Warnings while inserting composition in PRISM [{0}] for [{1}] with errors\r\n{2}", bbgCode, composition.compositionDate, string.Join("\r\n", res.warnings.Select(x => x.message))));
                }
            }
            else
            {
                LoggingService.Warn(this.GetType(), "Composition not inserted when testMode is activated");
            }
        }

        public void Insert(indexCompositionAlgoWs composition)
        {
            var proxy = new IndexAlgoFeedService();
            proxy.Url = WebServiceUrlFeedProd;

            var res = proxy.feedIndex(composition);

            var errors = res.errors;

            if (!errors.IsNullOrEmpty())
            {
                throw new Exception(string.Format("Failed to insert composition in PRISM [{0}] for [{1}] with errors\r\n{2}", composition.indexProduct.bloombergCode, composition.compositionDate, string.Join("\r\n", errors.Select(x => x.message))));
            }
            if (!res.warnings.IsNullOrEmpty())
            {
                LoggingService.Warn(this.GetType(), string.Format("Warnings while inserting composition in PRISM [{0}] for [{1}] with errors\r\n{2}", composition.indexProduct.bloombergCode, composition.compositionDate, string.Join("\r\n", res.warnings.Select(x => x.message))));
            }
        }

        public indexCompositionAlgoWs GetComposition(string bbgCode, string currency, BasketIndex basketIndex, double currentQuote,
            DateTime dataDate, Dictionary<string, TimeSerieDB> fx, ref Dictionary<string, double> ajustmentFactors, bool isForward = false, string fieldUseAsLast = "Last", BasketIndex auditBasket = null, DateTime? compositionDate = null, bool explodedCompo = true, bool transcodeTickerToPrism = true, Dictionary<string, double> forexValues = null, bool fxHedged = false)
        {
            TimeSeriesProvider tsp = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()), true);
            tsp.PricingContext = new PricingContext(dataDate, null);

            var prismtranscoder = new PrismTranscoder();

            var indexComponents = basketIndex.LastComposition.Select(c => c.BloombergTicker).Where(c => c.Contains(IndexPathHelper.Delimiter)).ToArray();

            Dictionary<string, string[]> explodedBasketTranscoDico = new Dictionary<string, string[]>();
            BasketIndex explodedBasketIndex = basketIndex;
            var explodedAuditBasketIndex = auditBasket;

            Dictionary<string, indexCompositionAlgoWs> indexComponentsCompositions = null;
            ajustmentFactors = ajustmentFactors ?? new Dictionary<string, double>();
            Dictionary<string, IndexDTO> indexComponentsIndexInfos = null;

            var _ajustmentFactors = ajustmentFactors;

            ProjectDTO project = null;


            if (indexComponents.Any())
            {
                var indexInfos = PersistanceService.IndexProvider.GetIndexFromCode(bbgCode, UserService.CaesarSession);
                project = PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(indexInfos.id.AsArray(), UserService.CaesarSession)[indexInfos.id];

                project = PersistanceService.IndexProvider.ReadProject(project.id, UserService.CaesarSession);

                var components = BasketTools.GetComponentBaskets(tsp, dataDate, dataDate, project, basketIndex.LastComposition);
                indexComponentsIndexInfos = indexComponents.ToDictionary(x => x, x => PersistanceService.IndexProvider.GetIndexFromCode(BasketTools.GetFullPath(x, project), UserService.CaesarSession));
                var componentAudits = BasketTools.GetComponentAuditBaskets(tsp, dataDate, dataDate, project, basketIndex.LastComposition);

                explodedAuditBasketIndex = BasketTools.AggregateBaskets(componentAudits.Where(x => x.EffectiveDate == dataDate).SelectMany(x => x.Baskets).Union(auditBasket.AsArray()).ToArray());

                indexComponentsCompositions = indexComponents.Where(x => IsInternalScript(project, x, indexComponentsIndexInfos[x]) || explodedCompo).ToDictionary(x => x, x =>
                {
                    return GetComposition(indexComponentsIndexInfos[x].bloomberg_ticker,
                        indexComponentsIndexInfos[x].currency_code,
                        components[x].SelectMany(b => b.Baskets).Where(b => b.Name != BasketIndex.AuditBasketName).First(),
                        auditBasket[DataFieldsEnum.IndexQuote, x].EvaluateLast(),
                        dataDate,
                        new Dictionary<string, TimeSerieDB>(), ref _ajustmentFactors, auditBasket: explodedAuditBasketIndex,
                        transcodeTickerToPrism: transcodeTickerToPrism, forexValues: forexValues);
                });

                ajustmentFactors = _ajustmentFactors;

                explodedBasketIndex = BasketTools.GetExplodedCompositionWithWeights(dataDate, basketIndex, project, components, indexComponentsCompositions, indexComponentsIndexInfos, explodedCompo);
                explodedBasketTranscoDico = BasketTools.GetExplodedCompositionTickerTranscoDico(dataDate, basketIndex, project, components, indexComponentsCompositions, explodedCompo);
            }

            if (explodedAuditBasketIndex != null)
            {
                tsp.AuditDataBaskets = new BasketIndexList(dataDate, new List<BasketIndex> { explodedBasketIndex, explodedAuditBasketIndex });
            }

            forexValues = forexValues ?? new Dictionary<string, double>();


            IDictionary<string, string> currencies = GetCurrencies(explodedBasketIndex, project, currency, indexComponentsIndexInfos);

            if (indexComponentsIndexInfos != null)
            {
                indexComponentsIndexInfos.Where(x => !currencies.ContainsKey(x.Key)).ForEach(kv => currencies.Add(kv.Key, kv.Value.currency_code));
            }

            var componentTypesDico = explodedBasketIndex.LastComposition.ToDictionary(x => x.BloombergTicker, x => IsInternalIndex(x.BloombergTicker) ? SophisHelper.BloombergSuffixIndex : SophisHelper.GetBloombergTicker(x.BloombergTicker).Split(' ').Last());

            var prismTranscoder = !transcodeTickerToPrism ?
                explodedBasketIndex.LastComposition.ToDictionary(c => c.BloombergTicker, c => c.BloombergTicker)
                :
                prismtranscoder.GetValidPrismTickers(explodedBasketIndex.LastComposition.Select(c => c.BloombergTicker).Where(x => componentTypesDico[x] == SophisHelper.BloombergSuffixEquity).ToArray(), PrismTranscoder.NotFoundBehaviour.IncludeAsIs)
                .ToDictionary(x => x.Key, x => x.Value);

            var transcoder = prismTranscoder.ToDictionary(x => x.Key, x => x.Value);

            foreach (var instrumentNonEquity in explodedBasketIndex.LastComposition.Select(c => c.BloombergTicker).Where(x => componentTypesDico[x] != SophisHelper.BloombergSuffixEquity).ToArray())
            {
                if (!transcoder.ContainsKey(instrumentNonEquity) && instrumentNonEquity.Contains(IndexPathHelper.Delimiter))
                {
                    var indexTicker = !IsInternalScript(project, instrumentNonEquity, indexComponentsIndexInfos[instrumentNonEquity]) ? (tsp.GetIndexInfos(instrumentNonEquity).bloomberg_ticker ?? instrumentNonEquity) : instrumentNonEquity;

                    transcoder.Add(instrumentNonEquity, indexTicker);
                }
                else if (!transcoder.ContainsKey(instrumentNonEquity))
                {
                        transcoder.Add(instrumentNonEquity, instrumentNonEquity);
                }
            }

            var quoteForPerf = GetUnderlyingQuoteForPerf(basketIndex) ?? currentQuote;

            var perfContribInPercentByComponents = basketIndex.LastComposition.ToDictionary(c => c,
                c =>
                {
                    double quotationPriceFactor = 1;
                    double forexRate = 1;

                    if (fx != null)
                    {
                        var cmpCur = currencies[c.BloombergTicker];

                        if (cmpCur == null)
                        {
                            throw new ArgumentException(string.Format("Unknown currency in PRISM for {0}", c.BloombergTicker));
                        }


                        if (currency != cmpCur)
                        {
                            if (cmpCur == "GBp")
                            {
                                quotationPriceFactor = 0.01d;
                            }

                            string fxTicker;
                            double? srcFxRate = GetFxRate(explodedAuditBasketIndex, tsp, currency, fx, cmpCur.ToUpper(), 1.0d,
                                dataDate, out fxTicker);

                            var quoteFactor = GetQuoteFactor(tsp, fxTicker);

                            srcFxRate *= quoteFactor;

                            if (srcFxRate.HasValue)
                            {
                                forexRate = srcFxRate.GetValueOrDefault();
                                var log =
                                    string.Format("{0} : currency : '{1}'  , Fx : '{2}' at date : '{3}', value = {4} .",
                                        c.BloombergTicker,
                                        cmpCur,
                                        fxTicker,
                                        dataDate,
                                        forexRate);

                                Console.WriteLine(log);
                                LoggingService.Info(this.GetType(), log);
                            }
                            else if (cmpCur.ToUpper() != currency)
                            {
                                var log = string.Format("No [FX] change value for ticker :{0}, fx missing is  : {1}",
                                    c.BloombergTicker, cmpCur + currency);
                                Console.WriteLine(log);
                                LoggingService.Error(this.GetType(), log);
                            }
                        }
                    }

                    if (!forexValues.ContainsKey(c.BloombergTicker))
                    {
                        forexValues.Add(c.BloombergTicker, forexRate);
                    }

                    if (!_ajustmentFactors.ContainsKey(c.BloombergTicker))
                    {
                        _ajustmentFactors.Add(c.BloombergTicker.Contains(IndexPathHelper.Delimiter) ? c.BloombergTicker : transcoder[c.BloombergTicker], quotationPriceFactor);
                    }

                    if (c.WeightInEquity.HasValue)
                        return new BasketComponent(c.BloombergTicker, c.WeightInEquity.GetValueOrDefault()).AsArray();

                    if (c.Weight == 0.0d && !c.BloombergTicker.Contains(IndexPathHelper.Delimiter))
                        return new BasketComponent(c.BloombergTicker, 0.0d).AsArray();

                    if (c.BloombergTicker.Contains(IndexPathHelper.Delimiter) && (explodedCompo || IsInternalScript(project, c.BloombergTicker, indexComponentsIndexInfos[c.BloombergTicker])))
                    {
                        var components =
                        indexComponentsCompositions[c.BloombergTicker]
                        .component;

                        components.Where(x => !forexValues.ContainsKey(x.listing.bloombergCode)).ForEach(x => forexValues.Add(x.listing.bloombergCode, x.forexValue));

                        return components.Select(comp => new BasketComponent(comp.listing.bloombergCode, quoteForPerf * c.Weight / indexComponentsCompositions[c.BloombergTicker].indexValue * comp.priceWeight / forexRate)).ToArray();
                    }

                    return new BasketComponent(c.BloombergTicker, quoteForPerf *
                           (1.0d /
                            ((GetPrice(explodedAuditBasketIndex, c.BloombergTicker, fieldUseAsLast, GetUnderlyingPerfDate(basketIndex)) * forexRate * quotationPriceFactor) *
                             (1.0d / c.Weight)))).AsArray();
                });

            var perfContribInNbEquity = perfContribInPercentByComponents.Values.SelectMany(x => x).GroupBy(x => x.BloombergTicker).ToDictionary(x =>
            x.First().BloombergTicker,
            x => x.Sum(v => v.Weight));


            var compo = explodedBasketIndex.LastComposition.Select(x => x.BloombergTicker).Distinct().Select(c =>
                    new fpComponentAlgoWs()
                    {
                        listing =
                            new mfpAlgoWs()
                            {
                                bloombergCode = transcoder[c],
                                quotationCurrency = currencies[c]
                            },
                        adjustementFactor = 1,
                        adjustementFactorSpecified = true,
                        basketWeight = perfContribInNbEquity[c],
                        basketWeightSpecified = true,
                        priceWeight = perfContribInNbEquity[c],
                        priceWeightSpecified = true,
                        closingPrice = GetPrice(explodedAuditBasketIndex, c, fieldUseAsLast, GetUnderlyingPerfDate(basketIndex)),
                        closingPriceSpecified = true,
                        freeFloatFactor = 1,
                        freeFloatFactorSpecified = true,
                        forexValueSpecified = true,
                        forexValue = forexValues[c],
                        componentType = GetComponentTypeFromBloombergSuffix(c, prismTranscoder, componentTypesDico[c]).GetValueOrDefault(),
                        componentTypeSpecified = GetComponentTypeFromBloombergSuffix(c, prismTranscoder, componentTypesDico[c]).HasValue
                    }
            ).ToArray();

            var composition = new indexCompositionAlgoWs()
            {
                indexValue = currentQuote,
                currency = currency,
                component = compo,
                componentsCount = explodedBasketIndex.LastComposition.Count,
                compositionDate = compositionDate.GetValueOrDefault(dataDate),
                divisor = 1,
                forward = isForward,
                indexProduct =
                    new indexProductAlgoWs()
                    {
                        bloombergTicker = bbgCode,
                        bloombergCode = "",
                        closingPrice = "",
                        quotationCurrency = currency,
                        ricCode = ""
                    },
                lastUpdateDate = DateTime.Now,
            };


            composition.source = "CAESAR";
            composition.forward = false;
            composition.valueDate = composition.compositionDate;
            composition.valueDateSpecified = true;
            composition.reshuffleDate = composition.compositionDate;
            composition.reshuffleDateSpecified = true;

            if (basketIndex.CompositionMetaData != null && Math.Abs(basketIndex.CompositionMetaData.IndexLevelBase.GetValueOrDefault() - basketIndex.CompositionMetaData.InvestedPoints.GetValueOrDefault()) > 1E-2d)
            {
                composition.componentCash = basketIndex.CompositionMetaData.IndexLevelBase.GetValueOrDefault() - basketIndex.CompositionMetaData.InvestedPoints.GetValueOrDefault();
                composition.componentCashSpecified = true;

                _ajustmentFactors.Add(currency, 1.0d);
                forexValues.Add(currency, 1.0d);
            }


            if (fxHedged)
            {
                var fxHedgeComponents = new List<fpComponentAlgoWs>();

                var fxWeights = composition.component.Select(x => x.listing.quotationCurrency).Distinct()
    .ToDictionary(x => x, x => composition.component.Where(c => c.listing.quotationCurrency == x).Select(c => c.basketWeight * c.closingPrice).Sum());

                var hedgeInIndexCurrency = -composition.component.Where(x => x.listing.quotationCurrency != currency).Sum(c => c.basketWeight * c.closingPrice * _ajustmentFactors[transcoder.First(x => x.Value == c.listing.bloombergCode).Key] * c.forexValue);


                foreach (var foreignCurrency in fxWeights)
                {
                    var fxPrice = compo.First(x => x.listing.quotationCurrency == foreignCurrency.Key).forexValue;

                    var factor = foreignCurrency.Key.Last().ToString() != foreignCurrency.Key.Last().ToString().ToUpper() ? 0.01d : 1;

                    var w = (foreignCurrency.Key == currency ? (double)hedgeInIndexCurrency : foreignCurrency.Value) * factor;

                    var item = new fpComponentAlgoWs()
                    {
                        listing =
                            new mfpAlgoWs()
                            {
                                bloombergCode = currency == foreignCurrency.Key.ToUpper() ? foreignCurrency.Key.ToUpper() : currency + foreignCurrency.Key.ToUpper(),
                                quotationCurrency = foreignCurrency.Key.ToUpper()
                            },
                        adjustementFactor = 1,
                        adjustementFactorSpecified = true,
                        basketWeight = w,
                        basketWeightSpecified = true,
                        priceWeight = w,
                        priceWeightSpecified = true,
                        closingPrice = fxPrice,
                        closingPriceSpecified = true,
                        freeFloatFactor = 1,
                        freeFloatFactorSpecified = true,
                        forexValueSpecified = true,
                        forexValue = fxPrice,
                        componentType = componentType.CURRENCY,
                        componentTypeSpecified = true
                    };

                    fxHedgeComponents.Add(item);
                }

                composition.component = composition.component.Concat(fxHedgeComponents).ToArray();

                forexValues = TranscodeDico(explodedCompo, forexValues, explodedBasketTranscoDico);
                _ajustmentFactors = TranscodeDico(explodedCompo, _ajustmentFactors, explodedBasketTranscoDico);
            }
            else
            {
                forexValues = TranscodeDico(explodedCompo, forexValues, explodedBasketTranscoDico);
                _ajustmentFactors = TranscodeDico(explodedCompo, _ajustmentFactors, explodedBasketTranscoDico);
            }

            ajustmentFactors = _ajustmentFactors;

            return composition;
        }

        private static DateTime? GetUnderlyingPerfDate(BasketIndex basketIndex)
        {
            return basketIndex.CompositionMetaData != null ? basketIndex.CompositionMetaData.DateBase : null;
        }

        private static double? GetUnderlyingQuoteForPerf(BasketIndex basketIndex)
        {
            return basketIndex.CompositionMetaData != null ? basketIndex.CompositionMetaData.InvestedPoints : null;
        }

        private static bool IsInternalScript(ProjectDTO project, string ticker, IndexDTO idxInfos)
        {
            return project != null && (string.IsNullOrEmpty(idxInfos.bloomberg_ticker) || project.indexes.Any(i => i.ticker == ticker));
        }

        private Dictionary<string, double> TranscodeDico(bool explodedCompo, Dictionary<string, double> toTranscode, Dictionary<string, string[]> transcodingDico)
        {
            return toTranscode.Distinct().Select(x => new KeyValuePair<string, double>(!explodedCompo && transcodingDico.ContainsKey(x.Key) ? transcodingDico[x.Key].First() : x.Key, x.Value))
                .GroupBy(x => x.Key)
                .Select(x => x.First())
                .ToDictionary(x => x.Key, x => x.Value);
        }

        private bool IsInternalIndex(string ticker)
        {
            return ticker.Contains(IndexPathHelper.Delimiter.ToString()) || (!ticker.Contains(" ") && ticker.StartsWith("NXS"));
        }

        private componentType? GetComponentTypeFromBloombergSuffix(string ticker, Dictionary<string, string> prismTranscoDico, string bloombergSuffix)
        {
            switch (bloombergSuffix)
            {
                case "Equity":
                    {
                        if(!prismTranscoDico.ContainsKey(ticker))
                        {
                            return componentType.FOND;
                        }

                        return componentType.EQUITY;
                    }
                case "Index":
                    return componentType.INDEX;
            }

            if (SophisHelper.IsCurrencyTicker(ticker))
                return componentType.CURRENCY;

            return null;
        }

        private double GetPrice(BasketIndex explodedAuditBasketIndex, string bloombergTicker, string fieldUseAsLast, DateTime? priceDate = null, componentType componentType = componentType.EQUITY)
        {
            if (explodedAuditBasketIndex.Data.Any(x => x.Key == fieldUseAsLast && explodedAuditBasketIndex.Data[fieldUseAsLast].Any(v => v.Instrument == bloombergTicker)))
            {
                return explodedAuditBasketIndex[fieldUseAsLast, bloombergTicker].EvaluateLast(priceDate);
            }

            if (IsInternalIndex(bloombergTicker))
            {
                if (explodedAuditBasketIndex.Data.Any(x => x.Key == DataFieldsEnum.IndexQuote.ToString() && explodedAuditBasketIndex.Data[DataFieldsEnum.IndexQuote.ToString()].Any(v => v.Instrument == bloombergTicker)))
                {
                    return explodedAuditBasketIndex[DataFieldsEnum.IndexQuote, bloombergTicker].EvaluateLast(priceDate);
                }

                var internalIdxInfos = PersistanceService.IndexProvider.GetIndexFromCode(bloombergTicker, UserService.CaesarSession);
                var project = PersistanceService.IndexProvider.GetProjectDtosFromIndexIds(internalIdxInfos.id.AsArray(), UserService.CaesarSession).First().Value;

                var globalTicker = DataPath.Create(project.project_name, internalIdxInfos.ticker);

                if (explodedAuditBasketIndex.Data.Any(x => x.Key == DataFieldsEnum.IndexQuote.ToString() && explodedAuditBasketIndex.Data[DataFieldsEnum.IndexQuote.ToString()].Any(v => v.Instrument == globalTicker)))
                {
                    return explodedAuditBasketIndex[DataFieldsEnum.IndexQuote, globalTicker].EvaluateLast(priceDate, true);
                }

                var localTicker = internalIdxInfos.ticker;

                if (explodedAuditBasketIndex.Data.Any(x => x.Key == DataFieldsEnum.IndexQuote.ToString() && explodedAuditBasketIndex.Data[DataFieldsEnum.IndexQuote.ToString()].Any(v => v.Instrument == localTicker)))
                {
                    return explodedAuditBasketIndex[DataFieldsEnum.IndexQuote, localTicker].EvaluateLast(priceDate);
                }
            }

            return explodedAuditBasketIndex[DataFieldsEnum.SettlementPrice, bloombergTicker].EvaluateLast(priceDate);
        }

        private double GetQuoteFactor(ITimeSeriesProviderClientSide tsp, string fxTicker)
        {
            if (fxTicker == null)
                return 1.0d;

            var quoteFactorTs = tsp.Load(fxTicker, DataFieldsEnum.QuoteFactor);

            if(!quoteFactorTs.Any())
            {
                throw new Exception("QuoteFactor not available for " + fxTicker);
            }

            return quoteFactorTs.Any() ? quoteFactorTs.EvaluateLast() : 1.0d;
        }

        public static double? GetFxRate(BasketIndex auditData, ITimeSeriesProviderClientSide tsp, string currency, Dictionary<string, TimeSerieDB> fx, string cmpCur, double quotationPriceDivisor, DateTime compoDate, out string fxTicker)
        {
            if (currency == cmpCur)
            {
                fxTicker = null;
                return 1.0d;
            }

            if (tsp == null)
            {
                fxTicker = fx.Where(f => f.Key.StartsWith(cmpCur + currency)).Select(x => x.Key).FirstOrDefault();

                return fxTicker != null ? fx[fxTicker].Evaluate() / quotationPriceDivisor : (double?)null;
            }
            else if (string.IsNullOrWhiteSpace(currency) || string.IsNullOrWhiteSpace(cmpCur))
            {
                fxTicker = null;
                return null;
            }
            else
            {
                var lastData = auditData.Data[DataFieldsEnum.Last.ToString()];
                fxTicker = lastData.Where(f => f.Instrument.ToUpper().Contains(cmpCur.ToUpper()) && f.Instrument.ToUpper().Contains(currency.ToUpper())).Select(x => x.Instrument).FirstOrDefault();

                if (!fxTicker.IsNullOrEmpty())
                {
                    var fixingType = fxTicker.Substring(fxTicker.Contains(" ") ? fxTicker.IndexOf(" ") : 0).Trim();
                    fxTicker = (cmpCur + currency + " " + fixingType).Trim();


                    var classicWayTs = tsp.Load(fxTicker, DataFieldsEnum.Last, compoDate, compoDate);


                    if (classicWayTs != null && classicWayTs.X.Any())
                    {
                        return classicWayTs != null && classicWayTs.Any() ? classicWayTs.Evaluate() / quotationPriceDivisor : (double?)null;
                    }
                    else
                    {
                        fxTicker = (currency + cmpCur + " " + fixingType).Trim();
                        var inverseWayTs = tsp.Load(fxTicker, DataFieldsEnum.Last, compoDate, compoDate);


                        return inverseWayTs != null && inverseWayTs.Any() ? (1.0d / inverseWayTs.Evaluate()) : (double?)null;
                    }
                }
                else
                {
                    var indexCurrencyPairs = lastData.Where(f => f.Instrument.ToUpper().Contains(cmpCur.ToUpper())).ToArray();
                    var underlyingCurrencyPairs = lastData.Where(f => f.Instrument.ToUpper().Contains(currency.ToUpper())).ToArray();

                    var indexCurrencyPairsSecondCurrency = indexCurrencyPairs.Select(x => x.Instrument.Substring(3, 3)).ToArray();
                    var underlyingCurrencyPairsSecondCurrency = underlyingCurrencyPairs.Select(x => x.Instrument.Substring(3, 3)).ToArray();

                    var matchingCurrency = indexCurrencyPairsSecondCurrency.Intersect(underlyingCurrencyPairsSecondCurrency).First();

                    var matchingIndexCurrencyPair = indexCurrencyPairs.Where(f => f.Instrument.ToUpper().Contains(matchingCurrency.ToUpper())).ToArray();
                    var matchingUnderlyingCurrencyPair = underlyingCurrencyPairs.Where(f => f.Instrument.ToUpper().Contains(cmpCur.ToUpper()) && f.Instrument.ToUpper().Contains(matchingCurrency.ToUpper())).ToArray();



                    return null;
                }
            }
        }


        public static IDictionary<string, string> GetCurrencies(BasketIndex basketIndex, ProjectDTO project, string defaultCurrency, Dictionary<string, IndexDTO> idxInfos)
        {
            var timeSeriesProvider = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()),
                parameters: new TimeSeriesProviderParameters
                {
                    DataHandlersToUse = new string[] { "SOPHIS", "PRISM", "PRISM_INSTRUMENT_INFOS", "INDEX_VALUES" }
                });
            timeSeriesProvider.PricingContext = new PricingContext(DateTime.Today, null);


            var tickers = basketIndex.LastComposition.Select(_ => _.BloombergTicker).Where(x => idxInfos == null || (!idxInfos.ContainsKey(x) || !IsInternalScript(project, x, idxInfos[x]))).ToList();

            var currencyTSs =
                timeSeriesProvider.Load(tickers, new[] { DataFieldsEnum.Currency }, DateTime.Today.AddDays(-30),
                    DateTime.Today);

            return tickers.ToDictionary(t => t, t =>
            {
                string value = currencyTSs.Any(x => x.Instrument == t) ? currencyTSs[t, DataFieldsEnum.Currency].EvaluateAsString() : null;
                if (null == value || value == string.Empty)
                {
                    value = basketIndex[DataFieldsEnum.Currency, t].EvaluateAsString();
                }
                return string.IsNullOrEmpty(value) ? defaultCurrency : value;
            });
        }

        private static string GetCurrency(BasketIndex basketIndex, IBasketComponent c)
        {
            var timeSeriesProvider = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()),
                parameters: new TimeSeriesProviderParameters
                {
                    DataHandlersToUse = new string[] { "PRISM", "PRISM_POLLING" }
                });
            timeSeriesProvider.PricingContext = new PricingContext(DateTime.Today, null);

            var currency =
                timeSeriesProvider.Load(c.BloombergTicker, DataFieldsEnum.Currency, DateTime.Today.AddDays(-30),
                    DateTime.Today).EvaluateAsString();

            return currency ?? basketIndex[DataFieldsEnum.Currency, c.BloombergTicker].EvaluateAsString();
        }

        public PrismWS.IndexPrismPublishService.Index GetComposition(string bbgCode)
        {

            //var directoryPath = @"\\swpafrt07app01\applog2$\ext\idx_custom"/* settingsManager.PrismBasketBookingServiceDirectoryPath*/;
            var proxy = new PrismWS.IndexPrismPublishService.IndexPrismPublishService();
            proxy.Url = WebServiceUrlIndexForwardProd;
            var obj = new PrismWS.IndexPrismPublishService.IndexCompositionRequest()
            {
                requestTypeSpecified = true,
                requestType = PrismWS.IndexPrismPublishService.requestType.BBG_TICKER,
                bloombergTicker = bbgCode,
                compositionDate = DateTime.Today.AddDays(0).ToString("yyyy-MM-dd")
            };


            var fileContent = obj.ToSerializedString();

            return proxy.getIndexComposition(obj);
        }

    }
}
