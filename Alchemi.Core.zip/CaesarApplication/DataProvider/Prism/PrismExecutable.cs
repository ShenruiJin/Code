﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.Prism
{
    public abstract class PrismExecutable<T> : ProviderExecutable where T : IMarketData
    {
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null,
            ILoadingContext loadingContext = null)
        {
            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.MaxValue);

            var tickersAsArray = tickers as string[] ?? tickers.ToArray();
            List<T> marketDatas = Load(tickersAsArray, startDateOrDefault, endDateOrDefault, loadingContext);

            return tickersAsArray.Select(ticker => new TimeSerieDB(GetKeyValuePairs(ticker, startDateOrDefault, endDateOrDefault, marketDatas), ticker, field, loadingContext)).ToArray();
        }

        protected abstract KeyValuePair<DateTime, IMarketData>[] GetKeyValuePairs(string ticker, DateTime startDate, DateTime endDate, List<T> dataItems);

        protected abstract List<T> Load(string[] tickers, DateTime startDateOrDefault, DateTime endDateOrDefault, ILoadingContext loadingContext);
    }
}