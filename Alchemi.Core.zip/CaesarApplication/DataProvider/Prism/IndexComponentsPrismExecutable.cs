﻿using System;
using System.Collections.Generic;
using System.Linq;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using PricingBase.Index;
using GlobalDerivativesApplications.Prism.Polling;
using GlobalDerivativesApplications.Prism.RequestApi;
using GlobalDerivativesApplications.Serialization;
using System.Text.RegularExpressions;
using System.IO;
using System.Globalization;
using System.Xml;
using System.Configuration;
using CaesarApplication.Service.Configuration;
using System.Text;
using CaesarCommon.Configuration;
using PricingBase.Maths.Optimizer;

namespace CaesarApplication.DataProvider.Prism
{
    /// <summary>
    /// Prism provider for index composition
    /// </summary>
    [Serializable]
    public class IndexComponentsPrismExecutable : ProviderExecutable
    {
        /// <summary>
        /// Entry point to the TimeSeriesProvider mandatory to load Last/Close curves
        /// </summary>
        protected IDataHandler ProviderDataHandler = null;

        /// <summary>
        /// Main Ctor.
        /// </summary>
        public IndexComponentsPrismExecutable(IDataHandler providerDataHandler)
        {
            _fields = new List<DataFieldsEnum>
            {
                DataFieldsEnum.IndexcomponentsWeightsAndPrices,
                DataFieldsEnum.IndexComponents
            };

            ProviderDataHandler = providerDataHandler;
        }

        /// <summary>
        /// Main load
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null,
                                                            DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            var id = Guid.NewGuid();

            var directory = new CaesarSettingsManager().OptionFilesDirectoryPath ??
                      AppDomain.CurrentDomain.BaseDirectory;

            var startDateOrDefault = startDate.GetValueOrDefault();
            var endDateOrDefault = endDate.GetValueOrDefault(DateTime.MaxValue);

            using (var prismPollingManager = new PrismPollingManager())
            {
                string FileRegexString = @".*" + PrismConstants.DateRegexPattern + @"(_" + (tickers.Count() == 1 ? tickers.First() : string.Join("|", tickers)) + @")?IndexComposition\.xml$";
                Regex FileRegex = new Regex(FileRegexString);

                var eligibleFiles = PrismHelper.GetEligibleFilesOnTickers(FileRegex, directory, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), tickers);

                var indexComponents = ParseIndexXml(tickers.ToList(), startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), eligibleFiles);

                IList<TimeSerieDB> priceTimeSeries = new List<TimeSerieDB>();

                if (field == DataFieldsEnum.IndexcomponentsWeightsAndPrices)
                {

                    // All tickers in compositions
                    var indexTickers = indexComponents.Values.SelectMany(
                            o => o.Values.SelectMany(
                                p => p.Components.Select(
                                    q => q.Reference)))
                                    .Distinct().ToList();

                    // Load spots
                    priceTimeSeries = ProviderDataHandler.Load(
                        indexTickers,
                        DataFieldsEnum.Last.AsArray(),
                        startDate,
                        endDate,
                        loadingContext);
                }

                return SetDataComponent(indexComponents, priceTimeSeries, field, loadingContext);
            }
        }

        /// <summary>
        /// Create request file in Prism polling folder
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public string GetIndexDescriptionRequestContent(string[] tickers, DateTime startDate, DateTime endDate)
        {
            var prismRequest = new PrismRequest
            {
                ApplicationName = PrismConstants.CallingAppName,
                UserName = Environment.UserName,
                CodeType = PrismConstants.CodeTypeBloomberg,
                DateRange = PrismHelper.GetNormalizeDateRange(startDate, endDate),
                Service = PrismConstants.ServiceIndexComponents,
                Product = PrismConstants.ProductIndex,
                RequestTime = DateTime.Today,
                Codes = tickers
            };

            return prismRequest.ToSerializedString();
        }

        /// <summary>
        /// Parse Index Prism files
        /// </summary>
        /// <typeparam name="DateTime"></typeparam>
        /// <typeparam name="IndexComponents"></typeparam>
        /// <param name=""></param>
        /// <param name="tickers"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="filePaths"></param>
        /// <returns></returns>
        protected IDictionary<string, IDictionary<DateTime, IndexComponents>> ParseIndexXml(IList<string> tickers, DateTime startDate, DateTime endDate, IList<string> filePaths)
        {
            IDictionary<string, IDictionary<DateTime, IndexComponents>> indexComponents = new Dictionary<string, IDictionary<DateTime, IndexComponents>>();

            foreach (string filePath in filePaths)
            {
                // Case when requesting one date, if we have our data we can yield the result
                if (startDate == endDate && indexComponents.Keys.Count == tickers.Count)
                {
                    return indexComponents;
                }

                if (File.Exists(filePath))
                {
                    using (var resultStream = File.OpenText(filePath).BaseStream)
                    {
                        ParseIndexXml(tickers, startDate, endDate, resultStream, indexComponents);
                        resultStream.Close();
                    }
                }
                else
                {
                    log4net.LogManager.GetLogger(GetType()).Error("Response file " + filePath + " not found");
                }
            }

            return indexComponents;
        }

        /// <summary>
        /// Parse Index Prism polling result from memory
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="resultContent"></param>
        /// <returns></returns>
        protected IDictionary<string, IDictionary<DateTime, IndexComponents>> ParseIndexXml(IList<string> tickers, DateTime startDate, DateTime endDate, string resultContent)
        {
            IDictionary<string, IDictionary<DateTime, IndexComponents>> indexComponents = new Dictionary<string, IDictionary<DateTime, IndexComponents>>();

            using (var resultStream =  new MemoryStream(Encoding.UTF8.GetBytes(resultContent)))
            {
                ParseIndexXml(tickers, startDate, endDate, resultStream, indexComponents);
            }

            return indexComponents;
        }

        /// <summary>
        /// Parse content of Prism result
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="resultStream"></param>
        /// <param name="indexComponents"></param>
        protected void ParseIndexXml(IList<string> tickers, DateTime startDate, DateTime endDate, Stream resultStream, IDictionary<string, IDictionary<DateTime, IndexComponents>> indexComponents)
        {
            var indexDocument = new XmlDocument();
            indexDocument.Load(resultStream);

            XmlNodeList nodes = indexDocument.DocumentElement.SelectNodes("/indexCompositionResponse/listIndexResponse/index");

            foreach (XmlNode node in nodes)
            {
                string currentTickerNode = node.Attributes["code"].Value;

                // Case when requesting one date, if we have our data we can yield the result
                if(startDate == endDate && indexComponents.Keys.Count == tickers.Count)
                {
                    return;
                }

                if (tickers.Contains(currentTickerNode))
                {
                    foreach (XmlNode compositionNode in node.SelectNodes("compositions/composition"))
                    {
                        DateTime.TryParse(compositionNode.Attributes["startDate"].Value, out DateTime startDateNode);
                        DateTime.TryParse(compositionNode.Attributes["endDate"].Value, out DateTime endDateNode);
                        double.TryParse(compositionNode.Attributes["adjustedDivisor"].Value, out double adjustedDivisor);
                        string currency = compositionNode.Attributes["currency"].Value;
                        double.TryParse(compositionNode.Attributes["value"].Value, out double indexValue);

                        if ((startDate.Date >= startDateNode.Date && startDate.Date <= endDateNode.Date)
                            || (startDateNode.Date <= endDate.Date && endDate.Date <= endDateNode.Date))
                        {
                            IndexComponents components = new IndexComponents(currentTickerNode, IndexComponentWeight_Type.Absolute, 1.0, currency);

                            if (!indexComponents.ContainsKey(currentTickerNode))
                            {
                                indexComponents.Add(currentTickerNode, new Dictionary<DateTime, IndexComponents>());
                            }

                            // In case, there are multiple compositions matching a date
                            if (!indexComponents[currentTickerNode].ContainsKey(endDateNode.Date))
                            {
                                var dates = GetDatesInPeriod(startDateNode.Date, endDateNode.Date);

                                foreach (var date in dates)
                                {
                                    indexComponents[currentTickerNode].Add(date.Date, components);
                                }

                                foreach (XmlNode componentNode in compositionNode.SelectNodes("components/component"))
                                {
                                    if (componentNode.Attributes["code"] != null && componentNode.Attributes["weight"] != null)
                                    {
                                        double weightCoefficient = 0.0;
                                        double.TryParse(componentNode.Attributes["weightCoefficient"].Value,
                                            NumberStyles.Float,
                                            CultureInfo.InvariantCulture,
                                            out weightCoefficient);
                                        double weight = 0.0;
                                        double.TryParse(componentNode.Attributes["weight"].Value,
                                            NumberStyles.Float,
                                            CultureInfo.InvariantCulture,
                                            out weight);

                                        if (Algebra.Compare(weightCoefficient, weight / adjustedDivisor, InitialiseData.m_tolerance_data))
                                        {
                                            components.Components.Add(new IndexComponent(componentNode.Attributes["code"].Value,
                                                weightCoefficient, -1.0, weightCoefficient));
                                        }
                                        else
                                        {
                                            components.Weights_Type = IndexComponentWeight_Type.NA;
                                            components.Components.Add(new IndexComponent(componentNode.Attributes["code"].Value,
                                                double.NaN, -1.0, double.NaN));
                                            LoggingService.Warn(GetType(), String.Format("Incoherent data from Prism for index {0} at the date {1} for {2} weight {3}, adjusted divisor {4}, weightCoefficient {5}", 
                                                currentTickerNode , endDateNode.Date, componentNode.Attributes["code"].Value, weight, adjustedDivisor, weightCoefficient));
                                        }

                                        
                                    }
                                }
                            }
                            else
                            {
                                LoggingService.Warn(GetType(),
                                    "A composition already exists for the instrument "
                                    + currentTickerNode
                                    + " at the date "
                                    + endDateNode.Date);
                            }
                        }
                    }

                    if (indexComponents.ContainsKey(currentTickerNode))
                    {
                        indexComponents[currentTickerNode] = indexComponents[currentTickerNode].OrderBy(o => o.Key).ToDictionary(o => o.Key, o => o.Value);
                    }
                }
            }
        }

        /// <summary>
        /// Retrives dates in a period described by two dates
        /// </summary>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="removeWeekend"></param>
        /// <returns></returns>
        protected IList<DateTime> GetDatesInPeriod(DateTime startDate, DateTime endDate, bool removeWeekend = true)
        {
            IList<DateTime> allDates = new List<DateTime>();

            for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            {
                if (date != startDate && date.DayOfWeek != DayOfWeek.Sunday && date.DayOfWeek != DayOfWeek.Saturday)
                {
                    allDates.Add(date);
                }
            }

            return allDates;
        }

        /// <summary>
        /// Set spot and weight in index components and return a list of TimeSerie
        /// </summary>
        /// <param name="indexComponents"></param>
        /// <param name="priceComponentsTimeSeries"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        protected IList<TimeSerieDB> SetDataComponent(IDictionary<string, IDictionary<DateTime, IndexComponents>> indexComponents, IList<TimeSerieDB> priceComponentsTimeSeries, DataFieldsEnum field, ILoadingContext loadingContext = null)
        {
            if (priceComponentsTimeSeries.Count > 0)
            {
                indexComponents.Values.ForEach(
                    o =>
                        o.ForEach(
                            p =>
                                SetSpotAndWeight(p.Key, p.Value, priceComponentsTimeSeries)));
            }

            TimeSeries timeSeries = new TimeSeries();

            foreach (string index in indexComponents.Keys)
            {
                TimeSerieDB ts = new TimeSerieDB(indexComponents[index].Keys.ToList(), 
                    indexComponents[index].Values.Select(o => (IMarketData)o).ToList(), 
                    index, 
                    field, 
                    loadingContext);

                timeSeries.Add(ts);
            }

            return timeSeries;
        }

        /// <summary>
        /// Set spot and weight for each component
        /// </summary>
        /// <param name="date"></param>
        /// <param name="components"></param>
        /// <param name="spotTimeSeries"></param>
        private void SetSpotAndWeight(DateTime date, IndexComponents components, IList<TimeSerieDB> spotTimeSeries)
        {
            if (components.Weights_Type != IndexComponentWeight_Type.Absolute)
            {
                return;
            }
            double totalWeight = 0.0;

            TimeSeries timeSeries = new TimeSeries(spotTimeSeries);

            foreach (IndexComponent component in components.Components)
            {
                component.Value = timeSeries[component.Reference, DataFieldsEnum.Last].Evaluate(date);
                totalWeight += component.Value * component.Weight;
            }

            if (totalWeight > 0.0)
            {
                foreach (IndexComponent component in components.Components)
                {
                    component.Weight = component.Value * component.Weight / totalWeight;
                }
                components.Weights_Type = IndexComponentWeight_Type.Percentage;
            }
        }
    }
}
