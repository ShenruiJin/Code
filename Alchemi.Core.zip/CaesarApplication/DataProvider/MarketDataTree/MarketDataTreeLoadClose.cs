﻿//using GlobalDerivativesApplications.Data;
//using GlobalDerivativesApplications.Data.MarketData;
//using GlobalDerivativesApplications.DynamicDataExchange;
//using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
//using GlobalDerivativesApplications.FinancingTools.Constants;
//using MarketDataMgr.Trees;
//using MarketDataMgr.Trees.Ext;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;

//namespace PricingBase.TimeSeriesProvider.MarketDataTree
//{
//    /// <summary>
//    /// Load a close from the cache
//    /// </summary>
//    public class MarketDataTreeLoadClose : IProviderExecutable
//    {
//        /// <summary>
//        /// Current cache
//        /// </summary>
//        private OverloadedMarketDataTree Tree;

//        /// <summary>
//        /// Constructor
//        /// </summary>
//        /// <param name="tree"></param>
//        public MarketDataTreeLoadClose(OverloadedMarketDataTree tree)
//        {
//            Tree = tree;
//        }

//        public DDETimeSerie<MarketDataProperty> Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
//        {
//            MarketDataProperty property;

//            Tree.OriginalTree.Tree.TryFindProperty(field.ToString(), out property);

//            if (property != null)
//            {
//                return (DDETimeSerie<MarketDataProperty>)property.Value;
//            }

//            return null;
//        }

//        public IList<DDETimeSerie<MarketDataProperty>> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
//        {
//            throw new NotImplementedException();
//        }

//        public void Save(IList<DDETimeSerie<MarketDataProperty>> timeSeries)
//        {
//            throw new NotImplementedException();
//        }

//        public IList<DataFieldsEnum> SupportedFields
//        {
//            get { throw new NotImplementedException(); }
//        }
//    }
//}
