﻿//using MarketDataMgr.Trees;
//using MarketDataMgr.Trees.Ext;
//using System;
//using System.Collections.Generic;
//using System.Linq;
//using GlobalDerivativesApplications.Data;
//using GlobalDerivativesApplications.Data.MarketData;
//using GlobalDerivativesApplications.DynamicDataExchange;
//using GlobalDerivativesApplications.FinancingTools.Constants;

//namespace PricingBase.TimeSeriesProvider.MarketDataTree
//{
//    public class MarketDataTreeSave : IProviderExecutable
//    {
//        private OverloadedMarketDataTree _tree;

//        /// <summary>
//        /// Constructor
//        /// </summary>
//        /// <param name="tree"></param>
//        public MarketDataTreeSave(OverloadedMarketDataTree tree)
//        {
//            _tree = tree;
//        }

//        public DDETimeSerie<MarketDataProperty> Load(string ticker, GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
//        {
//            throw new NotImplementedException();
//        }

//        public IList<DDETimeSerie<MarketDataProperty>> Load(IEnumerable<string> tickers, GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
//        {
//            throw new NotImplementedException();
//        }

//        public void Save(IList<DDETimeSerie<MarketDataProperty>> timeSeries)
//        {
//            foreach (var timeSerie in timeSeries)
//            {
//                MarketDataProperty propertyToAdd = new MarketDataProperty();
//                MarketDataList marketDataList = new MarketDataList(timeSerie.Y.ToList());

//                //propertyToAdd()

//                DataTree<MarketDataProperty> typeTree;
//                string typeTreePath = MarketDataLabelsConstants.MarketData +
//                                      MarketDataMgr.Trees.MarketDataTree.PathDelimiter + 
//                                      timeSerie.Field;

//                if (!_tree.OriginalTree.Tree.TryFindSubTree(typeTreePath, out typeTree))
//                {
//                    _tree.OriginalTree.Tree.AddSubTree(MarketDataLabelsConstants.MarketData, timeSerie.Field.ToString());
//                }

//                DataTree<MarketDataProperty> tickerTree;
//                string tickerTreePath = MarketDataLabelsConstants.MarketData +
//                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                                        timeSerie.Field +
//                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                                        timeSerie.Instrument;

//                if (!_tree.OriginalTree.Tree.TryFindSubTree(tickerTreePath, out tickerTree))
//                {
//                    _tree.OriginalTree.Tree.AddSubTree(typeTreePath, timeSerie.Instrument);
//                }

//                //DataTree<MarketDataProperty> historyTree;
//                //string historyTreePath = MarketDataLabelsConstants.MarketData +
//                //                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                //                        timeSerie.Field +
//                //                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                //                        timeSerie.Instrument +
//                //                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                //                        MarketDataLabelsConstants.History;

//                //if (!_tree.OriginalTree.Tree.TryFindSubTree(historyTreePath, out historyTree))
//                //{
//                //    _tree.OriginalTree.Tree.AddSubTree(typeTreePath, timeSerie.Instrument);
//                //}

//                MarketDataProperty property;
//                string historyTreePath = MarketDataLabelsConstants.MarketData +
//                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                                        timeSerie.Field +
//                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                                        timeSerie.Instrument +
//                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
//                                        MarketDataLabelsConstants.History;
//                if (!_tree.OriginalTree.Tree.TryFindProperty(historyTreePath, out property))
//                {
//                    _tree.OriginalTree.Tree.AddProperty(historyTreePath, MarketDataLabelsConstants.History, marketDataList);
//                }
//            }
//        }

//        public IList<GlobalDerivativesApplications.DynamicDataExchange.V2.Fields.DataFieldsEnum> SupportedFields
//        {
//            get { throw new NotImplementedException(); }
//        }
//    }
//}
