﻿using System;
using System.Collections.Generic;
using System.Linq;
using FuncFramework.Business;
using GlobalDerivativesApplications.Data;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.FinancingTools.Constants;
using MarketDataMgr.Trees;
using OverloadedMarketDataTree = MarketDataMgr.Trees.Ext.OverloadedMarketDataTree;
using PricingBase.DataProvider;


namespace CaesarApplication.DataProvider.MarketDataTree
{
    public static class MarketDataTreeUtils
    {
        public static void ClearData(this DataTree<MarketDataProperty> tree, DataFieldsEnum field, string[] tickers = null, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext context = null)
        {
            foreach (var ticker in tickers ?? GetAvailableTickersForField(tree, field, context))
            {
                MarketDataProperty property;

                var historyPath = GetHistoryPath(ticker, field, context);

                var historyDirPath = GetHistoryPath(ticker, field, context);
                var propertyNode = GetHistoryNode(context);

                tree.TryFindProperty(historyPath, out property);

                if (property != null && property.Value is TimeSerieDB)
                {
                    TimeSerieDB timeSerie = property.Value as TimeSerieDB;
                    if (startDate.HasValue || endDate.HasValue)
                    {
                        foreach (var date in timeSerie.GetX(startDate, endDate, true, true))// timeSerie.GetPeriod(startDate, endDate).X)
                        {
                            timeSerie.Remove(new KeyValuePair<DateTime, IMarketData>(date, timeSerie[date]));
                        }
                    }
                    else
                    {
                        tree.RemoveSubTree(GetTreePath(ticker, field));
                        tree.RemoveProperty(historyDirPath, propertyNode);
                    }
                }
            }
        }

        public static void ClearData(this DataTree<MarketDataProperty> tree, DataFieldsEnum field)
        {
            var tickers = GetAvailableTickersForField(tree, field, null).ToList();
            tickers.ForEach(t=>
            {
                var path = GetTreePath(t, field);
                if (path != null)
                    tree.RemoveSubTree(path);
            });
        }

        public static TimeSerieDB[] GetCustomDataFromTree(DataTree<MarketDataProperty> targetedTree, string[] indexPaths)
        {
            List<TimeSerieDB> result = new List<TimeSerieDB>();

            DataTree<MarketDataProperty> marketDataTree;

            if (targetedTree.TryFindSubTree(MarketDataLabelsConstants.MarketData, out marketDataTree))
            {
                foreach (var treeKeyVal in marketDataTree.SubTrees)
                {
                    DataFieldsEnum field;

                    if (Enum.TryParse(treeKeyVal.Key, out field))
                    {
                        foreach (var indexPath in indexPaths)
                        {
                            string fieldTreePath = GetTreePath(indexPath, field);

                            DataTree<MarketDataProperty> fieldTree;
                            if (targetedTree.TryFindSubTree(fieldTreePath, out fieldTree))
                            {
                                result.AddRange(fieldTree.SubTrees.Where(t => t.Key != MarketDataLabelsConstants.History).SelectMany(t => GetAllChildrenTimeSeries(t.Value)));
                            }
                        }
                    }
                }
            }

            return result.ToArray();
        }

        private static IEnumerable<TimeSerieDB> GetAllChildrenTimeSeries(DataTree<MarketDataProperty> tree)
        {
            var res = new List<TimeSerieDB>();

            foreach (var property in tree.Properties)
            {
                TimeSerieDB ts = property.Value.Value as TimeSerieDB;

                if (ts != null)
                {
                    res.Add(ts);
                }
            }

            foreach (var subTree in tree.SubTrees)
            {
                res.AddRange(GetAllChildrenTimeSeries(subTree.Value));
            }

            return res;
        }

        private static IEnumerable<string> GetAvailableTickersForField(DataTree<MarketDataProperty> tree, DataFieldsEnum field, ILoadingContext context)
        {
            DataTree<MarketDataProperty> fieldSubTree;

            if (tree.TryFindSubTree(
                MarketDataLabelsConstants.MarketData +
                MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                field, out fieldSubTree))
            {
                return fieldSubTree.SubTrees.Select(x => x.Key);
            }

            return new string[0];
        }

        /// <summary>
        /// Format MarketDataTree path from a ticker and a field
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <returns></returns>
        public static string GetHistoryPath(string ticker, DataFieldsEnum field, ILoadingContext context = null)
        {
            string propertyNode = GetHistoryNode(context);

            string path =
                GetTreePath(ticker, field) +
                MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                propertyNode;

            return path;
        }

        public static string GetTreePath(string ticker, DataFieldsEnum field)
        {
            if (ticker == null)
                return string.Empty;

            var result = GetDataTreePath(field) +
                    (ticker.StartsWith(MarketDataMgr.Trees.MarketDataTree.PathDelimiter.ToString())
                    ?
                    ticker:MarketDataMgr.Trees.MarketDataTree.PathDelimiter + ticker);

            return result;
        }

        private static string GetDataTreePath(DataFieldsEnum field)
        {
            return GetDataTreePath(field.ToString());
        }

        private static string GetDataTreePath(string field)
        {
            return MarketDataLabelsConstants.MarketData +
                   MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                   field;
        }

        public static string GetHistoryNode(ILoadingContext context = null)
        {
            if (context == null || context.IndexId == 0)
            {
                return MarketDataLabelsConstants.History;
            }
            return MarketDataLabelsConstants.History + " _ " + context.IndexId;
        }

        public static MarketDataMgr.Trees.MarketDataTree CreateTreeToSave(
            MarketDataMgr.Trees.MarketDataTree marketDataTree, params DataFieldsEnum[] excludedFields)
        {
            return CreateTreeToSave(marketDataTree, excludedFields.Select(x => x.ToString()).ToArray());
        }

        public static OverloadedMarketDataTree Merge(params OverloadedMarketDataTree[] marketDataTrees)
        {
            var res = marketDataTrees.First();

            foreach (var tree in marketDataTrees.Skip(1).ToArray())
            {
                res.Merge(tree);
            }

            return res;
        }

        public static MarketDataMgr.Trees.MarketDataTree CreateTreeToSave(MarketDataMgr.Trees.MarketDataTree marketDataTree, params string[] excludedFields)
        {
            var res = new MarketDataMgr.Trees.MarketDataTree();

            res.Tree.AddAllSubTrees(MarketDataLabelsConstants.MarketData);

            foreach (var subTree in marketDataTree.Tree.SubTrees.First().Value.SubTrees)
            {
                if (!excludedFields.Contains(subTree.Key))
                {
                    if (!res.Tree.AddSubTree(MarketDataLabelsConstants.MarketData, subTree.Value))
                    { //// the tree already exists, just merge it
                        subTree.Value.MergeInto(res.Tree.FindSubTree(MarketDataLabelsConstants.MarketData).FindSubTree(subTree.Key));
                    }
                }
            }

            return res;
        }

        /// <summary>
        /// to integrate into GDA quickly
        /// </summary>
        private class MergeTask<T>
        {
            public DataTree<T> Src { get; set; }
            public DataTree<T> Dst { get; set; }
        }

        /// <summary>
        /// to integrate into GDA quickly
        /// </summary>
        public static void MergeInto<T>(this DataTree<T> currentSource, DataTree<T> currentDestination)
        {
            Queue<MergeTask<T>> todo = new Queue<MergeTask<T>>();
            todo.Enqueue(new MergeTask<T>() { Src = currentSource, Dst = currentDestination });

            while (todo.Count > 0)
            {
                MergeTask<T> current = todo.Dequeue();

                lock (current.Dst.SyncRoot)
                {
                    // in any cases, add all properties of the node we are iterating on
                    foreach (var property in current.Src.Properties.ToArray())
                    {
                        current.Dst.AddProperty(string.Empty, property.Key, property.Value);
                    }
                }

                // handle subtrees
                foreach (var subtree in current.Src.SubTrees.ToArray())
                {
                    lock (current.Dst.SyncRoot)
                    {
                        DataTree<T> destinationSubTree = null;
                        if (current.Dst.TryFindSubTree(subtree.Key, out destinationSubTree))
                        { //// found subtree, enqueue it
                            todo.Enqueue(new MergeTask<T>() { Src = subtree.Value, Dst = destinationSubTree });
                        }
                        else
                        { //// add subtree in place, thats a reference, not a copy
                            current.Dst.AddSubTree(string.Empty, subtree.Value);
                        }
                    }
                }
            }
        }


        public static MarketDataMgr.Trees.MarketDataTree CreateTreeToSaveWithInclusion(MarketDataMgr.Trees.MarketDataTree marketDataTree, params string[] includedFields)
        {
            var res = new MarketDataMgr.Trees.MarketDataTree();

            res.Tree.AddAllSubTrees(MarketDataLabelsConstants.MarketData);

            foreach (var subTree in marketDataTree.Tree.SubTrees.First().Value.SubTrees)
            {
                if (includedFields.Contains(subTree.Key))
                {
                    res.Tree.AddSubTree(MarketDataLabelsConstants.MarketData, subTree.Value);
                }
            }

            return res;
        }


        public static DataTree<MarketDataProperty> GetDataSubTreeAndRemove(MarketDataMgr.Trees.MarketDataTree marketDataTree, DataFieldsEnum field)
        {
            return GetDataSubTreeAndRemove(marketDataTree, field.ToString());
        }

        public static DataTree<MarketDataProperty> GetDataSubTreeAndRemove(MarketDataMgr.Trees.MarketDataTree marketDataTree, string field)
        {
            DataTree<MarketDataProperty> subTree;

            var dataTreePath = GetDataTreePath(field);
            if (marketDataTree.Tree.TryFindSubTree(dataTreePath, out subTree))
            {
                marketDataTree.Tree.RemoveSubTree(dataTreePath);

                return subTree;
            }

            return null;
        }

        public static void AddDataSubTree(MarketDataMgr.Trees.MarketDataTree tree, DataTree<MarketDataProperty> subTreeToAdd)
        {
            if (subTreeToAdd != null)
            {
                tree.Tree.RemoveSubTree(MarketDataLabelsConstants.MarketData, subTreeToAdd.Name);
                tree.Tree.AddSubTree(MarketDataLabelsConstants.MarketData, subTreeToAdd);
            }
        }
    }
}