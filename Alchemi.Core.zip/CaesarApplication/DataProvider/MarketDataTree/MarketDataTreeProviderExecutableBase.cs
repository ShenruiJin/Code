﻿using System;
using System.Collections.Generic;
using System.Linq;
using GlobalDerivativesApplications.DynamicDataExchange;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;

namespace CaesarApplication.DataProvider.MarketDataTree
{
    /// <summary>
    /// Abstract class for operation on MarketDataTree
    /// </summary>
    [Serializable]
    public abstract class MarketDataTreeProviderExecutableBase : IProviderExecutable
    {
        /// <summary>
        /// The tree, used as cache
        /// </summary>
        protected MarketDataMgr.Trees.Ext.OverloadedMarketDataTree Tree { get; set; }

        /// <summary>
        /// Constructor with tree
        /// </summary>
        /// <param name="tree"></param>
        protected MarketDataTreeProviderExecutableBase(ref MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree)
        {
            Tree = tree;
        }

        /// <summary>
        /// Load method with LoadingContext
        /// </summary>
        /// <param name="ticker"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public virtual TimeSerieDB Load(string ticker, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null)
        {
            return Load(new[] { ticker }, field, startDate, endDate, loadingContext).FirstOrDefault();
        }

        /// <summary>
        /// Load multiple TimeSeries
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <returns></returns>
        public IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null)
        {
            return Load(tickers, field, startDate, endDate, null);
        }

        public abstract IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, ILoadingContext loadingContext = null);

        public abstract void Save(IList<TimeSerieDB> timeSeries);

        /// <summary>
        /// Save TimeSeries
        /// </summary>
        /// <param name="timeSeries"></param>
        /// <param name="loadingContext"></param>
        public virtual void Save(IList<TimeSerieDB> timeSeries, ILoadingContext loadingContext)
        {
            Save(timeSeries);
        }

        public abstract IList<DataFieldsEnum> SupportedFields { get; }
        public abstract DataTypeEnum SourceType { get; }
    }
}