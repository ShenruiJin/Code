﻿using System;
using System.Collections.Generic;
using CaesarApplication.Service.Logging;
using GlobalDerivativesApplications.Data;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.FinancingTools.Constants;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;
using System.Linq;
using FuncFramework.Business;

namespace CaesarApplication.DataProvider.MarketDataTree
{
    /// <summary>
    /// Load a close from the cache
    /// </summary>
    [Serializable]
    public class MarketDataTreeExecutable : MarketDataTreeProviderExecutableBase
    {
        /// <summary>
        /// Constructor with tree
        /// </summary>
        /// <param name="tree"></param>
        public MarketDataTreeExecutable(ref MarketDataMgr.Trees.Ext.OverloadedMarketDataTree tree) : base(ref tree)
        {

        }

        /// <summary>
        /// Load method
        /// </summary>
        /// <param name="tickers"></param>
        /// <param name="field"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="loadingContext"></param>
        /// <returns></returns>
        public override IList<TimeSerieDB> Load(IEnumerable<string> tickers, DataFieldsEnum field, DateTime? startDate = null, DateTime? endDate = null, PricingBase.DataProvider.ILoadingContext loadingContext = null)
        {
            IList<TimeSerieDB> result = new List<TimeSerieDB>();

            var originalTree = Tree.OriginalTree.Tree;
            var overloadTree = Tree.OverloadedTree.Tree;

            var computedStartDate = UnDatedFields.Contains(field) ? null : startDate;
            var computedEndDate = UnDatedFields.Contains(field) ? null : endDate;

            foreach (string ticker in tickers)
            {
                //MarketDataProperty property; -- never used
                TimeSerieDB loadedTimeSerie;
                if (loadingContext != null && loadingContext.IndexId > 0)
                {
                    loadedTimeSerie = Load(overloadTree, ticker, field, computedStartDate, computedEndDate, loadingContext);
                    if (loadedTimeSerie != null)
                    {
                        result.Add(loadedTimeSerie);
                    }
                }
                else if (loadingContext == null || loadingContext.IndexId == 0)
                {
                    if (IsIndexPricingInstructionProjectRequest(field, ticker))
                    {
                        var series = GetIndexPricingInstructions(originalTree, ticker, field);

                        if (series != null)
                        {
                            result.AddRange(series);
                        }
                    }
                    else
                    {
                        loadedTimeSerie = Load(originalTree, ticker, field, computedStartDate, computedEndDate);

                        if (loadedTimeSerie != null)
                        {
                            result.Add(loadedTimeSerie);
                            loadedTimeSerie.Instrument = loadedTimeSerie.Instrument;
                            loadedTimeSerie.Field = loadedTimeSerie.Field;
                        }
                    }
                }
                else
                {
                    LoggingService.Warn(GetType(), "The market data " + field + " was not found for the ticker " + ticker);
                }
            }

            result.ForEach(t=>t.IsConsideredAsComplete = false);
            return result;
        }

        private static bool IsIndexPricingInstructionProjectRequest(DataFieldsEnum field, string ticker)
        {
            return field == DataFieldsEnum.IndexPricingInstruction && !ticker.Contains(StrategyTree.PathDelimiter);
        }

        public TimeSerieDB Load(DataTree<MarketDataProperty> tree, string ticker, DataFieldsEnum field, DateTime? startDate = null,
            DateTime? endDate = null, ILoadingContext context = null)
        {
            MarketDataProperty property;

            tree.TryFindProperty(MarketDataTreeUtils.GetHistoryPath(ticker, field, context), out property);

            if (property != null && property.Value is TimeSerieDB)
            {
                TimeSerieDB timeSerie = property.Value as TimeSerieDB;
                //if (endDate < timeSerie.StartDate || startDate > timeSerie.EndDate)
                //    return null;
                //return timeSerie.GetPeriod(startDate, endDate, false);
                return timeSerie.GetInterval(startDate.GetValueOrDefault(), endDate.GetValueOrDefault(), false, true);
            }

            return null;
        }

        private static TimeSerieDB[] GetIndexPricingInstructions(DataTree<MarketDataProperty> tree, string ticker, DataFieldsEnum field)
        {
            DataTree<MarketDataProperty> subtree;

            if (tree.TryFindSubTree(MarketDataTreeUtils.GetTreePath(ticker, field), out subtree))
            {
                return GetTimeSerieDbs(subtree);
            }
            else
            {
                return null;
            }
        }

        private static TimeSerieDB[] GetTimeSerieDbs(DataTree<MarketDataProperty> subtree)
        {
            var res = new List<TimeSerieDB>();

            res.AddRange(GetTimeSerieProperties(subtree));

            foreach (var t in subtree.SubTrees.Select(x => x.Value))
            {
                res.AddRange(GetTimeSerieDbs(t));
            }

            return res.ToArray();
        }

        private static IEnumerable<TimeSerieDB> GetTimeSerieProperties(DataTree<MarketDataProperty> tree)
        {
            foreach (var p in tree.Properties)
            {
                var ts = p.Value.Value as TimeSerieDB;
                if (ts != null)
                {
                    yield return ts;
                }
            }
        }

        /// <summary>
        /// Save method
        /// </summary>
        /// <param name="timeSeries"></param>
        public override void Save(IList<TimeSerieDB> timeSeries)
        {
            foreach (var ts in timeSeries)
            {
                TimeSerieDB timeSerie = ts;

                if (UnDatedFields.Contains(timeSerie.Field) && timeSerie.X.Any())
                {
                    timeSerie = new TimeSerieDB(DateTime.MinValue, timeSerie.Y.Last(), timeSerie.Instrument, timeSerie.Field, timeSerie.Context);
                }

                DataTree<MarketDataProperty> targetedTree;
                if (timeSerie.Context == null || timeSerie.Context.IndexId == 0)
                {
                    targetedTree = Tree.OriginalTree.Tree;
                }
                else
                {
                    targetedTree = Tree.OverloadedTree.Tree;
                }

                DataTree<MarketDataProperty> typeTree;
                string typeTreePath = GetTypeTreePath(timeSerie);

                if (!targetedTree.TryFindSubTree(typeTreePath, out typeTree))
                {
                    targetedTree.AddSubTree(MarketDataLabelsConstants.MarketData, timeSerie.Field.ToString());
                }

                //DataTree<MarketDataProperty> tickerTree; -- never used
                string tickerTreePath = MarketDataLabelsConstants.MarketData +
                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                                        timeSerie.Field +
                                        MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                                        timeSerie.Instrument;

                AddMissingSubTree(targetedTree, tickerTreePath, typeTreePath, timeSerie);

                // DataTree<MarketDataProperty> historyTree; -- never used
                MarketDataProperty property;

                string historyNode = MarketDataTreeUtils.GetHistoryNode(timeSerie.Context);
                string historyPropertyPath = MarketDataTreeUtils.GetHistoryPath(timeSerie.Instrument, timeSerie.Field, timeSerie.Context);

                //if (!targetedTree.TryFindSubTree(historyTreePath, out historyTree))
                //{
                //    targetedTree.AddSubTree(tickerTreePath, historyNode);
                //}

                if (!targetedTree.TryFindProperty(historyPropertyPath, out property))
                {
                    property = new MarketDataProperty() { Name = MarketDataLabelsConstants.History, Value = timeSerie };
                    var index_leaf = targetedTree.AddAllSubTrees(tickerTreePath);
                    index_leaf.AddProperty(string.Empty, historyNode, property);
                }
                else
                {
                    if (property.Value is TimeSerieDB)
                    {
                        TimeSerieDB storedTimeSerie = property.Value as TimeSerieDB;
                        storedTimeSerie.Merge(timeSerie);
                    }
                }
            }
        }

        private static string GetTypeTreePath(TimeSerieDB timeSerie)
        {
            return MarketDataLabelsConstants.MarketData +
                   MarketDataMgr.Trees.MarketDataTree.PathDelimiter +
                   timeSerie.Field;
        }

        private static void AddMissingSubTree(DataTree<MarketDataProperty> targetedTree, string tickerTreePath, string typeTreePath,
            TimeSerieDB timeSerie)
        {
            targetedTree.AddAllSubTrees(tickerTreePath);
        }

        private DataFieldsEnum[] UnDatedFields
        {
            get
            {
                return new[]
                {
                    DataFieldsEnum.ICB_INDUSTRY_NAME,
                    DataFieldsEnum.Currency,
                    DataFieldsEnum.IndexPricingInstruction,
                    DataFieldsEnum.Isin,
                    DataFieldsEnum.DividendCurrency,
                    DataFieldsEnum.CountryIssue,
                    DataFieldsEnum.DirtyClean,
                    DataFieldsEnum.PriceFlag,
                    DataFieldsEnum.CashflowDescription,
                    DataFieldsEnum.QuoteFactor
                };
            }
        }

        /// <summary>
        /// Executable for all use cases
        /// </summary>
        public override IList<DataFieldsEnum> SupportedFields
        {
            get { throw new NotImplementedException(); }
        }

        /// <summary>
        /// Executable for all use cases
        /// </summary>
        public override DataTypeEnum SourceType
        {
            get { throw new NotImplementedException(); }
        }
    }
}
