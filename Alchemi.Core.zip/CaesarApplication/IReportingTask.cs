﻿
using System.Collections.Generic;

namespace CaesarApplication
{
    public interface IReportingTask
    {
        string FileToUpload { get; set; }

        string IndexName { get; set; }

        string Comments { get; set; }

        IList<string> Recipients { get; set; }
    }
}