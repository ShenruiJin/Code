﻿using System.Collections.Generic;

namespace CaesarApplication
{
    public interface IReportingTaskManager
    {
        bool Delete(string[] taskId);
        bool Delete(string taskId);
        IReportingTask LoadTask(string taskId);
        bool SaveTask(string taskId, string reportFilePath, string indexName, string additonnalComments = null, IList<string> recipients = null);
    }
}