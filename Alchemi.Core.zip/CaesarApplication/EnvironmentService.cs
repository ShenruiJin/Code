﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

//// no namespace as this service will contain extention methods
////namespace CaesarApplication
////{
    /// <summary>
    /// environmment applicative helpers
    /// </summary>
    static public class EnvironmentService
    {
        public static void InheritCulture(this Thread thread)
        {
            //// inherit culture
            thread.CurrentCulture = Thread.CurrentThread.CurrentCulture;
            thread.CurrentUICulture = Thread.CurrentThread.CurrentUICulture;
        }
    }
////}
