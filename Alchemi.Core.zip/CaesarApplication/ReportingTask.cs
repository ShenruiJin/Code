﻿
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace CaesarApplication
{
    [DataContract]
    public class ReportingTask : IReportingTask
    {
        [DataMember]
        public string FileToUpload { get; set; }

        [DataMember]
        public string IndexName { get; set; }

        [DataMember]
        public string Comments { get; set; }    

        [DataMember]
        public IList<string> Recipients { get; set; }

    }
}
