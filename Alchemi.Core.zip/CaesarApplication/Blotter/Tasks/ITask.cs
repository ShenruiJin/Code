﻿using System;
using System.ComponentModel;
using DealIndexDataTransferObject;

namespace CLIQIndexesBlotter.TaskManagement
{
    public interface ITask : INotifyPropertyChanged
    {
        TaskType Type { get; }

        DateTime Date { get; }

        DateTime VersionDate { get; }

        TaskInformationLevel InformationLevel { get; }

        bool Completed { get; set; }

        string Identifier { get; }

        string Description { get; }

        string Project { get; }

        string Index { get; }

        string BBGTicker { get; }

        ITaskStatus Status { get; set; }

        IndexDTO IndexDTO { get; }

        ProjectDTO ProjectDTO { get; }
        IQuotationResultDTO QuotationResultDTO { get; }
        string IndexFullPath { get; }
    }

    public interface ITask<T> : ITask
        where T : IQuotationResultDTO
    {
        T TypedQuotationResultDTO { get; }
    }
}