﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using DealIndexDataTransferObject;
using FuncFramework.Business;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public abstract class IndexTask<T> : ITask<T>
        where T : IQuotationResultDTO
    {
        private ITaskStatus status;

        public IndexTask(ProjectDTO project, IndexDTO index, T quotationResultDTO)
        {
            Date = quotationResultDTO.date_version;

            Index = index.ticker.Replace(IndexPathHelper.Delimiter.ToString(), "->");

            VersionDate = quotationResultDTO.date_computation;
            Date = quotationResultDTO.date_version;

            Project = project.project_name;
            IndexId = index.id;
            BBGTicker = index.bloomberg_ticker;
            IndexFullPath = IndexPathHelper.Combine(Project, index.ticker);

            IndexDTO = index;
            ProjectDTO = project;
            TypedQuotationResultDTO = quotationResultDTO;
            quotationResultDTO.computation_index = index;
        }

        protected virtual string GetIdentifier(ProjectDTO project, IQuotationResultDTO quote)
        {
            return string.Join("|",
                Type.ToString(),
                project.project_name,
                Index,
                quote.date_version.ToString());
        }

        protected abstract string GetTaskDescription(ProjectDTO project, T quote);


        protected abstract TaskInformationLevel GetInformationLevel(T quotationResult);

        public abstract TaskType Type { get; }

        public DateTime Date { get; private set; }

        public DateTime VersionDate { get; private set; }

        public TaskInformationLevel InformationLevel
        {
            get
            {
                return GetInformationLevel(TypedQuotationResultDTO);
            }
        }

        public virtual bool Completed
        {
            get { return status != null && status.Status == TaskStatus.Validated; }
            set
            {
                var newStatus = status ?? new TaskStatusBase();
                SetTaskStatusValues(value, newStatus);
                Status = newStatus;
                OnPropertyChanged();
            }
        }

        private void SetTaskStatusValues(bool statusAsBool, ITaskStatus taskStatus)
        {
            taskStatus.Login = Environment.UserName;
            taskStatus.StatusDate = DateTime.Now;
            taskStatus.Status = statusAsBool ? TaskStatus.Validated : TaskStatus.Pending;
        }

        public string Identifier { get { return GetIdentifier(ProjectDTO, QuotationResultDTO); } }

        public long IndexId { get; private set; }

        public string IndexFullPath { get; private set; }

        public virtual string Description
        {
            get { return GetTaskDescription(ProjectDTO, TypedQuotationResultDTO); }
        }

        public string Project { get; private set; }
        public string Index { get; private set; }
        public string BBGTicker { get; private set; }

        public virtual ITaskStatus Status
        {
            get { return status; }
            set
            {
                status = value;

                if (status != null)
                {
                    status.TaskKey = Identifier;
                }
                OnPropertyChanged();
                OnPropertyChanged("Completed");
            }
        }

        public IndexDTO IndexDTO { get; private set; }
        public ProjectDTO ProjectDTO { get; private set; }
        public IQuotationResultDTO QuotationResultDTO
        {
            get { return TypedQuotationResultDTO; }
            set { TypedQuotationResultDTO = (T)value; }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            if (PropertyChanged != null) PropertyChanged.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public T TypedQuotationResultDTO
        { get; private set; }
    }
}