﻿using System.Globalization;
using DealIndexDataTransferObject;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public class PublicationTask : IndexQuoteTask
    {
        public PublicationTask(ProjectDTO project, IndexDTO index, IndexQuoteDTO quote) : base(project, index, quote)
        {
        }

        protected override string GetTaskDescription(ProjectDTO project, IndexQuoteDTO quote)
        {
            return string.Format("{0}->{1} is ready to publish with value : {2}",
      project.project_name,
      Index,
      quote.value.GetValueOrDefault().ToString(CultureInfo.InvariantCulture)
      );
        }

        protected override TaskInformationLevel GetInformationLevel(IndexQuoteDTO quote)
        {
            return TaskInformationLevel.Info;
        }

        public override TaskType Type
        {
            get
            {
                return TaskType.Publication;
            }
        }
    }
}
