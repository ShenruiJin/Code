using DealIndexDataTransferObject;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public abstract class IndexQuoteTask : IndexTask<IndexQuoteDTO>
    {
        protected IndexQuoteTask(ProjectDTO project, IndexDTO index, IndexQuoteDTO quotationResultDTO) : base(project, index, quotationResultDTO)
        {
        }

        public IndexQuoteDTO IndexQuoteDTO
        {
            get { return TypedQuotationResultDTO; }
        }
    }
}