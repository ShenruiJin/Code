﻿using System;

namespace CLIQIndexesBlotter.TaskManagement
{
    public interface ITaskStatus
    {
        string Login { get; set; }

        DateTime StatusDate { get; set; }

        TaskStatus Status { get; set; }

        string TaskKey { get; set; }

        void LoadFromString(string dataAsStr);

        string GetStatusAsString();
    }
}