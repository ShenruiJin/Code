﻿using System;
using System.Globalization;
using DealIndexDataTransferObject;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public class SanityCheckTask : IndexQuoteTask
    {
        public SanityCheckTask(ProjectDTO project, IndexDTO index, IndexQuoteDTO quote, double validationValue) : base(project, index, quote)
        {
            ValidationValue = validationValue;
        }

        protected override string GetTaskDescription(ProjectDTO project, IndexQuoteDTO quote)
        {
            if (double.IsNaN(ValidationValue))
            {
                return string.Format("{0} has not its validation value ({1}) calculated",
                  Project + "->" + Index, IndexDTO.validation_ticker);
            }
            else if (IsOK(quote, ValidationValue))
            {
                return
                    string.Format("{0} has spread between index value {1} and {2} {3} is less or equal than the threshold {4} vs {5}",
                        Project + "->" + Index, AsString(quote.value), IndexDTO.validation_ticker, AsString(ValidationValue), AsString(GetSpreadValue(quote, ValidationValue)), AsString(IndexDTO.validation_threshold));
            }
            else
            {
                return string.Format("{0} has spread between index value {1} and {2} {3} exceed the threshold {4} vs {5}",
                        Project + "->" + Index, AsString(quote.value), IndexDTO.validation_ticker, AsString(ValidationValue), AsString(GetSpreadValue(quote, ValidationValue)), AsString(IndexDTO.validation_threshold));
            }
        }

        public string AsString(double? val)
        {
            return val.HasValue ? val.GetValueOrDefault().ToString(CultureInfo.InvariantCulture) : "";
        }

        private bool IsOK(IndexQuoteDTO quote, double validationValue)
        {
            return GetSpreadValue(quote, validationValue) <= IndexDTO.validation_threshold;
        }

        private static double GetSpreadValue(IndexQuoteDTO quote, double validationValue)
        {
            return Math.Round(Math.Abs(validationValue - quote.value.GetValueOrDefault()), 5);
        }

        protected override TaskInformationLevel GetInformationLevel(IndexQuoteDTO quote)
        {
            return IsOK(quote, ValidationValue) ? TaskInformationLevel.OK : TaskInformationLevel.KO;
        }

        public override TaskType Type
        {
            get
            {
                return TaskType.Validation;
            }
        }

        public double ValidationValue { get; private set; }
    }
}