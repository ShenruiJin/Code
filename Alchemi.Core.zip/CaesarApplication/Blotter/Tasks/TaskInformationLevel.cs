﻿namespace CLIQIndexesBlotter.TaskManagement
{
    public enum TaskInformationLevel
    {
        OK,
        KO,
        Warning,
        Info
    }
}