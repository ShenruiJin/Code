﻿using System;
using System.Globalization;
using DealIndexDataTransferObject;
using PricingBase.Index;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public sealed class QuoteTask : IndexQuoteTask
    {
        public QuoteTask(ProjectDTO project, IndexDTO index, IndexQuoteDTO quote) : base(project, index, quote)
        {
        }

        protected override string GetTaskDescription(ProjectDTO project, IndexQuoteDTO quote)
        {
            return string.Format("{0}->{1} has finished with status {2}{3}{4}",
                project.project_name,
                Index,
                quote.status,
                !string.IsNullOrEmpty(quote.comment) ? " (" + quote.comment + ")" : string.Empty,
                !double.IsNaN(quote.value.GetValueOrDefault(double.NaN)) ? " with quote : " + quote.value.GetValueOrDefault().ToString(CultureInfo.InvariantCulture) : string.Empty
                );
        }

        public override TaskType Type
        {
            get { return TaskType.Valuation; }
        }

        protected override TaskInformationLevel GetInformationLevel(IndexQuoteDTO quote)
        {
            var statusAsEnum = (QuoteStatus)Enum.Parse(typeof(QuoteStatus), quote.status);

            switch (statusAsEnum)
            {
                case QuoteStatus.Calculated:
                    return TaskInformationLevel.OK;
                case QuoteStatus.NotCalculated:
                    return TaskInformationLevel.Warning;
                case QuoteStatus.Pending:
                    return TaskInformationLevel.Warning;
                case QuoteStatus.Error:
                    return TaskInformationLevel.KO;
                case QuoteStatus.CalendarHoliday:
                    return TaskInformationLevel.Info;
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }
    }
}
