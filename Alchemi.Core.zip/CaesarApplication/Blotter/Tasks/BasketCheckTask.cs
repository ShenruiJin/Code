﻿using System;
using System.Globalization;
using DealIndexDataTransferObject;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public class BasketCheckTask: IndexQuoteTask
    {
        private readonly BasketValidationTask _basketValidationTask;

        public bool CompletionStatus
        {
            get { return _basketValidationTask.Completed; }
        }

        public BasketCheckTask(ProjectDTO project, IndexDTO index, IndexQuoteDTO quote, BasketValidationTask basketValidationTask) : base(project, index, quote)
        {
            _basketValidationTask = basketValidationTask;

            Status = basketValidationTask.Status;

            _basketValidationTask.PropertyChanged += (sender, args) =>
            {
                if (args.PropertyName == "Status")
                {
                    Status = basketValidationTask.Status;
                }
            };
        }

        protected override string GetIdentifier(ProjectDTO project, IQuotationResultDTO quote)
        {
            return base.GetIdentifier(project, quote) + "|" + _basketValidationTask.IndexFullPath + "|" + _basketValidationTask.Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture);
        }

        protected override string GetTaskDescription(ProjectDTO project, IndexQuoteDTO quote)
        {
            if (CompletionStatus)
            {
                return string.Format("{0} at {1} has been calculated with validated basket {2} with effective date {3}",
    IndexFullPath, Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture), _basketValidationTask.IndexFullPath, _basketValidationTask.Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));
            }
            else
            {
                return string.Format("{0} at {1} has been calculated with non validated basket {2} with effective date {3}",
    IndexFullPath, Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture), _basketValidationTask.IndexFullPath, _basketValidationTask.Date.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture));

            }
        }

        protected override TaskInformationLevel GetInformationLevel(IndexQuoteDTO quotationResult)
        {
            return CompletionStatus ? TaskInformationLevel.OK : TaskInformationLevel.KO;
        }

        public override TaskType Type
        {
            get
            {
                return TaskType.IndexBasketValidation;
            }
        }
    }
}