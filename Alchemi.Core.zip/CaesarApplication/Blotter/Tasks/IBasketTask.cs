﻿using PricingBase.Product.CsInfoContainer;

namespace CLIQIndexesBlotter.TaskManagement
{
    public interface IBasketTask
    {
        BasketIndexList BasketsList { get; }
    }
}