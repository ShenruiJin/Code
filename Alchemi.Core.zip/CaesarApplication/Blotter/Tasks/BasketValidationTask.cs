﻿using System.Linq;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using GlobalDerivativesApplications.Reporting;
using PricingBase.Product.CsInfoContainer;

namespace CLIQIndexesBlotter.TaskManagement.Tasks
{
    public class BasketValidationTask : IndexTask<BasketResultDTO>, IBasketTask
    {
        public BasketValidationTask(ProjectDTO project, IndexDTO index, BasketResultDTO basket)
            : base(project, index, basket)
        {
            BasketsList = new BasketResultDTOConverter<BasketResultDTO>().ConvertFromDTO(basket.AsArray())
                .SelectMany(x => x.Y.Cast<BasketIndexList>())
                .Last();
        }

        public BasketIndexList BasketsList
        {
            get;
            private set;
        }

        public override ITaskStatus Status
        {
            get
            {
                return new TaskStatusBase
                {
                    Status = GetTaskStatusFromBoolean(BasketsList.Validated),
                    TaskKey = Identifier,
                    StatusDate = BasketsList.ValidationDate.GetValueOrDefault(),
                    Login = BasketsList.Validator
                };
            }
            set
            {
                var hasChanged = value == null || value.Status != (GetTaskStatusFromBoolean(BasketsList.Validated));

                if (value != null && hasChanged)
                {
                    BasketsList.Validated = value.Status == TaskStatus.Validated;
                    BasketsList.ValidationDate = value.StatusDate;
                    BasketsList.Validator = value.Login;
                }

                if (hasChanged)
                {
                    OnPropertyChanged();
                    OnPropertyChanged("Completed");
                }
            }
        }

        public override bool Completed
        {
            get { return BasketsList.Validated; }
            set { base.Completed = value; }
        }

        private TaskStatus GetTaskStatusFromBoolean(bool validated)
        {
            return validated ? TaskStatus.Validated : TaskStatus.Pending;
        }

        protected override string GetTaskDescription(ProjectDTO project, BasketResultDTO quote)
        {
            if (!Completed)
            {
                return string.Format("{0}->{1} with effective date at {2} need to be validated",
                    project.project_name,
                    Index,
                    BasketsList.EffectiveDate.GetValueOrDefault().ToString("dd/MM/yyyy")
                    );
            }
            else
            {
                return string.Format("{0}->{1} with effective date at {2} has been validated",
                   project.project_name,
                   Index,
                   BasketsList.EffectiveDate.GetValueOrDefault().ToString("dd/MM/yyyy")
                   );
            }
        }

        protected override TaskInformationLevel GetInformationLevel(BasketResultDTO quote)
        {
            return Completed ? TaskInformationLevel.OK : TaskInformationLevel.Warning;
        }

        public override TaskType Type
        {
            get
            {
                return TaskType.BasketValidation;
            }
        }
    }
}