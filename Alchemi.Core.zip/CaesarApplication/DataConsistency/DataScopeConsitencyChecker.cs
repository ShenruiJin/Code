﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Database.Converters;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using DealIndexDataTransferObject;
using DealServerLocal.Description;
using FuncFramework.Business;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.Data.Json;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using GlobalDerivativesApplications.Reporting;
using log4net;
using MarketData;
using Pricing.Engine.Indices;
using PricingBase.Index;
using PricingBase.OST;
using PricingBase.Product.CsInfoContainer;
using PricingContext = PricingBase.DataProvider.PricingContext;
using TimeSerieDB = PricingBase.DataProvider.TimeSerieDB;
using PricingBase.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.DataProvider.MDM;
using GlobalDerivativesApplications.ToolsBox;
using GlobalDerivativesApplications;
using CaesarApplication.Reporting;
using CaesarCommon.Configuration;
using CaesarApplication.DataProvider.Helpers;
using System.Globalization;

namespace CaesarApplication.DataConsistency
{
    public class DataScopeConsitencyChecker
    {
        private TimeSeriesProvider tsp;
        private int scopeLag;
        private readonly string reportSales;
        private DateTime referenceDate;

        private string compareXlsx = @"C:\Temp\DataFromPricing_Compare.xlsx";
        private string rawDataXlsx = @"C:\Temp\DataFromPricing_rawData.xlsx";

        private ILog logger = LogManager.GetLogger(typeof(DataScopeConsitencyChecker));

        private ITimeSeriesProvider mdmDataProvider;

        private SophisTranscoder sophisTranscoder;

        public DataScopeConsitencyChecker(DateTime referenceDate, int scopeLag, string reportSales)
        {
            this.scopeLag = scopeLag;
            this.reportSales = reportSales;
            this.tsp = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, true, dataHandlersToUse: new[] { "DB" });
            tsp.PricingContext = new PricingContext();
            this.referenceDate = referenceDate;
        }

        private string[] ReportSales
        {
            get { return string.IsNullOrEmpty(reportSales) ? GlobalDerivativesApplications.Reporting.Extensions.AsArray("PROD") : reportSales.Split(',', ';'); }
        }

        public IndexData[] GetDatas(string[] sales = null)
        {
            var res = new List<IndexData>();

            var prjs = PersistanceService.IndexProvider.ReadAllProjects(UserService.CaesarSession);
            var dealDescriptionCollection = PersistanceService.DealProvider.GetSpecificDeals(DateTime.MinValue, DateTime.Today, prjs.Select(x => x.project_name).ToArray(), new SuperSession(UserService.CaesarSession)).ToArray();

            var deals = dealDescriptionCollection.Where(x => (sales == null || sales.Select(s => s.ToLower()).Contains(x.Sales.ShortName.ToLower()))).ToArray();


            foreach (var deal in deals)
            {
                var prj = prjs.FirstOrDefault(x => x.project_name == deal.Name);

                if (prj != null)
                {
                    prj = PersistanceService.IndexProvider.ReadProject(prj.id, UserService.CaesarSession);

                    foreach (var indexDTO in prj.indexes)
                    {
                        res.AddRange(GetDatas(prj, indexDTO));
                    }
                }
            }

            return res.ToArray();
        }


        public IndexData[] GetPricingDatas(string[] sales = null)
        {
            var res = new List<IndexData>();

            var prjs = PersistanceService.IndexProvider.ReadAllProjects(UserService.CaesarSession);
            var dealDescriptionCollection = PersistanceService.DealProvider.GetSpecificDeals(DateTime.MinValue, DateTime.Today, prjs.Select(x => x.project_name).ToArray(), new SuperSession(UserService.CaesarSession)).ToArray();

            var deals = dealDescriptionCollection.Where(x => (sales == null || sales.Select(s => s.ToLower()).Contains(x.Sales.ShortName.ToLower()))).ToArray();

            foreach (var deal in deals)
            {
                var prj = prjs.FirstOrDefault(x => x.project_name == deal.Name);

                if (prj != null)
                {
                    prj = PersistanceService.IndexProvider.ReadProject(prj.id, UserService.CaesarSession);

                    foreach (var indexDTO in prj.indexes)
                    {
                        res.AddRange(GetPricingDatas(prj, indexDTO));
                    }
                }
            }

            return res.ToArray();
        }

        private IEnumerable<IndexData> GetPricingDatas(ProjectDTO prj, IndexDTO indexDTO)
        {
            var res = new List<IndexData>();

            var quotes = PersistanceService.IndexProvider.LoadIndexHistoryQuotesByPath(UserService.CaesarSession,
                indexDTO.id.ToString(), referenceDate.AddDays(-scopeLag), referenceDate).Where(x => x.status == QuoteStatus.Calculated.ToString()).ToArray();

            foreach (var indexQuotesForSameDate in quotes.GroupBy(q => q.date_version).Where(g => g.Count() > 1).Select(x => x.ToArray()).ToArray())
            {
                res.AddRange(GetPricingDatas(prj, indexDTO, indexQuotesForSameDate));
            }

            return res.ToArray();
        }

        private IEnumerable<IndexData> GetPricingDatas(ProjectDTO prj, IndexDTO index, IndexQuoteDTO[] indexQuotesForSameDate)
        {
            var quoteConverter = new IndexQuoteDtoConverter();

            var valueDate = indexQuotesForSameDate[0].date_version;

            foreach (var quote in indexQuotesForSameDate)
            {
                var auditBasket = tsp.GetBasketsAudit(index.id.ToString(), valueDate, valueDate, quote.date_computation, false);

                foreach (var bkt in auditBasket.Y.Cast<BasketIndexList>().SelectMany(x => x.Baskets))
                {
                    foreach (var kv in bkt.Data.Union(new[] { new KeyValuePair<string, IList<TimeSerieDB>>(DataFieldsEnum.IndexComponents.ToString(), new List<TimeSerieDB> { new TimeSerieDB(bkt.Components.Select(x => new KeyValuePair<DateTime, IMarketData>(x.Key, new BasketComponents(x.Value))).ToArray(), "", DataFieldsEnum.IndexComponents) }) }))
                    {
                        foreach (var ts in kv.Value)
                        {
                            foreach (var tsKv in ts.GetElements())
                            {
                                yield return
                                    new IndexData
                                    {
                                        Date = tsKv.Key,
                                        Data = tsKv.Value,
                                        Field = ts.FieldName,
                                        Index = index,
                                        Quote = (IndexQuote)quoteConverter.ConvertFromDTO(quote).Value,
                                        Project = prj,
                                        Ticker = ts.Instrument,
                                        Source = ts.GetSource(tsKv.Key)
                                    };
                            }
                        }
                    }
                }
            }
        }



        public IndexData[] GetDatas(ProjectDTO prj, IndexDTO index)
        {
            var res = new List<IndexData>();

            var quotes = tsp.Load(index.id.ToString(), DataFieldsEnum.IndexQuote, referenceDate.AddDays(-scopeLag), referenceDate);

            foreach (var indexQuote in quotes.Y.Cast<IndexQuote>())
            {
                res.AddRange(GetDatas(prj, index, indexQuote));
            }

            return res.ToArray();
        }

        public IEnumerable<IndexData> GetDatas(ProjectDTO prj, IndexDTO index, IndexQuote quote)
        {
            var auditBasket = tsp.GetBasketsAudit(index.id.ToString(), quote.Date, quote.Date, null, false);

            var timeSeries =
                auditBasket.Y.Cast<BasketIndexList>().SelectMany(x => x.Baskets).SelectMany(x => x.Data.Values.SelectMany(v => v))
                .GroupBy(ts => new { ts.FieldName, ts.Instrument }).Select(g => g.OrderBy(v => v.Count).Last()).ToArray();

            sophisTranscoder = sophisTranscoder ?? new SophisTranscoder();

            foreach (var ts in timeSeries)
            {
                foreach (var tsKv in ts.GetElements())
                {
                    yield return
                        new IndexData
                        {
                            Date = tsKv.Key,
                            Sicovam = sophisTranscoder.TranscodeExternalToInternal(new[] { ts.Instrument }, null).FirstOrDefault(),
                            Data = tsKv.Value,
                            Field = ts.FieldName,
                            Index = index,
                            Quote = quote,
                            Project = prj,
                            Ticker = ts.Instrument,
                            Source = ts.GetSource(tsKv.Key)
                        };
                }
            }
        }

        public void ExportDataScope(string outputPath)
        {
            if (File.Exists(outputPath))
            {
                File.Delete(outputPath);
            }

            File.WriteAllLines(outputPath, GetDatas(ReportSales).GroupBy(x => new { x.Field, x.Date, x.Ticker }).Select(x => x.Key.Field + ";" + x.Key.Ticker + ";" + x.Key.Date + ";" + ValueAsString(x.First().Data)));
        }

        public void ExportCaesarVsMDMComparisonReport(string outputPath)
        {
            var recipients = new CaesarSettingsManager().MDMvsCaesarReportingRecipients.Split(';', ',');
            var startDate = referenceDate.AddDays(-scopeLag);
            var endDate = referenceDate;

            var instrumentTypeByTicker = new Dictionary<string, string>();

            var finalOutputPath = outputPath.Replace("{StartDate}", startDate.ToString("ddMMyyyy")).Replace("{EndDate}", endDate.ToString("ddMMyyyy"));

            if (File.Exists(finalOutputPath))
            {
                File.Delete(finalOutputPath);
            }

            var indexDatas = GetDatas(ReportSales).Where(x => x.Field == DataFieldsEnum.Last.ToString()).ToArray();

            var requestedData = new Dictionary<string, double?>();
            var lines = new List<string>();

            var alreadyComputedValues = new List<string>();

            int nbOK = 0;
            bool haveKO = false;
            bool haveMissing = false;
            var koTable = new Table("KO value matching");
            var missingTable = new Table("Missing data in MDM");

            missingTable.AddHeader("Ticker", "Sicovam", "Date", "Field", "InstrumentType", "CaesarValue");
            koTable.AddHeader("Ticker", "Sicovam", "Date", "Field", "InstrumentType", "CaesarValue", "MDMValue",  "Diff");
            lines.Add(new []{ "Ticker", "Sicovam", "Date", "Field", "CaesarValue", "MDMValue", "InstrumentType", "Status" }.Stringify(";"));

            foreach (var item in indexDatas.Where(x => x.Date >= startDate && x.Date <= endDate))
            {
                var dataKey = string.Format("{0}|{1}|{2}", item.Ticker, item.Date, item.Field);

                if (!requestedData.ContainsKey(dataKey))
                {
                    requestedData.Add(dataKey, RequestDataFromMDM(item.Ticker, item.Date, item.Field));
                }

                var mdmData = requestedData[dataKey];
                var caesarValue = item.Data is MarketDataDouble ? ((MarketDataDouble)item.Data).Data : (double?)null;

                var caesarValueDataKey = string.Format("{0}|{1}|{2}|{3}", item.Ticker, item.Date, item.Field, caesarValue);

                if (!alreadyComputedValues.Contains(caesarValueDataKey))
                {
                    alreadyComputedValues.Add(caesarValueDataKey);
                    string status;

                    

                    if(!instrumentTypeByTicker.ContainsKey(item.Ticker))
                    {
                        instrumentTypeByTicker.Add(item.Ticker, GetInstrumentTypeByTicker(item.Ticker));
                    }

                    string instrumentType = instrumentTypeByTicker[item.Ticker];

                    if (mdmData == caesarValue)
                    {
                        status = "OK";
                        nbOK++;
                    }
                    else if (mdmData == null || double.IsNaN(mdmData.GetValueOrDefault()))
                    {
                        status = "MISSING_MDM";
                        haveKO = true;
                        haveMissing = true;

                        missingTable.AddRow(item.Ticker, item.Sicovam, item.Date, item.Field, instrumentType, caesarValue);
                    }
                    else
                    {
                        koTable.AddRow(item.Ticker, item.Sicovam, item.Date, item.Field, caesarValue, instrumentType, mdmData, caesarValue - mdmData);
                        status = "KO";
                        haveKO = true;
                    }

                    lines.Add(string.Format("{0};{1};{2};{3};{4};{5};{6};{7}", item.Ticker, item.Sicovam, item.Date, item.Field, 
                        caesarValue.HasValue ? caesarValue.GetValueOrDefault().ToString(CultureInfo.InvariantCulture) : null,
                        mdmData.HasValue ? mdmData.GetValueOrDefault().ToString(CultureInfo.InvariantCulture) : null, instrumentType, status));
                }
            }

            File.WriteAllLines(finalOutputPath, lines);

            var report = new Report();

            if(haveKO)
            {
                report.Tables.Add(koTable);
            }

            if(haveMissing)
            {
                report.Tables.Add(missingTable);
            }

           

            var header = new[]
            {
                string.Format("Total items : {0}", alreadyComputedValues.Count()),
                string.Format("OK items : {0}", nbOK),
                string.Format("KO items : {0}", haveKO ? koTable.GetMatrix(false).Count() : 0),
                string.Format("Missing items : {0}", haveMissing ? missingTable.GetMatrix(false).Count() : 0),
                ""
            }.Stringify("<br />");

            MailTools.SendBasicHtmlMail(string.Format("Caesar vs MDM between {0} and {1} {2}", startDate, endDate, haveKO ? "KO" : "OK"), System.IO.File.ReadAllText(@"K:\ED_ExcelTools\Application\Caesar\ReportsTemplates\TemplateSimpleTable.html").Replace("{{Body}}", header + MailTools.GetTablesAsHtml(report.Tables.ToArray())), recipients, finalOutputPath);

        }

        private string[] privateIndexesBbgTickers;

        private string GetInstrumentTypeByTicker(string ticker)
        {
            privateIndexesBbgTickers = privateIndexesBbgTickers ?? PersistanceService.IndexProvider.ReadAllIndexes(UserService.CaesarSession).Select(x => x.bloomberg_ticker).Distinct().ToArray();
            
            try
            {
                if (ticker.Contains(IndexPathHelper.Delimiter))
                    return "INTERNAL";

                if (privateIndexesBbgTickers.Contains(ticker) || ticker.EndsWith(" " + SophisHelper.BloombergSuffixIndex))
                {
                    return "INDICE";
                }

                if (SophisHelper.IsCurrencyTicker(ticker))
                {
                    return "FX";
                }

                return SophisHelper.GetInstrumentInfo(ticker.Replace(" " + SophisHelper.BloombergSuffixIndex, string.Empty)).Allotment;
            }
            catch
            {
                return "UNKNOWN";
            }
        }

        public static void SendBasicHtmlMail(string subject, string emailContent, IList<string> recipients, string attachement)
        {
            string emailAddress = System.Configuration.ConfigurationManager.AppSettings["SenderEmailAddress"] ?? "eda25-desk-quant-applications@natixis.com";
            string emailContent2 = emailContent.Replace("\u001a", "->");
            Tools.System.SendEmailEWS(emailAddress, recipients, subject, emailContent2,
                impersonatedAddress: emailAddress, userName: "nt_eqd_sos", password: "Ba13h,7j", bodyType: BodyType.HTML);
        }

        private double? RequestDataFromMDM(string ticker, DateTime date, string field)
        {
            if (mdmDataProvider == null)
            {
                mdmDataProvider = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()),
                    new TimeSeriesProviderParameters { DataHandlersToUse = new[] { "MDM_PRICES" }, NoCacheLoading = true, SpecificDBSources = new[] { "MDM_PRICES" } });

                ((TimeSeriesProvider)mdmDataProvider).AddExecutable("MDM_PRICES", new MDMLastProviderExecutable());
            }

            var ts = mdmDataProvider.Load(ticker, DataFieldsEnum.Last, date, date);

            return ts != null ? ts.Evaluate(date) : (double?)null;
        }

        public void SendDataReports(bool sendRawDataReport = false)
        {
            var r = GetDatas(ReportSales);

            if (sendRawDataReport)
            {
                var report = ReportingTools.CreateReport();

                int nbSheets = 0;


                r.Group(20000).ForEach(grp =>
                {
                    var table = report.CreateTable("RawData" + (nbSheets != 0 ? nbSheets.ToString() : ""));
                    table.AddHeader("ProjectName", "IndexTicker", "BloombergTicker", "Ticker", "Field", "Date", "Value", "Source", "Quote", "Quote.Date");

                    grp.ForEach(re =>
                        table.AddRow(
                            re.Project.project_name,
                            re.Index.ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            re.Index.bloomberg_ticker,
                            re.Ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            re.Field,
                            re.Date,
                            ValueAsString(re.Data),
                            re.Source,
                            ((IIndexQuoteTechnical)re.Quote).ValueWithoutTest,
                            re.Quote.Date));

                    nbSheets++;
                });

                try
                {
                    var xlExporter = ReportingTools.TableExporterFactory.CreateXl(rawDataXlsx);

                    ReportingTools.ReportAndSendByMail("DataConsitency Raw Data", xlExporter, report);
                }
                catch (Exception ex)
                {
                    logger.Error(ex);
                }
            }


            {
                var dataByResults = r.GroupBy(x =>
                {
                    return new { x.Field, x.Date, x.Ticker };
                }).Where(x => x.Key.Field != DataFieldsEnum.Other.ToString()).OrderBy(x => x.Key.Date).ToArray();

                var compareRes = new List<string>();

                var koRes = new List<string>();

                var report = ReportingTools.CreateReport();

                var tableByField = dataByResults.Select(x => x.Key.Field)
                    .Distinct()
                    .ToDictionary(x => x, x => report.CreateTable(x));

                foreach (var table in tableByField)
                {
                    table.Value.AddHeader("Status", "Field", "Ticker", "ValueDate", "Value", "Source", "Implicated indexes");
                }

                foreach (var dataByResult in dataByResults)
                {
                    var dataByResultValue = dataByResult.GroupBy(x => ValueAsString(x.Data)).ToArray();

                    foreach (var re in dataByResultValue)
                    {
                        var testRes = dataByResultValue.Length == 1 ? "OK" : "KO";

                        var rowValues = new Object[]
                        {
                            testRes, dataByResult.Key.Field,
                            dataByResult.Key.Ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            dataByResult.Key.Date, re.Key, re.Select(x => x.Source).Distinct().Stringify("|"),
                            string.Join("|",
                                re.Select(
                                    x =>
                                        x.Index.bloomberg_ticker ??
                                        (x.Project.project_name + "->" +
                                         x.Index.ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"))))
                        };

                        tableByField[dataByResult.Key.Field].AddRow(rowValues);
                        var line = string.Join(",", rowValues);
                        compareRes.Add(line);

                        if (testRes == "KO")
                        {
                            koRes.Add(line);
                        }
                    }
                }

                var xlExporter = ReportingTools.TableExporterFactory.CreateXl(compareXlsx);

                ReportingTools.ReportAndSendByMail("DataConsitency Compare", xlExporter, report, string.Join("\r\n", koRes));
            }
        }

        public void SendPricingReports()
        {
            var r = GetPricingDatas(ReportSales);

            {
                var report = ReportingTools.CreateReport();
                var table = report.CreateTable("RawData");

                table.AddHeader("ProjectName", "IndexTicker", "BloombergTicker", "Ticker", "Field", "Date", "Value", "Source", "Quote", "Quote.Date", "Quote.ComputationDate");

                r.ForEach(re => table.AddRow(
                            re.Project.project_name,
                            re.Index.ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            re.Index.bloomberg_ticker,
                            re.Ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            re.Field,
                            re.Date,
                            ValueAsString(re.Data),
                            re.Source,
                            ((IIndexQuoteTechnical)re.Quote).ValueWithoutTest,
                            re.Quote.Date,
                            re.Quote.ComputationDate));

                var xlExporter = ReportingTools.TableExporterFactory.CreateXl(rawDataXlsx);

                ReportingTools.ReportAndSendByMail("PricingConsitency Raw Data", xlExporter, report);
            }


            {
                var dataByResults = r.GroupBy(x =>
                {
                    return new { x.Project, x.Field, x.Date, x.Ticker, x.Index, QuoteDate = x.Quote.Date };
                }).OrderBy(x => x.Key.Date).ToArray();

                var compareRes = new List<string>();

                var koRes = new List<string>();

                var report = ReportingTools.CreateReport();

                var tableByField = dataByResults.Select(x => x.Key.Field)
                    .Distinct()
                    .ToDictionary(x => x, x => report.CreateTable(x));

                foreach (var table in tableByField)
                {
                    table.Value.AddHeader("Status", "Field", "Ticker", "Index", "ValueDate", "Value", "QuoteDate", "QuoteValue", "Implicated computation dates");
                }

                foreach (var dataByResult in dataByResults)
                {
                    var dataByResultValue = dataByResult.GroupBy(x => new { QuoteValue = ((IIndexQuoteTechnical)x.Quote).ValueWithoutTest }).ToArray();

                    foreach (var re in dataByResultValue)
                    {
                        var testRes = dataByResultValue.SelectMany(x => x).Select(x => ValueAsString(x.Data)).Distinct().Count() == 1 ? "OK" : "KO";

                        var rowValues = new Object[]
                        {
                            testRes,
                            dataByResult.Key.Field,
                            dataByResult.Key.Ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                            GetIndexDesc(dataByResult.Key.Index, dataByResult.Key.Project),
                            dataByResult.Key.Date,
                            ValueAsString(re.First().Data),
                            dataByResult.Key.QuoteDate.ToString("dd/MM/yyyy"),
                            re.Key.QuoteValue,
                            string.Join("|",
                                re.Select(
                                    x => x.Quote.ComputationDate.GetValueOrDefault().ToString("dd/MM/yyyy HH:mm:ss") + ":" +  ((IIndexQuoteTechnical)x.Quote).ValueWithoutTest))
                        };

                        tableByField[dataByResult.Key.Field].AddRow(rowValues);
                        var line = string.Join(",", rowValues);
                        compareRes.Add(line);

                        if (testRes == "KO")
                        {
                            koRes.Add(line);
                        }
                    }
                }

                var xlExporter = ReportingTools.TableExporterFactory.CreateXl(compareXlsx);

                ReportingTools.ReportAndSendByMail("PricingConsitency Compare", xlExporter, report, GetMailContent(koRes));
            }
        }

        private static string GetMailContent(List<string> koRes)
        {
            return string.Join("\r\n", koRes);
        }

        private static string GetIndexDesc(IndexDTO indexDTO, ProjectDTO projectDTO)
        {
            return indexDTO.bloomberg_ticker ??
                   (projectDTO.project_name + "->" +
                    indexDTO.ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->"));
        }

        private static string ValueAsString(IMarketData valueAsString)
        {
            if (valueAsString is MarketDataDouble)
                return ((MarketDataDouble)valueAsString).Data.ToString();

            if (valueAsString is MarketDataString)
                return ((MarketDataString)valueAsString).Data;

            if (valueAsString is IDividend)
                return ((IDividend)valueAsString).Value.ToString();

            if (valueAsString is IIndexQuoteTechnical)
                return ((IIndexQuoteTechnical)valueAsString).ValueWithoutTest.ToString();

            if (valueAsString is OptionDescAndPricesList)
                return ((OptionDescAndPricesList)valueAsString).Count + " options with first ticker:" + (((OptionDescAndPricesList)valueAsString).Count > 0 ? ((OptionDescAndPricesList)valueAsString)[0].Ticker : "NA");

            if (valueAsString is OSTCollection)
                return valueAsString.ToJsonStringSimple();

            if (valueAsString is BasketComponents)
                return
                    ((BasketComponents)valueAsString).Select(x => string.Format("{0}:{1}", x.BloombergTicker.Replace(StrategyTree.PathDelimiter.ToString(), "->"), x.Weight))
                        .Stringify("|");


            return "ND";
        }

        public class IndexData
        {
            public IndexDTO Index { get; set; }

            public string Ticker { get; set; }

            public string Sicovam { get; set; }

            public IndexQuote Quote { get; set; }

            public DateTime Date { get; set; }

            public string Field { get; set; }

            public IMarketData Data { get; set; }

            public string Source { get; set; }

            public ProjectDTO Project
            {
                get;
                set;
            }
        }

        public class BasketComponents : List<IBasketComponent>, IMarketData
        {
            public BasketComponents(IList<IBasketComponent> components) : base(components)
            { }
        }
    }
}
