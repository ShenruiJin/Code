﻿using DealServerInterface;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace CaesarApplication
{
    /// <summary>
    /// 
    /// </summary>
    /// <remarks>
    /// Copyright (c) Microsoft.  All Rights Reserved.
    /// Licensed under the Apache License, Version 2.0.
    /// </remarks>
    /// <typeparam name="TResult">Type of the result the task should return before serializing to send to client</typeparam>
    public class RemoteAsyncOperation<TResult> : MarshalByRefObject, IRemoteAsyncOperation<TResult>
    {
        private readonly TaskCompletionSource<TResult> _completion;

        public RemoteAsyncOperation()
        {
            _completion = new TaskCompletionSource<TResult>();
        }

        public Task<TResult> Task
        {
            // async call to remote process:
            get
            {
                return _completion.Task;
            }
        }

        /// <summary>
        /// Might be called remotely from the service.
        /// </summary>
        /// <returns>Returns true if the operation hasn't been completed until this call.</returns>
        public void Completed(TResult result)
        {
            SetResult(result);
        }

        /// <summary>
        /// Triggered method when the asynchronous application did not finish well
        /// </summary>
        /// <param name="exception"></param>
        public void EndedOnException(Exception exception)
        {
            _completion.TrySetException(exception);
        }

        private void SetResult(TResult result)
        {
            // Warning: bug 9466 describes a rare race condition where this method can be called
            // more than once. If you just call SetResult the second time, it will throw an
            // InvalidOperationException saying: An attempt was made to transition a task to a final
            // state when it had already completed. To work around it without complicated locks, we
            // just call TrySetResult which in case where the Task is already in one of the three
            // states (RunToCompletion, Faulted, Canceled) will just do nothing instead of throwing.
            _completion.TrySetResult(result); // Called by server but implemented on client side
        }

        public override object InitializeLifetimeService()
        {
            ILease baseLease = (ILease)base.InitializeLifetimeService();
            if (baseLease.CurrentState == LeaseState.Initial)
            {
                // For demonstration the initial time is kept small.
                // in actual scenarios it will be large.
                baseLease.InitialLeaseTime = TimeSpan.FromSeconds(30);
                baseLease.RenewOnCallTime = TimeSpan.FromSeconds(20);
                baseLease.SponsorshipTimeout = TimeSpan.FromMinutes(2);
            }
            return baseLease;
        }
    }
}
