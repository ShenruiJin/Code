﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using CaesarApplication.Service.Logging;
using DealIndexDataTransferObject.Blotter.DataContracts;
using DealServerInterfaceIndex.Blotter;
using DealServerLocal.DB.Accessibility;
using GlobalDerivativesApplications.Reporting;
using GlobalDerivativesApplications.Serialization;
using GlobalDerivativesApplications.Settings;

namespace CaesarApplication.BlotterAsService
{
    public class ProfilManager : IProfilManager, IDisposable
    {
        public string ProfileConfigurationFilePath = ConfigurationManager.AppSettings["ProfileConfigurationFilePath"];
        private IDictionary<string, string[]> profilesByUserName = null;

        private LdapManager ldapManager = null;

        public string[] GetUserProfiles(string userName = null)
        {
            profilesByUserName = profilesByUserName ?? LoadFile();

            var name = userName ?? Environment.UserName;

            if (!profilesByUserName.ContainsKey(name))
            {
                var msg = string.Format("Unknown profile for {0} in {1}", name, ProfileConfigurationFilePath);
                LoggingService.ErrorFormatted(GetType(), msg);
                throw new ApplicationException(msg);
            }

            return profilesByUserName[name];
        }

        private IDictionary<string, string[]> LoadFile()
        {
            var config =
                ReadConfiguration();

            if (config == null)
            {
                return new Dictionary<string, string[]>();
            }

            config.Users = config.Users ?? new ProfilByUser[0];
            config.Groups = config.Groups ?? new ProfilByGroup[0];

            ldapManager = ldapManager ?? new LdapManager(config.Groups.Select(x => x.GroupName).Distinct().ToArray());

            var res = new Dictionary<string, string[]>();

            foreach (var profilByGroup in config.Groups)
            {
                ldapManager.GetMembersLdap(profilByGroup.GroupName).ForEach(u => AddProfil(res, u, profilByGroup.ProfilName));
            }

            foreach (var profilByUser in config.Users)
            {
                AddProfil(res, profilByUser.UserName, profilByUser.ProfilName);
            }

            return res;
        }

        private ProfilConfiguration ReadConfiguration()
        {
            var settingsManager = new GdaSettingsMgr("CLIQIndexes.Blotter.ProfilManager");
            return settingsManager.GetCommonSettings<ProfilConfiguration>();
        }

        private static void AddProfil(Dictionary<string, string[]> res, string u, string profilName)
        {
            res[u] = (res.ContainsKey(u) ? res[u] : new string[0]).Union(profilName.AsArray()).Distinct().ToArray();
        }

        public void Dispose()
        {
            if (ldapManager != null)
            {
                ldapManager.Dispose();
            }
        }
    }
}