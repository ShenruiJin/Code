﻿using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Diagnostics;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Strategy;
using CaesarApplication.Service.Validation;
using CaesarApplication.TestsEngine;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Blotter;
using DealIndexDataTransferObject.Blotter.DataContracts;
using DealIndexDataTransferObject.Blotter.Tasks;
using DealIndexDataTransferObject.Converters;
using DealIndexDataTransferObject.TestsEngine;
using DealServerInterface.Service;
using DealServerInterfaceIndex.Blotter;
using DealServerInterfaceIndex.Service;
using DealServerLocalIndex.Provider;
using FuncFramework.Business;
using FuncFramework.Helpers;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.DataProvider;
using IndexDBProviderFactory = CaesarApplication.DataProvider.IndexDBProviderFactory;
using PricingCalendar = GlobalDerivativesApplications.Data.MarketData.Calendar;
using TaskStatus = DealIndexDataTransferObject.Blotter.TaskStatus;
using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Utilities;
using GlobalDerivativesApplications.Date;
using GlobalDerivativesApplications.Threading;

namespace CaesarApplication.BlotterAsService
{
    public class TaskManager : ITaskManager
    {
        private DateTime? startDate;
        private DateTime? endDate;

        private Dictionary<DateTime, IndexTask[]> tasksByDate = new Dictionary<DateTime, IndexTask[]>();

        private readonly TaskStatusManager taskStatusManager = new TaskStatusManager();

        private readonly ITimeSeriesProvider timeSeriesProvider;
        private IList<ProjectDTO> projects = new List<ProjectDTO>();

        private IList<string> validationValuesTickers = new List<string>();

        private IList<IndexDTO> indexesWithRevisions = new List<IndexDTO>();

        private readonly IIndexDBProviderFactory indexDBProviderFactory;
        private readonly IIndexDependencyManager indexDependencyManager;
        private readonly IIndexTestResultManager indexTestResultManager;
        private readonly IIndexTestDefinitionManager indexTestDefinitionManager;

        private static object lockDBLoading = new object();
        private static object lockLoadTasksLoading = new object();

        private string _configurationName = "Production";

        private ContribConfigurationItemDTO[] contributionItems;
        private IndexDependencyKey[] valuationTasksDependenciesKeys;

        public event EventHandler<TasksUpdateEventArgs> OnTasksUpdate;
        public event EventHandler<TaskStatusUpdateEventArgs> OnTasksStatusUpdate;

        private DateTime? lastRefreshRequestDate;

        private TaskContext currentTaskContext;

        private object lockRefresh = new object();

        private bool loadOnGoing;
        private ManualResetEvent projectsLoaded = new ManualResetEvent(false);

        private ElasticSearchService elasticSearchService;

        private List<TaskManagerNotification> taskManagerNotifications = new List<TaskManagerNotification>();
        
        private static TaskFactory elasticSearchTaskFactory;
        private static TaskFactory taskFactory;

        private System.Timers.Timer taskManagerNotificationsTimer = new System.Timers.Timer(1000);
        private object lockTaskManagerNotificationsTimer = new object();

        public TaskManager(IIndexDBProviderFactory indexDBProviderFactory = null,
            ITimeSeriesProvider timeSeriesProvider = null, IIndexDependencyManager indexDependencyManager = null,
            IIndexTestResultManager indexTestResultManager = null,
            IIndexTestDefinitionManager indexTestDefinitionManager = null)
            : this(indexDBProviderFactory, timeSeriesProvider, indexDependencyManager,
                indexTestResultManager, indexTestDefinitionManager, new ElasticSearchService())
        { }
        public TaskManager(IIndexDBProviderFactory indexDBProviderFactory,
        ITimeSeriesProvider timeSeriesProvider, IIndexDependencyManager indexDependencyManager,
        IIndexTestResultManager indexTestResultManager,
        IIndexTestDefinitionManager indexTestDefinitionManager, ElasticSearchService elasticSearchService)
        {
            elasticSearchTaskFactory = new TaskFactory(new WorkerTaskScheduler("ElasticSearch_Thread", MaxThreads: 1));
            taskFactory = new TaskFactory(new WorkerTaskScheduler("TaskManager_Thread", MaxThreads: 3));

            this.indexDBProviderFactory = indexDBProviderFactory ?? new IndexDBProviderFactory();
            this.indexDependencyManager = indexDependencyManager ??
                                          new IndexDependencyManager(this.indexDBProviderFactory);
            this.indexTestDefinitionManager = indexTestDefinitionManager ??
                                              new IndexTestDefinitionManager(this.indexDBProviderFactory);
            this.indexTestResultManager = indexTestResultManager ??
                                          new IndexTestResultManager(this.indexDBProviderFactory);
            taskStatusManager = new TaskStatusManager(indexDbProviderFactory: this.indexDBProviderFactory);

            this.timeSeriesProvider = timeSeriesProvider ??
                                      new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, true,
                                          dataHandlersToUse: "DB".AsArray(),
                                          indexDbProviderFactory: this.indexDBProviderFactory, noCacheLoading: true);

            IndexMessenger.OnContribConfigurationSaved += IndexMessengerOnContribConfigurationSaved;
            IndexMessenger.OnProjectsChanged += IndexMessengerOnProjectsChanged;

            IndexMessenger.OnNewQuoteInserted += IndexMessengerOnNewQuoteInserted;
            IndexMessenger.OnNewBasketInserted += IndexMessengerOnNewBasketInserted;
            IndexMessenger.OnNewTimeSeriesValueSaved += OnNewTimeSeriesValueSaved;
            IndexMessenger.OnIndexTestResultsSaved += OnIndexTestResultsSaved;
            IndexMessenger.OnTaskStatusChanged += OnTaskStatusChanged;
            this.elasticSearchService = elasticSearchService ?? new ElasticSearchService();

            Task.Factory.StartNew(() => IndexMessengerOnProjectsChanged());

            taskManagerNotificationsTimer.Elapsed += OnTaskManagerNotificationsTimerElapsed;
            taskManagerNotificationsTimer.Start();
        }

        private void OnTaskManagerNotificationsTimerElapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            lock (lockTaskManagerNotificationsTimer)
            {
                var taskManagerNotificationsToWork = taskManagerNotifications.ToArray();

                if (taskManagerNotificationsToWork.Any())
                {
                    TreatNotifications(taskManagerNotificationsToWork);
                }

                taskManagerNotifications.Clear();
            }
        }

        private void TreatNotifications(TaskManagerNotification[] notifications)
        {
            var taskContext = GetCurrentTaskContext();
            var updateRequired = false;

            foreach (var notification in notifications)
            {
                switch (notification.Type)
                {
                    case "NewQuotes":
                        {
                            var project = GetProjectForIndexId(notification.Index);
                            var quotes = (IEnumerable<IndexQuoteDTO>)notification.Data;

                            if (ContributionItems.Any(c => c.enabled && c.index_id == notification.Index.id && c.project_name == project.project_name))
                            {
                                quotes.ForEach(quote =>
                                {
                                    LoggingService.InfoFormatted(GetType(),
                                        "New quote saved impacting tasks {0} at the date {1} at value {2}",
                                        IndexPathHelper.Combine(project.project_name, notification.Index.ticker), quote.date_version, quote.value);
                                    AddValuationTask(taskContext, project, notification.Index, quote);

                                    updateRequired = true;
                                });
                            }
                        }
                        break;
                    case "NewBaskets":
                        {
                            var indexWithRevisions = IndexesWithRevisions.Where(i => i != null).FirstOrDefault(i => i.id == notification.Index.id) ?? ReadIndexWithLastRevision(notification.Index);

                            if (indexWithRevisions.IsBasketReshuffle())
                            {
                                var project = GetProjectForIndexId(notification.Index);
                                var baskets = (IEnumerable<BasketResultDTO>)notification.Data;

                                baskets.ForEach(bkt =>
                                {
                                    AddBasketTask(taskContext, project, notification.Index, bkt);
                                    LoggingService.InfoFormatted(GetType(), "IndexMessengerOnNewBasketInserted on {0} for effective date {1} created at {2} by {3} on {4}", DataPath.Create(project.project_name, notification.Index.ticker), bkt.date_version, bkt.date_creation, bkt.login, bkt.computer);
                                });

                                updateRequired = true;
                            }
                        }
                        break;
                    case "NewTimeSeriesValues":
                        {
                            foreach (var newTimeSeriesValueSavedItem in (NewTimeSeriesValueSavedItems[])notification.Data)
                            {
                                var dataFieldsEnum = (DataFieldsEnum)newTimeSeriesValueSavedItem.DataType;

                                if (validationValuesTickers.Contains(newTimeSeriesValueSavedItem.Ticker) &&
                                    ((newTimeSeriesValueSavedItem.Ticker.Contains(IndexPathHelper.Delimiter) &&
                                      dataFieldsEnum == DataFieldsEnum.IndexQuote) ||
                                     (!newTimeSeriesValueSavedItem.Ticker.Contains(IndexPathHelper.Delimiter) &&
                                      dataFieldsEnum == DataFieldsEnum.Last)))
                                {
                                    LoggingService.InfoFormatted(GetType(), "OnNewTimeSeriesValueSaved on {0} on field {1}", newTimeSeriesValueSavedItem.Ticker, dataFieldsEnum);

                                    var dates =
                                        newTimeSeriesValueSavedItem.TimeSeries.SelectMany(x => x.values)
                                            .Select(x => x.date_version)
                                            .ToArray();

                                    var impactedTasks = taskContext.ValuationTasks.Where(v => dates.Contains(v.Date)).ToArray();

                                    if (impactedTasks.Any())
                                    {
                                        taskContext.SanityCheckTasks =
                                            taskContext.SanityCheckTasks
                                                .Where(
                                                    x =>
                                                        (x.IndexDTO.validation_ticker != newTimeSeriesValueSavedItem.Ticker || !dates.Contains(x.Date))
                                                        ||
                                                        (x.ValidationValue == newTimeSeriesValueSavedItem.TimeSeries.Where(v => v.instrument == newTimeSeriesValueSavedItem.Ticker).SelectMany(v => v.values.Where(b => b.date_version == x.VersionDate).Select(b => b.value)).FirstOrDefault())
                                                        )
                                                .ToArray();

                                        RemoveSanityCheckWithDependencyImpactedByChange(taskContext, impactedTasks);

                                        updateRequired = true;
                                    }
                                }
                            }
                        }
                        break;
                    case "NewIndexTestResults":
                        {
                            foreach (var indexTestResult in (IEnumerable<IndexTestResult>)notification.Data)
                            {
                                var impactedTask = GetSanityCheckForIndexTestResult(indexTestResult, taskContext.SanityCheckTasks);

                                if (impactedTask != null)
                                {
                                    impactedTask.IndexTestResults =
                                        (impactedTask.IndexTestResults ?? new IndexTestResult[0]).Concat(indexTestResult.AsArray())
                                            .ToArray();

                                    LoggingService.InfoFormatted(GetType(), "OnIndexTestResultsSaved on {0}", impactedTask.Identifier);


                                    updateRequired = true;
                                }
                            }
                        }
                        break;
                    case "NewTaskStatuses":
                        {
                            var allTasks = GetAllTasks(taskContext);
                            var statuses = (IEnumerable<ITaskStatus>)notification.Data;


                            foreach (var taskStatus in statuses)
                            {
                                var impactedTask = allTasks.FirstOrDefault(x => x.Identifier == taskStatus.TaskKey);

                                if (impactedTask != null &&
                                    (impactedTask.Status == null || impactedTask.Status.Status != TaskStatus.Validated))
                                {
                                    impactedTask.Status = taskStatus;

                                    LoggingService.InfoFormatted(GetType(), "OnTaskStatusChanged on {0} to status {1} at {2} by {3}", impactedTask.Identifier, taskStatus.Status, taskStatus.StatusDate, taskStatus.Login);

                                    updateRequired = true;
                                }
                            }

                            var taskKeys = statuses.Select(x => x.TaskKey).ToArray();

                            taskContext.SanityCheckTasks =
                                taskContext.SanityCheckTasks.Where(
                                    x => x.Dependencies == null || !x.Dependencies.Any(d => taskKeys.Contains(d.Identifier))).ToArray();

                            RemoveSanityCheckWithDependencyImpactedByChange(taskContext, taskKeys);

                            if (OnTasksStatusUpdate != null)
                            {
                                OnTasksStatusUpdate(this, new TaskStatusUpdateEventArgs(DateTime.Now, statuses.Where(s => s is TaskStatusBase).Cast<TaskStatusBase>().ToArray()));
                            }
                        }
                        break;
                }
            }

            if (updateRequired)
            {
                RaiseUpdate(taskContext);
            }
        }

        public IList<IndexDTO> IndexesWithRevisions
        {
            get
            {
                return indexesWithRevisions;
            }
        }

        public IList<ProjectDTO> Projects
        {
            get
            {
                if (projects.Count != 0)
                    return projects;

                if (!loadOnGoing)
                {
                    IndexMessengerOnProjectsChanged();
                }
                else
                {
                    projectsLoaded.WaitOne();
                }
                return projects;
            }
        }

        private void OnTaskStatusChanged(ITaskStatus[] statuses)
        {
            taskManagerNotifications.Add(new TaskManagerNotification { Type = "NewTaskStatuses", Data = statuses });
        }

        private TaskContext GetCurrentTaskContext()
        {
            return currentTaskContext != null ? currentTaskContext.Copy() : new TaskContext();
        }

        private void OnIndexTestResultsSaved(IndexTestResult[] indexTestResults)
        {
            taskManagerNotifications.Add(new TaskManagerNotification { Type = "NewIndexTestResults", Data = indexTestResults });

        }

        private SanityCheckTask GetSanityCheckForIndexTestResult(IndexTestResult indexTestResult,
            IList<SanityCheckTask> checkTasks)
        {
            return checkTasks.FirstOrDefault(x =>
                    indexTestResult.Test.IndexId == x.IndexId
                    &&
                    x.TypedQuotationResultDTO.date_computation == indexTestResult.QuoteComputationDate
                    &&
                    x.TypedQuotationResultDTO.date_version == indexTestResult.QuoteDate
            );
        }

        private void OnNewTimeSeriesValueSaved(NewTimeSeriesValueSavedItems[] items)
        {
            taskManagerNotifications.Add(new TaskManagerNotification { Type = "NewTimeSeriesValues", Data = items });
        }

        private void RemoveSanityCheckWithDependencyImpactedByChange(TaskContext taskContext, ITask[] tasks)
        {
            taskContext.SanityCheckTasks =
                taskContext.SanityCheckTasks
                    .Where(x => x.Dependencies == null ||
                                !x.Dependencies.Any(
                                    d => tasks.Any(t => t.IndexDTO.id == d.IndexDTO.id && t.Date == d.Date))
                    ).ToArray();
        }

        private void RemoveSanityCheckWithDependencyImpactedByChange(TaskContext taskContext, string[] taskKeys)
        {
            taskContext.SanityCheckTasks =
                taskContext.SanityCheckTasks
                    .Where(x => x.Dependencies == null ||
                                !x.Dependencies.Any(d => taskKeys.Contains(d.Identifier))
                    ).ToArray();
        }

        private void IndexMessengerOnNewBasketInserted(IndexDTO index, BasketResultDTO[] baskets)
        {
            taskManagerNotifications.Add(new TaskManagerNotification { Type = "NewBaskets", Data = baskets, Index = index });
        }

        private IndexDTO ReadIndexWithLastRevision(IndexDTO index)
        {
            var idx = indexDBProviderFactory.Create().ReadIndex(index, null);

            indexesWithRevisions.Add(idx);

            return idx;
        }

        private void RaiseUpdate(TaskContext taskContext)
        {
            var requestedRefreshDate = DateTime.Now;

            lastRefreshRequestDate = requestedRefreshDate;

            lock (lockRefresh)
            {
                DateTime? requestedEndDate = endDate;
                DateTime updateDate;

                LoggingService.InfoFormatted(GetType(), "RaiseUpdate start to refresh date {0}", lastRefreshRequestDate);

                var tasks = GetAllTasks(taskContext, false, startDate.GetValueOrDefault(DateTime.Today.AddDays(-10)), ref requestedEndDate, out updateDate);

                LoggingService.InfoFormatted(GetType(), "RaiseUpdate end to refresh date {0}", lastRefreshRequestDate);


                if (OnTasksUpdate != null)
                {
                    OnTasksUpdate(this, new TasksUpdateEventArgs(updateDate, tasks));
                }
            }
        }

        private void IndexMessengerOnProjectsChanged()
        {
            try
            {
                indexesWithRevisions.Clear();
                loadOnGoing = true;
                projects = indexDBProviderFactory.Create().ReadAllProjectsWithoutRevisions(null);
                loadOnGoing = false;
                projectsLoaded.Set();

                var validationValuesTickers = projects.SelectMany(x => x.indexes)
                    .Select(x => x.validation_ticker)
                    .Distinct()
                    .Where(x => x != null)
                    .ToArray();

                this.validationValuesTickers = TransformTimeSerieTickerToSicovam(validationValuesTickers);

                LoggingService.InfoFormatted(GetType(), "IndexMessengerOnProjectsChanged");
            }
            catch (Exception ex)
            {
                loadOnGoing = false;
                projectsLoaded.Set();
                LoggingService.Error(GetType(), "Fail to load Projects with indexes", ex);
            }

        }

        private string[] TransformTimeSerieTickerToSicovam(string[] tsTickers)
        {
            string[] sicovamsToTranscode = tsTickers.Where(x => !x.Contains(IndexPathHelper.Delimiter)).ToArray();
            Dictionary<string, int> sicovamsToTranscodeResult = new Dictionary<string, int>();

            try
            {
                sicovamsToTranscodeResult = SophisHelper.GetSicovams(sicovamsToTranscode);
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), ex);
            }

            return
                tsTickers.Select(
                        t => sicovamsToTranscodeResult.ContainsKey(t) ? sicovamsToTranscodeResult[t].ToString() : t)
                    .ToArray();
        }



        private void IndexMessengerOnNewQuoteInserted(IndexDTO index, IndexQuoteDTO[] quotes)
        {
            taskManagerNotifications.Add(new TaskManagerNotification { Type = "NewQuotes", Data = quotes, Index = index });
        }

        private ContribConfigurationItemDTO[] ContributionItems
        {
            get { return contributionItems = contributionItems ?? LoadContribConfiguration(); }
        }

        private ProjectDTO GetProjectForIndexId(IndexDTO index)
        {
            return GetProjectForIndexId(index.id);
        }

        private ProjectDTO GetProjectForIndexId(long indexId)
        {
            return Projects.FirstOrDefault(x => x.indexes.Any(i => i.id == indexId));
        }

        private void IndexMessengerOnContribConfigurationSaved(ContribConfigurationItemDTO[] configurationItems)
        {
            if (configurationItems.Any(x => x.userConfigurationName == _configurationName))
            {
                contributionItems = LoadContribConfiguration();
            }

            RaiseUpdate(GetCurrentTaskContext());
        }

        public void AddValuationTask(TaskContext taskContext, ProjectDTO project, IndexDTO index, IndexQuoteDTO quote)
        {
            var newTask = new QuoteTask(project, index, quote);

            taskContext.ValuationTasks =
                taskContext.ValuationTasks.Where(v => v.Identifier != newTask.Identifier).Concat(newTask.AsArray()).ToArray();

            taskContext.SanityCheckTasks = taskContext.SanityCheckTasks.Where(s => !(s.Date == newTask.Date &&
                                                             s.IndexDTO.id == newTask.IndexDTO.id &&
                                                             (s.TypedQuotationResultDTO.value !=
                                                              newTask.TypedQuotationResultDTO.value &&
                                                              s.TypedQuotationResultDTO.id !=
                                                              newTask.TypedQuotationResultDTO.id))).ToArray();
        }

        private ContribConfigurationItemDTO[] LoadContribConfiguration()
        {
            return indexDBProviderFactory.Create()
                .LoadContribConfiguration(DateTime.Now, null, _configurationName);
        }

        public void AddBasketTask(TaskContext taskContext, ProjectDTO project, IndexDTO index, BasketResultDTO basket)
        {
            var basketValidationTask = new BasketValidationTask(project, index, basket);

            taskContext.BasketValidationTasks =
                taskContext.BasketValidationTasks.Where(b => b.Identifier != basketValidationTask.Identifier)
                    .Concat(basketValidationTask.AsArray())
                    .ToArray();
        }

        public ITask[] GetExpectedQuoteTasks(DateTime startDate, DateTime endDate)
        {
            return GetExpectedQuoteTasks(
                indexDBProviderFactory.Create().LoadContribConfiguration(DateTime.Today, null, _configurationName),
                startDate, endDate, true);
        }

        public ITask[] GetExpectedQuoteTasks(ContribConfigurationItemDTO[] contributionItems, DateTime startDate,
               DateTime endDate, bool ignoreLag = false, IDictionary<string, IndexManagementKPI> kpis = null)
        {
            var indexDbProvider = indexDBProviderFactory.Create();

            var res = new ConcurrentBag<ITask>();

            var groups = contributionItems.Group((int)Math.Round((double)contributionItems.Length / 5.0d));

            var taskDescription = "Expected Quote Task";
            var tasks = groups.Select(contributionItemsGroup => taskFactory.StartNew(() =>
            {
                var requestedStartDate = startDate;

                contributionItemsGroup.ForEach(contributionItem =>
                {
                    var stopWatch = new Stopwatch();
                    var startTime = DateTime.Now;

                    TimeSerieStringDTO calendars = null;
                    IndexDTO idx = null;
                    ProjectDTO prj = null;
                    try
                    {
                        stopWatch.Start();

                        idx = GetIndexFromId(contributionItem.index_id);
                        prj = Projects.First(x => x.project_name == contributionItem.project_name);
                        calendars = indexDbProvider.LoadTimeSerieString(
                            prj.project_name + IndexPathHelper.Delimiter + idx.ticker +
                            IndexPathHelper.Delimiter + "Calendar." + idx.index_name, 9915, null,
                            requestedStartDate.AddDays(-40), endDate, null, null);

                        var calendarsTs =
                            new TimeSerieStringDtoConverter().ConvertFromDTO(calendars.AsArray()).First();

                        var calendar = calendarsTs.Y.Cast<IPricingCalendar>().Last();

                        GetExpectedQuotes(startDate, endDate, calendar, prj, idx, ignoreLag)
                            .ForEach(x => res.Add(x));
                    }
                    catch (Exception ex)
                    {
                        LoggingService.Error(GetType(), ex);
                    }
                    finally
                    {
                        stopWatch.Stop();
                        if (idx != null)
                        {
                            var kpi = new TaskKPI(idx.index_name, taskDescription)
                            { EndTime = DateTime.Now, Duration = stopWatch.ElapsedMilliseconds, StartTime = startTime, IndexGroup = idx.index_group };
                            kpis[contributionItem.path].TaskKPIList.Add(kpi);
                        }
                    }
                });
            })).ToArray();

            tasks.ForEach(x => x.Wait());

            return res.ToArray();
        }

        private static ITask[] GetExpectedQuotes(DateTime startDate, DateTime endDate, IPricingCalendar calendar,
            ProjectDTO prj, IndexDTO idx, bool ignoreLag)
        {
            var res = new List<ITask>();

            foreach (var bday in new PricingCalendar().GetBusinessDays(startDate, endDate))
            {
                res.Add(new ExpectedQuoteTask(calendar.IsBusinessDay(bday), prj, idx, bday));
            }

            return res.Where(x => ignoreLag || x.Date <= AddDays(x, new PricingCalendar())).ToArray().ToArray();
        }

        private static DateTime AddDays(ITask x, PricingCalendar pricingCalendar)
        {
            var res = DateTime.Today;
            int nbDays = 0;

            while (nbDays < x.IndexDTO.lag)
            {
                res = res.AddDays(-1);

                if (pricingCalendar.IsBusinessDay(res))
                {
                    nbDays++;
                }
            }

            return res;
        }

        private IndexDTO GetIndexFromId(long indexId)
        {
            return Projects.SelectMany(x => x.indexes).FirstOrDefault(x => x.id == indexId);
        }

        public QuoteTask[] GetValuationTasks(ContribConfigurationItemDTO[] contributionItems, DateTime startDate,
            DateTime endDate, IDictionary<string, IndexManagementKPI> kpis = null)
        {
            var indexDbProvider = indexDBProviderFactory.Create();

            var res = new ConcurrentBag<QuoteTask>();
            var taskDescription = "Valuation Task";
          
            var tasks = contributionItems.Select(contributionItem => taskFactory.StartNew(() =>
            {
                IndexDTO idx = null;
                var stopWatch = new Stopwatch();
                var startTime = DateTime.Now;

                try
                {
                    stopWatch.Start();
                    idx = indexDbProvider.GetIndexFromId(contributionItem.index_id.ToString(), null);
                    var prj = Projects.First(x => x.project_name == contributionItem.project_name);
                    var requestedEndDate = endDate;
                    var requestedStartDate = startDate;

                    var quotes = indexDbProvider.LoadIndexQuotesByPath(null, idx.id.ToString(),
                        requestedStartDate, requestedEndDate);

                    foreach (var quote in quotes)
                    {
                        res.Add(new QuoteTask(prj, idx, quote));
                    }
                }
                catch (Exception ex)
                {
                    LoggingService.Error(GetType(), "Error while computing valuation task");
                    LoggingService.Error(GetType(), ex);
                }
                finally
                {
                    stopWatch.Stop();
                    var kpi = new TaskKPI(idx.index_name, taskDescription)
                    { EndTime = DateTime.Now, Duration = stopWatch.ElapsedMilliseconds, StartTime = startTime, IndexGroup = idx.index_group };
                    kpis[contributionItem.path].TaskKPIList.Add(kpi);
                }
            })).ToArray();
            
            tasks.ForEach(t => t.Wait());

            return res.ToArray();
        }

        public ITask[] GetPublicationTasks(TaskContext taskContext, ITask[] valuationTasks, IndexQuoteTask[] sanityCheckTasks)
        {
            var publicationsTasks =
                valuationTasks.Where(t => t.Completed)
                    .Cast<QuoteTask>()
                    .Where(t => !double.IsNaN(t.IndexQuoteDTO.value.GetValueOrDefault(double.NaN)))
                    .Select(x => new PublicationTask(x.ProjectDTO, x.IndexDTO, x.IndexQuoteDTO))
                    .ToArray();

            return
                publicationsTasks.Where(
                    x =>
                    {
                        var checkTasks =
                            taskContext.SanityCheckTasks.Cast<ITask>()
                                .Union(taskContext.IndexBasketValidationTasks)
                                .Where(t => Equals((IndexQuoteTask)t, x))
                                .ToArray();

                        return !checkTasks.Any(t => !t.Completed);
                    }).ToArray();
        }

        private static bool Equals(IndexQuoteTask t, IndexQuoteTask x)
        {
            return t.IndexQuoteDTO.date_version == x.IndexQuoteDTO.date_version && x.IndexDTO.id == t.IndexDTO.id;
        }

        //Attention ttes les taches dépendences ne sont pas de nouvelles taches
        public IList<SanityCheckTask> GetSanityCheckTasks(TaskContext taskContext,
            IndexTask<IndexQuoteDTO>[] valuationTasks, IDictionary<string, IndexManagementKPI> kpis)
        {
            var taskDescription = "Sanity check Tasks";

            var table = new Dictionary<long, TaskKPI>();
            kpis.ForEach(k =>
            {
                var kpi = new TaskKPI(k.Value.IndexName, taskDescription) { StartTime = DateTime.Now };
                table[k.Value.IndexId] = kpi;
                k.Value.TaskKPIList.Add(kpi);
            });

            var quoteTasks = valuationTasks.Cast<QuoteTask>().ToArray();

            var quoteTasksDependenciesKeys = IndexDependency.GetKeyForTasks(quoteTasks);

            var quoteDependencies = indexDependencyManager.LoadQuoteDependencies(quoteTasksDependenciesKeys);

            var indexBasketDependenciesDico = new ConcurrentDictionary<IndexDependencyKey, IndexDependency[]>(quoteDependencies);

            var indexWithTestsIds = indexTestDefinitionManager.LoadAll().Select(x => x.IndexId);

            var filteredTasks = quoteTasks
                .Select(x =>
                    new
                    {
                        Task = x,
                        Dependencies = indexBasketDependenciesDico.FirstOrDefault(i => i.Key.IndexId == x.IndexId).Value,
                        HasTests = indexWithTestsIds.Contains(x.IndexId)
                    });

            var tasks = filteredTasks
                .GroupBy(x => x.Task.IndexDTO)
                .SelectMany(x =>
                {
                    var stopWatch = new Stopwatch();
                    stopWatch.Start();

                    var values = GetValidationValues(x.Min(v => v.Task.IndexQuoteDTO.date_version),
                        x.Max(v => v.Task.IndexQuoteDTO.date_version), x.Key);

                    stopWatch.Stop();
                    if (table.ContainsKey(x.Key.id))
                        table[x.Key.id].Duration += stopWatch.ElapsedMilliseconds;

                    return x.Select(q => new SanityCheckTask(q.Task.ProjectDTO, q.Task.IndexDTO, q.Task.IndexQuoteDTO,
                                        values.Evaluate(q.Task.IndexQuoteDTO.date_version))
                    { HasTests = q.HasTests }).ToArray();
                }).ToList();

            var allTasks = tasks.Cast<ITask>()
                .Union(taskContext.ValuationTasks)
                .Union(valuationTasks)
                .Union(taskContext.SanityCheckTasks)
                .ToList();

            var execTasks = tasks.Select(task => taskFactory.StartNew(() =>
            {
                var stopWatch = new Stopwatch();
                stopWatch.Start();

                var entry = indexBasketDependenciesDico.FirstOrDefault(i => i.Key.IndexId == task.IndexId);
                if (entry.Value == null)
                    return;
                var dependencies = entry.Value;
                var taskDependencies =
                    dependencies.SelectMany(d =>
                    allTasks.Where(t => t.IndexFullPath == d.DependencyTicker && t.Date == d.DependencyValueDate));

                task.Dependencies = taskDependencies.Where(t => !(t.IndexDTO.id == task.IndexDTO.id && t.Date == task.Date)).ToList();

                stopWatch.Stop();
                if (table.ContainsKey(task.IndexId))
                {
                    table[task.IndexId].Duration += stopWatch.ElapsedMilliseconds;
                    table[task.IndexId].EndTime = DateTime.Now;
                    table[task.IndexId].IndexGroup = task.IndexDTO.index_group;
                }

            })).ToArray();
            
            execTasks.ForEach(x => x.Wait());

            taskContext.CheckedValuationTasksKeys =
                taskContext.CheckedValuationTasksKeys.Union(quoteTasks.Select(x => x.Identifier)).Distinct().ToArray();

            return tasks;
        }

        public IndexBasketValidationTask[] GetIndexBasketValidationTasks(TaskContext taskContext, QuoteTask[] valuationTasks,
            BasketValidationTask[] basketValidationTasks, IDictionary<string, IndexManagementKPI> kpis = null)
        {

            var taskDescription = "Index Basket validation Tasks";

            var table = new Dictionary<long, TaskKPI>();
            kpis.ForEach(k =>
            {
                var kpi = new TaskKPI(k.Value.IndexName, taskDescription) { StartTime = DateTime.Now };
                table[k.Value.IndexId] = kpi;
                k.Value.TaskKPIList.Add(kpi);
            });

            var indexDependencyKeys = IndexDependency.GetKeyForTasks(valuationTasks);
            var indexBasketDependenciesDico = indexDependencyManager.LoadBasketDependencies(indexDependencyKeys);

            valuationTasksDependenciesKeys = valuationTasksDependenciesKeys.Union(indexDependencyKeys).Distinct().ToArray();


            var tmp = basketValidationTasks.Select(bktValid =>
            {
                var stopWatch = new Stopwatch();
                stopWatch.Start();

                var indexBasketDependencies = indexBasketDependenciesDico.Where(dep =>
                    dep.Value.Any(d =>
                        d.DependencyTicker == bktValid.IndexFullPath &&
                        d.DependencyValueDate == bktValid.Date)).ToArray();

                stopWatch.Stop();
                if (table.ContainsKey(bktValid.IndexId))
                    table[bktValid.IndexId].Duration += stopWatch.ElapsedMilliseconds;

                return new { ValidationTask = bktValid, Dependencies = indexBasketDependencies };
            });

            var result = tmp.SelectMany(i =>
            {
                return i.Dependencies.Select(x =>
                {
                    var stopWatch = new Stopwatch();
                    stopWatch.Start();


                    var quoteTask = valuationTasks.FirstOrDefault(v => v.IndexDTO.id == x.Key.IndexId &&
                               v.TypedQuotationResultDTO.date_computation == x.Key.IndexCalculationDate &&
                               v.Date == x.Key.IndexValueDate);

                    if (quoteTask == null)
                        return null;

                    var usages = taskContext.BasketUsageValidationTasks.Where(b => i.ValidationTask.IndexDTO.id == b.IndexDTO.id
                               && i.ValidationTask.Date == b.Date && i.ValidationTask.VersionDate == b.VersionDate &&
                               b.BasketUser.id == quoteTask.IndexDTO.id).ToArray();

                    stopWatch.Stop();
                    if (table.ContainsKey(x.Key.IndexId))
                    {
                        table[x.Key.IndexId].Duration += stopWatch.ElapsedMilliseconds;
                        table[x.Key.IndexId].EndTime = DateTime.Now;
                        table[x.Key.IndexId].IndexGroup = quoteTask.IndexDTO.index_group;
                    }

                    return new IndexBasketValidationTask(quoteTask.ProjectDTO, quoteTask.IndexDTO,
                        quoteTask.IndexQuoteDTO, i.ValidationTask, usages);
                });
            }).ToArray();

            return result;
        }

        private TimeSerieDB GetValidationValues(DateTime startDate, DateTime endDate, IndexDTO index)
        {
            if (index.validation_ticker == null)
            {
                return new TimeSerieDB();
            }

            return timeSeriesProvider.Load(index.validation_ticker,
                index.validation_ticker.Contains(IndexPathHelper.Delimiter)
                    ? DataFieldsEnum.IndexQuote
                    : DataFieldsEnum.Last, startDate, endDate);
        }

        public BasketValidationTask[] GetBasketValidationTasks(DateTime startDate, DateTime endDate,
            IDictionary<string, IndexManagementKPI> kpis = null)
        {
            var stopWatch = new Stopwatch();
            string taskDescription = "Basket Validation Tasks";
            var startTime = DateTime.Now;

            var result = new BasketValidationTask[0];
            Dictionary<IndexDTO, IEnumerable<BasketResultDTO>> reshuffledBasketsByIndex = null;
            try
            {
                stopWatch.Start();
                var indexDbProvider = indexDBProviderFactory.Create();
                reshuffledBasketsByIndex = indexDbProvider.GetBasketsFromReshuffleIndexes(startDate.AddYears(-1),
                    endDate.AddYears(1), null);
                var projectsByIndexId =
                    indexDbProvider.GetProjectDtosFromIndexIds(
                        reshuffledBasketsByIndex.Keys.Select(x => x.id).Distinct().ToArray(), null);

                result = reshuffledBasketsByIndex.SelectMany(c => c.Value.
                Select(x => new BasketValidationTask(projectsByIndexId[c.Key.id], c.Key, x)))
                .Where(x => x.BasketsList.Baskets.Any()).ToArray();
            }
            catch (Exception ex)
            {
                var type = GetType();
                LoggingService.Error(type, "Error while retrieving basket validation tasks");
                LoggingService.Error(type, ex);
            }
            finally
            {
                stopWatch.Stop();
                var endtTime = DateTime.Now;
                var duration = stopWatch.ElapsedMilliseconds;
                kpis.ForEach(k =>
                {
                    var kpi = new TaskKPI(k.Value.IndexName, taskDescription)
                    {
                        EndTime = endtTime,
                        Duration = duration,
                        StartTime = startTime
                    };
                    var basket = result.FirstOrDefault(i => i.IndexId == k.Value.IndexId);
                    IndexDTO idx = null;
                    if (basket == null)
                        idx = indexDBProviderFactory.Create().GetIndexFromId(k.Value.IndexId.ToString(), null);
                    else
                        idx = basket.IndexDTO;

                    kpi.IndexGroup = idx.index_group;
                    k.Value.TaskKPIList.Add(kpi);
                });
            }
            return result;
        }

        public BasketUsageValidationTask[] GetBasketUsageValidationTasks(BasketValidationTask[] basketValidationTasks,
            IDictionary<string, IndexManagementKPI> kpis = null)
        {
            var taskDescription = "Basket Usage Validation Task";

            try
            {
                var indexBasketDependencies = indexDependencyManager.
                    LoadBasketDependencies(basketValidationTasks.Select(b =>
                    new IndexDependencyValueKey { DependencyTicker = b.IndexFullPath, DependencyValueDate = b.Date }).ToArray());

                var dict = basketValidationTasks.GroupBy(x => x.IndexDTO).ToDictionary(x => x.Key, x => x.ToArray());
                var tasks = dict.SelectMany(c => c.Value.SelectMany(x =>
                    {
                        var stopWatch = new Stopwatch();
                        var startTime = DateTime.Now;
                        stopWatch.Start();
                        try
                        {
                            var projectForIndexId = GetProjectForIndexId(c.Key);
                            if (projectForIndexId == null) return new BasketUsageValidationTask[] { default(BasketUsageValidationTask) };

                            var path = projectForIndexId.project_name + IndexTask.Delimiter + c.Key.ticker;
                            var tmp = indexBasketDependencies.Where(d => d.DependencyTicker == path).Select(d => d.IndexId).Distinct().ToList();
                            return tmp.Select(t =>
                            {
                                bool isInScope = ContributionItems.Any(e => e.enabled && e.index_id == t);
                                var index = GetIndexFromId(t);
                                return index == null || !isInScope ? null :
                                new BasketUsageValidationTask(projectForIndexId, c.Key, x.TypedQuotationResultDTO, index);
                            }).Where(t => t != null).ToArray();
                        }
                        catch (Exception e)
                        {
                            var type = GetType();
                            LoggingService.Error(type, "Error while computing basket usage validation task for " + x.Project);
                            LoggingService.Error(type, e);
                            return new BasketUsageValidationTask[] { default(BasketUsageValidationTask) };
                        }
                        finally
                        {
                            stopWatch.Stop();
                            var endtTime = DateTime.Now;
                            var duration = stopWatch.ElapsedMilliseconds;

                            var kvp = kpis.FirstOrDefault(k => k.Key.StartsWith(x.IndexId.ToString()));
                            if (kvp.IsNotDefault())
                            {
                                var kpi = new TaskKPI(kvp.Value.IndexName, taskDescription)
                                { StartTime = startTime, EndTime = endtTime, Duration = duration, IndexGroup = x.IndexDTO.index_group };
                                kvp.Value.TaskKPIList.Add(kpi);
                            }
                        }

                    }));

                return tasks.Where(i => i != null).ToArray();

            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), ex);
                return new BasketUsageValidationTask[0];
            }
        }

        public BlotterNotification GetCurrentTasks(DateTime? lastUpdateDate, bool refreshFromDB, DateTime requestedStartDate, DateTime? requestedEndDate)
        {
            DateTime updateDate;

            ITask[] allTasks = GetAllTasks(GetCurrentTaskContext(), refreshFromDB, requestedStartDate, ref requestedEndDate, out updateDate);

            return GetBlotterNotificationFromDelta(lastUpdateDate, updateDate, allTasks, requestedStartDate, requestedEndDate);
        }

        private ITask[] GetAllTasks(TaskContext taskContext, bool refreshFromDB, DateTime requestedStartDate, ref DateTime? requestedEndDate,
            out DateTime updateDate)
        {
            lock (lockRefresh)
            {
                updateDate = DateTime.Now;
                var localContext = taskContext ?? new TaskContext();

                var allTasks = GetAllTasks(localContext, refreshFromDB, requestedStartDate, ref requestedEndDate, updateDate);

                var indexTasks = allTasks.Cast<IndexTask>().ToArray();

                if (tasksByDate.ContainsKey(updateDate))
                {
                    tasksByDate[updateDate] = indexTasks;
                }
                else
                {
                    tasksByDate.Add(updateDate, indexTasks);
                }
                //clean up tasks older than an hour
                tasksByDate.Remove(i => DateTime.Now.Subtract(i.Key).Hours > 1);
                return allTasks;
            }
        }

        public ITask[] GetAllTasks(TaskContext taskContext, bool refreshFromDB, DateTime requestedStartDate, ref DateTime? requestedEndDate,
            DateTime lastUpdateDate)
        {
            var kpiContainer = new Dictionary<string, IndexManagementKPI>();

            try
            {
                if (ShouldReloadFromDB(refreshFromDB, requestedStartDate, requestedEndDate))
                {
                    var contribConfigurationItems = indexDBProviderFactory.Create()
                        .LoadContribConfiguration(DateTime.Now, null, _configurationName);

                    contribConfigurationItems.ForEach(i => kpiContainer.Add(i.path,
                        new IndexManagementKPI() { IndexName = i.project_name, IndexId = i.index_id }));

                    taskContext.IndexBasketValidationTasks = new IndexBasketValidationTask[0];
                    taskContext.CheckedValuationTasksKeys = new string[0];
                    valuationTasksDependenciesKeys = new IndexDependencyKey[0];
                    taskContext.SanityCheckTasks = new SanityCheckTask[0];

                    requestedEndDate = requestedEndDate ?? DateTime.Now;

                    LogStart("GetExpectedQuoteTasks", requestedStartDate, requestedEndDate);

                    //no need to lock
                    //////////////////////////////////
                    taskContext.ExpectedQuoteTasks = GetExpectedQuoteTasks(contribConfigurationItems, requestedStartDate,
                        requestedEndDate.GetValueOrDefault(), kpis: kpiContainer);
                    //////////////////////////////////

                    LogEnd("GetExpectedQuoteTasks", requestedStartDate, requestedEndDate, taskContext.ExpectedQuoteTasks.Length);

                    LogStart("GetValuationTasks", requestedStartDate, requestedEndDate);

                    //no need to lock
                    //////////////////////////////////
                    taskContext.ValuationTasks = GetValuationTasks(contribConfigurationItems, requestedStartDate,
                        requestedEndDate.GetValueOrDefault(), kpis: kpiContainer);
                    //////////////////////////////////


                    LogEnd("GetValuationTasks", requestedStartDate, requestedEndDate, taskContext.ValuationTasks.Length);

                    LogStart("GetBasketValidationTasks", requestedStartDate, requestedEndDate);


                    //no need to lock
                    //////////////////////////////////
                    taskContext.BasketValidationTasks = GetBasketValidationTasks(requestedStartDate,
                        requestedEndDate.GetValueOrDefault(), kpis: kpiContainer);
                    //////////////////////////////////


                    LogEnd("GetBasketValidationTasks", requestedStartDate, requestedEndDate, taskContext.BasketValidationTasks.Length);

                    LogStart("GetBasketUsageValidationTasks", requestedStartDate, requestedEndDate);


                    //no need to lock
                    //////////////////////////////////
                    taskContext.BasketUsageValidationTasks = GetBasketUsageValidationTasks(taskContext.BasketValidationTasks,
                        kpis: kpiContainer);
                    //////////////////////////////////



                    LogEnd("GetBasketUsageValidationTasks", requestedStartDate, requestedEndDate, taskContext.BasketUsageValidationTasks.Length);

                    startDate = requestedStartDate;
                    endDate = requestedEndDate.GetValueOrDefault();


                    //////////////////////////////////
                    taskStatusManager.LoadStatuses(
                        taskContext.BasketValidationTasks.Cast<ITask>()
                            .Union(taskContext.ValuationTasks));
                    //////////////////////////////////
                }


                var oldIndexBasketValidationTasks = taskContext.IndexBasketValidationTasks;

                LogStart("GetBasketUsageValidationTasks", requestedStartDate, requestedEndDate);

                //////////////////////////////////
                taskContext.IndexBasketValidationTasks = oldIndexBasketValidationTasks.Union(
                        GetIndexBasketValidationTasks(taskContext, GetEligibleValuationTasksWithoutIndexChecks(taskContext),
                        taskContext.BasketValidationTasks, kpis: kpiContainer)).ToArray();
                //////////////////////////////////

                //////////////////////////////////
                taskStatusManager.LoadStatuses(taskContext.BasketUsageValidationTasks);
                //////////////////////////////////

                LogEnd("GetBasketUsageValidationTasks", requestedStartDate, requestedEndDate, taskContext.IndexBasketValidationTasks.Length);

                LogStart("GetSanityCheckTasks", requestedStartDate, requestedEndDate);
                var oldsanityCheckTasks = taskContext.SanityCheckTasks.ToArray();

                //no need to lock
                //////////////////////////////////
                var eligibleValuationTasksWithoutSanityCheck =
                    GetEligibleValuationTasksWithoutSanityCheck(taskContext, oldsanityCheckTasks, kpis: kpiContainer);
                //////////////////////////////////


                //no need to lock
                //////////////////////////////////
                var uneligibleValuationTasksForSanityCheck =
                    taskContext.ValuationTasks.Where(x => x.Completed && !taskContext.CheckedValuationTasksKeys.Contains(x.Identifier))
                        .Except(eligibleValuationTasksWithoutSanityCheck);
                //////////////////////////////////

                //no need to lock
                //////////////////////////////////
                var newSanityChecks = GetSanityCheckTasks(taskContext, eligibleValuationTasksWithoutSanityCheck, kpis: kpiContainer);
                //////////////////////////////////

                taskContext.CheckedValuationTasksKeys =
                    taskContext.CheckedValuationTasksKeys.Union(uneligibleValuationTasksForSanityCheck.Select(x => x.Identifier))
                        .Distinct().ToArray();

                var newSanityChecksKeys = newSanityChecks.Select(x => x.Identifier);

                //////////////////////////////////
                ReportStatusFromOldTasks(oldsanityCheckTasks, newSanityChecks.ToArray());
                //////////////////////////////////

                //////////////////////////////////
                taskContext.SanityCheckTasks = newSanityChecks.Concat(oldsanityCheckTasks
                    .Where(x => newSanityChecksKeys.DoesNotContain(x.Identifier))).ToList();
                //////////////////////////////////

                taskStatusManager.LoadStatuses(newSanityChecks);
                indexTestResultManager.LoadForTasks(newSanityChecks);

                //no need to lock saving to db 
                ValidateCompletionPending(taskContext);
                LogEnd("GetSanityCheckTasks", requestedStartDate, requestedEndDate, taskContext.SanityCheckTasks.Count);

                var checkTasks = taskContext.SanityCheckTasks.Concat(taskContext.IndexBasketValidationTasks.Cast<ITask>()).Cast<IndexQuoteTask>();

                LogStart("GetPublicationTasks", requestedStartDate, requestedEndDate);
                //////////////////////////////////

                var valuationTaskForPublicationTasks = GetValuationTasksForPublicationTasks(taskContext, taskContext.ValuationTasks);

                var oldPublicationTasks = taskContext.PublicationTasks.ToArray();

                taskContext.PublicationTasks = GetPublicationTasks(taskContext, valuationTaskForPublicationTasks, checkTasks.ToArray());
                ReportStatusFromOldTasks(oldPublicationTasks, taskContext.PublicationTasks.ToArray());
                //////////////////////////////////

                taskStatusManager.LoadStatuses(taskContext.PublicationTasks.Where(x => x.Status == null || x.Status.Status != TaskStatus.Validated));
                LogEnd("GetPublicationTasks", requestedStartDate, requestedEndDate, taskContext.SanityCheckTasks.Count);

                currentTaskContext = taskContext;

                elasticSearchTaskFactory.StartNew(() =>
                {
                    try
                    {
                        foreach (var kpi in kpiContainer.Values)
                        {
                            kpi.TaskKPIList.ForEach(t =>
                            {
                                var res = elasticSearchService.Client.IndexAsync(t);
                            });
                        }
                    }
                    catch (Exception innerE)
                    {
                        LoggingService.Error(this.GetType(), innerE);
                    }
                });

                return GetAllTasks(taskContext);
            }
            catch (Exception e)
            {
                LoggingService.Error(this.GetType(), e);
                return null;
            }
        }

        private bool ShouldReloadFromDB(bool refreshFromDB, DateTime requestedStartDate, DateTime? requestedEndDate)
        {
            return refreshFromDB || !startDate.HasValue || !endDate.HasValue || requestedStartDate < startDate || requestedEndDate > endDate;
        }

        private void LogEnd(string methodName, DateTime requestedStartDate, DateTime? requestedEndDate, int count)
        {
            LoggingService.InfoFormatted(GetType(), methodName + " from {0} to {1} finished with {2} values",
                requestedStartDate, requestedEndDate, count);
        }

        private void LogStart(string methodName, DateTime requestedStartDate, DateTime? requestedEndDate)
        {
            LoggingService.InfoFormatted(GetType(), methodName + " from {0} to {1}", requestedStartDate, requestedEndDate);
        }

        private QuoteTask[] GetValuationTasksForPublicationTasks(TaskContext taskContext, QuoteTask[] valuationTasks)
        {
            return valuationTasks.Where(x => taskContext.CheckedValuationTasksKeys.Contains(x.Identifier)).ToArray();
        }

        private void ReportStatusFromOldTasks(ITask[] oldTasks, ITask[] newTasks)
        {
            var oldCheckTasksAsDico = oldTasks.ToDictionary(x => x.Identifier, x => x);

            foreach (var newTask in newTasks)
            {
                if (oldCheckTasksAsDico.ContainsKey(newTask.Identifier))
                {
                    newTask.Status = oldCheckTasksAsDico[newTask.Identifier].Status;
                }
            }
        }

        public ITask[] GetAllTasks()
        {
            return GetAllTasks(GetCurrentTaskContext());
        }

        public ITask[] GetAllTasks(TaskContext taskContext)
        {
            return taskContext.BasketValidationTasks.Cast<ITask>()
                .Union(taskContext.ValuationTasks)
                .Union(taskContext.ExpectedQuoteTasks)
                .Union(taskContext.IndexBasketValidationTasks)
                .Union(taskContext.BasketUsageValidationTasks)
                .Union(taskContext.SanityCheckTasks)
                .Union(taskContext.PublicationTasks)
                .Distinct().ToArray();
        }

        private void ValidateCompletionPending(TaskContext taskContext)
        {
            var valuationTasksToComplete = GetAllTasks(taskContext).Where(x => x.Status != null && x.Status.Status == TaskStatus.InternalValidating).ToArray();

            valuationTasksToComplete.ForEach(x => x.Status.Status = TaskStatus.Validated);

            taskStatusManager.SaveStatuses(valuationTasksToComplete);
        }

        private IndexTask<IndexQuoteDTO>[] GetEligibleValuationTasksWithoutSanityCheck(TaskContext taskContext, IndexTask<IndexQuoteDTO>[] oldsanityCheckTasks,
            IDictionary<string, IndexManagementKPI> kpis = null)
        {
            var taskDescription = "Eligible validation tasks without sanity check";
            var stopWatch = new Stopwatch();
            var startTime = DateTime.Now;

            try
            {
                stopWatch.Start();
                var completedTasks = taskContext.ValuationTasks.Where(x => x.CompletedOrCompleting).ToArray();

                var nonTreatedTasks = GetNonTreatedTasks(oldsanityCheckTasks, completedTasks);

                var quoteTasksDependenciesKeys = IndexDependency.GetKeyForTasks(nonTreatedTasks);
                var indexBasketDependenciesDico = indexDependencyManager.LoadQuoteDependencies(quoteTasksDependenciesKeys);

                var indexWithTestsIds = indexTestDefinitionManager.LoadAll().Select(x => x.IndexId).ToArray();

                return nonTreatedTasks.Select(x =>
                        new
                        {
                            Task = x,
                            Dependencies = indexBasketDependenciesDico.Where(i => i.Key.IndexId == x.IndexId).ToArray(),
                            HasTests = indexWithTestsIds.Contains(x.IndexId)
                        })
                    .Where(x => HasValidationValue(x.Task) || x.HasTests || x.Dependencies.Any()).Select(x => x.Task).ToArray();

            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Failed to retrieve Eligible validation tasks without sanity check");
                LoggingService.Error(GetType(), ex);
                return new IndexTask<IndexQuoteDTO>[0];
            }
            finally
            {
                stopWatch.Stop();
                var endtTime = DateTime.Now;
                var duration = stopWatch.ElapsedMilliseconds;
                kpis.Values.ForEach(v =>
                {
                    var kpi = new TaskKPI(v.IndexName, taskDescription)
                    { StartTime = startTime, EndTime = endtTime, Duration = duration };
                    var task = oldsanityCheckTasks.Union(taskContext.ExpectedQuoteTasks).FirstOrDefault(i => i.IndexDTO.id == v.IndexId);
                    IndexDTO idx = null;
                    if (task == null)
                        idx = indexDBProviderFactory.Create().GetIndexFromId(v.IndexId.ToString(), null);
                    else
                        idx = task.IndexDTO;

                    kpi.IndexGroup = idx.index_group;

                    v.TaskKPIList.Add(kpi);
                });
            }

        }

        private static QuoteTask[] GetNonTreatedTasks(IndexTask<IndexQuoteDTO>[] oldTasks, QuoteTask[] tasksToTreat)
        {
            return tasksToTreat.Where(vTask =>
                    !oldTasks.Any(
                        sTask =>
                            sTask.IndexDTO.id == vTask.IndexDTO.id &&
                            sTask.QuotationResultDTO.date_version == vTask.QuotationResultDTO.date_version))
                .ToArray();
        }

        private QuoteTask[] GetEligibleValuationTasksWithoutIndexChecks(TaskContext taskContext)
        {
            return taskContext.ValuationTasks.Where(vTask => !valuationTasksDependenciesKeys.Contains(IndexDependency.GetKeyForTask(vTask))).Distinct().ToArray();
        }

        private static bool HasValidationValue(QuoteTask x)
        {
            return !string.IsNullOrEmpty(x.IndexDTO.validation_ticker) && x.IndexDTO.validation_threshold.HasValue;
        }

        public BlotterNotification GetBlotterNotificationFromDelta(DateTime? lastUpdateDate, DateTime updateDate, ITask[] allTasks, DateTime? requestedStartDate, DateTime? requestedEndDate)
        {
            var tasksToUpdate = allTasks.Where(t => (!requestedStartDate.HasValue || requestedStartDate == DateTime.MinValue || t.Date >= requestedStartDate.GetValueOrDefault()) && (!requestedEndDate.HasValue || requestedEndDate == DateTime.MinValue || t.Date <= requestedEndDate.GetValueOrDefault())).ToArray();


            var oldTasks = lastUpdateDate.HasValue && tasksByDate.ContainsKey(lastUpdateDate.Value)
                ? tasksByDate[lastUpdateDate.Value]
                : new IndexTask[0];

            var oldTasksIdentifiers = oldTasks.Select(x => x.Identifier).ToList();
            var newTasksIdentifiers = tasksToUpdate.Select(x => x.Identifier).ToList();

            var newItems = tasksToUpdate.Cast<IndexTask>().Where(t => !oldTasksIdentifiers.Contains(t.Identifier)).ToArray();

            var removedItems = oldTasks.Where(i => !newTasksIdentifiers.Contains(i.Identifier)).ToArray();

            var oldTaskMaxStatusDate = oldTasks.Length == 0 ? DateTime.MinValue : oldTasks.Where(x => x.Status != null).Max(x => x.Status.StatusDate);

            var taskWithStatusChangedKeys = tasksToUpdate.Where(x => x.Status != null && x.Status.StatusDate >= lastUpdateDate.GetValueOrDefault(oldTaskMaxStatusDate).AddMinutesSecurised(-10)).ToArray();

            var newQuotationResultTask = tasksToUpdate.Where(t => oldTasksIdentifiers.Contains(t.Identifier))
                .Where(
                    newTask =>
                    {
                        var indexTask = oldTasks.First(oldTask => oldTask.Identifier == newTask.Identifier);

                        return indexTask.QuotationResultDTO != null &&
                               indexTask.QuotationResultDTO.id != newTask.QuotationResultDTO.id;
                    })
                .ToArray();

            var newValidationResultTask = tasksToUpdate.Where(t => t is SanityCheckTask && oldTasksIdentifiers.Contains(t.Identifier))
                .Cast<SanityCheckTask>()
        .Where(
            newTask =>
            {
                var oldTask = ((SanityCheckTask)oldTasks.First(t => t is SanityCheckTask && t.Identifier == newTask.Identifier));

                return
                HasValidationTestsChanged(oldTask, newTask)
                ||
                HasValidationValueChanged(oldTask, newTask);
            })
        .ToArray();

            var basketValidationTasks = tasksToUpdate.Where(t => t is BasketValidationTask).Cast<BasketValidationTask>().ToArray();
            var basketUsageValidationTasks = tasksToUpdate.Where(t => t is BasketUsageValidationTask).Cast<BasketUsageValidationTask>().ToArray();
            var indexBasketValidationTasks = tasksToUpdate.Where(t => t is IndexBasketValidationTask).Cast<IndexBasketValidationTask>().ToArray();

            var indexBasketValidationTasksHasChanged = taskWithStatusChangedKeys.Where(x => x.Type == TaskType.IndexBasketValidation)
                .Cast<IndexBasketValidationTask>()
                .SelectMany(x => basketValidationTasks.Where(v => v.Identifier == x.ValidationTask.Identifier)).ToArray();


            var indexBasketValidationTasksHasChangedFomBuv = basketUsageValidationTasks.Where(x => x.Type == TaskType.BasketUsageValidation)
                .SelectMany(x => indexBasketValidationTasks.Where(v => v.BasketUsageValidationTasks.Any(buv => buv.Identifier == x.Identifier))).ToArray();


            var modifiedItems = taskWithStatusChangedKeys.Union(newQuotationResultTask).Union(indexBasketValidationTasksHasChangedFomBuv).Union(newValidationResultTask).Union(indexBasketValidationTasksHasChanged).Distinct().Except(newItems).Cast<IndexTask>().ToArray();

            LoggingService.InfoFormatted(GetType(), "Delta at {0}", updateDate);
            newItems.ForEach(i => LoggingService.InfoFormatted(GetType(), "Added Items : {0}", i.Identifier));
            removedItems.ForEach(i => LoggingService.InfoFormatted(GetType(), "Removed Items : {0}", i.Identifier));
            modifiedItems.ForEach(i => LoggingService.InfoFormatted(GetType(), "ModifiedItems Items : {0}", i.Identifier));

            return new BlotterNotification
            {
                NotificationDate = updateDate,
                StartDate = requestedStartDate != DateTime.MinValue ? requestedStartDate : this.startDate,
                EndDate = requestedEndDate.GetValueOrDefault() != DateTime.MinValue ? requestedEndDate.GetValueOrDefault() : this.endDate.GetValueOrDefault(),
                AddedItems = newItems,
                RemovedItems = removedItems,
                ModifiedItems = modifiedItems
            };
        }

        private static bool HasValidationTestsChanged(SanityCheckTask oldTask, SanityCheckTask newTask)
        {
            return (oldTask.IndexTestResults ?? new IndexTestResult[0]).Length != (newTask.IndexTestResults ?? new IndexTestResult[0]).Length;
        }

        private static bool HasValidationValueChanged(SanityCheckTask oldTask, SanityCheckTask newTask)
        {
            return (!(double.IsNaN(oldTask.ValidationValue) && double.IsNaN(newTask.ValidationValue)) && oldTask.ValidationValue != newTask.ValidationValue);
        }

        public class TaskManagerNotification
        {
            public Object Data { get; set; }
            public string Type { get; set; }

            public IndexDTO Index { get; set; }
        }
    }
}