﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Blotter;
using DealServerInterface.Service;
using DealServerInterfaceIndex.Blotter;
using GlobalDerivativesApplications.Reporting;

namespace CaesarApplication.BlotterAsService
{
    public class TaskStatusManager : ITaskStatusManager
    {
        private readonly IIndexDBProviderFactory indexDbProviderFactory;

        public readonly string statusFilePath = ConfigurationManager.AppSettings["TaskStatusFilePath"] ??
                                        Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "TaskStatuses.xml");

        private IExecutionTaskManager executionTaskManager;

        public TaskStatusManager(IExecutionTaskManager executionTaskManager = null, IIndexDBProviderFactory indexDbProviderFactory = null)
        {
            this.indexDbProviderFactory = indexDbProviderFactory ?? new IndexDBProviderFactory();
            this.executionTaskManager = executionTaskManager ?? new ExecutionTaskManager(this.indexDbProviderFactory);
        }

        public TaskStatusBase[] LoadStatuses(IEnumerable<ITask> tasksToUpdate, DateTime? startDate = null, DateTime? endDate = null, bool apply = true, bool applyOnInternalStatus = false)
        {
            var lastestStatusByKey =
                indexDbProviderFactory.Create()
                    .LoadLastStatusesForTasks(tasksToUpdate
                    .Where(t => (applyOnInternalStatus || t.Status == null || t.Status.Status != TaskStatus.InternalValidating))
                    .Select(x => x.Identifier).ToArray(), startDate, endDate);

            if (apply)
            {
                lastestStatusByKey.ForEach(s =>
                {
                    var taskToUpdate = tasksToUpdate.FirstOrDefault(x => x.Identifier == s.Key);

                    if (taskToUpdate != null && (applyOnInternalStatus || taskToUpdate.Status == null || taskToUpdate.Status.Status != TaskStatus.InternalValidating))
                    {
                        taskToUpdate.Status = s.Value;
                    }
                });
            }

            return lastestStatusByKey.Select(x => x.Value).ToArray();
        }

        private string[] ReadAllLinesLockFree()
        {
            using (var fs = new StreamReader(File.Open(statusFilePath, FileMode.Open, FileAccess.Read, FileShare.Read)))
            {
                return fs.ReadToEnd().Split(Environment.NewLine.AsArray(), StringSplitOptions.RemoveEmptyEntries);
            }
        }

        public void SaveStatuses(IEnumerable<ITask> tasksToSave)
        {
            var executionTasks = new List<ExecutionTaskDTO>();

            var tasksAsArray = tasksToSave as ITask[] ?? tasksToSave.Where(x => x.Status != null).ToArray();

            var lastStatusesForTask =
                indexDbProviderFactory.Create()
                    .LoadLastStatusesForTasks(tasksAsArray.Select(x => x.Identifier).ToArray());

            foreach (var task in tasksAsArray)
            {
                ExecutionTaskDTO[] taskExecutionTasks = new ExecutionTaskDTO[0];

                if (!lastStatusesForTask.ContainsKey(task.Identifier) || lastStatusesForTask[task.Identifier].Status == TaskStatus.Pending)
                {
                    if (task.Status.Status == TaskStatus.ToValidate)
                    {
                        taskExecutionTasks = executionTaskManager.CreateExecutionTasks(task);
                    }
                }

                if (task.Status.Status == TaskStatus.ToValidate)
                {
                    if (taskExecutionTasks.Any())
                    {
                        executionTasks.AddRange(taskExecutionTasks);
                        task.Status.Status = TaskStatus.Validating;
                    }
                    else
                    {
                        task.Status.Status = TaskStatus.InternalValidating;
                    }
                }
            }

            SaveTaskStatuses(GetChangingTaskStatuses(tasksAsArray, lastStatusesForTask));

            indexDbProviderFactory.Create().SaveExecutionTasks(executionTasks.ToArray(), null);
        }

        private static TaskStatusBase[] GetChangingTaskStatuses(ITask[] tasksAsArray, Dictionary<string, TaskStatusBase> lastStatusesForTask)
        {
            return tasksAsArray.Where(t => t.Status != null && (!lastStatusesForTask.ContainsKey(t.Identifier) || lastStatusesForTask[t.Identifier].Status != t.Status.Status)).Select(t => (TaskStatusBase)t.Status).ToArray();
        }

        public void SaveTaskStatuses(TaskStatusBase[] taskStatuses)
        {
            var nonInternalStatus = taskStatuses.Where(x => x.Status != TaskStatus.InternalValidating).ToArray();

            if (nonInternalStatus.Any())
            {
                indexDbProviderFactory.Create().SaveTaskStatuses(nonInternalStatus, null);
            }
        }
    }
}
