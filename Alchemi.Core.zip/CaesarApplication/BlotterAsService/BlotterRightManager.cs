﻿using System.Configuration;
using System.IO;
using System.Linq;
using DealIndexDataTransferObject.Blotter.DataContracts;
using DealServerInterfaceIndex.Blotter;
using GlobalDerivativesApplications.Serialization;
using GlobalDerivativesApplications.Settings;
using CaesarApplication.Service.Logging;

namespace CaesarApplication.BlotterAsService
{
    public class BlotterRightManager : IBlotterRightManager
    {
        public string BlotterRightsFilePath = ConfigurationManager.AppSettings["BlotterRightsFilePath"];

        public BlotterRight[] GetRights(string[] profiles)
        {
            var rights = ReadRights();

            return profiles.SelectMany(x => rights.Where(r => r.ProfileName == x)).ToArray();
        }

        private BlotterRight[] ReadRights()
        {
            if (BlotterRightsFilePath == null)
            {
                var settingsManager = new GdaSettingsMgr("CLIQIndexes.Blotter.RightManager");
                return settingsManager.GetCommonSettings<BlotterRights>().Rights.ToArray();
            }

            if (File.Exists(BlotterRightsFilePath))
                return File.ReadAllText(BlotterRightsFilePath).FromSerializedString<BlotterRights>().Rights;
            else
            {
                LoggingService.Error(GetType(), "Unable to locate rights file at : " + BlotterRightsFilePath);
                return new BlotterRight[0];
            }
        }
    }
}