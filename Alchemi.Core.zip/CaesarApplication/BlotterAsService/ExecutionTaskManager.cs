﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Xml.Serialization;
using CaesarApplication.BlotterAsService.ExecutionTaskStrategies;
using CaesarApplication.BlotterAsService.Notifications;
using CaesarApplication.Service.Configuration;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Blotter;
using DealServerInterface.Service;
using DealServerLocalIndex.Provider;
using GlobalDerivativesApplications.Serialization;
using PricingBase.DataProvider;

namespace CaesarApplication.BlotterAsService
{
    public class ExecutionTaskManager : IExecutionTaskManager
    {
        private Assembly[] executionTaskStrategyTaskTypeAssemblies = new Assembly[]
        {
           typeof(ExecutionTaskManager).Assembly
        };

        private Dictionary<string, Type> executionTaskStrategyTaskTypeByStrategyName = null;
        private IIndexDBProviderFactory indexDbProviderFactory;
        private ExecutionTaskDefinitionDTO[] executionTaskDefinitions;

        public ExecutionTaskManager(IIndexDBProviderFactory indexDbProviderFactory)
        {
            this.indexDbProviderFactory = indexDbProviderFactory;

            IndexMessenger.OnExecutionTaskDefinitionsChanged += () =>
            {
                executionTaskDefinitions = null;
            };
        }

        public Assembly[] ExecutionTaskStrategyTaskTypeAssemblies
        {
            get { return executionTaskStrategyTaskTypeAssemblies; }
            set { executionTaskStrategyTaskTypeAssemblies = value; }
        }

        public Dictionary<string, Type> ExecutionTaskStrategyTaskTypeByStrategyName
        {
            get { return executionTaskStrategyTaskTypeByStrategyName = executionTaskStrategyTaskTypeByStrategyName ?? LoadExecutionTaskStrategyTaskTypeByStrategyName(); }
            set { executionTaskStrategyTaskTypeByStrategyName = value; }
        }

        public ExecutionTaskDTO[] CreateExecutionTasks(ITask blotterTask)
        {
            var executionTaskDefinitions = GetExecutionTaskDefinitionDTOForTask(blotterTask);

            return executionTaskDefinitions.Select(def => CreateExecutionTask(def, blotterTask)).ToArray();
        }

        private ExecutionTaskDTO CreateExecutionTask(string strategyName, string login, string taskKey, Func<ExecutionTaskStrategy, IExecutionTaskStrategyParameters> getExecutionTaskStrategyParameters)
        {
            var taskStrategy = CreateEmptyTaskStrategy(strategyName);

            var strategyParameters = getExecutionTaskStrategyParameters(taskStrategy);
            taskStrategy.Parameters = strategyParameters;

            var creationDate = DateTime.Now;

            return new ExecutionTaskDTO
            {
                CreationDate = creationDate,
                TaskContent = ToDataContractSerializedString(taskStrategy, taskStrategy.Parameters.GetType().AsArray()),
                TaskKey = taskKey,
                CreatorLogin = login,
                StatusDate = creationDate,
                Status = ExecutionTaskDTOStatus.Creating,
                StrategyName = strategyName
            };
        }

        public ExecutionTaskDTO CreateExecutionTask(string strategyName, string login, string taskKey, IExecutionTaskStrategyParameters executionTaskStrategyParameters)
        {
            return CreateExecutionTask(strategyName, login, taskKey, taskStrategy =>
            {
                return executionTaskStrategyParameters;
            });
        }

        private ExecutionTaskDTO CreateExecutionTask(ExecutionTaskDefinitionDTO executionTaskDefinition, ITask blotterTask)
        {
            return CreateExecutionTask(executionTaskDefinition.StrategyName, blotterTask.Status.Login, blotterTask.Identifier, taskStrategy =>
            {
                var strategyParameters = GetExecutionTaskStrategyParameters(executionTaskDefinition, taskStrategy);

                if (strategyParameters is IPricingDateHolder)
                {
                    ((IPricingDateHolder)strategyParameters).PricingDate = blotterTask.Date;
                }

                if (strategyParameters is ITaskInformationsHolder)
                {
                    ((ITaskInformationsHolder)strategyParameters).IndexId = blotterTask.IndexDTO.id;
                    ((ITaskInformationsHolder)strategyParameters).BBGTicker = blotterTask.BBGTicker;
                }

                if (strategyParameters is IIndexQuoteHolder && blotterTask is ITask<IndexQuoteDTO>)
                {
                    ((IIndexQuoteHolder)strategyParameters).Quote = ((ITask<IndexQuoteDTO>)blotterTask).TypedQuotationResultDTO.GetIndexQuoteInfos();
                }

                return strategyParameters;
            });
        }

        private string ToDataContractSerializedString(Object objToSerialize, Type[] knownTypes)
        {
            using (var memStream = new MemoryStream())
            {
                new DataContractSerializer(objToSerialize.GetType(), knownTypes).WriteObject(memStream, objToSerialize);

                return Encoding.UTF8.GetString(memStream.ToArray());
            }
        }

        public static IExecutionTaskStrategyParameters GetExecutionTaskStrategyParameters(
            ExecutionTaskDefinitionDTO executionTaskDefinition, ExecutionTaskStrategy taskStrategy)
        {
            return GetExecutionTaskStrategyParameters(executionTaskDefinition, taskStrategy.GetType());
        }

        public static IExecutionTaskStrategyParameters GetExecutionTaskStrategyParameters(ExecutionTaskDefinitionDTO executionTaskDefinition, Type taskStrategyType)
        {
            Type parametersType = GetExecutionTaskStrategyParametersType(taskStrategyType);

            if (parametersType == null)
                return null;

            IExecutionTaskStrategyParameters strategyParameters = parametersType != null
                ? (executionTaskDefinition.Parameters != null ? FromSerializedString<IExecutionTaskStrategyParameters>(parametersType, executionTaskDefinition.Parameters) : (IExecutionTaskStrategyParameters)Activator.CreateInstance(parametersType))
                : null;
            return strategyParameters;
        }

        public static Type GetExecutionTaskStrategyParametersType(Type taskStrategyType)
        {
            var genericExecutionTaskStrategyBaseType = GetBaseType(taskStrategyType, typeof(ExecutionTaskStrategy<>));

            return genericExecutionTaskStrategyBaseType != null
                ? genericExecutionTaskStrategyBaseType.GetGenericArguments()[0]
                : null;
        }

        private static Type GetBaseType(Type taskStrategyType, Type expectedType)
        {
            Type baseType = taskStrategyType.BaseType;

            while (baseType != expectedType && baseType.GetGenericTypeDefinition() != expectedType && baseType != null)
            {
                baseType = baseType.BaseType;
            }

            return baseType;
        }

        private ExecutionTaskStrategy CreateEmptyTaskStrategy(string executionTaskDefinitionStrategyName)
        {
            var executionTaskStrategyTaskType = GetExecutionTaskStrategyTaskType(executionTaskDefinitionStrategyName);

            ExecutionTaskStrategy strategy = (ExecutionTaskStrategy)Activator.CreateInstance(executionTaskStrategyTaskType);

            return strategy;
        }
        public static T FromSerializedString<T>(Type objectType, string stringToDeserialize)
        {
            using (var memStream = new MemoryStream(Encoding.UTF8.GetBytes(stringToDeserialize)))
            {
                return (T)new XmlSerializer(objectType, new Type[0]).Deserialize(memStream);
            }
        }

        public static T FromDataContractSerializedString<T>(Type objectType, string stringToDeserialize)
        {
            using (var memStream = new MemoryStream(Encoding.UTF8.GetBytes(stringToDeserialize)))
            {
                return (T)new DataContractSerializer(objectType, new Type[0]).ReadObject(memStream);
            }
        }

        private Type GetExecutionTaskStrategyTaskType(string strategyName)
        {
            executionTaskStrategyTaskTypeByStrategyName = executionTaskStrategyTaskTypeByStrategyName ?? LoadExecutionTaskStrategyTaskTypeByStrategyName();

            return executionTaskStrategyTaskTypeByStrategyName[strategyName];
        }

        public Dictionary<string, Type> LoadExecutionTaskStrategyTaskTypeByStrategyName()
        {
            return executionTaskStrategyTaskTypeAssemblies.SelectMany(
                    asm =>
                        asm.GetTypes()
                            .Where(x => x.GetCustomAttributes().Any(a => a is ExecutionTaskStrategyAttribute)))
                .ToDictionary(x => ((ExecutionTaskStrategyAttribute)x.GetCustomAttributes().First(a => a is ExecutionTaskStrategyAttribute)).StrategyName, x => x);
        }

        public IExecutionTask GetExecutionTask(ExecutionTaskDTO executionTaskDTO)
        {
            var strategyType = LoadExecutionTaskStrategyTaskTypeByStrategyName()[executionTaskDTO.StrategyName];

            var task = FromDataContractSerializedString<IExecutionTask>(strategyType, executionTaskDTO.TaskContent);

            return task;
        }

        private ExecutionTaskDefinitionDTO[] GetExecutionTaskDefinitionDTOForTask(ITask blotterTask)
        {
            executionTaskDefinitions = executionTaskDefinitions ?? indexDbProviderFactory.Create().LoadExecutionTaskDefinitions(UserService.CaesarSession);

            return
                executionTaskDefinitions.Where(
                    x =>
                        x.Enabled && blotterTask.Status != null && blotterTask.Status.Status == TaskStatus.ToValidate && blotterTask.Type.ToString() == x.TaskType &&
                        blotterTask.IndexFullPath == x.IndexFullPath).ToArray();
        }
    }

    public interface IExecutionTaskManager
    {
        Assembly[] ExecutionTaskStrategyTaskTypeAssemblies { get; set; }
        Dictionary<string, Type> ExecutionTaskStrategyTaskTypeByStrategyName { get; set; }
        Dictionary<string, Type> LoadExecutionTaskStrategyTaskTypeByStrategyName();
        ExecutionTaskDTO[] CreateExecutionTasks(ITask blotterTask);
    }
}