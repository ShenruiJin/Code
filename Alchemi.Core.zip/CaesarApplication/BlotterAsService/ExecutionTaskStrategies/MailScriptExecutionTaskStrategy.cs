﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Runtime.Serialization;
using DealIndexDataTransferObject;
using FuncFramework.Business;
using GlobalDerivativesApplications;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "MailScript")]
    [DataContract]
    [Serializable]
    public class MailScriptExecutionTaskStrategy : ExecutionTaskStrategy<MailScriptExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            Tools.System.SendEmailEWS(TypedParameters.SenderAddress,
        TypedParameters.DestinationAddresses.Split(',', ';').Select(x => x.Formatted(TypedParameters)).ToArray(),
        TypedParameters.Subject.Formatted(TypedParameters),
        TypedParameters.Body.Formatted(TypedParameters),
        impersonatedAddress: TypedParameters.SenderAddress, userName: "nt_eqd_sos", password: "Ba13h,7j", attachments: TypedParameters.Attachments != null ? TypedParameters.Attachments.Split(',', ';').Select(x => x.Formatted(TypedParameters)).ToArray() : null);
        }
    }

    [DataContract]
    [Serializable]
    public class MailScriptExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder
    {
        [DataMember]
        public string SenderAddress { get; set; }
        [DataMember]
        public string DestinationAddresses { get; set; }
        [DataMember]
        public string Subject { get; set; }
        [DataMember]
        public string Body { get; set; }
        [DataMember]
        public string Attachments { get; set; }
        [DataMember]
        public DateTime? PricingDate { get; set; }
        [DataMember]
        public long IndexId { get; set; }
        [DataMember]
        public string BBGTicker { get; set; }

        [IgnoreDataMember]
        public string PricingDateFormatted
        {
            get { return PricingDate != null ? PricingDate.GetValueOrDefault().ToString("ddMMyyyy") : null; }
        }
    }
}