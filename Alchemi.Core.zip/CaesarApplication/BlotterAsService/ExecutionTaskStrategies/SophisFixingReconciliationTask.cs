﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using CaesarApplication.Booking;
using DealIndexDataTransferObject;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisFixingReconciliation")]
    [DataContract]
    [Serializable]
    public class SophisFixingReconciliationTask : ExecutionTaskStrategy<SophisFixingReconciliationTaskStrategyParameters>
    {
        public override void Execute()
        {
            TypedParameters.CompareItems.GroupBy(x => x.Sicovam.GetValueOrDefault()).ForEach(grp => new GenericBooker().ApplyFixingsAmendements(grp.Key, grp.ToArray(), BookingManager.Database));
        }
    }

    [DataContract]
    [Serializable]
    public class SophisFixingReconciliationTaskStrategyParameters : IExecutionTaskStrategyParameters
    {
        [DataMember]
        public BookingFixingCompareItem[] CompareItems
        {
            get;
            set;
        }
    }
}