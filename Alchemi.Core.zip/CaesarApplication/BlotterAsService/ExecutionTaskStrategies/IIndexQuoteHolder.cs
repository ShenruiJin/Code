﻿using DealIndexDataTransferObject;
using Pricing.Engine.Indices;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    public interface IIndexQuoteHolder
    {
        IndexQuoteInfos Quote { get; set; }
    }
}