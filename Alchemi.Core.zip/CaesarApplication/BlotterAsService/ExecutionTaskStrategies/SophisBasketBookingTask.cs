﻿using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using DealIndexDataTransferObject;
using log4net;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisBasketBooking")]
    [DataContract]
    [Serializable]
    public class SophisBasketBookingTask : ExecutionTaskStrategy<SophisBasketBookingTaskStrategyParameters>
    {
        private ILog logger = LogManager.GetLogger(typeof(SophisBasketBookingTask));

        public override void Execute()
        {
            logger = logger ?? LogManager.GetLogger(typeof(SophisBasketBookingTask));
            var tsp = new TimeSeriesProvider(new OverloadedMarketDataTree(new MarketDataTree()), new TimeSeriesProviderParameters { ReadOnly = true });
            tsp.PricingContext = new PricingContext();
            tsp.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var ticker = TypedParameters.BBGTicker;

            try
            {
                logger.Info("Start to feed " + ticker + " for " + TypedParameters.PricingDate);

                var idxInfos = tsp.GetIndexInfosByBbgTicker(ticker);

                var quoteTs = tsp.GetIndexQuotes(idxInfos.id.ToString(), TypedParameters.PricingDate, TypedParameters.PricingDate, true);

                var refDate = quoteTs.X.Cast<DateTime?>().LastOrDefault();

                if (refDate.HasValue)
                {
                    var baskets = tsp.GetBasketsAudit(idxInfos.id.ToString(), refDate, refDate);

                    var basketIndexList = baskets.Y.Cast<BasketIndexList>().Last();

                    var mainBasket = basketIndexList.Baskets.First(x => x.Name != BasketIndex.AuditBasketName);
                    var auditBasket = basketIndexList.Baskets.First(x => x.Name == BasketIndex.AuditBasketName);

                    BookingGeneric.SophisCompositionBookingInsertBasket(idxInfos.bloomberg_ticker, mainBasket, quoteTs.EvaluateLast(), refDate.GetValueOrDefault(), auditBasket, database: TypedParameters.Environement ?? "PROD", cleanerMode: TypedParameters.CleanerMode, fxHedged: TypedParameters.FxHedged, removeNullWeights: TypedParameters.RemoveNullWeights);
                     
                    logger.InfoFormat("End to feed with success " + ticker + " for " + TypedParameters.PricingDate);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                logger.Error("End to feed with Failure " + ticker + " for " + TypedParameters.PricingDate);

                throw ex;
            }
        }
    }

    [DataContract]
    [Serializable]
    public class SophisBasketBookingTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        private bool cleanerMode = true;
        private bool removeNullWeights = true;

        [DataMember]
        public bool CleanerMode
        {
            get
            {
                return cleanerMode;
            }
            set
            {
                cleanerMode = value;
            }
        }

        [DataMember]
        public bool RemoveNullWeights
        {
            get
            {
                return removeNullWeights;
            }
            set
            {
                removeNullWeights = value;
            }
        }

        [DataMember]
        public bool FxHedged
        {
            get;
            set;
        }

        [DataMember]
        public string Environement
        {
            get;
            set;
        }

        [DataMember]
        public string BBGTicker
        {
            get;
            set;
        }
        [DataMember]
        public long IndexId
        {
            get;
            set;
        }
        [DataMember]
        public DateTime? PricingDate
        {
            get;
            set;
        }
        [DataMember]
        public IndexQuoteInfos Quote
        {
            get;
            set;
        }
    }
}