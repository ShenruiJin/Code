﻿using System;
using System.Runtime.Serialization;
using CaesarApplication.Service.Contribution;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Reporting;
using System.Linq;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "ExternalPublication")]
    [DataContract]
    [Serializable]
    public class ExternalPublicationTaskStrategy : ExecutionTaskStrategy<ExternalPublicationTaskStrategyParameters>
    {
        public override void Execute()
        {
            var simpleContribResultObserver = new SimpleContribResultObserver { IndexQuote = TypedParameters.Quote.ToIndexQuoteDTO(), ValuationDate = TypedParameters.Quote.date_version, IsContributed = TypedParameters.Quote.contribution_date != DateTime.MinValue };
            var res = new ExternalUploadContributor().ContributeMultiIndexes(TypedParameters.ConfigurationName, true, ContributionManager.GroupQuotesByIndex(simpleContribResultObserver.AsArray()).Values.First());

            if (!res.NoError)
            {
                throw new Exception(string.Format("Publication to {0} has failed for {1} at the date of {2:dd/MM/yyyy} with value : {3} with message {4}", TypedParameters.ConfigurationName, TypedParameters.BBGTicker, TypedParameters.Quote.date_version, TypedParameters.Quote.value, res.Message));
            }
        }
    }

    [DataContract]
    [Serializable]
    public class ExternalPublicationTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public DateTime? PricingDate { get; set; }

        [DataMember]
        public long IndexId { get; set; }

        [DataMember]
        public string BBGTicker { get; set; }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }

        [DataMember]
        public string ConfigurationName { get; set; }
    }
}