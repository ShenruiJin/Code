﻿using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.DataProvider.Prism;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "PrismCompositionReconciliation")]
    [DataContract]
    [Serializable]
    public class PrismCompositionReconciliationTask : ExecutionTaskStrategy<PrismCompositionReconciliationStrategyParameters>
    {
        public override void Execute()
        {
            var tsp = new TimeSeriesProvider(new MarketDataMgr.Trees.Ext.OverloadedMarketDataTree(new MarketDataMgr.Trees.MarketDataTree()), new TimeSeriesProviderParameters());
            tsp.PricingContext = new PricingBase.DataProvider.PricingContext();


            TypedParameters.CompareItems
                .ForEach(item =>
{

    var indexInfos = item.Index;
    var date = item.Date;

    tsp.PricingContext.SetNewReferenceDate(date, new BasketIndexList(), new BasketIndex());


    var baskets = tsp.GetBasketsAudit(indexInfos.id.ToString(), date, date);
    var quoteTs = tsp.GetIndexQuotes(indexInfos.id.ToString(), date, date);

    if (baskets.Any() && quoteTs.Any())
    {
        var basketIndexList = baskets.Y.Cast<BasketIndexList>().Last();

        var auditBasket = basketIndexList[BasketIndex.AuditBasketName];
        var cal = auditBasket.ResultData[DataFieldsEnum.Calendar.ToString()].First().Y.Cast<ICalendar>().First();
        var nextDay = cal.GetBusinessDays(date.AddDays(1), date.AddDays(365)).First();
        var compoDate = basketIndexList.EffectiveDate.Value;

        var mainBasket = basketIndexList.Baskets.First(b => b.Name != BasketIndex.AuditBasketName);


        var componentsList = mainBasket.LastComposition.Select(i => i.BloombergTicker);

        var prismBookingManager = new PrismBookingManager();

        prismBookingManager.Insert(indexInfos.bloomberg_ticker, indexInfos.currency_code, mainBasket,
            quoteTs.EvaluateLast(),
            compoDate,
            auditBasket.Data[DataFieldsEnum.Last.ToString()].ToDictionary(x => x.Instrument, x => x),
            auditBasket: basketIndexList.Baskets.First(b => b.Name == BasketIndex.AuditBasketName), compositionDate: nextDay);
    }
});
        }
    }

    [DataContract]
    [Serializable]
    public class PrismCompositionReconciliationStrategyParameters : IExecutionTaskStrategyParameters
    {
        [DataMember]
        public BookingPrismCompositionCompareItem[] CompareItems
        {
            get;
            set;
        }
    }
}