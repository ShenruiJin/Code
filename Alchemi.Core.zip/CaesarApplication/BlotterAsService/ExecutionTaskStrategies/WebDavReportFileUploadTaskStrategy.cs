﻿using System;
using System.Net;
using System.Runtime.Serialization;
using CaesarApplication.Service.WebDav;
using DealIndexDataTransferObject;
using log4net;
using WebDAV;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "WebDavReportFileUpload")]
    [DataContract]
    [Serializable]
    public class WebDavReportFileUploadTaskStrategy :
        ExecutionTaskStrategy<WebDavReportFileUploadTaskStrategyParameters>
    {
        public override void Execute()
        {
            IWebProxy proxy = WebRequest.GetSystemWebProxy();
            proxy.Credentials = new NetworkCredential("nt_eqd_sos", "Ba13h,7j");

            var uploader = new WebDavReportFileUploader(TypedParameters.Server,
                TypedParameters.Port, 
                TypedParameters.BasePath,
                TypedParameters.UserName,
                TypedParameters.Passwd, 
                proxy, 
                LogManager.GetLogger(GetType()));

            uploader.UploadFile(TypedParameters.LocalFilePath.Formatted(TypedParameters), TypedParameters.RemoteDirectory != null ? TypedParameters.RemoteDirectory.Formatted(TypedParameters) : "");
        }
    }

    [DataContract]
    [Serializable]
    public class WebDavReportFileUploadTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder
    {
        [DataMember]
        public int Port { get; set; }
        [DataMember]
        public string BasePath { get; set; }
        [DataMember]
        public string UserName { get; set; }
        [DataMember]
        public string Passwd { get; set; }
        [DataMember]
        public string Server { get; set; }
        [DataMember]
        public string LocalFilePath { get; set; }
        [DataMember]
        public string RemoteDirectory { get; set; }
        [DataMember]
        public DateTime? PricingDate { get; set; }
        [DataMember]
        public long IndexId { get; set; }
        [DataMember]
        public string BBGTicker { get; set; }
    }
}