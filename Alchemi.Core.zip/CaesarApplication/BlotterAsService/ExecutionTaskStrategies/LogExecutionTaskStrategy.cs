﻿using System;
using System.Runtime.Serialization;
using CaesarApplication.Service.Logging;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Log;
using Pricing.Engine.Indices;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "Log")]
    [DataContract]
    [Serializable]
    public class LogExecutionTaskStrategy : ExecutionTaskStrategy<LogExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            LoggingService.Info(typeof(LogExecutionTaskStrategy), TypedParameters.Message);
        }
    }

    [DataContract]
    [Serializable]
    public class LogExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters
    {
        [DataMember]
        public string Message { get; set; }
    }
}
