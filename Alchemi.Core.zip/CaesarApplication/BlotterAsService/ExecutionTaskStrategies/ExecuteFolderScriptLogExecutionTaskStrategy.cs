﻿using System;
using System.Runtime.Serialization;
using CaesarApplication.QuoteCalculator;
using DealIndexDataTransferObject;
using FuncFramework.Business;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "ExecuteFolderScript")]
    [DataContract]
    [Serializable]
    public class ExecuteFolderScriptLogExecutionTaskStrategy : ExecutionTaskStrategy<ExecuteFolderScriptExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            BatchPricerRunConfig config = new BatchPricerRunConfig
            {
                DirectoriesToPrice = TypedParameters.FolderPath.Replace("->", IndexPathHelper.Delimiter.ToString()),
                StartDate = TypedParameters.PricingDate.GetValueOrDefault(),
                EndDate = TypedParameters.PricingDate.GetValueOrDefault(),
                NbDaysLag = 0
            };

            IndexPricingResultNotifier indexPricingResultNotifier = new IndexPricingResultNotifier();
            indexPricingResultNotifier.LaunchPricing(config);

            if (config.RunLocal)
            {
                indexPricingResultNotifier.WriteRunLocalInfo(config);
            }

            if (!config.RunLocal || config.SendMailAnyWay)
            {
                indexPricingResultNotifier.SendResultMail(config);
            }

            if (!indexPricingResultNotifier.IsSuccess)
            {
                throw new Exception(indexPricingResultNotifier.msg.ToString());
            }
        }
    }


    [DataContract]
    [Serializable]
    public class ExecuteFolderScriptExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters, IPricingDateHolder
    {
        [DataMember]
        public string FolderPath { get; set; }

        [DataMember]
        public int? PricingCalculationLag { get; set; }

        [DataMember]
        public DateTime? PricingDate { get; set; }
    }
}