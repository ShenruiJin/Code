﻿using CaesarApplication.Booking;
using DealIndexDataTransferObject;
using System;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisCalendarReconciliation")]
    [DataContract]
    [Serializable]
    public class SophisCalendarReconciliationTask : ExecutionTaskStrategy<SophisCalendarReconciliationTaskStrategyParameters>
    {
        public override void Execute()
        {
            TypedParameters.CompareItems.GroupBy(x => x.Sicovam.GetValueOrDefault()).ForEach(grp => new GenericBooker().ApplyClausesAmendements(grp.Key, grp.ToArray(), BookingManager.Database));
        }
    }

    [DataContract]
    [Serializable]
    public class SophisCalendarReconciliationTaskStrategyParameters : IExecutionTaskStrategyParameters
    {
        [DataMember]
        public BookingCalendarCompareItem[] CompareItems
        {
            get;
            set;
        }
    }
}
