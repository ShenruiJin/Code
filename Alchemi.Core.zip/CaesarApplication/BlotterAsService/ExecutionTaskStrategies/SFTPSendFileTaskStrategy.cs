﻿using CaesarApplication.Service.Contribution;
using CaesarCommon.Configuration;
using DealIndexDataTransferObject;
using log4net;
using System;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SFTPSendFile")]
    [DataContract]
    [Serializable]
    public class SFTPSendFileTaskStrategy : ExecutionTaskStrategy<SFTPSendFileTaskStrategyParameters>
    {
        private ILog logger = LogManager.GetLogger(typeof(SFTPSendFileTaskStrategy));
        public override void Execute()
        {
            logger = LogManager.GetLogger(typeof(SFTPSendFileTaskStrategy));
            var contributor = new ExternalUploadContributor();
            var caesarSettingsManager = new CaesarSettingsManager();

            var folderToUpload = !string.IsNullOrEmpty(TypedParameters.FolderToUploadDateFormat) ? Path.Combine(TypedParameters.FolderToUpload, TypedParameters.Quote.date_version.ToString(TypedParameters.FolderToUploadDateFormat)) : TypedParameters.FolderToUpload;

            logger.InfoFormat("Directory to upload {0}", folderToUpload);

            if(!caesarSettingsManager.SFTPUploadConfigurations.Any(x => x.Name == TypedParameters.SFTPConfigurationName))
            {
                var errorMsg = string.Format("Configuration {0} not existing", folderToUpload);

                logger.Error(errorMsg);
                throw new Exception(errorMsg);
            }

            if (Directory.Exists(folderToUpload))
            {
                foreach(var file in Directory.GetFiles(folderToUpload))
                {
                    logger.InfoFormat("File to upload {0}", file);

                    contributor.UploadFile(caesarSettingsManager.SFTPUploadConfigurations.First(x => x.Name == TypedParameters.SFTPConfigurationName), file);
                }
            }
            else
            {
                logger.WarnFormat("Directory to upload {0} not existed", folderToUpload);
            }
        }
    }

    [DataContract]
    [Serializable]
    public class SFTPSendFileTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public DateTime? PricingDate { get; set; }

        [DataMember]
        public long IndexId { get; set; }

        [DataMember]
        public string BBGTicker { get; set; }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }

        [DataMember]
        public string FolderToUpload { get; set; }

        [DataMember]
        public string FolderToUploadDateFormat { get; set; }

        [DataMember]
        public string SFTPConfigurationName { get; set; }
    }
}
