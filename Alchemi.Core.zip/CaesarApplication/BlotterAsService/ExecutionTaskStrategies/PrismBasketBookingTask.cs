﻿using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Data.MarketData;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using log4net;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using Pricing.Engine.Indices;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "PrismBasketBooking")]
    [DataContract]
    [Serializable]
    public class PrismBasketBookingTask : ExecutionTaskStrategy<PrismBasketBookingTaskStrategyParameters>
    {
        private ILog logger = LogManager.GetLogger(typeof(PrismBasketBookingTask));

        public override void Execute()
        {
            var tsp = new TimeSeriesProvider(new OverloadedMarketDataTree(new MarketDataTree()), new TimeSeriesProviderParameters { ReadOnly = true });
            tsp.PricingContext = new PricingContext();
            tsp.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var ticker = TypedParameters.BBGTicker;

            logger = logger ?? LogManager.GetLogger(typeof(PrismBasketBookingTask));

            try
            {
                logger.Info("Start to feed " + ticker + " for " + TypedParameters.Quote.date_version);

                var idxInfos = tsp.GetIndexInfosByBbgTicker(ticker);

                var quoteTs = tsp.GetIndexQuotes(idxInfos.id.ToString(), TypedParameters.Quote.date_version, TypedParameters.Quote.date_version, true);

                var refDate = quoteTs.X.Cast<DateTime?>().LastOrDefault();

                if (refDate.HasValue)
                {
                    var baskets = tsp.GetBasketsAudit(idxInfos.id.ToString(), refDate, refDate);

                    var basketIndexList = baskets.Y.Cast<BasketIndexList>().Last();

                    var mainBasket = basketIndexList.Baskets.First(x => x.Name != BasketIndex.AuditBasketName);
                    var auditBasket = basketIndexList.Baskets.First(x => x.Name == BasketIndex.AuditBasketName);
                    var compoDate = basketIndexList.EffectiveDate.Value;
                   
                    var cal = auditBasket.ResultData[DataFieldsEnum.Calendar.ToString()].First().Y.Cast<ICalendar>().First();
                    var nextDay = cal.GetBusinessDays(refDate.GetValueOrDefault().AddDays(1), refDate.GetValueOrDefault().AddDays(365)).First();

                    var res = BookingGeneric.PrismBookingInsertBasket(idxInfos.bloomberg_ticker,
                                                                                 idxInfos.currency_code,
                                                                                 mainBasket,
                                                                                 quoteTs.Y.Cast<IndexQuote>().Last().Value,
                                                                                 compoDate,
                                                                                 auditBasket.Data.ContainsKey(DataFieldsEnum.Last.ToString())
                                                                                 ?
                                                                                 auditBasket.Data[DataFieldsEnum.Last.ToString()].ToDictionary(x => x.Instrument, x => x)
                                                                                 :
                                                                                 new Dictionary<string, TimeSerieDB>(),
                                                                                 auditBasket: basketIndexList.Baskets.First(b => b.Name == BasketIndex.AuditBasketName),
                                                                                 compositionDate: nextDay,
                                                                                 explodeCompo:TypedParameters.ExplodeInternalIndexes,
                                                                                 removeNullWeights:TypedParameters.RemoveNullWeights
                                                                                 );

                    if (res.StartsWith("KO"))
                    {
                        throw new Exception(res);
                    }

                    logger.InfoFormat("End to feed with success " + ticker + " for " + TypedParameters.Quote.date_version);
                }
            }
            catch (Exception ex)
            {
                logger.Error(ex);
                logger.Error("End to feed with Failure " + ticker + " for " + TypedParameters.Quote.date_version);

                throw ex;
            }
        }
    }

    [DataContract]
    [Serializable]
    public class PrismBasketBookingTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        private bool explodeInternalIndexes = true;

        [DataMember]
        public bool ExplodeInternalIndexes
        {
            get
            {
                return explodeInternalIndexes;
            }
            set
            {
                explodeInternalIndexes = value;
            }
        }

        [DataMember]
        public bool RemoveNullWeights
        {
            get;
            set;
        }

        [DataMember]
        public bool FxHedged
        {
            get;
            set;
        }

        [DataMember]
        public string Environement
        {
            get;
            set;
        }

        [DataMember]
        public string BBGTicker
        {
            get;
            set;
        }
        [DataMember]
        public long IndexId
        {
            get;
            set;
        }
        [DataMember]
        public DateTime? PricingDate
        {
            get;
            set;
        }
        [DataMember]
        public IndexQuoteInfos Quote
        {
            get;
            set;
        }
    }
}
