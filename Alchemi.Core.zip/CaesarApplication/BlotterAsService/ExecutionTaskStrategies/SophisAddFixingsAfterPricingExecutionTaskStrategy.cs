﻿using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using CaesarCommon.Utils;
using DealIndexDataTransferObject;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisAddFixingsAfterPricing")]
    [DataContract]
    [Serializable]
    public class SophisAddFixingsAfterPricingExecutionTaskStrategy : ExecutionTaskStrategy<SophisAddFixingsAfterPricingExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            var tsp = new TimeSeriesProvider(new OverloadedMarketDataTree(new MarketDataTree()), new TimeSeriesProviderParameters { ReadOnly = true });
            tsp.PricingContext = new PricingContext();
            tsp.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var executionTaskManager = new ExecutionTaskManager(new IndexDBProviderFactory());

            var bookingManager = new BookingManager(tsp);

            var idxInfos = tsp.GetIndexInfos(TypedParameters.BBGTicker);

            var sicovams = string.IsNullOrEmpty(TypedParameters.Sicovams) ? BookingManagerExtensions.GetOptionSicovamForExternalRef(idxInfos.bloomberg_ticker) : TypedParameters.Sicovams.Trim().Split(',', ';').Select(x => int.Parse(x)).ToArray();

            var result = new List<BookingFixingCompareItem>();

            Comment = "Sicos:" + sicovams.Select(x => x.ToString()).Stringify(",");

            foreach (var sico in sicovams)
            {
                try
                {
                    result.AddRange(bookingManager.GetFixingsToAdd(sico.AsArray(), idxInfos, DateTime.Today.AddDays(-100), DateTime.Today.AddDays(500)));
                }
                catch
                {

                }
            }


            if (TypedParameters.ApplyFixes && result.Any())
            {
                var taskKey = string.Format("AutoSophisFixingReconciliationAddClauses|{0}|{1}|{2}", Environment.UserName,
                    DateTime.Now.ToString("ddMMyyyyHHmmss"), idxInfos.bloomberg_ticker + TypedParameters.PricingDate.GetValueOrDefault().ToShortDateString());

                var tasksToSend = executionTaskManager.CreateExecutionTask("SophisFixingReconciliation", Environment.UserName,
                        taskKey,
                        new SophisFixingReconciliationTaskStrategyParameters { CompareItems = result.Where(x => x.Status != BookingFixingCompareItemStatus.OK).ToArray() }).AsArray();

                PersistanceService.IndexProvider.SaveExecutionTasks(tasksToSend, UserService.CaesarSession);
            }
        }
    }

    [DataContract]
    [Serializable]
    public class SophisAddFixingsAfterPricingExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public DateTime? PricingDate { get; set; }

        [DataMember]
        public long IndexId { get; set; }

        [DataMember]
        public string BBGTicker { get; set; }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }

        [DataMember]
        public bool ApplyFixes { get; set; }

        [DataMember]
        public string Sicovams { get; set; }

        [DataMember]
        public bool AddDayIfLastDayIsHoliday { get; set; }
    }
}
