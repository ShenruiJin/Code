﻿using System;
using PricingBase.Index;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    public interface IPricingDateHolder
    {
        DateTime? PricingDate { get; set; }
    }

    public interface ITaskInformationsHolder : IPricingDateHolder
    {
        long IndexId { get; set; }

        string BBGTicker { get; set; }
    }
}