﻿using CaesarApplication.Booking;
using CaesarApplication.DataProvider;
using CaesarApplication.DataProvider.Parameters;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using CaesarCommon.Utils;
using DealIndexDataTransferObject;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using PricingBase.DataProvider;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisCalendarCheckAfterPricing")]
    [DataContract]
    [Serializable]
    public class SophisCalendarCheckAfterPricingExecutionTaskStrategy : ExecutionTaskStrategy<SophisCalendarCheckAfterPricingExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            var tsp = new TimeSeriesProvider(new OverloadedMarketDataTree(new MarketDataTree()), new TimeSeriesProviderParameters { ReadOnly = true });
            tsp.PricingContext = new PricingContext();
            tsp.PricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var executionTaskManager = new ExecutionTaskManager(new IndexDBProviderFactory());

            var bookingManager = new BookingManager(tsp);

            var idxInfos = tsp.GetIndexInfos(TypedParameters.BBGTicker);

            var sicovams = string.IsNullOrEmpty(TypedParameters.Sicovams) ? BookingManagerExtensions.GetOptionSicovamForExternalRef(idxInfos.bloomberg_ticker) : TypedParameters.Sicovams.Trim().Split(',', ';').Select(x => int.Parse(x)).ToArray();

            var result = new List<BookingCalendarCompareItem>();

            Comment = "Sicos:" + sicovams.Select(x => x.ToString()).Stringify(",");

            foreach (var sico in sicovams)
            {
                try
                {
                    result.AddRange(bookingManager.CompareCalendar(sico, idxInfos, TypedParameters.Quote.date_version, TypedParameters.Quote.date_version, TypedParameters.CompareFuture, TypedParameters.FutureNbDays.GetValueOrDefault(500), null,  TypedParameters.AddDayIfLastDayIsHoliday, TypedParameters.FutureNbYears.GetValueOrDefault()));
                }
                catch
                {

                }
            }

            if (TypedParameters.ApplyFixes && result.Any())
            {
                var taskKey = string.Format("AutoSophisCalendarReconciliation|{0}|{1}|{2}", Environment.UserName,
                    DateTime.Now.ToString("ddMMyyyyHHmmss"), idxInfos.bloomberg_ticker + TypedParameters.PricingDate.GetValueOrDefault().ToShortDateString());

                var tasksToSend = executionTaskManager.CreateExecutionTask("SophisCalendarReconciliation", Environment.UserName,
                        taskKey,
                        new SophisCalendarReconciliationTaskStrategyParameters { CompareItems = result.Where(x => x.Status != BookingCalendarCompareItemStatus.OK && (TypedParameters.ApplyOnAllValues)).ToArray() }).AsArray();

                PersistanceService.IndexProvider.SaveExecutionTasks(tasksToSend, UserService.CaesarSession);

            }
        }
    }

    [DataContract]
    [Serializable]
    public class SophisCalendarCheckAfterPricingExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public DateTime? PricingDate { get; set; }

        [DataMember]
        public long IndexId { get; set; }

        [DataMember]
        public string BBGTicker { get; set; }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }

        [DataMember]
        public bool ApplyFixes { get; set; }

        [DataMember]
        public int? FutureNbDays { get; set; }


        [DataMember]
        public int? FutureNbYears { get; set; }

        [DataMember]
        public bool CompareFuture { get; set; }

        [DataMember]
        public bool ApplyOnAllValues { get; set; }

        [DataMember]
        public string Sicovams { get; set; }

        [DataMember]
        public bool AddDayIfLastDayIsHoliday { get; set; }
    }
}
