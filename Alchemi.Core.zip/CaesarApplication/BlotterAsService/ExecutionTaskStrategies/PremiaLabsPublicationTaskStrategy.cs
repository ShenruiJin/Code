﻿using System;
using System.Runtime.Serialization;
using CaesarApplication.DataProvider;
using CaesarApplication.QuoteCalculator;
using CaesarApplication.Service.Contribution;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications.Reporting;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using System.Linq;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "PublicationPremiaLabs")]
    [DataContract]
    [Serializable]
    public class PremiaLabsPublicationTaskStrategy : ExecutionTaskStrategy<PremiaLabsPublicationTaskStrategyParameters>
    {
        public override void Execute()
        {
            var simpleContribResultObserver = new SimpleContribResultObserver { IndexQuote = TypedParameters.Quote.ToIndexQuoteDTO(), ValuationDate = TypedParameters.Quote.date_version, IsContributed = TypedParameters.Quote.contribution_date != DateTime.MinValue };
            var res = new ExternalUploadContributor().ContributeMultiIndexes("PremiaLabs", true, ContributionManager.GroupQuotesByIndex(simpleContribResultObserver.AsArray()).Values.First());

            if (!res.NoError)
            {
                throw new Exception(string.Format("Publication to PremiaLabs has failed for {0} at the date of {1:dd/MM/yyyy} with value : {2} with message {3}", TypedParameters.BBGTicker, TypedParameters.Quote.date_version, TypedParameters.Quote.value, res.Message));
            }
        }
    }

    [DataContract]
    [Serializable]
    public class PremiaLabsPublicationTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public DateTime? PricingDate { get; set; }

        [DataMember]
        public long IndexId { get; set; }

        [DataMember]
        public string BBGTicker { get; set; }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }
    }
}