﻿using System;
using System.Linq;
using System.Runtime.Serialization;
using CaesarApplication.Booking;
using DealIndexDataTransferObject;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "SophisBasketsReconciliation")]
    [DataContract]
    [Serializable]
    public class SophisBasketsReconciliationTask : ExecutionTaskStrategy<SophisBasketsReconciliationTaskStrategyParameters>
    {
        public override void Execute()
        {
            TypedParameters.CompareItems.GroupBy(x => x.Sicovam.GetValueOrDefault()).ForEach(grp => new GenericBooker().ApplyBasketsAmendements(grp.Key, grp.ToArray(), BookingManager.Database));
        }
    }

    [DataContract]
    [Serializable]
    public class SophisBasketsReconciliationTaskStrategyParameters : IExecutionTaskStrategyParameters
    {
        [DataMember]
        public BookingBasketWeightCompareItem[] CompareItems
        {
            get;
            set;
        }
    }
}