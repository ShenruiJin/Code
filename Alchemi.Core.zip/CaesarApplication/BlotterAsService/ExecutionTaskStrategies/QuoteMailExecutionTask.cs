﻿using DealIndexDataTransferObject;
using GlobalDerivativesApplications;
using GlobalDerivativesApplications.Reporting;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.ExecutionTaskStrategies
{
    [ExecutionTaskStrategy(StrategyName = "QuoteMail")]
    [DataContract]
    [Serializable]
    public class QuoteMailExecutionTask : ExecutionTaskStrategy<QuoteMailExecutionTaskStrategyParameters>
    {
        public override void Execute()
        {
            var report = ReportingTools.CreateReport();

            var mainTable = report.CreateTable("");

            mainTable.AddHeader((TypedParameters.FileHeaders ?? "Ticker,Date,Last price").Split(TypedParameters.Delimiter.AsArray(), StringSplitOptions.None).Cast<object>().ToArray());

            Func<string> dateFunc = () => TypedParameters.Quote.date_version.ToString(TypedParameters.DateFormat ?? "dd/MM/yyyy");
            Func<string> tickerFunc = () => TypedParameters.BBGTicker;
            Func<string> valueFunc = () => TypedParameters.Quote.value.GetValueOrDefault().ToString(TypedParameters.Culture != null ? new CultureInfo(TypedParameters.Culture) : CultureInfo.InvariantCulture);

            SortedDictionary<int, Func<string>> actionsByPriority = new SortedDictionary<int, Func<string>>
            {
                { TypedParameters.TickerIndex.GetValueOrDefault(0), tickerFunc  },
                { TypedParameters.DateIndex.GetValueOrDefault(1), dateFunc  },
                { TypedParameters.ValueIndex.GetValueOrDefault(2), valueFunc  }
            };

            mainTable.AddRow(actionsByPriority.Select(x => x.Value()).Cast<object>().ToArray());

            var filePath = Path.Combine(@"C:\temp\" + Guid.NewGuid(), TypedParameters.FileName.Formatted(TypedParameters));
            var directoryPath = Path.GetDirectoryName(filePath);

            Directory.CreateDirectory(directoryPath);

            File.WriteAllLines(filePath, mainTable.GetMatrixAsObject().Select(l => l.Select(x => x.ToString()).Stringify(TypedParameters.Delimiter)));

            var emailAddress = TypedParameters.SenderAddress ?? "eda25-desk-quant-applications@natixis.com";

            Tools.System.SendEmailEWS(emailAddress,
      TypedParameters.DestinationAddresses.Split(',', ';').Select(x => x.Formatted(TypedParameters)).ToArray(),
      TypedParameters.Subject.Formatted(TypedParameters),
      TypedParameters.Body.Formatted(TypedParameters),
      impersonatedAddress: TypedParameters.SenderAddress, userName: "nt_eqd_sos", password: "Ba13h,7j", attachments: filePath.AsArray());

            try
            {
                Directory.Delete(directoryPath, true);
            }
            catch
            { }
        }
    }

    [DataContract]
    [Serializable]
    public class QuoteMailExecutionTaskStrategyParameters : IExecutionTaskStrategyParameters, ITaskInformationsHolder, IIndexQuoteHolder
    {
        [DataMember]
        public int? TickerIndex { get; set; }
        [DataMember]
        public int? DateIndex { get; set; }
        [DataMember]
        public int? ValueIndex { get; set; }

        [DataMember]
        public string DateFormat { get; set; }

        [DataMember]
        public string FileName { get; set; }

        [DataMember]
        public string Culture { get; set; }

        private string delimiter = ",";

        [DataMember]
        public string Delimiter
        {
            get
            {
                return delimiter;
            }
            set
            {
                delimiter = value;
            }
        }

        [DataMember]
        public string FileHeaders { get; set; }

        [DataMember]
        public string SenderAddress { get; set; }
        [DataMember]
        public string DestinationAddresses { get; set; }
        [DataMember]
        public string Subject { get; set; }
        [DataMember]
        public string Body { get; set; }

        [DataMember]
        public DateTime? PricingDate { get; set; }
        [DataMember]
        public long IndexId { get; set; }
        [DataMember]
        public string BBGTicker { get; set; }

        [IgnoreDataMember]
        public string PricingDateFormatted
        {
            get { return PricingDate != null ? PricingDate.GetValueOrDefault().ToString("ddMMyyyy") : null; }
        }

        [DataMember]
        public IndexQuoteInfos Quote { get; set; }
    }
}
