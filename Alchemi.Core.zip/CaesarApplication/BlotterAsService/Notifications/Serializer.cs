using System;
using System.IO;
using System.Linq;
using GlobalDerivativesApplications.Serialization;
using PricingBase.DataProvider;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class Serializer : ISerializer
    {
        private SerializationManager serializationManager = new SerializationManager(SerializationType.Binary);

        public T GetObjectFromBytes<T>(byte[] msgBytes)
        {
            using (var memStream = new MemoryStream(msgBytes))
            {
                return serializationManager.Deserialize<T>(memStream);
            }
        }

        public object GetObjectFromBytes(Type type, byte[] msgBytes)
        {
            using (var memStream = new MemoryStream(msgBytes))
            {
                var method = serializationManager.GetType().GetMethods().First(m => m.Name == "Deserialize" && m.GetParameters().Any() && m.GetParameters().First().ParameterType == typeof(Stream)).MakeGenericMethod(type);

                return method.Invoke(serializationManager, new object[] { memStream, new Type[0]});
            }
        }

        public byte[] GetBytesFromObject(Type[] knownTypes, object body)
        {
            using (var memStream = new MemoryStream())
            {
                serializationManager.Serialize(body, memStream);

                return memStream.ToArray();
            }
        }
    }
}