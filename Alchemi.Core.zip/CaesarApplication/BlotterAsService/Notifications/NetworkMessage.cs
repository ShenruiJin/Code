﻿using System;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.Notifications
{
    [Serializable]
    [DataContract]
    public class NetworkMessage<T> : NetworkMessage
    {
        public string bodyType;
        private byte[] _bodyBytes;

        [DataMember]
        public byte[] BodyBytes
        {
            get { return _bodyBytes; }
            private set { _bodyBytes = value; }
        }

        [DataMember]
        public string BodyType
        {
            get { return bodyType; }
            private set { bodyType = value; }
        }

        [IgnoreDataMember]
        public T Body
        {
            get { return (T)UnTypedBody; }
            set { UnTypedBody = value; }
        }
    }

    [Serializable]
    [DataContract]
    public class NetworkMessage : IEquatable<NetworkMessage>
    {
        private Guid id;
        
        public string bodyType;
        private byte[] _bodyBytes;
        private DateTime? sentTime;
        private DateTime? ackTime;

        [IgnoreDataMember]
        public string Topic { get; set; }

        [DataMember]
        public byte[] BodyBytes
        {
            get { return _bodyBytes; }
            set { _bodyBytes = value; }
        }

        [DataMember]
        public string BodyType
        {
            get { return bodyType; }
            set { bodyType = value; }
        }

        [IgnoreDataMember]
        public object UnTypedBody { get; set; }

        [DataMember]
        public Guid Id
        {
            get { return id; }
            set { id = value; }
        }

        [DataMember]
        public DateTime? SentTime
        {
            get { return sentTime; }
            set { sentTime = value; }
        }

        [DataMember]
        public DateTime? AckTime
        {
            get { return ackTime; }
            set { ackTime = value; }
        }

        public bool Equals(NetworkMessage other)
        {
            return other != null && Id.Equals(other.Id);
        }

        public override bool Equals(object obj)
        {
            return Equals(obj as NetworkMessage);
        }

        public override int GetHashCode()
        {
            return Id.GetHashCode();
        }

    }
}