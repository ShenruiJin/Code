using System;
using System.Collections.Generic;
using System.Linq;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public abstract class MessageManager<TMessageBody> : IMessageManager<TMessageBody>
    {
        public abstract object TreatMessage(NetworkMessage<TMessageBody> message);
        public abstract bool ReturnMessage(NetworkMessage<TMessageBody> message);

        public bool ReturnMessage(NetworkMessage message)
        {
            return ReturnMessage((NetworkMessage<TMessageBody>)message);
        }

        public object TreatMessage(NetworkMessage message)
        {
            return TreatMessage((NetworkMessage<TMessageBody>) message);
        }
    }

    public class MessageManager : IMessageManager
    {
        private Dictionary<Type, IMessageManager> managers;

        public MessageManager()
        {
            managers = new Dictionary<Type, IMessageManager>();
        }

        public MessageManager(Type[] assemblyTypes)
        {
            LoadManagers(assemblyTypes);
        }

        public void LoadManagers(params Type[] assemblyTypes)
        {
            var mgrs =
                assemblyTypes.Select(x => x.Assembly)
                    .SelectMany(
                        x => x.GetTypes().Where(t => 
                            !t.IsAbstract &&
                            GetInterfaces(t)
                                .Any(i => 
                                    i.IsGenericType && i.GetGenericTypeDefinition() == typeof(IMessageManager<>))))
                    .ToArray();

            managers = new Dictionary<Type, IMessageManager>();

            foreach (var type in mgrs)
            {
                AddManager(type);
            }
        }

        public void AddManager(Type type)
        {
            var msgType =
                type.GetInterfaces()
                    .First(i => i.GetGenericTypeDefinition() == typeof (IMessageManager<>))
                    .GetGenericArguments()[0];

            if (!managers.ContainsKey(msgType))
            {
                managers.Add(msgType, (IMessageManager) Activator.CreateInstance(type));
            }
        }

        public void AddManager(IMessageManager messageManager)
        {
            var msgType =
                messageManager.GetType().GetInterfaces()
                    .First(i => i.GetGenericTypeDefinition() == typeof(IMessageManager<>))
                    .GetGenericArguments()[0];

            if (!managers.ContainsKey(msgType))
            {
                managers.Add(msgType, messageManager);
            }
        }

        private static Type[] GetInterfaces(Type t)
        {
            return t.GetInterfaces().Union(t.BaseType != null ? GetInterfaces(t.BaseType) : new Type[0]).ToArray();
        }

        private IMessageManager GetMessageManager(NetworkMessage message)
        {
            var bodyType = message.UnTypedBody.GetType();

            return managers[bodyType];
        }

        public bool IsManaged(NetworkMessage message)
        {
            return managers.Keys.Contains(message.UnTypedBody.GetType());
        }

        public bool ReturnMessage(NetworkMessage message)
        {
            return GetMessageManager(message).ReturnMessage(message);
        }

        public object TreatMessage(NetworkMessage message)
        {
            return GetMessageManager(message).TreatMessage(message);
        }
    }
}