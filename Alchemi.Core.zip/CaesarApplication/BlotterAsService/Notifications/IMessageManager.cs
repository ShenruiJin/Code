﻿namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface IMessageManager
    {
        bool ReturnMessage(NetworkMessage message);

        object TreatMessage(NetworkMessage message);
    }
}