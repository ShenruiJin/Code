﻿using System;
using System.Collections.Generic;
using CaesarApplication.BlotterAsService.Notifications.DataContracts;
using DealIndexDataTransferObject.Blotter.DataContracts;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public static class BlotterMessages
    {
        public static Dictionary<string, Type> GetNotificationsDictionary()
        {
            return new Dictionary<string, Type>
            {
                {"Ack", typeof (AckMessage)},
                {"SubscribtionRequest", typeof (BlotterSubscribtionRequest)},
                {"UnsubscribtionRequest", typeof (UnsubscribtionRequest)},
                {"Notification", typeof (BlotterNotification)},
                {"TaskStatusUpdate", typeof (TaskStatusUpdateNotification)},
                {"SubscribtionReply", typeof (BlotterSubscribtionReply)},
                { "SubscribtionAck", typeof (SubscribtionAck)},
                 { "Ping", typeof (PingMessage)}
            };
        }
    }
}
