using System;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.Notifications
{
    [Serializable]
    [DataContract]
    public class AckMessage
    {
        [DataMember]
        public Guid Id { get; set; }

        [DataMember]
        public string Topic { get; set; }

        [DataMember]
        public DateTime Timestamp { get; set; }
    }
}