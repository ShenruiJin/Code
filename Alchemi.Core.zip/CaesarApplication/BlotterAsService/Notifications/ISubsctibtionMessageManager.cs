﻿namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface IMessageManager<TMessageBody> : IMessageManager
    {
        object TreatMessage(NetworkMessage<TMessageBody> message);

        bool ReturnMessage(NetworkMessage<TMessageBody> message);
    }
}
