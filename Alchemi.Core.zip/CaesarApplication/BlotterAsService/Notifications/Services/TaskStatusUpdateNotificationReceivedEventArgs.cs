﻿using DealIndexDataTransferObject.Blotter.DataContracts;
using System;

namespace CaesarApplication.BlotterAsService.Notifications.Services
{
    public class TaskStatusUpdateNotificationReceivedEventArgs : EventArgs
    {
        public TaskStatusUpdateNotificationReceivedEventArgs(TaskStatusUpdateNotification notification)
        {
            TaskStatusUpdateNotification = notification;
        }

        public TaskStatusUpdateNotification TaskStatusUpdateNotification { get; private set; }
    }
}
