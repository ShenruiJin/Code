using System;

namespace CaesarApplication.BlotterAsService.Notifications.Services
{
    public static class ConnectionStringHelper
    {
        public static string GetSubscribtionConnectionStringCustomized(string subscribtionConnectionString)
        {
            int? tasksPublishPort = null;

            Environment.GetCommandLineArgs().Consume("tasksPublishPort", (x, v) => { tasksPublishPort = int.Parse(v); });

            var subscribtionConnectionStringCustomized = GetConnectionStringWithPort(subscribtionConnectionString,
                tasksPublishPort);
            return subscribtionConnectionStringCustomized;
        }

        public static string GetRequestConnectionStringCustomized(string requestConnectionString)
        {
            int? tasksRequestPort = null;

            Environment.GetCommandLineArgs().Consume("tasksRequestPort", (x, v) => { tasksRequestPort = int.Parse(v); });

            var requestConnectionStringCustomized = GetConnectionStringWithPort(requestConnectionString,
                tasksRequestPort);


            return requestConnectionStringCustomized;
        }


        private static string GetConnectionStringWithPort(string requestConnectionString, int? tasksRequestPort)
        {
            string publicationServer = null;

            Environment.GetCommandLineArgs().Consume("publicationServer", (x, v) => { publicationServer = v; });

            var computerName = requestConnectionString.Substring(requestConnectionString.IndexOf("://") + 3);

            computerName = computerName.Substring(0, computerName.LastIndexOf(":"));

            var res = publicationServer != null
                ? requestConnectionString.Replace(computerName, publicationServer)
                : requestConnectionString;

            return tasksRequestPort.HasValue
                ? res.Substring(0, res.LastIndexOf(":")) + ":" +
                  tasksRequestPort.GetValueOrDefault()
                : res;
        }
    }
}