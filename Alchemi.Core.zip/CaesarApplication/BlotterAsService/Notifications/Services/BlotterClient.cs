﻿using System;
using System.Collections.Generic;
using CaesarApplication.BlotterAsService.Notifications.DataContracts;
using DealBusinessObject.IDescription;
using DealIndexDataTransferObject.Blotter.DataContracts;
using CaesarCommon.Configuration;
using DealIndexDataTransferObject;

namespace CaesarApplication.BlotterAsService.Notifications.Services
{
    public class BlotterClient
    {
        private readonly PublicationClient<BlotterSubscribtionRequest, BlotterSubscribtionReply> publicationClient;
        public event EventHandler<OnBlotterNotificationReceivedEventArgs> OnBlotterNotificationReceived;
        public event EventHandler<TaskStatusUpdateNotificationReceivedEventArgs> OnTaskStatusUpdateNotificationReceived;


        public BlotterClient(string requestConnectionString, string subscribtionConnectionString, ISerializer serializer)
        {
            Dictionary<string, Type> messagesTypes = BlotterMessages.GetNotificationsDictionary();
            var messageManager = new MessageManager();
            var blotterNotificationManager = new BlotterNotificationManager();
            blotterNotificationManager.OnBlotterNotificationReceived += (sender, args) =>
            {
                if (OnBlotterNotificationReceived != null)
                {
                    OnBlotterNotificationReceived(sender, args);
                }
            };

            var taskStatusUpdateNotificationManager = new TaskStatusUpdateNotificationManager();
            taskStatusUpdateNotificationManager.OnTaskStatusUpdateNotificationReceived += (sender, args) =>
            {
                if (OnTaskStatusUpdateNotificationReceived != null)
                {
                    OnTaskStatusUpdateNotificationReceived(sender, args);
                }
            };

            messageManager.AddManager(blotterNotificationManager);
            messageManager.AddManager(taskStatusUpdateNotificationManager);

            var requestConnectionStringCustomized = ConnectionStringHelper.GetRequestConnectionStringCustomized(requestConnectionString);
            var subscribtionConnectionStringCustomized = ConnectionStringHelper.GetSubscribtionConnectionStringCustomized(subscribtionConnectionString);

            publicationClient = new PublicationClient<BlotterSubscribtionRequest, BlotterSubscribtionReply>(requestConnectionStringCustomized, subscribtionConnectionStringCustomized, new NetworkMessageManager(serializer, messagesTypes), messageManager);
        }

        public void Subscribe(ICaesarSession session, DateTime startDate, DateTime? endDate)
        {
            publicationClient.Subscribe(new BlotterSubscribtionRequest { User = session.User.Login, StartDate = startDate, EndDate = endDate });
        }

        public void Unsubscribe()
        {
            publicationClient.Unsubscribe();
        }

        public static string GetSubscribtionConnectionString(bool isLocalMode, CaesarSettingsManager settingsManager, DealServerDirectoryEntry dealServerDirectoryEntry)
        {
            if (dealServerDirectoryEntry != null && dealServerDirectoryEntry.GetTypedServiceConfiguration() != null && dealServerDirectoryEntry.GetTypedServiceConfiguration().NotificationPort.HasValue)
            {
                return string.Format("tcp://{0}:{1}", dealServerDirectoryEntry.Server,
                    dealServerDirectoryEntry.GetTypedServiceConfiguration().NotificationPort);
            }

            return isLocalMode ? @"tcp://localhost:9015" : settingsManager.TaskSubscribtionConnectionString;
        }

        public static string GetRequestConnectionString(bool isLocalMode, CaesarSettingsManager settingsManager, DealServerDirectoryEntry dealServerDirectoryEntry)
        {
            if (dealServerDirectoryEntry != null && dealServerDirectoryEntry.GetTypedServiceConfiguration() != null && dealServerDirectoryEntry.GetTypedServiceConfiguration().ServicePort.HasValue)
            {
                return string.Format(">tcp://{0}:{1}", dealServerDirectoryEntry.Server,
                    dealServerDirectoryEntry.GetTypedServiceConfiguration().ServicePort);
            }

            return isLocalMode ? ">tcp://localhost:9010" : settingsManager.TaskRequestConnectionString;
        }
    }

    public class BlotterNotificationManager : MessageManager<BlotterNotification>
    {
        public event EventHandler<OnBlotterNotificationReceivedEventArgs> OnBlotterNotificationReceived;

        public override object TreatMessage(NetworkMessage<BlotterNotification> message)
        {
            if (OnBlotterNotificationReceived != null)
            {
                OnBlotterNotificationReceived(this, new OnBlotterNotificationReceivedEventArgs(message.Body));
            }

            return null;
        }

        public override bool ReturnMessage(NetworkMessage<BlotterNotification> message)
        {
            return false;
        }
    }

    public class TaskStatusUpdateNotificationManager : MessageManager<TaskStatusUpdateNotification>
    {
        public event EventHandler<TaskStatusUpdateNotificationReceivedEventArgs> OnTaskStatusUpdateNotificationReceived;

        public override object TreatMessage(NetworkMessage<TaskStatusUpdateNotification> message)
        {
            if (OnTaskStatusUpdateNotificationReceived != null)
            {
                OnTaskStatusUpdateNotificationReceived(this, new TaskStatusUpdateNotificationReceivedEventArgs(message.Body));
            }

            return null;
        }

        public override bool ReturnMessage(NetworkMessage<TaskStatusUpdateNotification> message)
        {
            return false;
        }
    }
}

