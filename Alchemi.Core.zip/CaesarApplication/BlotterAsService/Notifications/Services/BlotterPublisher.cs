﻿using System;
using System.Linq;
using System.Threading;
using CaesarApplication.BlotterAsService.Notifications.DataContracts;
using DealIndexDataTransferObject.Blotter;
using DealIndexDataTransferObject.Blotter.DataContracts;
using DealServerInterfaceIndex.Blotter;
using GlobalDerivativesApplications.Log;
using log4net;

namespace CaesarApplication.BlotterAsService.Notifications.Services
{
    public class BlotterPublisher : IDisposable
    {
        private readonly PublicationServer<BlotterSubscribtionRequest, BlotterSubscribtionReply> publisherServer;
        private readonly IBlotterRightManager rightManager;
        private readonly ITaskManager taskManager;
        public readonly IProfilManager profilManager;

        private ILog taskManagerLogger = LoggerManager.Logger(typeof(TaskManager));

        public BlotterPublisher(PublicationServer<BlotterSubscribtionRequest, BlotterSubscribtionReply> publisherServer, IBlotterRightManager rightManager, ITaskManager taskManager, IProfilManager profilManager)
        {
            this.publisherServer = publisherServer;
            this.rightManager = rightManager;
            this.taskManager = taskManager;
            this.profilManager = profilManager;

            publisherServer.OnSubscriberConnected += OnSubscriberConnected;

            taskManager.OnTasksUpdate += TaskManagerOnTasksUpdate;
            taskManager.OnTasksStatusUpdate += TaskManagerOnTasksStatusUpdate;
        }

        private void TaskManagerOnTasksStatusUpdate(object sender, TaskStatusUpdateEventArgs e)
        {
            foreach (var subscriberByTopic in publisherServer.GetSubscribers())
            {
                publisherServer.PublishMessage(subscriberByTopic.Key, new TaskStatusUpdateNotification { NotificationDate = e.UpdateDate, TaskStatuses = e.TaskStatuses.ToArray() });
            }
        }

        private void TaskManagerOnTasksUpdate(object sender, TasksUpdateEventArgs tasksUpdateEventArgs)
        {
            Publish(tasksUpdateEventArgs.Tasks, tasksUpdateEventArgs.UpdateDate);
        }

        private void OnSubscriberConnected(object sender, SubscriberConnectedEventArgs<BlotterSubscribtionRequest, BlotterSubscribtionReply> subscriberConnectedEventArgs)
        {
            taskManagerLogger.Info("Start subscribtion for :" + subscriberConnectedEventArgs.SubscribtionRequest.User);

            var tasks = taskManager.GetCurrentTasks(null, false, subscriberConnectedEventArgs.SubscribtionRequest.StartDate, subscriberConnectedEventArgs.SubscribtionRequest.EndDate);

            Publish(tasks.AddedItems.ToArray(), 
                tasks.NotificationDate, 
                subscriberConnectedEventArgs.SubscribtionReply.TopicName, 
                subscriberConnectedEventArgs.SubscribtionRequest,
                subscriberConnectedEventArgs.SubscribtionRequest.StartDate,
                subscriberConnectedEventArgs.SubscribtionRequest.EndDate);

            taskManagerLogger.Info("End subscribtion for :" + subscriberConnectedEventArgs.SubscribtionRequest.User);
        }

        public void Publish(ITask[] tasks, DateTime updateDate)
        {
            foreach (var subscriberByTopic in publisherServer.GetSubscribers())
            {
                Publish(tasks, updateDate, subscriberByTopic.Key, subscriberByTopic.Value);
            }
        }

        private void Publish(ITask[] tasks, DateTime updateDate, string subscriberTopic, BlotterSubscribtionRequest blotterSubscribtionRequest, DateTime? requestedStartDate = null, DateTime? requestedEndDate = null)
        {
            DateTime? lastMsgAckDate;
            var lastUpdateMsg = publisherServer.GetLastMessageForSubscriber<BlotterNotification>(subscriberTopic, true, out lastMsgAckDate);

            var subscribtion = publisherServer.Subscribers[subscriberTopic];

            var notif = taskManager.GetBlotterNotificationFromDelta(lastUpdateMsg != null ? lastUpdateMsg.NotificationDate : (DateTime?)null, updateDate, tasks,
                subscribtion.StartDate,
                subscribtion.EndDate);
            var rights = rightManager.GetRights(profilManager.GetUserProfiles(blotterSubscribtionRequest.User));

            notif = TaskRightManager.ApplyRightFilter(notif, rights);

            if (!notif.IsEmpty())
            {
                taskManagerLogger.Info("Publish for :" + subscriberTopic);
                taskManagerLogger.Info("Added :" + notif.AddedItems.Length);
                taskManagerLogger.Info("Modified :" + notif.ModifiedItems.Length);
                taskManagerLogger.Info("Removed :" + notif.RemovedItems.Length);

                publisherServer.PublishMessage(subscriberTopic, notif);
            }
        }

        public void Start()
        {
            publisherServer.Start();
        }

        public void Stop()
        {
            publisherServer.Stop();
        }

        public void Dispose()
        {
            publisherServer.Dispose();
        }
    }
}
