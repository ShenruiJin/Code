﻿using System;
using DealIndexDataTransferObject.Blotter.DataContracts;

namespace CaesarApplication.BlotterAsService.Notifications.Services
{
    public class OnBlotterNotificationReceivedEventArgs : EventArgs
    {
        public OnBlotterNotificationReceivedEventArgs(BlotterNotification blotterNotification)
        {
            BlotterNotification = blotterNotification;
        }

        public BlotterNotification BlotterNotification { get; private set; }
    }
}