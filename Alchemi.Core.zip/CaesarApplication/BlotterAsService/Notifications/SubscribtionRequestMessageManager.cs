using System;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class SubscribtionRequestMessageManager : MessageManager<SubscribtionRequest>
    {
        public override object TreatMessage(NetworkMessage<SubscribtionRequest> message)
        {
            var reply = new SubscribtionReply
            {
                TopicName = Guid.NewGuid().ToString()
            };
            
            return reply;
        }

        public override bool ReturnMessage(NetworkMessage<SubscribtionRequest> message)
        {
            return true;
        }
    }
}