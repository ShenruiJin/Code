using System;
using System.Collections.Generic;
using System.Linq;
using DocumentFormat.OpenXml.Office2010.Excel;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class NetworkMessageManager
    {
        private readonly ISerializer _serializer;
        private Dictionary<string, Type> messagesTypes;

        public NetworkMessageManager(ISerializer serializer, Dictionary<string, Type> messagesTypes)
        {
            _serializer = serializer;
            this.messagesTypes = messagesTypes;
        }

        public NetworkMessage GetNetworkMessageFromBytes(byte[] msgBytes)
        {
            var msg = _serializer.GetObjectFromBytes<NetworkMessage>(msgBytes);

            var bodyType = messagesTypes[msg.BodyType];

            msg.UnTypedBody = _serializer.GetObjectFromBytes(bodyType, msg.BodyBytes);

            var strongType = typeof(NetworkMessage<>).MakeGenericType(bodyType);

            var typedMsg = (NetworkMessage)Activator.CreateInstance(strongType);

            typedMsg.Id = msg.Id;
            typedMsg.Topic = msg.Topic;
            typedMsg.BodyType = msg.BodyType;
            typedMsg.BodyBytes = msg.BodyBytes;
            typedMsg.UnTypedBody = msg.UnTypedBody;

            return typedMsg;
        }

        public byte[] GetNetworkMessageAsBytes(Object body, out NetworkMessage msg)
        {
            var knownTypes = messagesTypes.Select(x => x.Value).Distinct().ToArray();

            var strongType = typeof(NetworkMessage<>).MakeGenericType(body.GetType());

            msg = (NetworkMessage)Activator.CreateInstance(strongType);

            msg.UnTypedBody = body;
            msg.BodyBytes = _serializer.GetBytesFromObject(knownTypes, body);
            msg.BodyType = messagesTypes.First(x => x.Value == body.GetType()).Key;
            msg.Id = Guid.NewGuid();

            return _serializer.GetBytesFromObject(knownTypes, msg);
        }
    }
}