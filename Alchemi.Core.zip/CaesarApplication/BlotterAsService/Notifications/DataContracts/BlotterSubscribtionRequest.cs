﻿using System;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.Notifications.DataContracts
{
    [Serializable]
    [DataContract]
    public class BlotterSubscribtionRequest : SubscribtionRequest
    {
        [DataMember]
        public string User { get; set; }
        
        [DataMember]
        public DateTime StartDate { get; set; }

        [DataMember]
        public DateTime? EndDate { get; set; }
    }

    [Serializable]
    [DataContract]
    public class BlotterSubscribtionReply : SubscribtionReply
    {
    }
}
