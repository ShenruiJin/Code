using System;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class SubscriberConnectedEventArgs<TRequest, TReply> : EventArgs
        where TRequest : SubscribtionRequest
         where TReply : SubscribtionReply
    {
        public SubscriberConnectedEventArgs(TRequest subscribtionRequest, TReply subscribtionReply)
        {
            SubscribtionRequest = subscribtionRequest;
            SubscribtionReply = subscribtionReply;
        }

        public TRequest SubscribtionRequest
        {
            get;
            private set;
        }

        public TReply SubscribtionReply
        {
            get;
            private set;
        }
    }
}