using System;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface IPublicationServer<TInputMessage>
    {

        void Unsubscribe(string subscribtionKey);

        void Ack(string subscribtionKey, Guid messageId, DateTime messageDate);

        event EventHandler<OnMessageReceived<TInputMessage>> OnMessageReceived;
    }
}