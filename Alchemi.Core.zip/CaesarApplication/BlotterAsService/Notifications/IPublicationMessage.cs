﻿using System;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface IPublicationMessage
    {
        DateTime MessageDate { get; set; }

        Guid Id { get; set; }
    }
}