﻿using System;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface ISerializer
    {
        T GetObjectFromBytes<T>(byte[] msgBytes);

        Object GetObjectFromBytes(Type type, byte[] msgBytes);
        byte[] GetBytesFromObject(Type[] knownTypes, object body);
    }
}