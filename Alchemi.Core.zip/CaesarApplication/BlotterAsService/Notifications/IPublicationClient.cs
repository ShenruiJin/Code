﻿using System;
using System.Runtime.Serialization;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public interface IPublicationClient<TSubscribtionRequest>
    {
        void Subscribe(TSubscribtionRequest subscribtionRequest);
        void Unsubscribe();
        TReply RequestAndReplyMessage<TRequest, TReply>(TRequest request);
        void SendMessage<TMsg>(TMsg request);
        void ReceiveMessage(byte[] receivedMessageBytes, string topic);
        void Dispose();
    }

    public class OnMessageReceived<T> : EventArgs
    {
        public OnMessageReceived(T message)
        {
            Message = message;
        }

        public T Message { get; private set; }
    }

    [Serializable]
    [DataContract]
    public class SubscribtionReply
    {
        [DataMember]
        public string TopicName { get; set; }
    }

    [Serializable]
    [DataContract]
    public class SubscribtionAck
    {
        [DataMember]
        public string TopicName { get; set; }
    }

    [Serializable]
    [DataContract]
    public class UnsubscribtionRequest
    {
        [DataMember]
        public string TopicName { get; set; }
    }

    [Serializable]
    [DataContract]
    public class SubscribtionRequest
    {
    }
}
