using System;
using System.Threading;
using log4net;
using NetMQ;
using NetMQ.Sockets;
using Timer = System.Timers.Timer;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class PublicationClient<TSubscribtionRequest, TSubscribtionReply> : IPublicationClient<TSubscribtionRequest>
        where TSubscribtionRequest : SubscribtionRequest, new()
        where TSubscribtionReply : SubscribtionReply, new()
    {
        private NetworkMessageManager networkMessageManager;
        private readonly MessageManager _messageManager;

        private string requestConnectionString = ">tcp://localhost:5556";
        private string subscribtionConnectionString = "tcp://localhost:5555";

        private SubscriberSocket subscriberSocket;
        private Thread listenThread;
        private bool isRunning;
        private TSubscribtionReply subcribtion;

        private Timer timer = new Timer(15000);

        private ILog logger = LogManager.GetLogger(typeof (PublicationClient<TSubscribtionRequest, TSubscribtionReply>));

        public PublicationClient(string requestConnectionString, string subscribtionConnectionString, NetworkMessageManager networkMessageManager, MessageManager messageManager)
        {
            this.networkMessageManager = networkMessageManager;
            _messageManager = messageManager;
            this.requestConnectionString = requestConnectionString;
            this.subscribtionConnectionString = subscribtionConnectionString;

            timer.Elapsed += (sender, args) => SendPing();
        }

        private void SendPing()
        {
            //SendMessage(new PingMessage { Topic = subcribtion.TopicName, Timestamp = DateTime.Now });
        }

        public void Subscribe(TSubscribtionRequest subscribtionRequest)
        {
            subscriberSocket = new SubscriberSocket();

            subscriberSocket.Options.ReceiveHighWatermark = 1000;
            subscriberSocket.Connect(subscribtionConnectionString);

            subcribtion = RequestAndReplyMessage<TSubscribtionRequest, TSubscribtionReply>(subscribtionRequest);

            subscriberSocket.Subscribe(subcribtion.TopicName);

            isRunning = true;

            listenThread = new Thread(() =>
            {
                while (isRunning)
                {
                    var topic = subscriberSocket.ReceiveFrameString();
                    var msgBytes = subscriberSocket.ReceiveFrameBytes();

                    try
                    {
                        ReceiveMessage(msgBytes, topic);
                    }
                    catch(Exception ex)
                    {
                        logger.Error(ex);
                    }
                }
            });

            listenThread.IsBackground = true;

            listenThread.Start();

            SendMessage(new SubscribtionAck { TopicName = subcribtion .TopicName });

            timer.Start();
        }


        public void Unsubscribe()
        {
            SendMessage(new UnsubscribtionRequest { TopicName = subcribtion.TopicName });

            if (subscriberSocket != null)
            {
                subscriberSocket.Disconnect(subscribtionConnectionString);
            }

            isRunning = false;
        }

        public TReply RequestAndReplyMessage<TRequest, TReply>(TRequest request)
        {
            NetworkMessage requestMsg;

            var bytesToSend = networkMessageManager.GetNetworkMessageAsBytes(request, out requestMsg);

            using (var requestSocket = new RequestSocket(requestConnectionString))
            {
                requestSocket.SendFrame(bytesToSend);
                var responseBytes = requestSocket.ReceiveFrameBytes();

                return ((NetworkMessage<TReply>)networkMessageManager.GetNetworkMessageFromBytes(responseBytes)).Body;
            }
        }

        public void SendMessage<TMsg>(TMsg request)
        {
            NetworkMessage requestMsg;

            var bytesToSend = networkMessageManager.GetNetworkMessageAsBytes(request, out requestMsg);

            using (var requestSocket = new RequestSocket(requestConnectionString))
            {
                requestSocket.SendFrame(bytesToSend);
                requestSocket.ReceiveFrameBytes();
            }
        }

        public void ReceiveMessage(byte[] receivedMessageBytes, string topic)
        {
            var msg = networkMessageManager.GetNetworkMessageFromBytes(receivedMessageBytes);
            Object responseBody = null;

            msg.Topic = topic;


            if (msg.BodyType == "PlainText")
            {
                Console.WriteLine(((NetworkMessage<string>)msg).Body);
            }
            else if (_messageManager.IsManaged(msg))
            {
                _messageManager.TreatMessage(msg);
            }

            if (msg.Topic != null)
            {
                SendMessage(new AckMessage { Id = msg.Id, Topic = topic, Timestamp = DateTime.Now });
            }
        }

        public void Dispose()
        {
            if (subscriberSocket != null)
            {
                subscriberSocket.Dispose();
            }

            if (timer.Enabled)
            {
                timer.Stop();
            }
        }
    }
}