﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using NetMQ;
using NetMQ.Sockets;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using CaesarApplication.Service.Logging;

namespace CaesarApplication.BlotterAsService.Notifications
{
    public class PublicationServer<TSubscribtionRequest, TSubscribtionReply> : IDisposable
        where TSubscribtionRequest : SubscribtionRequest
        where TSubscribtionReply : SubscribtionReply, new()
    {
        private NetworkMessageManager networkMessageManager;
        private readonly MessageManager _messageManager;
        private string publishConnectionString = "tcp://localhost:5555";
        private string responseConnectionString = "@tcp://*:5556";
        private Timer cleanUpTimer;

        private PublisherSocket publishSocket;
        private ResponseSocket responseSocket;
        private NetMQPoller poller;
        private bool isRunning;

        private ConcurrentDictionary<string, DateTime> availabilities = new ConcurrentDictionary<string, DateTime>();

        private ConcurrentDictionary<string, TSubscribtionRequest> subscribers =
            new ConcurrentDictionary<string, TSubscribtionRequest>();

        public ConcurrentDictionary<string, ConcurrentDictionary<string, NetworkMessage>> messagesAcked =
            new ConcurrentDictionary<string, ConcurrentDictionary<string, NetworkMessage>>();

        public Func<SubscribtionRequest, TSubscribtionReply, TSubscribtionReply> EnrichSubscribtionReply = null;
        private readonly int messageLifeTime = 10;

        private ConcurrentQueue<KeyValuePair<string, byte[]>> publishMessageQueue = new ConcurrentQueue<KeyValuePair<string, byte[]>>();
        public event EventHandler<SubscriberConnectedEventArgs<TSubscribtionRequest, TSubscribtionReply>>
            OnSubscriberConnected;

        private AutoResetEvent publishMessageEnQueued = new AutoResetEvent(false);

        public PublicationServer(string responseConnectionString, string publishConnectionString,
            NetworkMessageManager networkMessageManager, MessageManager messageManager)
        {
            this.responseConnectionString = responseConnectionString;
            this.publishConnectionString = publishConnectionString;
            this.networkMessageManager = networkMessageManager;
            _messageManager = messageManager;
            cleanUpTimer = new Timer(CleanUpMessages, null, 0*60000, 1*60000);
            Task.Factory.StartNew(StartPublishMessagesLoop, TaskCreationOptions.LongRunning);
        }

        public void Start()
        {
            publishSocket = new PublisherSocket();
            responseSocket = new ResponseSocket(responseConnectionString);

            publishSocket.Options.SendHighWatermark = 1000;
            publishSocket.Bind(publishConnectionString);

            isRunning = true;

            using (poller = new NetMQPoller { responseSocket })
            {
                responseSocket.ReceiveReady += OnReceiveReady;
                poller.Run();
            }
        }

        private void OnReceiveReady(object sender, NetMQSocketEventArgs args)
        {
            byte[] msg;
            for (int count = 0; count < 10; count++)
            {
                // exit the for loop if failed to receive a message
                if (!args.Socket.TryReceiveFrameBytes(out msg))
                    break;

                // send a response
                ReceiveAndResponseMessage(msg);
            }
        }

        public void Stop()
        {
            poller.Stop();
            isRunning = false;

            if (publishSocket != null)
            {
                publishSocket.Disconnect(publishConnectionString);
            }

            if (responseSocket != null)
            {
                responseSocket.Disconnect(responseConnectionString);
            }

            Dispose();
        }

        public void PublishMessage<T>(T sentMessageBody)
        {
            NetworkMessage requestMsg;
            var bytesToSend = networkMessageManager.GetNetworkMessageAsBytes(sentMessageBody, out requestMsg);

            foreach (var subscribtionRequest in Subscribers)
            {
                publishMessageQueue.Enqueue(new KeyValuePair<string, byte[]>(subscribtionRequest.Key, bytesToSend));
                publishMessageEnQueued.Set();

                messagesAcked.GetOrAdd(subscribtionRequest.Key, new ConcurrentDictionary<string, NetworkMessage>());
                messagesAcked[subscribtionRequest.Key][requestMsg.Id.ToString()] = requestMsg;
                requestMsg.BodyBytes = null;
            }
        }

        public void PublishMessage<T>(string topic, T sentMessageBody)
        {
            NetworkMessage requestMsg;
            var bytesToSend = networkMessageManager.GetNetworkMessageAsBytes(sentMessageBody, out requestMsg);
            requestMsg.SentTime = DateTime.Now;

            publishMessageQueue.Enqueue(new KeyValuePair<string, byte[]>(topic,bytesToSend));
            publishMessageEnQueued.Set();

            messagesAcked.GetOrAdd(topic, new ConcurrentDictionary<string, NetworkMessage>());
            messagesAcked[topic][requestMsg.Id.ToString()] = requestMsg;
            requestMsg.BodyBytes = null;
        }

        private void ReceiveAndResponseMessage(Byte[] receivedMessageBytes)
        {
            object responseBody = null;
            NetworkMessage msg = null;
            try
            {
                msg = networkMessageManager.GetNetworkMessageFromBytes(receivedMessageBytes);


                if (msg.BodyType == "SubscribtionRequest")
                {
                    var typedMessage = (NetworkMessage<TSubscribtionRequest>)msg;
                    responseBody = RegisterSubscribe(typedMessage.Body);
                }

                else if (msg.BodyType == "UnsubscribtionRequest")
                {
                    Unsubscribe(((NetworkMessage<UnsubscribtionRequest>)msg).Body);
                }
                else if (msg.BodyType == "Ack")
                {
                    var typedMessage = (NetworkMessage<AckMessage>)msg;

                    Ack(typedMessage.Body);
                }
                else if (msg.BodyType == "Ping")
                {
                    var typedMessage = (NetworkMessage<PingMessage>)msg;

                    UpdateAvailability(typedMessage);
                }
                else if (msg.BodyType == "SubscribtionAck")
                {
                    var typedMessage = (NetworkMessage<SubscribtionAck>)msg;
                    TSubscribtionRequest subscribtionRequest = null;
                    var topicName = typedMessage.Body.TopicName;
                    TSubscribtionRequest request;

                    if (Subscribers.TryGetValue(topicName, out request))
                    {
                        subscribtionRequest = request;
                    }

                    if (OnSubscriberConnected != null && subscribtionRequest != null)
                        OnSubscriberConnected(this,
                            new SubscriberConnectedEventArgs<TSubscribtionRequest, TSubscribtionReply>(subscribtionRequest, new TSubscribtionReply { TopicName = topicName }));
                }
                else
                {
                    responseBody = _messageManager.TreatMessage(msg);
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), ex);
            }

            if (responseBody != null || (msg != null && _messageManager.IsManaged(msg) && _messageManager.ReturnMessage(msg)))
            {
                NetworkMessage sentMsg;
                var responseMsg = networkMessageManager.GetNetworkMessageAsBytes(responseBody, out sentMsg);
                responseSocket.TrySendFrame(responseMsg);
            }
            else
            {
                responseSocket.TrySendFrameEmpty();
            }
        }

        private void UpdateAvailability(NetworkMessage<PingMessage> pingMessage)
        {
            availabilities.TryAdd(pingMessage.Body.Topic, pingMessage.Body.Timestamp);
        }

        private void Ack(AckMessage ackMessage)
        {
            if (!messagesAcked.ContainsKey(ackMessage.Topic))
                return;
            NetworkMessage msg;
            messagesAcked[ackMessage.Topic].TryGetValue(ackMessage.Id.ToString(), out msg);

            if (msg != null)
            {
                msg.AckTime = ackMessage.Timestamp;
                Console.WriteLine(@"Msg[{0}] acked at {1}", ackMessage.Id, ackMessage.Timestamp);
            }
        }

        private void Unsubscribe(UnsubscribtionRequest unsubscribtionRequest)
        {
            TSubscribtionRequest request;
            ConcurrentDictionary<string, NetworkMessage> concurrentDictionary;
            Subscribers.TryRemove(unsubscribtionRequest.TopicName, out request);
            messagesAcked.TryRemove(unsubscribtionRequest.TopicName, out concurrentDictionary);
        }

        private TSubscribtionReply RegisterSubscribe(TSubscribtionRequest subscribtionRequest)
        {

            var reply = new TSubscribtionReply
            {
                TopicName = Guid.NewGuid().ToString()
            };

            while (Subscribers.ContainsKey(reply.TopicName))
            {
                reply.TopicName = Guid.NewGuid().ToString();
            }

            Subscribers[reply.TopicName] = subscribtionRequest;

            if (EnrichSubscribtionReply != null)
            {
                reply = EnrichSubscribtionReply(subscribtionRequest, reply);
            }

            return reply;
        }

        public void Dispose()
        {
            if (publishSocket != null)
            {
                publishSocket.Dispose();
            }

            if (responseSocket != null)
            {
                responseSocket.Dispose();
            }
        }

        public IEnumerable<KeyValuePair<string,  TSubscribtionRequest>> GetSubscribers()
        {
            return Subscribers.Where(x => !availabilities.ContainsKey(x.Key) || ((DateTime.Now - availabilities[x.Key]) < NoPingTimeout)).ToArray();
        }

        public TimeSpan NoPingTimeout
        {
            get { return TimeSpan.FromSeconds(60); }
        }

        public ConcurrentDictionary<string, TSubscribtionRequest> Subscribers { get => subscribers; }

        public TBody GetLastMessageForSubscriber<TBody>(string subscriber, bool? acked, out DateTime? ackDate)
            where TBody : class
        {
            if (messagesAcked.ContainsKey(subscriber))
            {
                var msgs = messagesAcked[subscriber].Where(x => x.Value is NetworkMessage<TBody> && (!acked.GetValueOrDefault() || x.Value.AckTime.HasValue)).OrderBy(x => x.Value.AckTime).ToArray();

                if (msgs.Any())
                {
                    var message = msgs.Last();

                    ackDate = message.Value.AckTime;
                    return ((NetworkMessage<TBody>)message.Value).Body;
                }
            }

            ackDate = null;
            return null;
        }

        private void CleanUpMessages(object state)
        {
            try
            {
                Parallel.ForEach(messagesAcked.Values, topic =>
                {
                    var expiredMessages =
                        topic.Values.Where(
                            m => m.SentTime != null && DateTime.Now.Subtract(m.SentTime.Value).Minutes > messageLifeTime);

                    Parallel.ForEach(expiredMessages, expiredMessage =>
                    {
                        NetworkMessage msg;
                        topic.TryRemove(expiredMessage.Id.ToString(), out msg);
                    });
                });
            }
            catch (Exception e)
            {
                LoggingService.Error(this.GetType(),"Exception while cleaning up messages: "+ e);
            }
        }

        private void StartPublishMessagesLoop()
        {
            while (true)
            {
                KeyValuePair<string, byte[]> kvp;

                publishMessageEnQueued.WaitOne();
                while (publishMessageQueue.TryDequeue(out kvp))
                {
                    publishSocket.SendMoreFrame(kvp.Key).SendFrame(kvp.Value);
                }
            }
        }
    }
}