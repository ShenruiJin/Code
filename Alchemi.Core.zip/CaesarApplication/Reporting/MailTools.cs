﻿using GlobalDerivativesApplications;
using GlobalDerivativesApplications.Reporting;
using GlobalDerivativesApplications.ToolsBox;
using System;
using System.Collections.Generic;
using System.Linq;

namespace CaesarApplication.Reporting
{
    public static class MailTools
    {
        public static void SendBasicHtmlMail(string subject, string emailContent, IList<string> recipients, string attachement = null)
        {
            string emailAddress = System.Configuration.ConfigurationManager.AppSettings["SenderEmailAddress"] ?? "eda25-desk-quant-applications@natixis.com";
            string emailContent2 = emailContent.Replace("\u001a", "->");
            Tools.System.SendEmailEWS(emailAddress, recipients, subject, emailContent2,
                impersonatedAddress: emailAddress, userName: "nt_eqd_sos", password: "Ba13h,7j", bodyType: BodyType.HTML, attachments: attachement != null ? attachement.AsArray() : null);
        }

        public static string GetTablesAsHtml(Table[] tablesToExport)
        {
            return tablesToExport.Select(table =>
            {
                var matrix = table.GetMatrix(false);

                return new[] { "<h3>" + table.Name + "(" + matrix.Count() + " items) </h3><br />" + "<table><tr>" + table.Headers.Select(h => "<th>" + h + "</th>").Stringify("") + "</tr>" }.Union
                (matrix.Select(r => "<tr>" + r.Select(v => "<td>" + v + "</td>").Stringify("") + "</tr>"))
                .Stringify("\r\n") + "</table>";
        }).Stringify("<br />");

    }
    }
}
