using System;
using System.Threading;
using CaesarApplication.Service.Logging;
using Debugger;
using ICSharpCode.EditorExtension;
using CaesarApplication.Service.Connection;
using System.Linq;

namespace CaesarApplication.Debugger
{
    /// <summary>
    /// Wrapper Debugger pour le pricing
    /// </summary>
    public static class PricingDebug
    {
        static private System.Diagnostics.Process realDebuggedProcess = null;
        static bool isStarted = false;

        /// <summary>
        /// Attache l'Engine sur un Process
        /// </summary>
        /// <param name="aProcessID">l'id du Process (ne peut pas etre celui de l'application appelante)</param>
        public static int InitializeEngine()
        {
            LoggingService.Info(typeof(PricingDebug), "Starting pricing engine & debugger");

            if (System.Threading.Thread.CurrentThread.GetApartmentState() != ApartmentState.STA)
                throw new System.Exception("Can't launch the debugger form an MTA thread");

            // lance le process sans debugger // start a 8 to avoid conflict with dealserver
            int nextAvailablePort = 8158;
            // cehrche le premier port libre
            while (GlobalDerivativesApplications.Tools.Network.TcpIsListening("localhost", nextAvailablePort, 1000))
            {
                nextAvailablePort++;
            }

            // lance en indiquant le port
            realDebuggedProcess = new System.Diagnostics.Process();
            realDebuggedProcess.StartInfo.FileName = "PricingServer.exe";
            realDebuggedProcess.StartInfo.Arguments =
                System.Diagnostics.Process.GetCurrentProcess().Id.ToString()
                + " "
                + nextAvailablePort
                + ConnectionService.DealServicesCommandLineArguments
                + " "
                + Environment.GetCommandLineArgs().Skip(1).Stringify(" ").Replace(ConnectionService.DealServicesCommandLineArguments.Trim(), string.Empty);

            realDebuggedProcess.Start();

            EditorService.CurrentDebugger.Message += Debugger_Message;
            isStarted = true;
            return nextAvailablePort;
        }

        /// <summary>
        /// un peu de log
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="message"></param>
        static void Debugger_Message(string sender, string message)
        {
            System.Diagnostics.Trace.WriteLine(sender + "  : " + message);
        }

        /// <summary>
        /// debug session scope object
        /// </summary>
        public class DebugSession : IDisposable
        {
            bool detached = false;


            /// <summary>
            /// use DebugSession.NewSession static constructor method
            /// </summary>
            protected DebugSession()
            {
            }

            /// <summary>
            /// create a session, use in a using block or in a dispose pattern
            /// </summary>
            public static DebugSession NewSession(int PID, DebugModeFlag options = DebugModeFlag.Default)
            {
                var realDebuggedProcess = System.Diagnostics.Process.GetProcessById(PID);
                EditorService.CurrentDebugger.Attach(realDebuggedProcess, options);
                return new DebugSession(); 
            }

            /// <summary>
            /// </summary>
            public void Dispose()
            {
                if (!detached)
                {
                    LoggingService.Info(typeof(PricingDebug), "Stop debugging PricingServer");
                    EditorService.CurrentDebugger.Detach();
                    detached = true;
                }
            }

            /// <summary>
            /// debug session scopeobject
            /// </summary>
            ~DebugSession()
            {
                if (!detached)
                {
                    LoggingService.Error(typeof(DebugSession), "Invalid operation, debug session should not be in destructor not detached");
                }
            }
        }


        /// <summary>
        /// create a DebugSession scope object, use in a using block or dispose pattern
        /// </summary>
        /// <param name="options"></param>
        /// <returns></returns>
        public static DebugSession NewSession(DebugModeFlag options = DebugModeFlag.Debug)
        {
            if (EditorService.CurrentDebugger.IsDebugging)
                throw new System.Exception("Please stop the debugger first !");
            if (!realDebuggedProcess.HasExited)
            {
                return DebugSession.NewSession(realDebuggedProcess.Id);
            }
            else
            {
                return null;
            }
        }
        /// <summary>
        ///		Attche le debugger sur le process du pricingserver
        /// </summary>
        public static void Start()
        {
            // Attache le process du pricing server
            if (EditorService.CurrentDebugger.IsDebugging)
                throw new System.Exception("Please stop the debugger first !");

            LoggingService.Info(typeof(PricingDebug), "Attaching to PricingServer");
            // attache le debugger
            EditorService.CurrentDebugger.Attach(realDebuggedProcess);

            // previent que le debugger est lanc�
            LoggingService.Info(typeof(PricingDebug), "Attach completed");
        }

        /////// <summary>
        /////// On se detache du pricingServeur
        /////// </summary>
        ////public static void Stop()
        ////{
        ////    LoggingService.Info(typeof(PricingDebug), "Stop debugging PricingServer");
        ////    // detach
        ////    EditorService.CurrentDebugger.Detach();
        ////}

        /// <summary>
        /// termine le debuggage et indique qu'il faut terminer la loop
        /// </summary>
        public static void Kill()
        {
            if (isStarted)
            {
                LoggingService.Info(typeof(PricingDebug), "Closing debugger engine");
                // meurt
                if (null != EditorService.CurrentDebugger
                    && null != EditorService.CurrentDebugger.DebuggedProcess)
                {
                    try
                    {
                        EditorService.CurrentDebugger.DebuggedProcess.Terminate();
                    }
                    catch (System.Exception e)
                    {
                        LoggingService.Error(typeof(PricingDebug), e);
                    }
                }
                realDebuggedProcess = null;
                // reset
                isStarted = false;
            }
        }

        /// <summary>
        /// continue the execution (similaire a F5 dans VS)
        /// </summary>
        /// <param name="arguments"></param>
        public static void Go()
        {
            LoggingService.Debug(typeof(PricingDebug), "Debuggger = GO");
            EditorService.CurrentDebugger.Continue();
        }

        /// <summary>
        /// Step over a funtion (F10)
        /// </summary>
        public static void Next()
        {
            LoggingService.Debug(typeof(PricingDebug), "Debuggger = NEXT");
            EditorService.CurrentDebugger.Stop();
        }
    }


}

