﻿using CaesarApplication.DataProvider;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using DealServerInterface.Service;
using MarketDataMgr.Trees;
using MarketDataMgr.Trees.Ext;
using PricingBase.DataProvider;
using PricingBase.Index;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DealServerLocal.Description;
using System.Text;
using CaesarCommon.Configuration;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using DealServerLocal.Service;

namespace CaesarApplication
{
    public class IndexUniverseManager
    {
        #region private Fields

        private readonly ITimeSeriesProvider dataProvider;
        private readonly IDealProvider dealProvider;
        private readonly IIndexDBProvider indexProvider;
        private readonly object syncRoot = new object();
        private readonly object logSyncRoot = new object();
        private ArchivedDealDescriptionCache dealCache;
        private static IEnumerable<string> allStockTickers = null;
        private readonly ConcurrentDictionary<string, Tuple<DateTime, DateTime, TimeSerieDB>> cache;

        #endregion

        #region .Ctor

        public IndexUniverseManager(IDealProvider dealProvider, IIndexDBProvider indexProvider,
            ITimeSeriesProvider dataProvider)
        {
            this.dealProvider = dealProvider;
            this.indexProvider = indexProvider;
            this.dataProvider = dataProvider;
            cache = new ConcurrentDictionary<string, Tuple<DateTime, DateTime, TimeSerieDB>>();
        }

        public IndexUniverseManager()
            : this(PersistanceService.DealProvider, PersistanceService.IndexProvider,
                new TimeSeriesProvider(new OverloadedMarketDataTree(new MarketDataTree()), true))
        {
        }

        #endregion

        #region Properties

        public string ErrorDescription { get; protected set; }

        #endregion

        #region public Methods

        public virtual IDictionary<KeyValuePair<ProjectDTO, IndexDTO>, IEnumerable<string>> GetTickersPerIndex(DateTime startDate,
            DateTime endDate)
        {
            try
            {
                LoggingService.Info(this.GetType(), "Starting loading projects");

                var tickersPerIndex = indexProvider.GetUniverseTickersPerIndex();
                if (tickersPerIndex != null && tickersPerIndex.Count != 0)
                    return tickersPerIndex;

                var caesarSettingsManager = new CaesarSettingsManager();
                var caesarSession = new SuperSession(UserService.CaesarSession);

                //Gather all deals in production
                var projectDTOs = GetProductionProjectDtOs(caesarSession, caesarSettingsManager);

                LoggingService.Info(this.GetType(), "Loading projects ended, " + projectDTOs.Count + " projects loaded");

                //Gather all indexes in all deals (projects)
                var indexList = new ConcurrentBag<KeyValuePair<ProjectDTO, IndexDTO>>();
                Parallel.ForEach(projectDTOs, (p =>
                {
                    try
                    {
                        var project = indexProvider.ReadProject(p.id, null, caesarSession);
                        if (project.indexes != null && project.indexes.Count != 0)
                            project.indexes.ForEach(i => indexList.Add(new KeyValuePair<ProjectDTO, IndexDTO>(project, i)));
                    }
                    catch(Exception e)
                    {
                        LoggingService.Error(this.GetType(), "Exception happened while reading project with id = "+p.id, e);
                    }
                }));

                tickersPerIndex = new ConcurrentDictionary<KeyValuePair<ProjectDTO, IndexDTO>, IEnumerable<string>>();
                var erroraggregator = new StringBuilder();

                Parallel.ForEach(indexList, (indexByProject =>
                {
                    try
                    {
                        //Load basket Lists related to indexes
                        var timeSerie = GetBasketFromIndex(indexByProject.Value.id.ToString(), startDate, endDate);
                        //Build basket index list models 
                        var tmp = GetAllTickersInIndex(timeSerie);
                        if (!tmp.Any())
                            return;
                        tickersPerIndex[indexByProject] = tmp;
                    }
                    catch (Exception e)
                    {
                        lock (logSyncRoot)
                        {
                            erroraggregator.Append(string.Format("Error while retrieving tickers for index {0}: {1}",
                                indexByProject.Value.index_name, e.Message));
                        }
                    }
                }));

                //Trace out errors if any
                if (erroraggregator.Length != 0)
                    LoggingService.Error(this.GetType(), erroraggregator.ToString());
                return tickersPerIndex;
            }
            catch (Exception ex)
            {
                LoggingService.Error(this.GetType(), "Exception happened during project loading", ex);
                ErrorDescription = ex.Message;
                return null;
            }
            finally
            {
                try
                {
                    dataProvider.ClearTreeData(DataFieldsEnum.IndexBasketResult);
                }
                catch (Exception ex)
                {
                    LoggingService.Error(this.GetType(), "Exception happened during datatree cleaning", ex);
                }
            }
        }

        public List<ProjectDTO> GetProductionProjectDtOs(SuperSession caesarSession, CaesarSettingsManager caesarSettingsManager)
        {
            var startDate = DateTime.Today.AddYears(-1);
            var endDate = DateTime.Today;
            var dealDescriptions = dealProvider.GetDeals(startDate, endDate, caesarSession);

            var projectDTOs = indexProvider.ReadAllProjectsWithoutRevisions(caesarSession).Where(
                p =>
                {
                    var dealDescription = dealDescriptions.FirstOrDefault(d => d.Name == p.project_name);

                    return string.IsNullOrEmpty(caesarSettingsManager.IndexProductionEligibleSales) ||
                           (dealDescription != null && caesarSettingsManager.IndexProductionEligibleSales.Split(',')
                                .Contains(dealDescription.Sales.ShortName));
                }).ToList();
            return projectDTOs;
        }

        public virtual IEnumerable<string> GetIndexesTickers(DateTime startDate, DateTime endDate)
        {
            var result = indexProvider.GetUniverse();
            if (result != null && result.Count != 0)
                return result;
            var tickersPerIndex = GetTickersPerIndex(startDate, endDate);
            if (tickersPerIndex == null)
                return result;
            var tickers = tickersPerIndex.Values.SelectMany(list => list).Where(i => i != "Cash").Distinct();
            result = tickers.ToList();
            return result;

        }


        public virtual IEnumerable<string> GetIndexesTickersWithDependencies(DateTime startDate, DateTime endDate)
        {
            return GetTickersPerIndeWithDependencies(startDate, endDate).SelectMany(x => x.Value).Distinct().ToArray();
        }

        public virtual IDictionary<KeyValuePair<ProjectDTO, IndexDTO>, string[]> GetTickersPerIndeWithDependencies(DateTime startDate, DateTime endDate, bool skipIndexes = false)
        {
            var productionScope = indexProvider.LoadContribConfiguration(DateTime.Now, UserService.CaesarSession, "Production");
            var projectDtos = PersistanceService.IndexProvider.ReadAllProjectsWithoutRevisions(UserService.GetBatchSession())
                .GroupBy(x => x.project_name).Select(x => x.First()).ToDictionary(x => x.project_name, x => x);
            var indexDtos = PersistanceService.IndexProvider.ReadAllIndexes(UserService.GetBatchSession()).ToDictionary(x => x.id, x => x);
            var universesByIndexIds =
                skipIndexes
                ?
                indexProvider.GetUniverseTickersForIndexIdsWithoutIndexes(productionScope.Select(x => x.index_id).ToArray(),
                    UserService.CaesarSession)
                :
                indexProvider.GetUniverseTickersForIndexIds(productionScope.Select(x => x.index_id).ToArray(),
                    UserService.CaesarSession);

            return 
                productionScope.ToDictionary(
                    x => new KeyValuePair<ProjectDTO, IndexDTO>(projectDtos[x.project_name], indexDtos[x.index_id]),
                    x => universesByIndexIds[x.index_id]);
        }

        #endregion 

        #region private Method
        private List<string> GetAllTickersInIndex(TimeSerieDB timeSerie)
        {
            var tickers = new List<string>();
            timeSerie.ForEach(x =>
            {
                var value = x.Value as IBasketIndexList;
                if (value != null)
                    value.Baskets.ForEach(b =>
                    {
                        var aggregatedComposition = b.Components.SelectMany(c => c.Value).Select(c => c.BloombergTicker);
                        tickers.AddRange(aggregatedComposition.Where(ticker => !ticker.Contains(MarketDataTree.PathDelimiter)
                                    && !ticker.Contains("|")));
                    });
            });
            return tickers.Distinct().ToList();
        }

        private TimeSerieDB GetBasketFromIndex(string indexId, DateTime paramStartDate, DateTime paramEndDate)
        {
            TimeSerieDB basket;

            if (cache.ContainsKey(indexId))
            {
                var cachedStartDate  = cache[indexId].Item1;
                var cachedEndDate = cache[indexId].Item2;
                if (paramStartDate.CompareTo(cachedStartDate) >= 0  && paramEndDate.CompareTo(cachedEndDate)  <= 0 )
                {
                    basket = GetTimeSerieOnInterval(paramStartDate, paramEndDate, cache[indexId].Item3);
                    return basket;
                }
            }

            basket = dataProvider.GetBaskets(indexId, paramStartDate, paramEndDate);
            if(basket.Count!=0)
                cache[indexId] = new Tuple<DateTime, DateTime, TimeSerieDB>(paramStartDate, paramEndDate, basket);
            return basket;
        }

        private TimeSerieDB GetTimeSerieOnInterval(DateTime paramStartDate, DateTime paramEndDate, TimeSerieDB inputTimeSerie)
        {
            var output = inputTimeSerie.GetPeriod(paramStartDate, paramEndDate);
            return output;
        }

        public void ClearCache()
        {
            cache.Clear();
        }
        #endregion
    }
}
