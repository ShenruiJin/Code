﻿using CaesarApplication.QuoteCalculator;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using FuncFramework.Business;
using log4net;
using System;
using System.Collections.Concurrent;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using System.Threading;

namespace CaesarApplication.NRT
{
    public class NRTEngine
    {
        private int nbThreads = 5;

        private ILog logger = LogManager.GetLogger(typeof(NRTEngine));

        public void LaunchNRT(BatchPricerRunConfig config)
        {
            var startDate = DateTime.Now;
            var dateConfig = config.RunLocal ? null : config.ConfigurationDate;

            var batchConfigurations =
                    PersistanceService.IndexProvider.LoadBatchConfiguration(dateConfig, UserService.CaesarSession,
                            config != null ? config.ConfigName : null).ToArray();

            var nrtFilePath = IndexPricingResultNotifier.GetNRTFileNameForQuotes(config);

            var cmdLines = batchConfigurations.SelectMany(c => RemoteQuoteCalculator.GetNrtCmdLine(config.StartDate.GetValueOrDefault(), config.EndDate, "", (int)IndexPathHelper.GetProjectId(c.path), IndexPathHelper.GetLocalPath(c.path), nrtFilePath, config.ResultDirectory)).ToArray();

            var pricingToDoQueue = new ConcurrentQueue<string>(cmdLines);

            var workers = Enumerable.Range(0, nbThreads).Select(x =>
                new Thread(() =>
                {
                    string cmdLine;

                    while(pricingToDoQueue.TryDequeue(out cmdLine))
                    {
                        try
                        {
                            logger.Info("Start to run : " + cmdLine);

                            var currentDirectory = !string.IsNullOrEmpty(config.NrtExeFileToTest) ? @"c:\work\NRTIndexBatchPricerVersionToTest\current" : Path.GetDirectoryName(Assembly.GetEntryAssembly().Location);

                            new RemoteQuoteCalculator().Price(cmdLine, Path.Combine(currentDirectory, Path.GetFileName(Assembly.GetEntryAssembly().Location)), !string.IsNullOrEmpty(config.NrtExeFileToTest) ? config.NrtExeFileToTest : null, !string.IsNullOrEmpty(config.NrtExeFileToTest));

                            logger.Info("End to run with success : " + cmdLine);
                        } 
                        catch(Exception ex)
                        {
                            logger.Error("End to run with error : " + cmdLine);
                            logger.Error(ex);
                        }
                    }
                })).ToArray();

            workers.ForEach(x => x.Start());
            workers.ForEach(x => x.Join());

            if(!string.IsNullOrEmpty(config.NrtExeFileToTest))
            {
                var binVersion = IndexPricingResultNotifier.GetNRTBinVersion(config);
                var directory = Path.GetDirectoryName(nrtFilePath);

                var filesToAggregate = new DirectoryInfo(directory).GetFileSystemInfos("*.csv").Where(x => x.CreationTime > startDate && x.Name.Contains(binVersion) && x.Name.EndsWith("_Quotes.csv")).ToArray();
                
                File.WriteAllLines(nrtFilePath, filesToAggregate.SelectMany(fName => File.ReadAllLines(fName.FullName)).Where(x => !string.IsNullOrEmpty(x)).ToArray());
            }
        }
    }
}
