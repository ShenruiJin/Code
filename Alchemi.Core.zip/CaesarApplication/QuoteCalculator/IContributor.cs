﻿using System;
using System.Collections.Generic;
using DealIndexDataTransferObject;
using PricingBase.Index;

namespace CaesarApplication.QuoteCalculator
{
    public interface IContributor
    {
        /// <summary>
        /// Contribution logic to Bloomberg
        /// </summary>
        /// <returns></returns>
        ContributionResult Contribute(bool isHistoryMode, string referenceSophis, string sophisName, string bloombergTicker, string drv,
            string bloombergISIN, string indexName, IList<IIndexQuote> quotes, 
            Func<string, bool?> callbackAlert = null, int? keyPublicationDecimalNumber = null, MidpointRounding? keyPublicationRoundingPolicy = null);

        ContributionResult ContributeMultiIndexes(bool isHistoryMode, Dictionary<bool, Dictionary<IndexDTO, IList<IIndexQuote>>> quotesByIndex,
            Func<string, bool?> callbackAlert = null);

    }
}