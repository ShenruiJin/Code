using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using CaesarApplication.Service.Connection;
using DealIndexDataTransferObject;
using FuncFramework.Business;
using GlobalDerivativesApplications.Reporting;
using System.Collections.Generic;
using System.Configuration;

namespace CaesarApplication.QuoteCalculator
{
    public class RemoteQuoteCalculator : IQuoteCalculator
    {
        public event EventHandler<RemoteQuoteCalculatorFinishedEventArgs> OnRemoteQuoteCalculatorFinished;

        private readonly long? projectId;
        private readonly IndexDTO index;
        private Process executeProc;
        private Process logProc;
        private string configurationName;
        private bool isFolder;
        private string[] directoriesToPrice;

        public RemoteQuoteCalculator()
        {
        }

        public RemoteQuoteCalculator(long? projectId, IndexDTO index)
        {
            this.projectId = projectId;
            this.index = index;
        }

        public RemoteQuoteCalculator(string configurationName)
        {
            this.configurationName = configurationName;
        }


        public RemoteQuoteCalculator(long? projectId, string folderName, bool isFolder = false)
        {
            this.projectId = projectId;
            this.configurationName = folderName;
            this.isFolder = isFolder;
        }

        public RemoteQuoteCalculator(string[] directoriesToPrice)
        {
            this.directoriesToPrice = directoriesToPrice;
        }

        public bool Price(DateTime startDate, DateTime endDate, bool forceCalcul = true)
        {
            return Price(startDate, endDate, forceCalcul, true);
        }

        public bool Price(DateTime startDate, DateTime endDate, bool forceCalcul, bool redirectOutput)
        {
            var nbDaysLag = " --nbDaysLag:0";

            var command = GetCommand();

            var isFolder = " --isFolder:" + this.isFolder + " ";

            var nrtCmdLine = Environment.GetCommandLineArgs().Any(arg => arg.ToUpper().Contains("--NRT")) ? @" --resultDirectory:""C:\temp""  --runLocal:true" : string.Empty;

            string[] cmdLines = GetCmdLines(startDate, endDate, nbDaysLag, command, isFolder, nrtCmdLine, forceCalcul);

            var res = InstallLatestBatchPricer() && ExecuteBatch(cmdLines, redirectOutput);

            if (OnRemoteQuoteCalculatorFinished != null)
            {
                OnRemoteQuoteCalculatorFinished(this, new RemoteQuoteCalculatorFinishedEventArgs { Success = res });
            }

            return res;
        }


        public bool Price(string cmdLine, string exePath = null, string nrtVersionToInstall = null, bool setupVersion = true)
        {
            bool res = true;

            if(setupVersion)
            {
                res = (nrtVersionToInstall != null ? InstallNrtBatchPricer(nrtVersionToInstall) : InstallLatestBatchPricer());
            }

            res = res && ExecuteBatch(cmdLine.AsArray(), false, exePath);

            if (OnRemoteQuoteCalculatorFinished != null)
            {
                OnRemoteQuoteCalculatorFinished(this, new RemoteQuoteCalculatorFinishedEventArgs { Success = res });
            }

            return res;
        }

        public static string[] GetNrtCmdLine(DateTime startDate, DateTime? endDate, string command, int projectId, string indexToPrice, string nrtFilePath, string resultDirectory)
        {
            var end = endDate.HasValue ? string.Format(" --endDate:{0} ", endDate.GetValueOrDefault().ToString("ddMMyyyy", CultureInfo.InvariantCulture)) : " ";
            var start = string.Format(" --startDate:{0} ", startDate.ToString("ddMMyyyy", CultureInfo.InvariantCulture));
            var nrtCmdLine = string.Format(" --runLocal:true --nrtFilePath:{0} ", nrtFilePath);
            var isFolder = " --isFolder:true ";
            var directoriesToPrice = " --indexToPrice:\"" + string.Join(",", indexToPrice.AsArray().Select(NormalizeIndexName)) + "\" ";

            var projectIdStr = string.Format(" --projectId:{0} ", projectId);
            var resultDirectoryStr = string.Format(" --resultDirectory:\"{0}\" ", resultDirectory);


            return (command + " " + ConnectionService.DealServicesCommandLineArguments + " " + start + end + isFolder + nrtCmdLine + projectIdStr + directoriesToPrice + resultDirectoryStr).AsArray();
        }

        private string[] GetCmdLines(DateTime startDate, DateTime endDate, string nbDaysLag, string command, string isFolder, string nrtCmdLine, bool forceCalcul)
        {
            if (NbDaysPricingPeriod.HasValue && (endDate - startDate).TotalDays > NbDaysPricingPeriod.GetValueOrDefault())
            {
                var result = new List<string>();

                DateTime currentDate = startDate;

                while (currentDate.AddDays(NbDaysPricingPeriod.GetValueOrDefault()) <= endDate)
                {
                    var end = string.Format(" --endDate:{0}", (currentDate.AddDays(NbDaysPricingPeriod.GetValueOrDefault()) < endDate ? currentDate.AddDays(NbDaysPricingPeriod.GetValueOrDefault()) : endDate).ToString("ddMMyyyy", CultureInfo.InvariantCulture));
                    var start = forceCalcul ? string.Format(" --startDate:{0}", currentDate.ToString("ddMMyyyy", CultureInfo.InvariantCulture))
                        : string.Empty;

                    currentDate = currentDate.AddDays(NbDaysPricingPeriod.GetValueOrDefault());

                    result.Add(ConnectionService.DealServicesCommandLineArguments + " " + command + start + end + nbDaysLag + isFolder + nrtCmdLine);
                }

                return result.ToArray();
            }
            else
            {
                var end = string.Format(" --endDate:{0}", endDate.ToString("ddMMyyyy", CultureInfo.InvariantCulture));
                var start = forceCalcul ? string.Format(" --startDate:{0}", startDate.ToString("ddMMyyyy", CultureInfo.InvariantCulture))
                    : string.Empty;

                return (ConnectionService.DealServicesCommandLineArguments + " " + command + start + end + nbDaysLag + isFolder + nrtCmdLine).AsArray();
            }
        }


        private string GetCommand()
        {
            if (directoriesToPrice != null)
            {
                return "--directoriesToPrice:\"" + string.Join(",", directoriesToPrice.Select(NormalizeIndexName)) + "\"";
            }

            return projectId.HasValue ?
                string.Format("--projectId:{0} --indexToPrice:\"{1}\"",
                    projectId.GetValueOrDefault(), this.isFolder ? configurationName : NormalizeIndexName(index.ticker))
                : string.Format("--configName:\"{0}\"", configurationName);
        }

        private static string NormalizeIndexName(string ticker)
        {
            return ticker.Replace(StrategyTree.PathDelimiter.ToString(), "->");
        }

        public string message { get; set; }

        public Process ExecuteProc
        {
            get { return executeProc; }
        }

        private bool ExecuteBatch(string[] cmdLines, bool redirectOutput = true, string exePath = null)
        {
            foreach (var cmdLine in cmdLines)
            {
                var procStartInfos = new ProcessStartInfo
                {
                    WorkingDirectory = ConfigurationManager.AppSettings["BatchPricerPath"] != null ? Path.GetDirectoryName(ConfigurationManager.AppSettings["BatchPricerPath"]) : Path.GetDirectoryName(exePath ?? @"C:\work\IndexBatchPricer\Current"),
                    Arguments = cmdLine,
                    FileName = ConfigurationManager.AppSettings["BatchPricerPath"] != null ? ConfigurationManager.AppSettings["BatchPricerPath"] : exePath ?? "C:\\work\\IndexBatchPricer\\Current\\BatchPriceIndexes.exe",
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden,
                    UseShellExecute = false,
                };
                if (redirectOutput)
                {
                    procStartInfos.RedirectStandardError = true;
                    procStartInfos.RedirectStandardOutput = true;
                    procStartInfos.StandardOutputEncoding = Encoding.UTF8;
                }

                executeProc = Process.Start(procStartInfos);
                
                if (false && File.Exists(@"K:\ED_ExcelTools\Admin\baretail.exe"))
                {
                    Thread.Sleep(2000);


                    try
                    {
                        logProc = Process.Start(new ProcessStartInfo
                        {
                            WorkingDirectory = @"C:\work\IndexBatchPricer\Current\Log",
                            Arguments = @"Caesar.log",
                            FileName = @"K:\ED_ExcelTools\Admin\baretail.exe"
                        });
                    }
                    catch { }
                }


                try
                {
                    if (!executeProc.WaitForExit((int)TimeSpan.FromMinutes(120).TotalMilliseconds) || new[] { 0, 1, -1 }.DoesNotContain(executeProc.ExitCode))
                    {
                        message = !executeProc.HasExited || executeProc.ExitCode != 0
                            ? string.Format("Calculation has failed with code : {0}", executeProc.ExitCode)
                            : "Calculation has timeout";
                        return false;
                    }

                    if (executeProc.ExitCode == -1)
                    {
                        message = "Process has been stopped";
                        return true;
                    }

                }
                finally
                {
                    if (logProc != null && !logProc.HasExited)
                    {
                        try
                        {
                            logProc.Kill();
                        }
                        catch { }
                    }
                }
            }

            return true;
        }

        private object lockSetup = new object();

        private bool InstallNrtBatchPricer(string version)
        {
            lock (lockSetup)
            {
                var procStartInfos = new ProcessStartInfo
                {
                    FileName = @"K:\ED_ExcelTools\Application\Caesar\IndexBatchPricer\Env-VersionNRT\install.bat",
                    CreateNoWindow = true,
                    Arguments = version,
                    WindowStyle = ProcessWindowStyle.Hidden
                };

                var installProc = Process.Start(procStartInfos);

                if (!installProc.WaitForExit((int)TimeSpan.FromSeconds(60).TotalMilliseconds) || installProc.ExitCode != 0)
                {
                    message = "Failed to install NRT batchpricer install";
                    return false;
                }

                return true;
            }
        }

        private bool InstallLatestBatchPricer()
        {
            lock (lockSetup)
            {
                var procStartInfos = new ProcessStartInfo
                {
                    FileName = @"K:\ED_ExcelTools\Application\Caesar\IndexBatchPricer\Production\install.bat",
                    CreateNoWindow = true,
                    WindowStyle = ProcessWindowStyle.Hidden
                };

                var installProc = Process.Start(procStartInfos);

                if (!installProc.WaitForExit((int)TimeSpan.FromSeconds(60).TotalMilliseconds) || installProc.ExitCode != 0)
                {
                    message = "Failed to install latest batchpricer install";
                    return false;
                }

                return true;
            }
        }

        public void Cancel()
        {
            if (executeProc != null && !executeProc.HasExited)
            {
                executeProc.Kill();
            }
        }

        public int? NbDaysPricingPeriod
        {
            get; set;
        }
    }

    public class RemoteQuoteCalculatorFinishedEventArgs : EventArgs
    {
        public bool Success
        {
            get; set;
        }
    }
}