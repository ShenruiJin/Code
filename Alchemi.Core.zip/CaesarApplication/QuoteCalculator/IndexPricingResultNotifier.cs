﻿using CaesarApplication.Service.Logging;
using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using GlobalDerivativesApplications;
using Pricing.Engine;
using Pricing.Engine.Indices;
using PricingBase.Index;
using ScriptTools.Converters;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Strategy;
using FuncFramework.Business;
using MarketDataMgr.Trees;
using PricingBase.DataProvider;
using System.Diagnostics;
using System.Reflection;
using System.IO;
using Caesar.Pricing.Engine.Indices;
using CaesarApplication.Service.Validation;
using CaesarApplication.TestsEngine;
using CaesarApplication.Utilities;
using FuncFramework.Configuration;
using MarketDataMgr.Trees.Ext;
using PricingBase.Product.CsInfoContainer;
using OverloadedMarketDataTree = FuncFramework.Business.OverloadedMarketDataTree;

namespace CaesarApplication.QuoteCalculator
{
    public class IndexPricingResultNotifier
    {
        public StringBuilder msg = new StringBuilder();
        public StringBuilder runLocalQuoteReport = new StringBuilder();
        public StringBuilder runLocalMetadataReport = new StringBuilder();
        private DateTime endDate;
        private DateTime startDate;
        public const string PricingErrorStatus = "KO";
        public const string PricingSucessStatus = "OK";

        private IndexPricingResultNotifierHelper indexPricingResultNotifierHelper =
            new IndexPricingResultNotifierHelper();

        private readonly IndexDependencyManager indexDependencyManager = new IndexDependencyManager(new IndexDBProviderFactory());

        /// <summary>
        /// Map quotes to indexes
        /// </summary>
        private IDictionary<IndexDTO, IList<IIndexQuote>> quotesMapping = new Dictionary<IndexDTO, IList<IIndexQuote>>();

        private List<QuoteCalculator> quoteCalculators = new List<QuoteCalculator>();

        public void SendResultMail(BatchPricerRunConfig config)
        {
            var emailAddress = System.Configuration.ConfigurationManager.AppSettings["SenderEmailAddress"] ??
                               "eda25-desk-quant-applications@natixis.com";
            //"LD-M-CLIQ-USERS",

            SendMail(config, emailAddress,
                System.Configuration.ConfigurationManager.AppSettings["ReportMailingList"].Split(';'));

            List<string> unknown;

            var addresses =
                Tools.System.LdapGetMailAddress(Environment.UserName.AsArray(), Environment.UserDomainName, out unknown)
                    .ToArray();

            if (addresses.Any())
            {
                SendMail(config, emailAddress, addresses.Select(a => a.Address).ToArray());
            }
        }

        private void SendMail(BatchPricerRunConfig config, string emailAddress, string[] dests)
        {
            Tools.System.SendEmailEWS(emailAddress,
                dests,
                //new string[] { "valery.louis-ext@natixis.com"/*, "clement.zunino-ext@natixis.com"*/ },
                config.MailPrefix + "[CaesarBatchIndexPricing] Caesar Indexes Pricing Result",
                "Please find the result of the pricing : " + (IsSuccess ? "fully succesfull." : "contains failure(s).")
                + Environment.NewLine
                + Environment.NewLine
                + msg.Replace(StrategyTree.PathDelimiter.ToString(), "->") + Environment.NewLine,
                impersonatedAddress: emailAddress, userName: "nt_eqd_sos", password: "Ba13h,7j");
        }

        public static string GetNRTBinVersion(BatchPricerRunConfig config)
        {
            return !string.IsNullOrEmpty(config.NrtExeFileToTest) ? config.NrtExeFileToTest : FileVersionInfo.GetVersionInfo(Assembly.GetEntryAssembly().Location).ProductVersion.ToString();
        }

        public static string GetNRTFileNamePrefix(BatchPricerRunConfig config)
        {
            var binVersion = GetNRTBinVersion(config);
            var dateConfig = config == null || config.ConfigurationDate == null
                ? DateTime.Today
                : config.ConfigurationDate.GetValueOrDefault();


            return string.Format("BatchPricer_{0}_{1}_{2}_{3}", binVersion, dateConfig.ToString("ddMMyy"),
                config.ConfigName ?? "Default", DateTime.Now.ToString("ddMMyyHHmmss"));
        }

        public static string GetNRTFileNamePrefix(string binVersion, string dateConfig, string configName)
        {
            return string.Format("BatchPricer_{0}_{1}_{2}_{3}", binVersion, dateConfig,
                configName, DateTime.Now.ToString("ddMMyyHHmmss"));
        }


        public static string GetNRTDirectoryPath(BatchPricerRunConfig config)
        {
            return config.ResultDirectory ?? Environment.GetEnvironmentVariable("TEMP");
        }

        public static string GetNRTFileNameForQuotes(BatchPricerRunConfig config)
        {
            return string.Format(@"{0}\{1}_Quotes.csv", GetNRTDirectoryPath(config), GetNRTFileNamePrefix(config));
        }

        public static string GetNRTFileNameForMetadata(BatchPricerRunConfig config)
        {
            return string.Format(@"{0}\{1}_Metadata.csv", GetNRTDirectoryPath(config), GetNRTFileNamePrefix(config));
        }

        public static string GetNRTFileNameForResults(BatchPricerRunConfig config)
        {
            return string.Format(@"{0}\{1}_Results.csv", GetNRTDirectoryPath(config), GetNRTFileNamePrefix(config));
        }

        public void WriteRunLocalInfo(BatchPricerRunConfig config)
        {
            using (StreamWriter file = new StreamWriter(File.Open(config.NrtFilePath ?? GetNRTFileNameForQuotes(config), FileMode.Append, FileAccess.Write)))
            {
                file.WriteLine(runLocalQuoteReport.Replace(StrategyTree.PathDelimiter.ToString(), "->"));
            }

            using (StreamWriter file = new StreamWriter(GetNRTFileNameForMetadata(config)))
            {
                file.WriteLine(runLocalMetadataReport.Replace(StrategyTree.PathDelimiter.ToString(), "->"));
            }
            using (StreamWriter file = new StreamWriter(GetNRTFileNameForResults(config)))
            {
                file.WriteLine(msg.Replace(StrategyTree.PathDelimiter.ToString(), "->"));
            }

        }

        public static void SendErrorStatusMail(string exception)
        {
            var emailAddress = System.Configuration.ConfigurationManager.AppSettings["SenderEmailAddress"] ??
                               "eda25-desk-quant-applications@natixis.com";

            Tools.System.SendEmailEWS(emailAddress,
                System.Configuration.ConfigurationManager.AppSettings["ReportMailingList"].Split(';'),
                "[CaesarBatchIndexPricing] Batch Ended with error",
                "Error while pricing :"
                + Environment.NewLine
                + Environment.NewLine
                + exception.Replace(StrategyTree.PathDelimiter.ToString(), "->"),
                impersonatedAddress: emailAddress, userName: "nt_eqd_sos", password: "Ba13h,7j");
        }

        public void LaunchPricing(BatchPricerRunConfig runconfig)
        {
            MarketDataService.CurrentMarketDataTree = new MarketDataTree();
            var dateConfig = runconfig.RunLocal ? null : runconfig.ConfigurationDate;
            PriceIndexItem[] batchConfigurations;

            if (!string.IsNullOrEmpty(runconfig.FolderToPrice))
            {
                batchConfigurations = new[]
                {
                    new PriceIndexItem(runconfig.FolderToPrice, runconfig.ProjectId.GetValueOrDefault())
                    {
                        ProjectName = IndexPathHelper.GetProjectName(runconfig.FolderToPrice)
                    }
                };
            }
            else if (!string.IsNullOrEmpty(runconfig.DirectoriesToPrice))
            {
                var projects = PersistanceService.IndexProvider.ReadAllProjects(UserService.GetBatchSession());

                batchConfigurations = runconfig.DirectoriesToPrice.Split(',', ';')
                    .Select(
                        x =>
                        {
                            var projectName = IndexPathHelper.GetProjectName(x);

                            return new PriceIndexItem(IndexPathHelper.GetLocalPath(x),
                                    projects.First(p =>
                                    {

                                        return p.project_name == projectName;
                                    }).id)
                                {ProjectName = IndexPathHelper.GetLocalPath(x)};
                        }).ToArray();
            }
            else if (!IsMonoIndexCalculation(runconfig))
            {
                batchConfigurations =
                    PersistanceService.IndexProvider.LoadBatchConfiguration(dateConfig, UserService.CaesarSession,
                            runconfig != null ? runconfig.ConfigName : null)
                        .Select(x => new PriceIndexItem(x.path, x.rank)).OrderBy(x => x.PricingRank).ToArray();
            }
            else
            {
                batchConfigurations = null;
            }

            LaunchPricing(runconfig, batchConfigurations);
        }

        private static bool IsMonoIndexCalculation(BatchPricerRunConfig runconfig)
        {
            return !string.IsNullOrEmpty(runconfig.IndexToPrice) && string.IsNullOrEmpty(runconfig.FolderToPrice) &&
                   string.IsNullOrEmpty(runconfig.DirectoriesToPrice);
        }

        private void FilterBookingAndReportingElements(QuoteCalculator quoteCalculator, bool skipBooking,
            bool skipReporting)
        {
            quoteCalculator.IndexDtos.RemoveWhere(kvp => !kvp.Value.ticker.ToLower().Contains("index"));
            quoteCalculator.Elements = quoteCalculator.Elements.Where(x => x.Configuration is IndexPricingConfiguration
                                                                           &&
                                                                           (
                                                                               new[] {"index"}.Any(
                                                                                   v =>
                                                                                       ((IndexPricingConfiguration)
                                                                                               x.Configuration).Path
                                                                                           .ToLower
                                                                                           ().Contains(v))
                                                                           )
            ).ToArray();
        }

        public void LaunchPricing(BatchPricerRunConfig config, IList<IPriceIndexItem> items,
            bool isEnableContribution = false)
        {
            var runLocal = config.RunLocal;

            if (IsMonoIndexCalculation(config))
            {
                items = new IPriceIndexItem[]
                {
                    new PriceIndexItem(config.IndexToPrice, (long) config.ProjectId.GetValueOrDefault())
                };
            }
            else if (items.Count == 0)
            {
                msg.AppendLine("No index to price today.");
                msg.AppendLine("Please check configuration.");
            }
            items.ForEach(i => i.Status = string.Empty);

            Stopwatch stopWatch = new Stopwatch();
            stopWatch.Reset();
            stopWatch.Start();

            msg.AppendFormat("Configuration {0} run by {1} on {2}" + Environment.NewLine, config.ConfigName ?? "Default",
                Environment.UserName, Environment.MachineName);
            runLocalMetadataReport.AppendLine(string.Format("Index;Time (s);Mean Time (s);Max Memory"));

            foreach (var item in items.OrderBy(o => o.PricingRank))
            {
                if (runLocal)
                {
                    MarketDataService.CurrentMarketDataTree = new MarketDataTree();
                }

                string pricingMessage = string.Empty;
                try
                {
                    QuoteCalculator quoteCalculator =
                        IsMonoIndexCalculation(config)
                            ? new QuoteCalculator(config.ProjectId.GetValueOrDefault(), config.IndexToPrice, runLocal, config.SaveOnlyCalculated, UserService.GetBatchSession())
                            : new QuoteCalculator(
                                new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree,
                                    dataHandlersToUse: config.DataHandlers), item.ProjectId, item.ProjectName, item.Name,
                                runLocal, config.SaveOnlyCalculated, UserService.GetBatchSession());
                    msg.AppendLine("");
                    msg.AppendLine("-------------- ");
                    msg.AppendLine("Project : " +
                                   (quoteCalculator.ProjectDto != null &&
                                    quoteCalculator.ProjectDto.project_name != null
                                       ? quoteCalculator.ProjectDto.project_name
                                       : (item.ProjectName + "(Repo)")));
                    msg.AppendLine("");

                    if (quoteCalculator.ProjectDto != null && item.ProjectName != null)
                    {
                        LoggingService.InfoFormatted(GetType(), "[{0}]Start pricing",
                            IndexPathHelper.Combine(quoteCalculator.ProjectDto.project_name, item.ProjectName));
                    }

                    if (!quoteCalculator.IndexDtos.Any())
                    {
                        msg.AppendLine(string.Format("{0}: ERROR", item.Ticker));
                        msg.AppendLine(string.Format("Cannot retrieve index {0} from DB.", item.Ticker));
                        LoggingService.Info(this.GetType(),
                            string.Format("[{0}]Error during index quote calculation", item.Ticker));
                        item.Status = "Cannot Retrieve Index";
                        continue;
                    }

                    if (runLocal || config.SkipBooking || config.SkipReporting)
                        FilterBookingAndReportingElements(quoteCalculator, config.SkipBooking, config.SkipReporting);


                    var indexDtos = quoteCalculator.IndexDtos.Values.ToArray();

                    DefineCalculationDates(item.ProjectId, config, indexDtos);

                    var ticker = item.Name;
                    LoggingService.Info(GetType(),
                        string.Format("[{0}]Starting index quote calculation [{1}-{2}]", ticker, startDate, endDate));

                    if (indexDtos.Any() && startDate <= endDate)
                    {
                        int maxQuotestoShow = 1000;

                        if (quoteCalculator.Elements.Any() && quoteCalculator.Price(startDate, endDate))
                        {
                            pricingMessage = quoteCalculator.pricingResult;
                            quoteCalculators.Add(quoteCalculator);

                            foreach (
                                var resultKeyVal in
                                (quoteCalculator.result is IndexStrategyPricingResult
                                    ? ((IndexStrategyPricingResult) quoteCalculator.result).Results.ToArray()
                                    : new KeyValuePair<string, IndexPricingResult>(ticker,
                                        ((IndexPricingResult) quoteCalculator.result)).AsArray()))
                            {
                                var result = resultKeyVal.Value;
                                item.Ticker = resultKeyVal.Key;
                                var quotes = result[ResultString.Data] as IList<IIndexQuote> ?? new List<IIndexQuote>();

                                int nbQuotes = quotes.Count;
                                msg.AppendLine();
                                msg.AppendLine(string.Format("{0}  -  {1} quotation day{2} from {3} to {4}. ",
                                    item.Ticker,
                                    nbQuotes, nbQuotes < 1 ? string.Empty : "s",
                                    startDate.ToShortDateString(), endDate.ToShortDateString()));

                                if (nbQuotes > maxQuotestoShow)
                                {
                                    msg.AppendLine("...");
                                    msg.AppendLine(maxQuotestoShow +
                                                   " last quotes showed. See more quotes in CliqIndexes.");
                                    msg.AppendLine("...");
                                }
                                quotes.Skip(Math.Max(0, quotes.Count - maxQuotestoShow))
                                    .ForEach(
                                        q =>
                                            msg.AppendLine(string.Format("{0} : {1}, {2}",
                                                q.Date.ToShortDateString(), ((IIndexQuoteTechnical) q).ValueWithoutTest,
                                                q.Comment ?? "")));

                                LoggingService.Info(GetType(),
                                    string.Format("[{0}]Ending index quote calculation", ticker));
                                //if (item.ToContribute  && isEnableContribution)
                                //    Contribute(quotes, quoteCalculator.IndexDtos[resultKeyVal.Key]);

                                if (quoteCalculator.HasPricingError)
                                {
                                    item.Status = PricingErrorStatus;
                                }
                                else
                                {
                                    item.Status = PricingSucessStatus;

                                    SaveIndexDependencies(quoteCalculator, resultKeyVal);
                                }

                                var currentIndex = indexDtos.First(o => o.ticker == resultKeyVal.Value.Description);
                                if (item.Status == PricingSucessStatus)
                                {
                                    if (quotesMapping.ContainsKey(currentIndex))
                                    {
                                        quotesMapping[currentIndex].AddRange(quotes);
                                    }
                                    else
                                    {
                                        quotesMapping[currentIndex] = quotes;
                                    }
                                }

                                if (result.Last != null)
                                {
                                    item.Quote =
                                        ((IIndexQuoteTechnical) result.Last).ValueWithoutTest.ToString(
                                            CultureInfo.InvariantCulture);
                                    item.QuotationDate = result.Last.Date.ToShortDateString();
                                }
                                else
                                {
                                    item.Quote = "N/A";
                                    item.QuotationDate = "N/A";
                                }

                                if (runLocal)
                                {
                                    FillRunLocalReport(resultKeyVal.Key, quotes, stopWatch.ElapsedMilliseconds/1000,
                                        Process.GetCurrentProcess().PrivateMemorySize64);
                                }
                            }
                        }
                        else
                        {
                            item.Status = PricingErrorStatus;
                            item.Quote = "N/A";
                            item.QuotationDate = "N/A";
                            msg.AppendLine("Fail to calculate because :" + quoteCalculator.message);
                        }
                    }
                    else
                    {
                        msg.AppendLine("No days to calculate.");

                        LoggingService.Info(GetType(),
                            string.Format("[{0}]Ending index quote calculation, no more days to calculate", ticker));
                        item.Status = "No days to calculate";
                    }


                    if (quoteCalculator.ProjectDto != null && item.ProjectName != null)
                    {
                        LoggingService.InfoFormatted(GetType(), "[{0}]End pricing with status : {1}",
                            IndexPathHelper.Combine(quoteCalculator.ProjectDto.project_name, item.ProjectName),
                            item.Status);
                    }
                }
                catch (Exception ex)
                {
                    LoggingService.Error(GetType(), string.Format("Error during {0} index quote calculation", item.Name),
                        ex);
                    msg.AppendLine(string.Format("{0} :  {1}. ", item.Ticker, PricingErrorStatus));
                    msg.AppendLine(pricingMessage);
                    item.Status = PricingErrorStatus;
                }
            }
            stopWatch.Stop();
            LoggingService.Info(GetType(), string.Format("Processed in {0} ms", stopWatch.ElapsedMilliseconds));
            IsSuccess = items.All(x => x.Status == PricingSucessStatus || x.Status == "No days to calculate");

            AutomaticContribution(quotesMapping, IsSuccess);

            RunValidationTests(config.RunLocal);
        }

        private void RunValidationTests(bool runLocal)
        {
            if (runLocal)
             return;

                LoggingService.Info(GetType(), "Start compute tests");
            var indexTestEngine = new IndexTestEngine();

            try
            {
                foreach (var quoteCalculator in quoteCalculators)
                {
                    try
                    {
                        var allResults = new List<DealIndexDataTransferObject.TestsEngine.IndexTestResult>();
                        LoggingService.Info(GetType(), "Start compute tests for " + quoteCalculator.result.Description);

                        for (int i = 0; i < quoteCalculator.BasketIndexList.Count; i++)
                        {
                            var basketIndexListKv = quoteCalculator.BasketIndexList.ElementAt(i);
                            var index = quoteCalculator.IndexDtos.Values.First(x => x.ticker == basketIndexListKv.Key);

                            LoggingService.Info(GetType(), "Start compute tests for " + quoteCalculator.result.Description + "/" + index.ticker);

                            foreach (var basketIndexList in basketIndexListKv.Value)
                            {
                                var testResults = indexTestEngine.ExecuteAllTestsForBaskets(index.id, basketIndexList);

                                allResults.AddRange(testResults);
                            }

                            LoggingService.Info(GetType(), "End compute tests for " + quoteCalculator.result.Description + "/" + index.ticker);
                        }

                        if (!runLocal)
                        {
                            PersistanceService.IndexProvider.SaveIndexTestResults(allResults.ToArray(), UserService.CaesarSession);
                        }

                        LoggingService.Info(GetType(), "End compute tests for " + quoteCalculator.result.Description);
                    }
                    catch (Exception innerEx)
                    {
                        LoggingService.Error(GetType(), string.Format("Fail to compute automatic tests for {0}", quoteCalculator.result.Description), innerEx);
                    }
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Fail to compute automatic tests", ex);
            }

            LoggingService.Info(GetType(), "End compute tests");
        }

        private void SaveIndexDependencies(QuoteCalculator quoteCalculator, KeyValuePair<string, IndexPricingResult> resultKeyVal)
        {
            SaveBasketIndexDependencies(quoteCalculator, resultKeyVal);
            SaveQuoteIndexDependencies(quoteCalculator, resultKeyVal);
        }

        private void SaveBasketIndexDependencies(QuoteCalculator quoteCalculator, KeyValuePair<string, IndexPricingResult> resultKeyVal)
        {
            try
            {
                var indexBasketDependencies =
                    indexDependencyManager.GetIndexBasketDependencies(
                        quoteCalculator.ProjectDto,
                        quoteCalculator.IndexDtos.Values.First(i => i.ticker == resultKeyVal.Value.Description),
                        resultKeyVal.Value.GetBaskets());

                PersistanceService.IndexProvider.SaveIndexDependencies(indexBasketDependencies, UserService.CaesarSession);
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Can't save baskets validation alerts for " + resultKeyVal.Value.Description, ex);
            }
        }

        private void SaveQuoteIndexDependencies(QuoteCalculator quoteCalculator, KeyValuePair<string, IndexPricingResult> resultKeyVal)
        {
            try
            {
                var indexDependencies =
                    indexDependencyManager.GetIndexQuoteDependencies(
                        quoteCalculator.ProjectDto,
                        quoteCalculator.IndexDtos.Values.First(i => i.ticker == resultKeyVal.Value.Description),
                        resultKeyVal.Value.GetBaskets());

                PersistanceService.IndexProvider.SaveIndexDependencies(indexDependencies, UserService.CaesarSession);
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Can't save quotes validation alerts for " + resultKeyVal.Value.Description, ex);
            }
        }


        /// <summary>
        /// Manage contribution for indexes setted to automatic contribution type
        /// </summary>
        /// <param name="quoteResults"></param>
        /// <param name="isSuccess"></param>
        public ContributionResult AutomaticContribution(IDictionary<IndexDTO, IList<IIndexQuote>> quoteResults, bool isSuccess)
        {
            // Automatic contribution
            if (isSuccess && quoteResults.Any(o => o.Key.contribution_type_id.type == "Automatic"))
            {
                try
                {
                    Contributor contributor = new Contributor();
                    var quotesToContribute = quoteResults.Where(o => o.Key.contribution_type_id.type == "Automatic").ToDictionary(o => o.Key, o => o.Value);
                    var contributionResult = contributor.ContributeMultiIndexes(false, new Dictionary<bool, Dictionary<IndexDTO, IList<IIndexQuote>>> { { true, quotesToContribute } });

                    if (!contributionResult.NoError)
                    {
                        Console.WriteLine("Error during contribution, please see the message below.");
                    }
                    Console.WriteLine(contributionResult.Message);

                    return contributionResult;
                }
                catch (Exception ex)
                {
                    LoggingService.Error(GetType(), "Error during contribution, please see the message below.", ex);
                    msg.AppendLine("Error during contribution, please see the message below.");
                }
            }

            return null;
        }

        private void DefineCalculationDates(long projectId, BatchPricerRunConfig config, IndexDTO[] indexDtos)
        {
            if (config.StartDate.HasValue)
            {
                startDate = config.StartDate.GetValueOrDefault();
                endDate = indexPricingResultNotifierHelper.GetCalculationEndDate(config, config.NbDaysLag);
            }
            else
            {
                endDate = indexPricingResultNotifierHelper.GetCalculationEndDate(config, config.NbDaysLag);
                startDate = indexPricingResultNotifierHelper.RefreshPricerStartDate(projectId, indexDtos, config, endDate);
            }
        }

        private void FillRunLocalReport(string indexName, IList<IIndexQuote> quotes, long calculationTime, long maxMemory)
        {
            quotes.ForEach(q => runLocalQuoteReport.AppendLine(string.Format("{0};{1};{2};{3}", indexName, q.Date.ToShortDateString(), ((IIndexQuoteTechnical)q).ValueWithoutTest, q.Comment ?? "")));

            var meanTime = !quotes.Any() ? 0 : (calculationTime / quotes.Count);
            runLocalMetadataReport.AppendLine(string.Format("{0};{1};{2};{3}", indexName, calculationTime, meanTime, maxMemory));
        }

        public bool IsSuccess { get; private set; }


        private void Contribute(IList<IIndexQuote> quotes, IndexDTO index)
        {
            Contributor contributor = new Contributor();

            LoggingService.Info(this.GetType(), "Starting contribution");
            try
            {
                var contribResult = contributor.Contribute(false, index.sophis_reference, index.sophis_name, index.bloomberg_ticker, index.drv, index.ISIN, index.index_name, quotes, keyPublicationDecimalNumber: index.publication_decimal_number, keyPublicationRoundingPolicy:index.publication_rounding_policy);
                if (contribResult.NoError)
                {
                    LoggingService.Info(GetType(), contribResult.Message);
                    SaveToLocalDatabase(index, quotes);
                }
                else
                {
                    LoggingService.Info(GetType(), contribResult.Message);
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Error during contribution", ex);
            }
        }
        private void SaveToLocalDatabase(IndexDTO index, IList<IIndexQuote> indexQuoteModel)
        {
            LoggingService.Info(GetType(), "Starting save index quotations to local database");
            try
            {
                IndexQuoteConverter converter = new IndexQuoteConverter();

                IList<IndexQuoteDTO> quotes = indexQuoteModel.Select(o => converter.ToDTO(index, o, DateTime.Today)).ToList();
                // Save quote to local database - QuoteGlobalDTO
                IEnumerable<IndexQuoteDTO> contributedQuotes = PersistanceService.IndexProvider.SaveContributedQuotes(quotes, PersistanceService.CaesarSession);

                if (contributedQuotes != null && contributedQuotes.Count() != 0)
                {
                    LoggingService.Info(GetType(), "Index quotations saved with success to the local database");
                }
                else
                {
                    LoggingService.Info(GetType(), "Index quotations save to local database failed");
                }
            }
            catch (Exception ex)
            {
                LoggingService.Error(GetType(), "Error during index quotations save to local database", ex);
            }
        }
    }
}
