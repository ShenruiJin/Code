﻿using DealIndexDataTransferObject;
using DealServerInterface;
using FuncFramework.Business;
using FuncFramework.Configuration;
using Pricing.Engine;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Caesar.Pricing.Engine.Indices;
using Caesar.Pricing.MarketData.Exceptions;
using CaesarApplication.Service.Configuration;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using DealBusinessObject.IDescription;
using FuncFramework.Exceptions;
using Pricing.Engine.Indices;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.QuoteCalculator
{
    /// <summary>
    /// Manage Caesar pricer
    /// </summary>
    public class QuoteCalculator : IQuoteCalculator
    {
        private readonly bool saveAtTheEnd;
        private readonly bool saveOnlyCalculated;
        private readonly ICaesarSession session;
        //private readonly ITimeSeriesProvider timeSeriesProvider; -- never used

        /// <summary>
        /// Caesar strategy sequence elements - in our case indexes
        /// </summary>
        StrategyDataSetElement[] elements;

        /// <summary>
        /// Message returned at the end of a pricing
        /// </summary>
        public string message { get; set; }


        public string pricingResult = string.Empty;
        /// <summary>
        /// Result of the pricing
        /// </summary>
        public IResult result;

        private Dictionary<string, IndexDTO> indexDtos;
        private ProjectDTO projectDto;
        private IndexDTO[] projectIndexes;
        private bool hasPricingError;

        /// <summary>
        /// Constructor
        /// Take the current IndexDTO and convert it to a StrategyDataSetElement
        /// Initialize needed parameters by the pricing engine
        /// </summary>
        public QuoteCalculator(ITimeSeriesProvider timeSeriesProvider, long? projectId, string configToPrice, string indexName, bool saveAtTheEnd = false, bool saveOnlyCalculated = false, ICaesarSession session = null)
        {
            this.saveAtTheEnd = saveAtTheEnd;
            this.saveOnlyCalculated = saveOnlyCalculated;
            this.session = session;
            try
            {
                IndexPricingInstruction indexPricingInstruction = null;

                if (projectId.HasValue && configToPrice != null)
                {
                    indexPricingInstruction = timeSeriesProvider.GetInstructionFromFullPath(projectId, configToPrice);

                    if (indexPricingInstruction == null)
                    {
                        var errorMsg = string.Format("Please define an execution plan for the folder {0}", configToPrice.Replace(StrategyTree.PathDelimiter.ToString(), "->"));
                        Service.Logging.LoggingService.Error(GetType(), errorMsg);
                        throw new ArgumentException(errorMsg);
                    }
                }

                indexPricingInstruction = indexPricingInstruction ?? new IndexPricingInstruction(string.Format("{0}.{1}", configToPrice, indexName), indexName.AsArray());

                if (!PricingService.LoadIndexDtoFromPath(projectId.GetValueOrDefault(), indexPricingInstruction, out projectDto, out indexDtos))
                {
                    throw new ArgumentException(string.Format("Can't load DTO for {0}/{1}", projectId, configToPrice));
                }

                projectIndexes = projectDto.indexes.ToArray();

                var dealDescription = LoadDealDescription(projectDto.project_name);
                elements = PricingService.LoadStrategyDataSetElementsFromInstruction(dealDescription, projectDto.project_name, indexPricingInstruction, indexDtos, session);
            }
            catch (Exception ex)
            {
                Service.Logging.LoggingService.Error(GetType(), "Error during pricing engine initialization", ex);
                throw ex;
            }
        }




        /// <summary>
        /// Constructor
        /// Take the current IndexDTO and convert it to a StrategyDataSetElement
        /// Initialize needed parameters by the pricing engine
        /// </summary>
        public QuoteCalculator(long projectId, string indexName, bool saveAtTheEnd = false, bool saveOnlyCalculated = false, ICaesarSession session = null)
        {
            this.saveAtTheEnd = saveAtTheEnd;
            this.saveOnlyCalculated = saveOnlyCalculated;
            this.session = session;
            try
            {
                IndexPricingInstruction indexPricingInstruction = null;

                projectDto = PersistanceService.IndexProvider.ReadProject(projectId, UserService.CaesarSession);

                var indexDTO = projectDto.indexes.First(x => x.ticker == indexName);
                projectIndexes = indexDTO.AsArray();
                indexDtos = indexDTO.AsArray().ToDictionary(k => k.ticker, v => v);

                var dealDescription = LoadDealDescription(projectDto.project_name);

                elements = PricingService.LoadStrategyDataSetElement(dealDescription, projectDto.project_name, indexDTO, session).AsArray();
            }
            catch (Exception ex)
            {
                Service.Logging.LoggingService.Error(GetType(), "Error during pricing engine initialization", ex);
                throw ex;
            }
        }

        private IDealDescriptionCollection LoadDealDescription(string projectName)
        {
            var dealDescription = PersistanceService.DealProvider.GetSpecificDeals(null, null, projectName.AsArray(), session);
            return dealDescription;
        }

        public ProjectDTO ProjectDto { get { return projectDto; } }

        /// <summary>
        /// Caesar strategy sequence elements - in our case indexes
        /// </summary>
        public StrategyDataSetElement[] Elements
        {
            get { return elements; }
            set { elements = value; }
        }

        public Dictionary<string, IndexDTO> IndexDtos
        {
            get { return indexDtos; }
        }
        public bool HasPricingError { get { return hasPricingError; } }
        /// <summary>
        /// Price method for a single index with quote calculation period overload
        /// </summary>
        public bool Price(DateTime startDate, DateTime endDate, bool forceCalcul = true)
        {
            hasPricingError = false;
            var indexPricingConfiguration = new IndexPricingConfiguration()
            {
                InitialCalculationDate = startDate,
                FinalCalculationDate = endDate,
                LoadingStrategy = HistoryLoadStrategy.Incremental,
                Path = elements.Length == 1 ? ((IndexPricingConfiguration)elements[0].Configuration).Path : null,
                ProjectName = ((IndexPricingConfiguration)elements[0].Configuration).ProjectName,
                CacheTree = MarketDataService.CurrentOverloadedMarketDataTree,
                SaveAtTheEnd = saveAtTheEnd,
                ProjectPaths = projectIndexes.Select(i => i.ticker).ToArray(),
                SaveOnlyCalculated = saveOnlyCalculated
            };

            elements.ForEach(c =>
            {
                c.Configuration = new IndexPricingConfiguration()
                {
                    InitialCalculationDate = startDate,
                    FinalCalculationDate = endDate,
                    LoadingStrategy = HistoryLoadStrategy.Incremental,
                    Path = ((IndexPricingConfiguration)c.Configuration).Path,
                    ProjectName = ((IndexPricingConfiguration)c.Configuration).ProjectName,
                    CacheTree = MarketDataService.CurrentOverloadedMarketDataTree,
                    SaveAtTheEnd = saveAtTheEnd,
                    ProjectPaths = projectIndexes.Select(i => i.ticker).ToArray(),
                    SaveOnlyCalculated = saveOnlyCalculated
                };
            });

            try
            {
                Exception exception;

                PricingService.PricingFinished += OnPricingFinished;
                PricingService.Price(elements, indexPricingConfiguration, PolicyType.LocalPricing, out exception, QuoteCalculationCallback);

                if (exception != null)
                {
                    message = "Error during pricing : " + GetExceptionMessage(exception);
                }

                return exception == null;
            }
            catch (Exception ex)
            {
                CaesarApplication.Service.Logging.LoggingService.Error(this.GetType(), "Error during pricing", ex);
                message = "Error during pricing : " + ex;
                return false;
            }
        }

        private static string GetExceptionMessage(Exception exception)
        {
            return exception is PricingServerException && exception.InnerException is MissingDataException ? exception.InnerException.Message : exception.ToString();
        }

        private void OnPricingFinished(object sender, PricingService.PricingFinishedEventArgs e)
        {
            this.pricingResult = string.Join("\r\n", e.MessageTitle, e.MessageSubtitle);
        }

        /// <summary>
        /// Callback method for the pricer
        /// </summary>
        /// <param name="element"></param>
        /// <param name="message"></param>
        /// <param name="result"></param>
        private void QuoteCalculationCallback(StrategyDataSetElement element, string message, IResult result)
        {
            Quotes =
                result is IndexStrategyPricingResult
                    ? ((IndexStrategyPricingResult)result).Results.ToDictionary(x => x.Key, x => x.Value.GetQuotes())
                    : ((IndexPricingResult)result).AsArray().ToDictionary(x => x.Description, x => x.GetQuotes());

            if (Quotes.SelectMany(x => x.Value).Any(q => q.Status == QuoteStatus.Error))
                hasPricingError = true;

            BasketIndexList = result is IndexStrategyPricingResult
                ?
                ((IndexStrategyPricingResult)result).Results.ToDictionary(x => x.Key, x => x.Value.GetBaskets())
                :
                ((IndexPricingResult)result).AsArray().ToDictionary(x => x.Description, x => x.GetBaskets())
                ;

            this.message = message;
            this.result = result;
        }

        public Dictionary<string, IList<IIndexQuote>> Quotes { get; set; }

        public Dictionary<string, IList<BasketIndexList>> BasketIndexList { get; set; }
    }
}
