﻿namespace CaesarApplication.QuoteCalculator
{
    public class ContributionResult
    {
        public ContributionResult(bool noError, string message, string fileName = null)
        {
            NoError = noError;
            Message = message;
            ContributedFileName = fileName;
        }
        public bool NoError { get; set; }

        public string ContributedFileName { get; set; }

        public string Message { get; set; }
    }
}