using System;

namespace CaesarApplication.QuoteCalculator
{
    public interface IQuoteCalculator
    {
        /// <summary>
        /// Price method for a single index with quote calculation period overload
        /// </summary>
        bool Price(DateTime startDate, DateTime endDate, bool forceCalcul = true);

        string message { get; set; }
    }
}