﻿using System;
using DealBusinessObject.IDescription;

namespace CaesarApplication.QuoteCalculator
{
    public class BatchPricerRunConfig
    {
        public long? ProjectId { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }

        public DateTime? ConfigurationDate { get; set; }
        public string ConfigName { get; set; }
        public int NbDaysLag { get; set; }

        public string ResultDirectory { get; set; }
        public bool RunLocal { get; set; }
        public string IndexToPrice { get; private set; }

        public string FolderToPrice { get; set; }

        public BatchPricerRunConfig()
        {
        }

        public BatchPricerRunConfig(string resultDirectory, bool runLocal, DateTime? startDate, DateTime? endDate, DateTime? configurationDate, string configName, int nbDaysLag, string indexToPrice, int? projectId, bool skipBooking, bool skipReporting, string mailPrefix, bool sendMailAnyWay, int? nbCalculatedDays, string[] dataHandlers)
        {
            ProjectId = projectId;
            ResultDirectory = resultDirectory;
            RunLocal = runLocal;
            StartDate = startDate;
            EndDate = endDate;
            ConfigurationDate = configurationDate;
            ConfigName = configName;
            NbDaysLag = nbDaysLag;
            IndexToPrice = indexToPrice;
            SkipBooking = skipBooking;
            SkipReporting = skipReporting;
            MailPrefix = mailPrefix;
            SendMailAnyWay = sendMailAnyWay;
            NbCalculatedDays = nbCalculatedDays;
            DataHandlers = dataHandlers;
        }

        public int? NbCalculatedDays { get; set; }

        public bool SendMailAnyWay { get; set; }

        public string MailPrefix { get; set; }

        public bool SkipReporting { get;set;}

        public bool SkipBooking { get; set; }

        /// <summary>
        /// DataHandlers used during backtesting
        /// </summary>
        public string[] DataHandlers { get; set; }

        public string DirectoriesToPrice { get; set; }

        public bool SaveOnlyCalculated { get; set; }
        public string NrtFilePath { get; set; }
        public bool NrtMode { get; set; }
        public string NrtExeFileToTest { get; set; }
    }
}