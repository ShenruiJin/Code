﻿using CaesarApplication.Service.Persistance;
using DealIndexDataTransferObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using FuncFramework.Business;

namespace CaesarApplication.QuoteCalculator
{

    public class PriceIndexItem : IPriceIndexItem
    {
        public long IndexId
        {
            get;
            set;
        }
        public string Name
        {
            get;
            set;
        }

        public string ProjectName
        {
            get;
            set;
        }

        public string Ticker
        {
            get;
            set;
        }

        public bool ToPrice
        {
            get;
            set;
        }
        public long PricingRank
        {
            get;
            set;
        }
        public string Status
        {
            get;
            set;
        }
        public string QuotationDate
        {
            get;
            set;
        }

        public string Quote
        {
            get;
            set;
        }
        public long ProjectId
        {
            get;
            set;
        }

        public bool ToContribute { get; set; }
        public PriceIndexItem(IndexDTO index, long projectId, string projectName, Action UpdateLsit, bool pricingMode)
        {
            IndexId = index.id;
            Ticker = index.ticker;
            ProjectName = projectName;
            Name = index.index_name;
            Ticker = index.ticker;
            ToContribute = !pricingMode &&  index.bbg_contribution == "Y";
            ToPrice = !pricingMode && index.pricing_rank > 0;
            PricingRank = !pricingMode ? index.pricing_rank : 0;
            ProjectId = projectId;
        }

        public PriceIndexItem(string fullPath, int rank)
        {
            var localPath = IndexPathHelper.GetLocalPath(fullPath);

            Name = localPath;
            ProjectName = localPath;
            ProjectId = IndexPathHelper.GetProjectId(fullPath);
            PricingRank = rank;
        }

        public PriceIndexItem(string localPath, long projectId)
        {
            Name = localPath;
            ProjectId = projectId;
        }

        public static IndexDTO ModelToIndexDto(IPriceIndexItem priceIndexItem)
        {
            return ModelToIndexDto(priceIndexItem.IndexId, priceIndexItem.Ticker);
        }

        public static IndexDTO ModelToIndexDto(long indexId, string ticker)
        {
            if (ticker.IsNullOrEmpty())
                return null;
            IndexDTO indexDto;
            try
            {
                indexDto = new IndexDTO() { id = indexId };
                indexDto = PersistanceService.IndexProvider.ReadIndex(indexDto, PersistanceService.CaesarSession);
            }
            catch (Exception)
            {

                return null;
            }

            return indexDto == null ? null : indexDto;
        }
    }

    public interface IPriceIndexItem
    {

        long IndexId{
            get;
            set;
        }
        string Name
        {
            get;
            set;
        }

        string ProjectName
        {
            get;
            set;
        }

        string Ticker
        {
            get;
            set;
        }

        bool ToPrice
        {
            get;
            set;
        }
        long PricingRank
        {
            get;
            set;
        }
        string Status
        {
            get;
            set;
        }
        string QuotationDate
        {
            get;
            set;
        }

        string Quote
        {
            get;
            set;
        }

        long ProjectId
        {
            get;
            set;
        }

        bool ToContribute { get; set; }

    }
}
