﻿using CaesarApplication.Utilities;
using PricingBase.Index;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using CaesarCommon.Configuration;
using Exception = System.Exception;
using DealIndexDataTransferObject;
using FuncFramework.Helpers;

namespace CaesarApplication.QuoteCalculator
{
    // TODO : Change the object type
    /// <summary>
    /// Help to contribute data
    /// </summary>
    public class Contributor : IContributor
    {
        /// <summary>
        /// Folder path where to deposit the contribution file
        /// </summary>
        private string contributionFolderPath = new CaesarSettingsManager().ContributionFolderPath ?? ConfigurationManager.AppSettings["ContributionFolderPath"];
        private string contributionResultFolderPath = new CaesarSettingsManager().ContributionResultFolderPath ?? ConfigurationManager.AppSettings["ContributionResultFolderPath"];

        /// <summary>
        /// Header for the file to be contributed through VIPK2 to Bloomberg
        /// </summary>
        private string csvHeader;

        #region .ctor
        /// <summary>
        /// Constructor
        /// </summary>
        public Contributor()
        {
            csvHeader = new CaesarSettingsManager().ContributionFileHeader ?? ConfigurationManager.AppSettings["ContributionFileHeader"];
        }

        #endregion
        /// <summary>
        /// Contribution logic to Bloomberg
        /// </summary>
        /// <returns></returns>
        public ContributionResult Contribute(bool isHistoryMode, string referenceSophis, string sophisName, string bloombergTicker, string drv,
            string bloombergISIN, string indexName, IList<IIndexQuote> quotes,
            Func<string, bool?> callbackAlert = null, int? keyPublicationDecimalNumber = null, MidpointRounding? keyPublicationRoundingPolicy = null)
        {
            string message;
            log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            if ((string.IsNullOrWhiteSpace(bloombergTicker) || string.IsNullOrWhiteSpace(indexName)
                 || (isHistoryMode && string.IsNullOrWhiteSpace(drv))))
            {
                logger.Error("Fields are missing in the configuration of this index");
                message = "Fields are missing in the configuration of this index";
                return new ContributionResult(false, message);
            }

            try
            {
                string csv = ToCSVForInput(drv, bloombergTicker, quotes);

                string fileName = CreateFileNameForManualInput(string.IsNullOrWhiteSpace(bloombergTicker)
                    ? bloombergISIN
                    : bloombergTicker);

                string contributionFilePath = CreateContributionFile(csv, fileName);

                if (!isHistoryMode)
                {
                    if (!Utility.CanRead(contributionFolderPath))
                    {
                        message = "User doesn't have access to the Network Contribution Folder";
                        throw new Exception("User doesn't have access to the Network Contribution Folder");
                    }

                    if (callbackAlert != null)
                    {
                        var userApproval = callbackAlert(csv);

                        if (userApproval.HasValue && !userApproval.Value)
                        {
                            logger.Info("Contribution is aborted by user");
                            message = "Contribution is aborted by user";
                            return new ContributionResult(false, message);
                        }
                    }


                    File.Copy(contributionFilePath, Path.Combine(contributionFolderPath, fileName));

                    logger.Info("Contribution sent with success to contribution server");
                    message = "Contribution sent with success to contribution server";
                }
                else
                {
                    message = "New contribution files are available in the newly open directory : " + fileName;
                    System.Diagnostics.Process.Start("explorer.exe", Path.GetDirectoryName(contributionFilePath));
                }

                return new ContributionResult(true, message, fileName);
            }
            catch (Exception ex)
            {
                logger.Error("Error during contribution", ex);
                message = "Error during contribution";
            }

            return new ContributionResult(false, message);
        }

        public ContributionResult ContributeMultiIndexes(bool isHistoryMode, Dictionary<bool, Dictionary<IndexDTO, IList<IIndexQuote>>> quotesByIndex,
            Func<string, bool?> callbackAlert = null)
        {
            string message;
            log4net.ILog logger = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

            var missingFieldsIndexes = quotesByIndex.SelectMany(x => x.Value).Where(x => (string.IsNullOrWhiteSpace(x.Key.bloomberg_ticker))
                                                                || string.IsNullOrWhiteSpace(x.Key.index_name)
                                                                || (isHistoryMode && string.IsNullOrWhiteSpace(x.Key.drv)));

            if (missingFieldsIndexes.Any())
            {
                var mfi = missingFieldsIndexes.Select(x => x.Key.index_name).ToArray();
                message = string.Format("Fields are missing in the configuration of index{0} : {1}", mfi.Length > 1 ? "es" : string.Empty, string.Join(", ", mfi));
                logger.Error(message);
                return new ContributionResult(false, message);
            }

            try
            {
                var emp = string.Empty;
                var header = ToCSVForInput(emp, emp, new List<IIndexQuote>());
                StringBuilder csvBuilder = new StringBuilder(header);
                quotesByIndex.ForEach(quotesByIndexItems => quotesByIndexItems.Value.ForEach(x => csvBuilder.Append(ToCSVForInput(x.Key.drv, x.Key.bloomberg_ticker, x.Value, false, x.Key.publication_decimal_number, x.Key.publication_rounding_policy, quotesByIndexItems.Key))));
                string csv = csvBuilder.ToString();

                string fileName = CreateFileNameForManualInput("MultiIndicesContribution");

                string contributionFilePath = CreateContributionFile(csv, fileName);

                if (!isHistoryMode)
                {
                    if (!Utility.CanRead(contributionFolderPath))
                    {
                        message = "User doesn't have access to the Network Contribution Folder";
                        throw new Exception("User doesn't have access to the Network Contribution Folder");
                    }

                    if (callbackAlert != null)
                    {
                        var userApproval = callbackAlert(csv);

                        if (userApproval.HasValue && !userApproval.Value)
                        {
                            logger.Info("Contribution is aborted by user");
                            message = "Contribution is aborted by user";
                            return new ContributionResult(false, message);
                        }
                    }

                    File.Copy(contributionFilePath, Path.Combine(contributionFolderPath, fileName));

                    logger.Info("Contribution sent with success to contribution server");
                    message = "Contribution sent with success to contribution server";
                }
                else
                {
                    message = "New contribution files are available in the newly open directory : " + fileName;
                    System.Diagnostics.Process.Start("explorer.exe", Path.GetDirectoryName(contributionFilePath));
                }

                return new ContributionResult(true, message, fileName);
            }
            catch (Exception ex)
            {
                logger.Error("Error during contribution", ex);
                message = "Error during contribution :" + ex;
            }

            return new ContributionResult(false, message);
        }

        /// <summary>
        /// Formating data to a CSV
        /// Permits to be contributed through VIPK2 to Bloomberg
        /// </summary>
        /// <param name="referenceSophis"></param>
        /// <param name="sophisName"></param>
        /// <param name="bloombergTicker"></param>
        /// <param name="bloombergISIN"></param>
        /// <param name="indexName"></param>
        /// <param name="refDate"></param>
        /// <param name="quotes"></param>
        /// <returns></returns>
        private string ToCSV(string referenceSophis, string sophisName, string bloombergTicker, string bloombergISIN, string indexName, IList<IIndexQuote> quotes, bool withHeader = true, int? keyPublicationDecimalNumber = null, MidpointRounding? keyPublicationRoundingPolicy = null)
        {
            string csv = csvHeader;
            StringBuilder stringBuilder = withHeader ? new StringBuilder(csv) : new StringBuilder();

            //using (CultureHelper.Culture("fr-FR"))
            {

                foreach (IIndexQuote quote in quotes)
                {
                    var roundedQuote = IndexQuoteHelper.GetValueToContribute(quote.Value, keyPublicationDecimalNumber, keyPublicationRoundingPolicy).ToString(CultureInfo.InvariantCulture);

                    stringBuilder.Append(referenceSophis);
                    stringBuilder.Append(";");
                    stringBuilder.Append(sophisName);
                    stringBuilder.Append(";");
                    stringBuilder.Append((string.IsNullOrWhiteSpace(bloombergTicker) ? bloombergISIN : bloombergTicker));
                    stringBuilder.Append(";");
                    stringBuilder.Append(indexName);
                    stringBuilder.Append(";");
                    stringBuilder.Append("Index");
                    stringBuilder.Append(";");
                    // TODO : Apply Index quotation Lag !
                    stringBuilder.Append("J-" + (DateTime.Today.ToOADate() - quote.Date.ToOADate()));

                    stringBuilder.Append(";");
                    stringBuilder.Append(roundedQuote);
                    stringBuilder.Append(";");
                    stringBuilder.Append("True");
                    stringBuilder.Append(System.Environment.NewLine);
                }
            }
            csv = stringBuilder.ToString();

            stringBuilder = null;
            return csv;
        }


        /// <summary>
        /// Formating data to a CSV
        /// Permits to be contributed through VIPK2 to Bloomberg
        /// </summary>
        /// <param name="drv"></param>
        /// <param name="bloombergTicker"></param>
        /// <param name="quotes"></param>
        /// <param name="withHeader"></param>
        /// <param name="keyPublicationDecimalNumber"></param>
        /// <param name="keyPublicationRoundingPolicy"></param>
        /// <returns></returns>
        private string ToCSVForInput(string drv, string bloombergTicker, IList<IIndexQuote> quotes, bool withHeader = true, int? keyPublicationDecimalNumber = null, MidpointRounding? keyPublicationRoundingPolicy = null, bool noBBgPublication = false)
        {
            StringBuilder stringBuilder = new StringBuilder();

            if (withHeader)
                stringBuilder.AppendLine(csvHeader);

            foreach (IIndexQuote quote in quotes)
            {
                var roundedQuote = IndexQuoteHelper.GetValueToContribute(quote.Value, keyPublicationDecimalNumber, keyPublicationRoundingPolicy).ToString(CultureInfo.InvariantCulture);

                stringBuilder.Append(drv);
                stringBuilder.Append(";");
                stringBuilder.Append(bloombergTicker);
                stringBuilder.Append(";");
                stringBuilder.Append(quote.Date.ToString("dd/MM/yyyy"));
                stringBuilder.Append(";");
                stringBuilder.Append(roundedQuote);
                stringBuilder.Append(";");
                stringBuilder.Append(roundedQuote);
                stringBuilder.Append(";");
                stringBuilder.Append(noBBgPublication ? "False" : "True");
                stringBuilder.Append(System.Environment.NewLine);
            }

            return stringBuilder.ToString();
        }

        /// <summary>
        /// Determine the file name for the contribution file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string CreateFileName(string indexName)
        {
            return "NXS_" + indexName + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + ".csv";
        }

        /// <summary>
        /// Determine the file name for the contribution file
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private string CreateFileNameForManualInput(string indexName)
        {
            return "NXS_" + indexName + "_" + DateTime.Now.ToString("yyyyMMddhhmmss") + "_" + Guid.NewGuid().ToString().Substring(0, 8) + "_manual_vipk2.csv";
        }

        /// <summary>
        /// Create the contribution file
        /// </summary>
        /// <param name="indexData"></param>
        /// <returns></returns>
        private string CreateContributionFile(string csv, string fileName)
        {
            string contributionLocalFolder = Path.Combine(Environment.GetEnvironmentVariable("TEMP") ?? @"C:\temp", new CaesarSettingsManager().ContributionFolderLocalPath ?? ConfigurationManager.AppSettings["ContributionFolderLocalPath"]);

            if (!Directory.Exists(contributionLocalFolder))
            {
                Directory.CreateDirectory(contributionLocalFolder);
            }

            if (!Utility.CanRead(contributionLocalFolder))
            {
                throw new Exception("User doesn't have access to the Local Contribution Folder");
            }

            string contributionFilePath = Path.Combine(contributionLocalFolder, fileName);

            int fileCreateRetry = 0;

            while (File.Exists(contributionFilePath))
            {
                fileCreateRetry++;
                contributionFilePath += "_" + fileCreateRetry;
            }

            // Encode to UTF8
            File.WriteAllText(contributionFilePath, csv, Encoding.UTF8);
            return contributionFilePath;
        }
    }
}