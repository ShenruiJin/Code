﻿
using System;
using DealIndexDataTransferObject;
using DealIndexDataTransferObject.Converters;
using System.Collections.Generic;
using log4net;
using CaesarApplication.Service.Persistance;
using DealServerInterface.Service;

namespace CaesarApplication
{
    public class ReportingTaskManager : IReportingTaskManager
    {
        private static ILog logger;
        private IIndexDBProvider provider; 

        static ReportingTaskManager()
        {
            log4net.Config.XmlConfigurator.Configure();
            logger = LogManager.GetLogger(typeof(ReportingTaskManager));
        }

        public ReportingTaskManager()
            :this(PersistanceService.IndexProvider)
        {
        }
        public ReportingTaskManager(IIndexDBProvider provider)
        {
            this.provider = provider;
        }

        /// <summary>
        /// Method to save a task into the database
        /// </summary>
        /// <param name="reportFilePath"></param>
        /// <returns></returns>
        public bool SaveTask(string taskId,string reportFilePath, string indexName, string additonnalComments = null, IList<string> recipients = null)
        {
            var reportingTask = new ReportingTask() { FileToUpload = reportFilePath, IndexName = indexName,
                Comments = additonnalComments, Recipients = recipients};

            var task = new ReportingTaskDTO()
            {task_id = taskId, value = SerializationHelper.SerializeJson(reportingTask)};

            try
            {
                provider.SaveReportingTask(task);
            }
            catch (Exception e)
            {   
                logger.Error("Error while saving task to database: " + e.Message);
                throw new ApplicationException("Error while saving task to database: " + e.Message);
            }

            return true;
        }

        /// <summary>
        /// Method to load a task from the database and execute it
        /// </summary>
        /// <param name="taskId"></param>
        public IReportingTask LoadTask(string taskId)
        {
            try
            {
                IReportingTask reportingTask = null;
                var reportingTaskDTO = provider.LoadReportingTask(taskId);
                if (reportingTaskDTO != null)
                    reportingTask = SerializationHelper.DeserializeJson<ReportingTask>(reportingTaskDTO.value);
                return reportingTask;
            }
            catch (Exception e)
            {
                logger.Error("Error while loading task from database: " + e.Message);
                throw new ApplicationException("Error while loading task from database: " + e.Message);
            }
        }

        /// <summary>
        /// Method to delete a task from the database
        /// </summary>
        /// <param name="reportFilePath"></param>
        /// <returns></returns>
        public bool Delete(string taskId)
        {
            try
            {
                provider.DeleteReportingTask(taskId);
                return true;
            }
            catch (Exception e)
            {
                logger.Error(string.Format("Error while deleting task {0} from database", e.Message));
                throw new ApplicationException(string.Format("Error while deleting task {0} from database", e.Message));
            }
        }

        public bool Delete(string[] taskId)
        {
            taskId.ForEach(id => Delete(id));
            return true;
        }
    }
}
