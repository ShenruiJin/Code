﻿using CaesarApplication.DataProvider;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Strategy;
using DealIndexDataTransferObject;
using MarketData;
using Pricing.Engine.Indices;
using PricingBase.DataProvider;
using PricingBase.Index;
using PricingBase.Product.CsInfoContainer;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using GlobalDerivativesApplications.Data.MarketData;
using Pricing.Engine;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using PricingBase.OST;
using Caesar.Pricing.Engine.Indices;
using GlobalDerivativesApplications;
using System.DirectoryServices.AccountManagement;
using FuncFramework.Business;

namespace CaesarApplication.Exporter
{
    public class IndexPricingResultExporter
    {

        #region public method
        public static List<string[]> ExportToListCSVArray(string ticker, bool loadAll, bool basketInTreeOnly)
        {
            TimeSeriesProvider dataProvider =
                new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, readOnly: true);

            TimeSeriesProvider dataProviderTreeOnly =
                 new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, readOnly: true, isTreeOnly: basketInTreeOnly);

            var pricingContext = new PricingContext(IndexPathHelper.GetProjectName(ticker), IndexPathHelper.GetLocalPath(ticker).AsArray())
            {
                IndexPaths = IndexPathHelper.GetLocalPath(ticker).AsArray()
            };
            dataProvider.PricingContext = pricingContext;
            dataProviderTreeOnly.PricingContext = pricingContext;

            var resultQuotes = dataProvider.GetResultQuotes(IndexPathHelper.GetLocalPath(ticker));

            var tickerToUse = IndexPathHelper.GetLocalPath(ticker);

            var quotes = resultQuotes.Count == 0 ? new TimeSerieDB() :
                new TimeSerieDB(resultQuotes[0].Where(ts => loadAll || IsFromDb(ts)).ToList(), resultQuotes[0].Instrument,
                    resultQuotes[0].Field, resultQuotes[0].Context);

            IndexPricingResult result;
            TimeSerieDB indexBaskets;

            if (quotes.Count == 0 || loadAll)
            {
                indexBaskets = dataProviderTreeOnly.GetBasketsAudit(tickerToUse, null, null, null, false);
            }
            else
            {
                indexBaskets = dataProviderTreeOnly.GetBaskets(tickerToUse, quotes.Min(q => q.Key), quotes.Max(q => q.Key));
            }

            result = new IndexPricingResult("Result", new TimeSerieDB(quotes.Where(q => !indexBaskets.Any() || (q.Key >= indexBaskets.X.Min() && q.Key <= indexBaskets.X.Max())).ToArray(), quotes.Instrument, quotes.Field), indexBaskets);

            return ExportToListCSVArray((IList<IIndexQuote>)result[ResultString.Data], (IList<BasketIndexList>)result[ResultString.Baskets], tickerToUse.Replace(IndexPathHelper.Delimiter.ToString(), "->"));
        }


        public static List<string[]> ExportToListCSVArray(string ticker, DateTime? startDate = null, DateTime? endDate = null, bool sortDescending = false, bool basketFromDB = true, bool onlyQuotesFromDB = false)
        {
            TimeSeriesProvider dataProvider =
                new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, new DataProvider.Parameters.TimeSeriesProviderParameters { DataHandlersToUse = new[] { "DB" } });

            TimeSeriesProvider dataProviderTreeOnly = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, readOnly: true, isTreeOnly: true);

            var pricingContext = new PricingContext(IndexPathHelper.GetProjectName(ticker), IndexPathHelper.GetLocalPath(ticker).AsArray())
            {
                IndexPaths = IndexPathHelper.GetLocalPath(ticker).AsArray()
            };
            dataProvider.PricingContext = pricingContext;
            dataProviderTreeOnly.PricingContext = pricingContext;

            pricingContext.SetNewReferenceDate(DateTime.Today, new BasketIndexList(), new BasketIndex());

            var tickerToUse = IsNumeric(ticker) ? ticker : IndexPathHelper.GetLocalPath(ticker);

            var quoteStartDate = onlyQuotesFromDB ? startDate.GetValueOrDefault() : DateTime.MinValue;
            var quoteEndDate = onlyQuotesFromDB ? endDate.GetValueOrDefault() : DateTime.Today;

            var resultQuotesDB = dataProvider.GetIndexQuotes(tickerToUse, quoteStartDate, quoteEndDate);
            var resultQuotesCache = !startDate.HasValue ? dataProviderTreeOnly.GetIndexQuotes(tickerToUse, startDate.GetValueOrDefault(), endDate) : new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(), tickerToUse, DataFieldsEnum.IndexQuote);

            var resultQuotes = resultQuotesDB;

            resultQuotes.Merge(resultQuotesCache);

            var quotes = resultQuotes.Count == 0 ? new TimeSerieDB() :
                new TimeSerieDB(resultQuotes.ToList(), resultQuotes.Instrument,
                    resultQuotes.Field, resultQuotes.Context);

            IndexPricingResult result;
            TimeSerieDB indexBaskets = basketFromDB ? dataProvider.GetBasketsAudit(tickerToUse, startDate.GetValueOrDefault(), endDate.GetValueOrDefault(DateTime.Today), null, false) : dataProviderTreeOnly.GetBasketsAudit(tickerToUse, DateTime.MinValue, DateTime.Today, null, false);

            result = new IndexPricingResult("Result", quotes, indexBaskets);

            return ExportToListCSVArray((IList<IIndexQuote>)result[ResultString.Data], (IList<BasketIndexList>)result[ResultString.Baskets], tickerToUse.Replace(IndexPathHelper.Delimiter.ToString(), "->"), sortDescending);
        }

        private static bool IsNumeric(string valueAsString)
        {
            long val;

            return long.TryParse(valueAsString, out val);
        }


        private static bool IsFromDb(KeyValuePair<DateTime, IMarketData> ts)
        {
            if (ts.Value is IndexQuote && ((IndexQuote)ts.Value).Id != 0)
                return true;
            return false;
        }

        public static string[] ExportToCSVArray(IList<IIndexQuote> quotes, IList<BasketIndexList> baskets, string productName, bool sortDescending)
        {
            var reporter = new ResultCSVExporter();
            reporter.FillDictionnary(quotes, baskets, productName);

            return WriteCSV(productName, reporter, sortDescending);
        }

        public static List<string[]> ExportToListCSVArray(IList<IIndexQuote> quotes, IList<BasketIndexList> baskets, string productName, bool sortDescending = false, TimeSerieDB[] additionnalSeries = null)
        {
            var reporter = new ResultCSVExporter();
            reporter.FillDictionnary(quotes, baskets, productName, additionnalSeries);

            return WriteMultiDimArray(productName, reporter, sortDescending).ToList();
        }
        public static List<string[]> ExportCompoToListCSVArray(IList<IIndexQuote> quotes, IList<BasketIndexList> baskets, string productName)
        {
            var reporter = new ResultCSVExporter();
            reporter.FillCompositionDictionnary(baskets, productName);

            return WriteMultiDimArray(productName, reporter, false).ToList();
        }
        public static string GetTickerFromIndexId(long indexId)
        {
            if (indexId == 0)
                return string.Empty;
            var index = PersistanceService.IndexProvider.ReadIndex(new IndexDTO { id = indexId }, PersistanceService.CaesarSession);

            return index != null ? index.ticker : string.Empty;
        }

        public static IList<BasketIndexList> GetBasketResult(string ticker)
        {

            TimeSeriesProvider dataProvider =
            new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, true);
            var baskets = dataProvider.GetBaskets(ticker != null ? ticker : string.Empty);
            if (baskets.Count == 0)
                return new List<BasketIndexList>();

            var basketIndexlist = new List<BasketIndexList>();
            baskets.ForEach(b => basketIndexlist.Add((BasketIndexList)b.Value));


            return basketIndexlist;
        }
        #endregion

        #region private method


        private static string[] WriteCSV(string productName, ResultCSVExporter exporter, bool sortDescending)
        {
            var Dico = exporter.Dico;

            IList<string> csv = new List<string>();
            List<DateTime> dateList = new List<DateTime>();
            var columnHeaders = Dico.Keys.OrderBy(s => s.Priority).ThenByDescending(s => s.BasketName).ThenBy(s => s.ProductName).ThenBy(x => x.Key).ToArray();

            csv.Add(string.Format(exporter.headerFormat[0], string.Join(ResultCSVExporter.Separator.ToString(), columnHeaders.Select(k => k.BasketName)), productName));
            csv.Add(string.Format(exporter.headerFormat[1], string.Join(ResultCSVExporter.Separator.ToString(), columnHeaders.Select(k => k.Key))));
            csv.Add(string.Format(exporter.headerFormat[2], string.Join(ResultCSVExporter.Separator.ToString(), columnHeaders.Select(k => k.ProductName))));

            Dico.ForEach(o =>
            {
                o.Value.ForEach(kvp =>
                {
                    if (kvp.Key.IsNotIn(dateList))
                        dateList.Add(kvp.Key);
                });
            });

            (sortDescending
            ?
            dateList.OrderByDescending(d => d.Date)
            :
            dateList.OrderBy(d => d.Date)
            ).ForEach(d => csv.Add(exporter.GetValueOfDayLine(d, columnHeaders)));

            return csv.ToArray();
        }

        private static IList<string[]> WriteMultiDimArray(string productName, ResultCSVExporter exporter, bool sortDescending)
        {
            string[] csv = WriteCSV(productName, exporter, sortDescending);
            List<string[]> list = new List<string[]>();

            foreach (string line in csv)
                list.Add(line.Split(ResultCSVExporter.Separator));

            return list;
        }

        private static string GetValueOfDayLine(DateTime date, IEnumerable<CsvKey> columnHeaders, ResultCSVExporter exporter)
        {
            string value;

            var values = columnHeaders.Select(c => exporter.Dico[c].TryGetValue(date, out value) ? value : string.Empty);
            var ost = exporter.OstDico.ContainsKey(date) ? string.Join(", ", exporter.OstDico[date]) : string.Empty;
            return string.Format("{0};{1};{2}", date.ToShortDateString(), ost, string.Join(";", values));
        }
        #endregion

        public static List<string[]> ExportCompoQuotesToListCSVArray(IList<IIndexQuote> quotes, IList<BasketIndexList> baskets, string productName)
        {
            var exporter = new ResultCSVExporter();

            exporter.FillCompositionQuoteDictionnary(quotes, baskets, productName);

            return WriteMultiDimArray(productName, exporter, false).ToList();
        }
    }
}
