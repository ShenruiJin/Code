﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DealIndexDataTransferObject;
using PricingBase.Product.CsInfoContainer;

namespace CaesarApplication.Extension
{
    public static class BasketComponentExtension
    {
        public static BasketComponentDTO ToDTO(this BasketComponent basket)
        {
            

            return null;
        }
    }
}
