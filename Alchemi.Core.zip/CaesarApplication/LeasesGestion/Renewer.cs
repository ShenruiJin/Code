﻿using System;
using System.Runtime.Remoting.Lifetime;
using System.Threading;

namespace CaesarApplication
{
    /// <summary>
    /// Gestion du Lease avec l'appdomain 
    /// -> evite de laisser un lease infini et permet donc de detruire l'engine à la fin de son utilisation
    /// plutot qu'a la fin de vie de l'app domain
    /// </summary>
    public class Renewer
    {
        public ClientSponsor Sponsor { get; set; }
        public MarshalByRefObject Client { get; set; }
        private Thread _renewingThread;

        public volatile bool KeepRenew = true;

        public void Start()
        {
            _renewingThread = new Thread(Renew)
            {
                Name = "renewingThread",
                IsBackground = true
            };
            _renewingThread.Start();
        }

        private void Renew()
        {
            while (KeepRenew)
            {
                Thread.Sleep(10 * 1000);
                try
                {
                    (Client.GetLifetimeService() as ILease)?.Renew(new TimeSpan(0, 0, 30));
                }
                catch
                {
                    // ça peut merder si on unload l'appdomain pendant cet appel
                    // donc on ignore tout simplement
                }
            }
            Client = null;
        }

        public void Stop()
        {
            KeepRenew = false;

            try
            {
                (Client.GetLifetimeService() as ILease).Unregister(Sponsor);
            }
            catch
            {
                // if Client or its lifetime service is/are null, will throw an exception.
            }
        }
    }
}
