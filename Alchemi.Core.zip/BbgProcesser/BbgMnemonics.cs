﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BbgProcesser
{
    public class BbgMnemonics
    {
        public const int DataTableIndex = 1;
        public const string Currency = "CRNCY";
        public const string Security = "Security";
		public const string Date = "Date";
        public const string UtcDate = "UtcDate";
    }
}
