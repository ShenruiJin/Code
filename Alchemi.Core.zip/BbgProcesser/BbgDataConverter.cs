﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace BbgProcesser
{
   /* public static class BbgDataConverter
    {
        private static string _securitiesTable = "Securities";
        private static string _securityColumn = "Security";
        private static string _dateColumn = "UtcDate";
        private static string _dataTable = "Fields";

        // Delete weekends manually
        public static void CleanWeekends(DataSet ds, DateTime endDate)
        {
            // Loop through the dataset to delete rows belonging to a weekend
            for (int rowCounter = ds.Tables[_dataTable].Rows.Count - 1; rowCounter >= 0; rowCounter--)
            {
                DateTime date = Convert.ToDateTime(ds.Tables[_dataTable].Rows[rowCounter][_dateColumn]);
                if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday)
                {
                    ds.Tables[_dataTable].Rows.Remove(ds.Tables[_dataTable].Rows[rowCounter]);
                }
            }
        }

        public static Dictionary<string, DataRow> ConvertToStaticDataList(DataSet ds)
        {
            Dictionary<string, DataRow> staticDataMap = new Dictionary<string, DataRow>();

            // First step : underlying extraction
            foreach (DataRow sjRow in ds.Tables[_securitiesTable].Rows)
            {
                staticDataMap.Add(sjRow[_securityColumn].ToString(), null);
            }

            // Loop to extract static data to our custom struct
            // Need to use a temp list for the foreach to work
            string[] tempKeyList = new string[staticDataMap.Keys.Count];
            staticDataMap.Keys.CopyTo(tempKeyList, 0);
            foreach (string key in tempKeyList)
            {
                // Loop through the dataset
                string filterExpression = "Security = '" + key + "'";
                foreach (DataRow row in ds.Tables[_dataTable].Select(filterExpression))
                {
                    staticDataMap[key] = row;
                }
            }

            return staticDataMap;
        }

        // Convert function to be used for a column name different from close
        public static double[,] ConvertToDoubleMatrix(DataSet retrievedData, string columnName)
        {
            return ConvertToDoubleMatrix(retrievedData, columnName, null);
        }
        
        // Convert a Bbg dataset to a double matrix
        public static double[,] ConvertToDoubleMatrix(DataSet retrievedData, string columnName, List<string> previousDaySecurities)
        {
            Dictionary<string, List<double>> perfMap = new Dictionary<string, List<double>>();

            // First step : underlying extraction
            foreach (DataRow sjRow in retrievedData.Tables[_securitiesTable].Rows)
            {
                perfMap.Add(sjRow[_securityColumn].ToString(), new List<double>());
            }

            int nbSj = perfMap.Keys.Count;
            int matrixSize = int.MaxValue;
            string sortExpression = "Date ASC";
            int currentSj = 0;

            // Loop to extract perf data to our custom dictionary
            foreach (string key in perfMap.Keys)
            {
                // Loop through the dataset to get each performance
                string filterExpression = "Security = '" + key + "'";
                foreach (DataRow row in retrievedData.Tables[_dataTable].Select(filterExpression, sortExpression))
                {
                    double perf;
                    // Try to parse the Bbg data ; if impossible, add a NaN
                    if (!double.TryParse(row[columnName].ToString(), out perf))
                    {
                        perf = double.NaN;
                    }
                    perfMap[key].Add(perf);
                }

                // Change the reference day depending on the security geographic zone
                // Should only be done for prices : use the other overloaded functions for liquidities and others
                if (previousDaySecurities != null)
                {
                    // Check to see if the stock without the Bbg suffix ends with an asian value
                    // Convert everything to lower since Bbg isn't case compliant but C# is
                    string modKeyUnsuffixed = key.ToLower().Remove(key.LastIndexOf(' '));
                    foreach (string prevDaySec in previousDaySecurities)
                    {
                        if (modKeyUnsuffixed.EndsWith(prevDaySec.ToLower()))
                        {
                            // For asian securities, we use the previous day value
                            perfMap[key].RemoveAt(0);
                            // To keep the same historical length, we duplicate the last value
                            // Dumb but hey, that's how it's done in production
                            perfMap[key].Add(perfMap[key][perfMap[key].Count - 1]);

                            // Production bug mimicking
                            // Fill the first non double.NaN value with NaN
                            int counterPerf = 0;
                            while (double.IsNaN(perfMap[key][counterPerf]) && counterPerf < perfMap[key].Count - 1)
                            {
                                counterPerf++;
                            }
                            perfMap[key][counterPerf] = double.NaN;
                        }
                    }
                }

                // Increment the underlying index and set the matrix size
                currentSj++;
                matrixSize = Math.Min(matrixSize, perfMap[key].Count);
            }


            double[,] convertedPerfs = new double[nbSj, matrixSize];
            // Reloop to create the array of array
            int counter = 0;
            foreach (string key in perfMap.Keys)
            {
                double[] tempArray = perfMap[key].ToArray();
                for (int dataId = 0; dataId < matrixSize; dataId++)
                {
                    convertedPerfs[counter, dataId] = tempArray[dataId];
                }
                counter++;
            }
            return convertedPerfs;
        }
    }*/
}
