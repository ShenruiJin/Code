﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Estimators;
using RemotingInterfaces;
using CaesarApplication.Service.Connection;

namespace BbgProcesser
{
    public class CorrelFactory
    {
        #region Private Data
        private List<SecurityDescription> _securityList;
        private List<string> _securityTickerList;
        private string _quantoCurrency;
        private int _nbYearsBack;
        private CalculationPeriod _calcPeriod;
        private List<double> _horizonList;
        private static List<string> _previousDaySecurities;
        private int _nbNonQuantoSecurities;
		private bool _isEvolutionNeeded;
		private static string _delimiter = "#";
        #endregion

		public static string Delimiter
		{
			get { return _delimiter; }
		}
        public CalculationPeriod CalcPeriod
        {
            get { return _calcPeriod; }
            set { _calcPeriod = value; }
        }
        public static List<string> PreviousDaySecurities
        {
            get { return CorrelFactory._previousDaySecurities; }
            set { CorrelFactory._previousDaySecurities = value; }
        }
        public List<SecurityDescription> SecurityList
        {
            get { return _securityList; }
        }
        public List<double> HorizonList
        {
            get { return _horizonList; }
        }

        public CorrelFactory(List<string> securityTickerList, string quantoCurrency,
            CalculationPeriod calcPeriod, List<double> horizonList) :
            this(securityTickerList, quantoCurrency, calcPeriod, horizonList, true)
        {        
        }

        public CorrelFactory(List<string> securityTickerList, string quantoCurrency,
            CalculationPeriod calcPeriod, List<double> horizonList, bool isEvolutionNeeded)
        {
            InitDataList(securityTickerList, quantoCurrency, calcPeriod, horizonList, isEvolutionNeeded);
        }

        private void InitDataList(List<string> securityTickerList, string quantoCurrency,
            CalculationPeriod calcPeriod, List<double> horizonList, bool isEvolutionNeeded)
        {
            _securityTickerList = securityTickerList;
            _quantoCurrency = quantoCurrency;
            foreach (double nbYears in horizonList)
            {
                _nbYearsBack = Math.Max(_nbYearsBack, (int)Math.Ceiling(nbYears));
            }
            _calcPeriod = calcPeriod;
            _horizonList = horizonList;
            _securityList = new List<SecurityDescription>();
            _isEvolutionNeeded = isEvolutionNeeded;
        }

        #region Data retrieval and correlations computation
        // Data retrieval running on the background thread
        public DataSet StartCorrelComputations()
        {
            string message = "Correlation request failed to complete successfully ; " +
                         "check that server is still up and parameters for the request are correct.\n\n\nError description:\n";
            // Première requête : récupération des données statiques (nom, currency, ...)
            // et vérification de l'existence des tickers
            BbgQuery staticQuery = GenerateStaticQuery();

            // Remove custom data
            List<string> customDataList = new List<string>();
            foreach (string security in staticQuery.SecuritiesList)
            {
                if (security.StartsWith(Delimiter))
                {
                    customDataList.Add(security);
                }
            }
            // One more loop since we can't delete directly from staticQuery.SecuritiesList
            // if within a foreach on it
            foreach (string security in customDataList)
            {
                staticQuery.SecuritiesList.Remove(security);
            }

            if (staticQuery.SecuritiesList.Count == 0 && customDataList.Count == 0)
            {
                throw (new Exception("Basket is empty."));
            }
            else
            {
                try
                {
                    DataSet histoDataDs = new DataSet();
                    BbgQuery histoQuery = GenerateHistoricQuery();

                    // Retrieve data for Bbg tickers
                    if (staticQuery.SecuritiesList.Count > 0)
                    {
                        // Envoi de la query à Bloom et analyse de la requête
                        DataSet staticDataDs = Remoter.Send(staticQuery);

                        // Vérification que les données sont ok et màj datasource
                        // Màj de la liste des SJ
                        if (CheckStaticReply(staticDataDs))
                        {
                            // On passe à la deuxième requête sur les données histo
                            // Dirty update
                            histoQuery = GenerateHistoricQuery();
                            // Envoi de la query à Bloom et analyse de la requête
                            histoDataDs = Remoter.Send(histoQuery);

                            // Elimination des w-e manuellement
                            BbgDataConverter.CleanWeekends(histoDataDs);

                        }
                    }

                    return histoDataDs;
                }
                catch (Exception ex)
                {
                    message += ex.Message;
                    throw (new Exception(message));
                }
            }
        }

        private bool CheckStaticReply(DataSet ds)
        {
            bool noMissingData = true;
            int nbSecurities = _securityTickerList.Count;
            if (nbSecurities == 0)
            {
                noMissingData = false;
                throw(new Exception("No underlying in the basket."));
            }
            else
            {
                try
                {
                    // Preinit for quantos
                    List<string> forexList = new List<string>();
                    _nbNonQuantoSecurities = 0;

                    Dictionary<string, DataRow> staticDataMap = BbgDataConverter.ConvertToStaticDataList(ds);
                    // Update the static data columns in the datagrid
                    foreach (string security in _securityTickerList)
                    {
                        // If the map contains the given security, fill in the datatable
                        // TEMP : map on the security that begins with the same ticker
                        // We need to get rid of the " Equity", " Index", ... bit !
                        string securitySuffixed = String.Empty;
                        foreach (string key in staticDataMap.Keys)
                        {
                            if (key.IndexOf(security) == 0)
                            {
                                securitySuffixed = key;
                            }
                        }
                        if (securitySuffixed != String.Empty)
                        {
                            DataRow row = staticDataMap[securitySuffixed];
                            string name = row[BbgField.Name].ToString();
                            if (name == _missingData)
                            {
                                noMissingData = false;
                            }

                            // Quanto retrieval
                            string quanto = row[BbgField.Currency].ToString();
                            string country = row[BbgField.Country].ToString();
                            string companyDescription = row[BbgField.Name].ToString();
                            // On ajoute le descriptif à la liste des descriptions complètes de SJ
                            SecurityDescription desc = new SecurityDescription();
                            desc.Security = security;
                            desc.Quanto = quanto;
                            desc.Country = country;
                            desc.Description = companyDescription;
                            _securityList.Add(desc);
                        }
                        else
                        {
                            noMissingData = false;
                        }

                    }
                }
                catch (Exception ex)
                {
                    noMissingData = false;
                    throw(new Exception("Error while checking the static reply : " + ex.Message));
                }
            }

            return noMissingData;
        }

        public void EndCorrelComputation(DataSet histoDataDs, out double[,] perfMatrix,
            out Dictionary<double, CorrelationPack> correlationPackMap,
            out Dictionary<double, double[]> liquidityMap)
        {
            // Analyse des données
            // Extraction des cours des sous-jacents
            perfMatrix = BbgDataConverter.ConvertToDoubleMatrix(histoDataDs, BbgField.ClosePrice, _securityTickerList,
                PreviousDaySecurities);
            correlationPackMap = Correlations.Calculate(perfMatrix, _horizonList,
                _nbNonQuantoSecurities, _calcPeriod, _securityList, _quantoCurrency, _quantoType, _productMaturity);

            // Extraction des liquidités
            double[,] liqMatrix = BbgDataConverter.ConvertToDoubleMatrix(histoDataDs, BbgField.Volume, _securityTickerList);
            double[] lastQuantoed = ConvertToLastQuantoed(perfMatrix);
            liquidityMap = Estimators.Liquidity.Calculate(liqMatrix, _horizonList, lastQuantoed);
        }

        public Dictionary<double, CorrelationPack> FastCorrelationComputation(double[,] perfMatrix)
        {
            double[,] tempPerf = perfMatrix;
            // If quanto, multiply prices by their forex values
            if (_quantoType == QuantoType.Compo)
            {
                tempPerf = new double[perfMatrix.GetLength(0), perfMatrix.GetLength(1)];
                for (int i = 0; i < tempPerf.GetLength(0); i++)
                {
                    for (int j = 0; j < tempPerf.GetLength(1); j++)
                    {
                         tempPerf[i,j] = perfMatrix[i,j];
                    }
                }
                for (int counter = 0; counter < _nbNonQuantoSecurities; counter++)
                {
                    // Retrieve the quanto
                    string quantoSecurity = _securityList[counter].Quanto.ToUpper();
                    string forex = (quantoSecurity + _quantoCurrency).ToUpper();
                    
                    if (quantoSecurity != _quantoCurrency)
                    {
                        for (int counterForex = 0; counterForex < _securityTickerList.Count; counterForex++)
                        {
                            if (forex == _securityTickerList[counterForex].ToUpper())
                            {
                                for (int t = 0; t < perfMatrix.GetLength(1); t++)
                                {
                                    tempPerf[counter, t] *= tempPerf[counterForex, t];
                                }
                            }
                        }
                    }
                }
            }

            return Correlations.Calculate(tempPerf, _horizonList,
                _nbNonQuantoSecurities, _calcPeriod, _securityList, _quantoCurrency, _quantoType, _productMaturity);
        }
        
        #endregion

        #region Query generation
        // Création de la query sur les données static à partir de la liste des SJ
        private BbgQuery GenerateStaticQuery()
        {
            // Init the request list
            List<string> requestList = new List<string>();
            requestList.Add(BbgField.Name);
            requestList.Add(BbgField.Country);
            requestList.Add(BbgField.Currency);
            requestList.Add("ID_SEDOL1");

            // Single query for each field in the static list
            BbgQuery query = new BbgQuery();

            try
            {
                // Add each selected query field if not present
                foreach (string field in requestList)
                {
                    if (!query.FieldsList.Contains(field))
                    {
                        query.FieldsList.Add(field);
                    }
                }
                // Add the requested securities
                foreach (string security in _securityTickerList)
                {
                    string underlying = security.ToString().ToUpper();
                    if (underlying.Trim() != string.Empty && !query.SecuritiesList.Contains(underlying))
                    {
                        query.SecuritiesList.Add(underlying);
                    }
                }
                query.IsStatic = true;
            }
            catch (Exception ex)
            {
                throw(new Exception("Error on query generation : " + ex.Message));
            }

            return query;
        }

        // Création de la query des données histos (close, volume) à partir de la liste des SJ
        private BbgQuery GenerateHistoricQuery()
        {
            // Init the request list
            List<string> requestList = new List<string>();
            requestList.Add(BbgField.ClosePrice);
            requestList.Add(BbgField.Volume);
            //requestList.Add("PX_LAST_EURO");    // Last close in Euro

            BbgQuery query = new BbgQuery();

            // Add each selected query field if not present
            foreach (string field in requestList)
            {
                if (!query.FieldsList.Contains(field))
                {
                    query.FieldsList.Add(field);
                }
            }

            query.Periodicity = BbgPeriodicity.Daily;
            // Add the requested securities
            List<string> doublonSecurities = new List<string>();
            // Update the number of non-quanto securities
            _nbNonQuantoSecurities = _securityList.Count;
            foreach (SecurityDescription sjValue in _securityList)
            {
                string underlying = sjValue.Security.ToString().ToUpper();
                if (underlying.Trim() != string.Empty && !query.SecuritiesList.Contains(underlying))
                {
                    query.SecuritiesList.Add(underlying);
                }
            }
            foreach(SecurityDescription sjValue in _securityList)
            {
                string securityQuanto = sjValue.Quanto.ToString().ToUpper();
                // Add the quanto effect : get the currency of each underlying
                if (securityQuanto.Trim() != String.Empty && _quantoCurrency != securityQuanto)
                {
                    string forex = securityQuanto + _quantoCurrency;
                    if (!query.SecuritiesList.Contains(forex))
                    {
                        query.SecuritiesList.Add(forex);
                        _securityTickerList.Add(forex);
                    }
                }
            }

            // Get data up to n years ago plus a few days for cushion, where n = max horizon
            // End date is 2 weekdays ago
            // 1 day to be sure that data is present
            // 1 day due to the previous day use for asian values
            int backDays = -1;
            if (DateTime.Today.DayOfWeek == DayOfWeek.Monday)
            {
                backDays = -3;
            }
            query.EndDate = DateTime.UtcNow.Date.AddDays(backDays).Date;
            // *2 factor for graphical analysis if needed
            int historicalFactor = _isEvolutionNeeded ? 2 : 1;
            query.StartDate = query.EndDate.AddYears(-_nbYearsBack * historicalFactor).AddDays(-5).Date;
            // Force the start date to be on a tuesday to give 
            // an additional blanket for available data computation
            while (query.StartDate.DayOfWeek != DayOfWeek.Tuesday)
            {
                query.StartDate = query.StartDate.AddDays(-1);
            }

            return query;
        }
        #endregion
        

        #region Computing helpers
        // Convert the perf matrix to a last close quantoed array
        private double[] ConvertToLastQuantoed(double[,] perfMatrix)
        {
            int nbNonQuantoSecurities = _securityList.Count;
            double[] lastQuantoed = new double[nbNonQuantoSecurities];

            for (int counter = 0; counter < nbNonQuantoSecurities; counter++)
            {
                // Retrieve the last close
                int indexLastData = perfMatrix.GetLength(1) - 1;
                double lastClose = perfMatrix[counter, indexLastData];

                // Retrieve the quanto
                string quantoSecurity = _securityList[counter].Quanto.ToUpper();
                double quanto = 1;
                // Penny stocks
                string selfCurrency = quantoSecurity + quantoSecurity;
                if (ForexFactors.ContainsKey(selfCurrency))
                {
                    lastClose /= ForexFactors[selfCurrency];
                }

                if (quantoSecurity != _quantoCurrency)
                {
                    string forex = (quantoSecurity + _quantoCurrency).ToUpper();
                    // Retrieve quanto factor
                    if (ForexFactors.ContainsKey(forex))
                    {
                        quanto /= ForexFactors[forex];
                    }
                    for (int counterForex = 0; counterForex < _securityTickerList.Count; counterForex++)
                    {
                        if (forex == _securityTickerList[counterForex].ToUpper())
                        {
                            quanto *= perfMatrix[counterForex, indexLastData];
                        }
                    }
                }
                lastQuantoed[counter] = lastClose * quanto;
            }

            return lastQuantoed;
        }
        #endregion
    

        private string _missingData = "#N/A Sec";
        private static Dictionary<string, double> _forexFactors;
        private static QuantoType _quantoType;
		private static double _productMaturity;

		public double ProductMaturity
		{
			get { return CorrelFactory._productMaturity; }
			set { CorrelFactory._productMaturity = value; }
		}

        public QuantoType QuantoType
        {
            get { return CorrelFactory._quantoType; }
            set { CorrelFactory._quantoType = value; }
        }

        public static Dictionary<string, double> ForexFactors
        {
            get {
                if (_forexFactors == null)
                {
                    _forexFactors = new Dictionary<string, double>();
                }
                return CorrelFactory._forexFactors; }
            set { CorrelFactory._forexFactors = value; }
        }
    }
}
