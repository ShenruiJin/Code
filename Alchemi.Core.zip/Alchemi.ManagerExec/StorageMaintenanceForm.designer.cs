#region Alchemi copyright and license notice

/*
* Alchemi [.NET Grid Computing Framework]
* http://www.alchemi.net
* Title         :  StorageMaintenanceForm.Designer.cs
* Project       :  Alchemi.Console.DataForms
* Created on    :  05 May 2006
* Copyright     :  Copyright � 2006 Tibor Biro (tb@tbiro.com)
* Author        :  Tibor Biro (tb@tbiro.com)
* License       :  GPL
*                    This program is free software; you can redistribute it and/or
*                    modify it under the terms of the GNU General Public
*                    License as published by the Free Software Foundation;
*                    See the GNU General Public License
*                    (http://www.gnu.org/copyleft/gpl.html) for more details.
*
*/
#endregion

namespace Alchemi.ManagerExec
{
    partial class StorageMaintenanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.btnPerformMaintenance = new System.Windows.Forms.Button();
			this.chkRemoveAllApplications = new System.Windows.Forms.CheckBox();
			this.label1 = new System.Windows.Forms.Label();
			this.chkRemoveApplicationsByState = new System.Windows.Forms.CheckBox();
			this.lstApplicationStatesToRemove = new System.Windows.Forms.ListBox();
			this.maintenanceOptions = new System.Windows.Forms.TabControl();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.chkRemoveApplicationsByTimeCreated = new System.Windows.Forms.CheckBox();
			this.label2 = new System.Windows.Forms.Label();
			this.numTimeApplicationCreatedCutOffInMinutes = new System.Windows.Forms.NumericUpDown();
			this.numTimeApplicationCompletedCutOffInMinutes = new System.Windows.Forms.NumericUpDown();
			this.chkRemoveApplicationsByTimeCompleted = new System.Windows.Forms.CheckBox();
			this.label3 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.chkRemoveAllExecutors = new System.Windows.Forms.CheckBox();
			this.label7 = new System.Windows.Forms.Label();
			this.numTimeExecutorPingedCutOffInMinutes = new System.Windows.Forms.NumericUpDown();
			this.label8 = new System.Windows.Forms.Label();
			this.chkRemoveExecutorsByTimePinged = new System.Windows.Forms.CheckBox();
			this.tabPage3 = new System.Windows.Forms.TabPage();
			this.resetMessage = new System.Windows.Forms.Label();
			this.labelVersionDll = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.buttonResetDll = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.checkBox4 = new System.Windows.Forms.CheckBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.checkBox5 = new System.Windows.Forms.CheckBox();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.listBox2 = new System.Windows.Forms.ListBox();
			this.checkBox6 = new System.Windows.Forms.CheckBox();
			this.checkBox7 = new System.Windows.Forms.CheckBox();
			this.maintenanceOptions.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTimeApplicationCreatedCutOffInMinutes)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.numTimeApplicationCompletedCutOffInMinutes)).BeginInit();
			this.groupBox2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTimeExecutorPingedCutOffInMinutes)).BeginInit();
			this.tabPage3.SuspendLayout();
			this.SuspendLayout();
			// 
			// btnPerformMaintenance
			// 
			this.btnPerformMaintenance.Location = new System.Drawing.Point(125, 535);
			this.btnPerformMaintenance.Name = "btnPerformMaintenance";
			this.btnPerformMaintenance.Size = new System.Drawing.Size(164, 23);
			this.btnPerformMaintenance.TabIndex = 0;
			this.btnPerformMaintenance.Text = "Perform Maintenance";
			this.btnPerformMaintenance.UseVisualStyleBackColor = true;
			this.btnPerformMaintenance.Click += new System.EventHandler(this.btnPerformMaintenance_Click);
			// 
			// chkRemoveAllApplications
			// 
			this.chkRemoveAllApplications.AutoSize = true;
			this.chkRemoveAllApplications.Location = new System.Drawing.Point(21, 38);
			this.chkRemoveAllApplications.Name = "chkRemoveAllApplications";
			this.chkRemoveAllApplications.Size = new System.Drawing.Size(140, 17);
			this.chkRemoveAllApplications.TabIndex = 2;
			this.chkRemoveAllApplications.Text = "Remove All Applications";
			this.chkRemoveAllApplications.UseVisualStyleBackColor = true;
			this.chkRemoveAllApplications.CheckedChanged += new System.EventHandler(this.chkRemoveAllApplications_CheckedChanged);
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(18, 77);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(312, 13);
			this.label1.TabIndex = 3;
			this.label1.Text = "Remove only applications that have the following characteristics:";
			// 
			// chkRemoveApplicationsByState
			// 
			this.chkRemoveApplicationsByState.AutoSize = true;
			this.chkRemoveApplicationsByState.Location = new System.Drawing.Point(50, 102);
			this.chkRemoveApplicationsByState.Name = "chkRemoveApplicationsByState";
			this.chkRemoveApplicationsByState.Size = new System.Drawing.Size(217, 17);
			this.chkRemoveApplicationsByState.TabIndex = 4;
			this.chkRemoveApplicationsByState.Text = "Application status is one of the following:";
			this.chkRemoveApplicationsByState.UseVisualStyleBackColor = true;
			// 
			// lstApplicationStatesToRemove
			// 
			this.lstApplicationStatesToRemove.FormattingEnabled = true;
			this.lstApplicationStatesToRemove.Location = new System.Drawing.Point(245, 125);
			this.lstApplicationStatesToRemove.Name = "lstApplicationStatesToRemove";
			this.lstApplicationStatesToRemove.SelectionMode = System.Windows.Forms.SelectionMode.MultiSimple;
			this.lstApplicationStatesToRemove.Size = new System.Drawing.Size(120, 95);
			this.lstApplicationStatesToRemove.TabIndex = 5;
			// 
			// maintenanceOptions
			// 
			this.maintenanceOptions.Controls.Add(this.tabPage2);
			this.maintenanceOptions.Controls.Add(this.tabPage3);
			this.maintenanceOptions.Location = new System.Drawing.Point(12, 0);
			this.maintenanceOptions.Name = "maintenanceOptions";
			this.maintenanceOptions.SelectedIndex = 0;
			this.maintenanceOptions.Size = new System.Drawing.Size(431, 603);
			this.maintenanceOptions.TabIndex = 5;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.groupBox1);
			this.tabPage2.Controls.Add(this.btnPerformMaintenance);
			this.tabPage2.Controls.Add(this.groupBox2);
			this.tabPage2.Location = new System.Drawing.Point(4, 22);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(423, 577);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "Application maintenance";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.lstApplicationStatesToRemove);
			this.groupBox1.Controls.Add(this.chkRemoveApplicationsByTimeCreated);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Controls.Add(this.numTimeApplicationCreatedCutOffInMinutes);
			this.groupBox1.Controls.Add(this.numTimeApplicationCompletedCutOffInMinutes);
			this.groupBox1.Controls.Add(this.chkRemoveApplicationsByTimeCompleted);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.chkRemoveAllApplications);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.chkRemoveApplicationsByState);
			this.groupBox1.Location = new System.Drawing.Point(7, 7);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(407, 375);
			this.groupBox1.TabIndex = 20;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Applications";
			// 
			// chkRemoveApplicationsByTimeCreated
			// 
			this.chkRemoveApplicationsByTimeCreated.AutoSize = true;
			this.chkRemoveApplicationsByTimeCreated.Location = new System.Drawing.Point(50, 226);
			this.chkRemoveApplicationsByTimeCreated.Name = "chkRemoveApplicationsByTimeCreated";
			this.chkRemoveApplicationsByTimeCreated.Size = new System.Drawing.Size(331, 17);
			this.chkRemoveApplicationsByTimeCreated.TabIndex = 6;
			this.chkRemoveApplicationsByTimeCreated.Text = "The time elapsed since the application was created is larger than";
			this.chkRemoveApplicationsByTimeCreated.UseVisualStyleBackColor = true;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(326, 273);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(46, 13);
			this.label2.TabIndex = 8;
			this.label2.Text = "minutes.";
			// 
			// numTimeApplicationCreatedCutOffInMinutes
			// 
			this.numTimeApplicationCreatedCutOffInMinutes.Location = new System.Drawing.Point(245, 266);
			this.numTimeApplicationCreatedCutOffInMinutes.Name = "numTimeApplicationCreatedCutOffInMinutes";
			this.numTimeApplicationCreatedCutOffInMinutes.Size = new System.Drawing.Size(75, 20);
			this.numTimeApplicationCreatedCutOffInMinutes.TabIndex = 13;
			// 
			// numTimeApplicationCompletedCutOffInMinutes
			// 
			this.numTimeApplicationCompletedCutOffInMinutes.Location = new System.Drawing.Point(245, 336);
			this.numTimeApplicationCompletedCutOffInMinutes.Name = "numTimeApplicationCompletedCutOffInMinutes";
			this.numTimeApplicationCompletedCutOffInMinutes.Size = new System.Drawing.Size(75, 20);
			this.numTimeApplicationCompletedCutOffInMinutes.TabIndex = 14;
			// 
			// chkRemoveApplicationsByTimeCompleted
			// 
			this.chkRemoveApplicationsByTimeCompleted.AutoSize = true;
			this.chkRemoveApplicationsByTimeCompleted.Location = new System.Drawing.Point(50, 313);
			this.chkRemoveApplicationsByTimeCompleted.Name = "chkRemoveApplicationsByTimeCompleted";
			this.chkRemoveApplicationsByTimeCompleted.Size = new System.Drawing.Size(322, 17);
			this.chkRemoveApplicationsByTimeCompleted.TabIndex = 9;
			this.chkRemoveApplicationsByTimeCompleted.Text = "The time elapsed since the application completed is larger than";
			this.chkRemoveApplicationsByTimeCompleted.UseVisualStyleBackColor = true;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(326, 343);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(46, 13);
			this.label3.TabIndex = 11;
			this.label3.Text = "minutes.";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.chkRemoveAllExecutors);
			this.groupBox2.Controls.Add(this.label7);
			this.groupBox2.Controls.Add(this.numTimeExecutorPingedCutOffInMinutes);
			this.groupBox2.Controls.Add(this.label8);
			this.groupBox2.Controls.Add(this.chkRemoveExecutorsByTimePinged);
			this.groupBox2.Location = new System.Drawing.Point(7, 388);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(407, 128);
			this.groupBox2.TabIndex = 21;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Executors";
			// 
			// chkRemoveAllExecutors
			// 
			this.chkRemoveAllExecutors.AutoSize = true;
			this.chkRemoveAllExecutors.Location = new System.Drawing.Point(21, 19);
			this.chkRemoveAllExecutors.Name = "chkRemoveAllExecutors";
			this.chkRemoveAllExecutors.Size = new System.Drawing.Size(130, 17);
			this.chkRemoveAllExecutors.TabIndex = 15;
			this.chkRemoveAllExecutors.Text = "Remove All Executors";
			this.chkRemoveAllExecutors.UseVisualStyleBackColor = true;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(326, 102);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(46, 13);
			this.label7.TabIndex = 17;
			this.label7.Text = "minutes.";
			// 
			// numTimeExecutorPingedCutOffInMinutes
			// 
			this.numTimeExecutorPingedCutOffInMinutes.Location = new System.Drawing.Point(245, 100);
			this.numTimeExecutorPingedCutOffInMinutes.Name = "numTimeExecutorPingedCutOffInMinutes";
			this.numTimeExecutorPingedCutOffInMinutes.Size = new System.Drawing.Size(75, 20);
			this.numTimeExecutorPingedCutOffInMinutes.TabIndex = 19;
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Location = new System.Drawing.Point(18, 51);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(302, 13);
			this.label8.TabIndex = 18;
			this.label8.Text = "Remove only executors that have the following characteristics:";
			// 
			// chkRemoveExecutorsByTimePinged
			// 
			this.chkRemoveExecutorsByTimePinged.AutoSize = true;
			this.chkRemoveExecutorsByTimePinged.Location = new System.Drawing.Point(21, 77);
			this.chkRemoveExecutorsByTimePinged.Name = "chkRemoveExecutorsByTimePinged";
			this.chkRemoveExecutorsByTimePinged.Size = new System.Drawing.Size(375, 17);
			this.chkRemoveExecutorsByTimePinged.TabIndex = 16;
			this.chkRemoveExecutorsByTimePinged.Text = "The time elapsed since the executor was successfuly pinged is larger than";
			this.chkRemoveExecutorsByTimePinged.UseVisualStyleBackColor = true;
			// 
			// tabPage3
			// 
			this.tabPage3.Controls.Add(this.resetMessage);
			this.tabPage3.Controls.Add(this.labelVersionDll);
			this.tabPage3.Controls.Add(this.label9);
			this.tabPage3.Controls.Add(this.buttonResetDll);
			this.tabPage3.Location = new System.Drawing.Point(4, 22);
			this.tabPage3.Name = "tabPage3";
			this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage3.Size = new System.Drawing.Size(423, 577);
			this.tabPage3.TabIndex = 2;
			this.tabPage3.Text = "Pricing Dll";
			this.tabPage3.UseVisualStyleBackColor = true;
			// 
			// resetMessage
			// 
			this.resetMessage.AutoSize = true;
			this.resetMessage.Location = new System.Drawing.Point(133, 70);
			this.resetMessage.Name = "resetMessage";
			this.resetMessage.Size = new System.Drawing.Size(0, 13);
			this.resetMessage.TabIndex = 3;
			// 
			// labelVersionDll
			// 
			this.labelVersionDll.AutoSize = true;
			this.labelVersionDll.Location = new System.Drawing.Point(144, 31);
			this.labelVersionDll.Name = "labelVersionDll";
			this.labelVersionDll.Size = new System.Drawing.Size(41, 13);
			this.labelVersionDll.TabIndex = 2;
			this.labelVersionDll.Text = "label10";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Location = new System.Drawing.Point(33, 31);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(104, 13);
			this.label9.TabIndex = 1;
			this.label9.Text = "Current Dlls version :";
			// 
			// buttonResetDll
			// 
			this.buttonResetDll.Location = new System.Drawing.Point(36, 61);
			this.buttonResetDll.Name = "buttonResetDll";
			this.buttonResetDll.Size = new System.Drawing.Size(75, 23);
			this.buttonResetDll.TabIndex = 0;
			this.buttonResetDll.Text = "Reset";
			this.buttonResetDll.UseVisualStyleBackColor = true;
			this.buttonResetDll.Click += new System.EventHandler(this.buttonResetDll_Click);
			// 
			// textBox3
			// 
			this.textBox3.Location = new System.Drawing.Point(365, 239);
			this.textBox3.Name = "textBox3";
			this.textBox3.Size = new System.Drawing.Size(75, 20);
			this.textBox3.TabIndex = 10;
			// 
			// checkBox4
			// 
			this.checkBox4.AutoSize = true;
			this.checkBox4.Location = new System.Drawing.Point(28, 239);
			this.checkBox4.Name = "checkBox4";
			this.checkBox4.Size = new System.Drawing.Size(322, 17);
			this.checkBox4.TabIndex = 9;
			this.checkBox4.Text = "The time elapsed since the application completed is larger than";
			this.checkBox4.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(456, 205);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(46, 13);
			this.label4.TabIndex = 8;
			this.label4.Text = "minutes.";
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(365, 201);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(75, 20);
			this.textBox4.TabIndex = 7;
			// 
			// checkBox5
			// 
			this.checkBox5.AutoSize = true;
			this.checkBox5.Location = new System.Drawing.Point(28, 201);
			this.checkBox5.Name = "checkBox5";
			this.checkBox5.Size = new System.Drawing.Size(331, 17);
			this.checkBox5.TabIndex = 6;
			this.checkBox5.Text = "The time elapsed since the application was created is larger than";
			this.checkBox5.UseVisualStyleBackColor = true;
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(25, 60);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(312, 13);
			this.label5.TabIndex = 3;
			this.label5.Text = "Remove only applications that have the following characteristics:";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(456, 243);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(46, 13);
			this.label6.TabIndex = 11;
			this.label6.Text = "minutes.";
			// 
			// listBox2
			// 
			this.listBox2.FormattingEnabled = true;
			this.listBox2.Location = new System.Drawing.Point(288, 91);
			this.listBox2.Name = "listBox2";
			this.listBox2.Size = new System.Drawing.Size(120, 95);
			this.listBox2.TabIndex = 5;
			// 
			// checkBox6
			// 
			this.checkBox6.AutoSize = true;
			this.checkBox6.Location = new System.Drawing.Point(28, 91);
			this.checkBox6.Name = "checkBox6";
			this.checkBox6.Size = new System.Drawing.Size(217, 17);
			this.checkBox6.TabIndex = 4;
			this.checkBox6.Text = "Application status is one of the following:";
			this.checkBox6.UseVisualStyleBackColor = true;
			// 
			// checkBox7
			// 
			this.checkBox7.AutoSize = true;
			this.checkBox7.Location = new System.Drawing.Point(28, 20);
			this.checkBox7.Name = "checkBox7";
			this.checkBox7.Size = new System.Drawing.Size(140, 17);
			this.checkBox7.TabIndex = 2;
			this.checkBox7.Text = "Remove All Applications";
			this.checkBox7.UseVisualStyleBackColor = true;
			// 
			// StorageMaintenanceForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(450, 615);
			this.Controls.Add(this.maintenanceOptions);
			this.MaximizeBox = false;
			this.MinimizeBox = false;
			this.Name = "StorageMaintenanceForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "Storage Maintenance Form";
			this.Load += new System.EventHandler(this.StorageMaintenanceForm_Load);
			this.maintenanceOptions.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTimeApplicationCreatedCutOffInMinutes)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.numTimeApplicationCompletedCutOffInMinutes)).EndInit();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numTimeExecutorPingedCutOffInMinutes)).EndInit();
			this.tabPage3.ResumeLayout(false);
			this.tabPage3.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.Button btnPerformMaintenance;
        private System.Windows.Forms.CheckBox chkRemoveAllApplications;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListBox lstApplicationStatesToRemove;
        private System.Windows.Forms.CheckBox chkRemoveApplicationsByState;
		private System.Windows.Forms.TabControl maintenanceOptions;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.CheckBox chkRemoveApplicationsByTimeCreated;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.CheckBox chkRemoveApplicationsByTimeCompleted;
		private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ListBox listBox2;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.NumericUpDown numTimeApplicationCompletedCutOffInMinutes;
		private System.Windows.Forms.NumericUpDown numTimeApplicationCreatedCutOffInMinutes;
		private System.Windows.Forms.TabPage tabPage3;
		private System.Windows.Forms.NumericUpDown numTimeExecutorPingedCutOffInMinutes;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.CheckBox chkRemoveExecutorsByTimePinged;
		private System.Windows.Forms.CheckBox chkRemoveAllExecutors;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.Button buttonResetDll;
		private System.Windows.Forms.Label labelVersionDll;
		private System.Windows.Forms.Label resetMessage;
    }
}