﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using System.Collections;

namespace Alchemi.ManagerExec
{
	public class PerformanceGraph : UserControl
	{
		/// <summary> 
		/// Required designer variable.
		/// </summary>
		private List<ArrayList> _arrayList;
		private List<Color> _colorLines;

		private Color _colorGrid;
		
		private int  _yMaxInit;
		private int  _gridPixel;

		#region Constructor 

		public PerformanceGraph()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();
			this.SetStyle(ControlStyles.UserPaint | ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer, true);

			BackColor = Color.Black;
			_colorGrid = Color.DarkGreen;

			_yMaxInit = 300;
			_gridPixel = 10;

            _arrayList = new List<ArrayList>();
            _colorLines = new List<Color>();
		}

		#endregion
        public int CreateChart(Color lineColor)
        {
            _arrayList.Add(new ArrayList());
            _colorLines.Add(lineColor);
            return _colorLines.Count;
        }

		public void UpdateChart(int chartIndex, double d)
		{
			Rectangle rt = this.ClientRectangle;
			int dataCount = rt.Width/2;

            if (_arrayList[chartIndex].Count >= dataCount)
                _arrayList[chartIndex].RemoveAt(0);

            _arrayList[chartIndex].Add(d);

			Invalidate();
		}

		#region Component Designer generated code
		/// <summary> 
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Name = "DataChart";
			this.Size = new System.Drawing.Size(150, 16);
		}
		#endregion

		#region "Properties"

		[Description("Gets or sets the current Grid Color in chart"), Category("DataChart")]
		public Color GridColor
		{
			get { return _colorGrid; }
			set { _colorGrid = value; }
		}

		[Description("Gets or sets the initial maximum Height for sticks in chart"), Category("DataChart")]
		public int InitialHeight
		{
			get { return _yMaxInit; }
			set { _yMaxInit = value; }
		}
	 
		[Description("Enables grid drawing with spacing of the Pixel number"), Category("DataChart")]
		public int GridPixels
		{
			get { return _gridPixel; }
			set { _gridPixel = value; }
		}

		#endregion

		#region Drawing
		protected override void OnPaint(PaintEventArgs e)
		{
			Rectangle rt = this.ClientRectangle;

			int xStart = rt.Width;
			int yStart = rt.Height;
			int nX, nY;

			Pen pen = null;
			e.Graphics.Clear(BackColor);

			if (GridPixels!=0)
			{
				pen = new Pen(GridColor, 1);
				nX = rt.Width/GridPixels;
				nY = rt.Height/GridPixels;

				for (int i=1; i<=nX; i++)
					e.Graphics.DrawLine(pen, i*GridPixels, 0, i*GridPixels, yStart);

				for (int i=1; i<nY; i++)
					e.Graphics.DrawLine(pen, 0, i*GridPixels, xStart, i*GridPixels);
			}

            double y = 0, yMax = InitialHeight;
            for (int indexChart = 0; indexChart < _colorLines.Count; indexChart++)
            {
                ArrayList currentArray = _arrayList[indexChart];
                int count = currentArray.Count;

                // on zap si vide
                if (count == 0)
                    continue;

                for (int i = 0; i < count; i++)
                {
                    y = Convert.ToDouble(currentArray[i]);
                    if (y > yMax)
                        yMax = y;
                }
                y = yMax == 0 ? 1 : rt.Height / yMax;		// y ratio
                // From the most recent data, so X <--------------|	
                // Get data from _arrayList	 a[0]..<--...a[count-1]
                pen = new Pen(_colorLines[indexChart], 1);

                int nX0 = xStart - 2;
                int nY0 = (int)(yStart - y * Convert.ToDouble(currentArray[count - 1]));
                for (int i = count - 2; i >= 0; i--)
                {
                    nX = xStart - 2 * (count - i);
                    if (nX <= 0) break;

                    nY = (int)(yStart - y * Convert.ToDouble(currentArray[i]));
                    e.Graphics.DrawLine(pen, nX0, nY0, nX, nY);

                    nX0 = nX;
                    nY0 = nY;
                }
            }
			 

			base.OnPaint(e);
		}
		#endregion
	}

	public enum ChartType { Stick, Line }
	
}
