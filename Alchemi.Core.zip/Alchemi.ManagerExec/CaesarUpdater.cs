﻿using System;
using System.Collections.Generic;
using System.Text;
using Alchemi.Core.Owner;
using System.IO;
using System.Windows.Forms;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Remoting.Channels.Tcp;
using Alchemi.Core.Utility;
using Alchemi.Manager.Storage;
using Alchemi.Core;
using GlobalDerivativesApplications.Remoting.Compression;

namespace Alchemi.ManagerExec
{
    /// <summary>
    /// Class permettant d'updater les fichiers statics
    /// </summary>
    public class CaesarDirectoryUpdater : MarshalByRefObject, IDirectoryUpdater
    {
        FileDependencyCollection _files = null;
		int _currentVersion = -1; // si pas de fichier de version..on force

		/// <summary>
		/// La version actuelle
		/// </summary>
		public int CurrentVersion
		{
			get { return _currentVersion; }
			set { _currentVersion = value; }
		}

		/// <summary>
		/// RAZ de l'updsater
		/// ça va forcer la relecture du repertoire et de la version
		/// </summary>
		public void Reset()
		{
			_files = null;
			_currentVersion = -1;
		}

		/// <summary>
		/// Lit la version courante
		/// </summary>
		private void ReadVersion()
		{
			_currentVersion = int.MaxValue; 
			// le repertoire des update
			DirectoryInfo src = new DirectoryInfo(Application.StartupPath + "\\PricingDll");
			// on chope le numero de version
			// il est dans le nom du fichier version.***
			try
			{
				FileInfo[] files = src.GetFiles("version.*");
				if (files.Length > 0)
				{
					string ext = Path.GetExtension(files[0].FullName);
					_currentVersion = int.Parse(ext.Replace(".", ""));
				}
			}
			catch { 
				// ben on sait pas, donc on force l'update
				_currentVersion = int.MaxValue; 
			}
		}

        /// <summary>
        /// Effectue un chargement au premier appel
        /// </summary>
		private void Initialize()
        {
            // le repertoire des update
            DirectoryInfo src = new DirectoryInfo(Application.StartupPath + "\\PricingDll");
            // on rajoute les fichiers  
            _files = new FileDependencyCollection();
            //need to copy the core dll into the new app-base, so that its types can be accessed.
            foreach (FileInfo fi in src.GetFiles("*.*"))
            {
                FileDependency dependency = new EmbeddedFileDependency(fi.Name, fi.FullName);
                _files.Add(dependency);
            }
			// ajout du core Alchemi
			FileDependency alchemiDll = new ModuleDependency(typeof(ModuleDependency).Module);
			if (!_files.Contains(alchemiDll))
				_files.Add(alchemiDll);
        }

        /// <summary>
        /// Retourne les fichiers a updater
        /// </summary>
        /// <param name="currentVersion">la version installée sur l'executor</param>
        /// <returns>les fichiers a mettre a jour (ensemble vide si pas necessaire)</returns>
        public FileDependencyCollection GetFiles(int currentVersion)
        {
			// on check que le service est en vie
			if (!ManagerStorageFactory.IsManagerRunning)
			{
				throw new InvalidExecutorException("Service is off...", new Exception("Ben je t'ai dis off !!!"));
			}

			// check la version
			if (_currentVersion < 0)
				ReadVersion();

            // check la version : on ne fiat rien si le mec a foutu 15 version d'avance en modifiant les fichiers
            if (currentVersion >= _currentVersion)
                return new FileDependencyCollection();

			// on init au premier passage
			if (_files == null)
				Initialize();

            return _files;
        }

        /// <summary>
        /// on meurt seulement a la fin de l'appli
        /// </summary>
        /// <returns></returns>
        public override object InitializeLifetimeService()
        {
            return null;
        }
    }

    /// <summary>
    /// Lance le serveur sur le port 9003 par defaut
    /// </summary>
    public class CaesarUpdater
    {
        #region Startup methods  
        public static bool Startup()
        {
            int port = 9003;
            string objectUri = "PricingDllUpdater";
            // Create the listener channel on the specified port
            try
            {
				// Creating a custom formatter for a TcpChannel sink chain.
				IDictionary sinkProps = new Dictionary<string, string>();
				sinkProps["compressionThreshold"] = "100000";
				IServerChannelSinkProvider serverProvider = new CompressionServerChannelSinkProvider(sinkProps, null);
				serverProvider.Next = new BinaryServerFormatterSinkProvider();
				((BinaryServerFormatterSinkProvider)serverProvider.Next).TypeFilterLevel = TypeFilterLevel.Full;

                // Creating the IDictionary to set the port on the channel instance.
                IDictionary props = new Hashtable();
                props["name"] = "PricingUpdater";
                props["port"] = port;
                // Pass the properties for the port setting and the server provider in the server chain argument. (Client remains null here.)
                TcpServerChannel chan = new TcpServerChannel(props, serverProvider);
                ChannelServices.RegisterChannel(chan, false);
            }
            catch (Exception e)
            {
                if (
                    object.ReferenceEquals(e.GetType(), typeof(System.Runtime.Remoting.RemotingException)) /* assuming: "The channel tcp is already registered." */
                    |
                    object.ReferenceEquals(e.GetType(), typeof(System.Net.Sockets.SocketException)) /* assuming: "Only one usage of each socket address (protocol/network address/port) is normally permitted" */
                    )
                {
                    // ok
                }
                else
                {
                    throw new System.Runtime.Remoting.RemotingException("Could not register channel while trying to remote self: " + e.Message, e);
                }
            }

            // Register the remoting server as single call
            RemotingConfiguration.RegisterWellKnownServiceType(typeof(CaesarDirectoryUpdater), objectUri, WellKnownObjectMode.Singleton);

            return true;
        }

        #endregion

    }
}
