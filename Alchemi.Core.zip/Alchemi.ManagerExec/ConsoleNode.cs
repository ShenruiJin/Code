﻿using System;
using System.Collections.Generic;
using System.Text;
using Alchemi.Core;
using Alchemi.Core.Owner;

namespace Alchemi.ManagerExec
{
    /// <summary>
    ///  un petit observeur sur le manager
    /// </summary>
    public class ConsoleNode : GNode
    {
        public ConsoleNode(GConnection gc)
            : base(gc)
        {
        }
    }

}
