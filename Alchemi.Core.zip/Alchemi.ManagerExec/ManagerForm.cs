#region Alchemi copyright and license notice

/*
* Alchemi [.NET Grid Computing Framework]
* http://www.alchemi.net
*
* Title			:	ManagerTemplateForm.cs
* Project		:	Alchemi Manager 
* Created on	:	2005
* Copyright		:	Copyright � 2005 The University of Melbourne
*					This technology has been developed with the support of 
*					the Australian Research Council and the University of Melbourne
*					research grants as part of the Gridbus Project
*					within GRIDS Laboratory at the University of Melbourne, Australia.
* Author         :  Krishna Nadiminti (kna@csse.unimelb.edu.au) and Rajkumar Buyya (raj@csse.unimelb.edu.au)
* License        :  GPL
*					This program is free software; you can redistribute it and/or 
*					modify it under the terms of the GNU General Public
*					License as published by the Free Software Foundation;
*					See the GNU General Public License 
*					(http://www.gnu.org/copyleft/gpl.html) for more details.
*
*/
#endregion

using System;
using System.ComponentModel;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Windows.Forms;
using Alchemi.Core;
using Alchemi.Core.EndPointUtils;
using Alchemi.Core.Manager.Storage;
using Alchemi.Core.Owner;
using Alchemi.Manager;
using log4net;
using System.Net;
using Alchemi.Core.Utility;

// Configure log4net using the .config file
[assembly: log4net.Config.XmlConfigurator(Watch=true)]

namespace Alchemi.ManagerExec
{
   
    public class ManagerForm : Form
    {
        #region UI Controls

        private IContainer components;

        protected Button uiStartButton;
        protected Button uiStopButton;

        protected NotifyIcon TrayIcon;

        protected ContextMenu TrayMenu;
        protected MenuItem tmExit;
        protected MainMenu MainMenu;
		protected MenuItem uiManagerUpdateMenuItem;
        protected MenuItem uiManagerExitMenuItem;
        protected MenuItem uiHelpAboutMenuItem;
        protected MenuItem uiManagerMenuItem;
        protected MenuItem uiHelpMenuItem;
        protected TextBox uiLogMessagesTextBox;
        protected Label uiLogMessagesLabel;
        protected GroupBox uiActionsGroupBox;

        protected StatusBar uiStatusBar;

        #endregion

        protected ManagerContainer _container = null;
        private GroupBox groupBox1;
        private MonitorControl monitorControl1;
        private Panel panel1;
		private Panel panel2;
		private Panel panel3;
        protected static readonly Logger logger = new Logger();

        public ManagerForm()
        {
            InitializeComponent();
            ManagerContainer.ManagerStartEvent += new ManagerStartedEventHandler(this.Manager_StartStatusEvent);
            this.Text = "Alchemi Manager";
            Logger.LogHandler += new LogEventHandler(LogHandler);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
				this.TrayIcon.Dispose();		
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ManagerForm));
			this.uiStartButton = new System.Windows.Forms.Button();
			this.uiStopButton = new System.Windows.Forms.Button();
			this.TrayIcon = new System.Windows.Forms.NotifyIcon(this.components);
			this.TrayMenu = new System.Windows.Forms.ContextMenu();
			this.tmExit = new System.Windows.Forms.MenuItem();
			this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
			this.uiManagerMenuItem = new System.Windows.Forms.MenuItem();
			this.uiManagerUpdateMenuItem = new System.Windows.Forms.MenuItem();
			this.uiManagerExitMenuItem = new System.Windows.Forms.MenuItem();
			this.uiHelpMenuItem = new System.Windows.Forms.MenuItem();
			this.uiHelpAboutMenuItem = new System.Windows.Forms.MenuItem();
			this.uiActionsGroupBox = new System.Windows.Forms.GroupBox();
			this.uiLogMessagesLabel = new System.Windows.Forms.Label();
			this.uiLogMessagesTextBox = new System.Windows.Forms.TextBox();
			this.uiStatusBar = new System.Windows.Forms.StatusBar();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.panel1 = new System.Windows.Forms.Panel();
			this.panel2 = new System.Windows.Forms.Panel();
			this.panel3 = new System.Windows.Forms.Panel();
			this.monitorControl1 = new Alchemi.ManagerExec.MonitorControl();
			this.uiActionsGroupBox.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// uiStartButton
			// 
			this.uiStartButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.uiStartButton.Location = new System.Drawing.Point(28, 33);
			this.uiStartButton.Name = "uiStartButton";
			this.uiStartButton.Size = new System.Drawing.Size(153, 26);
			this.uiStartButton.TabIndex = 12;
			this.uiStartButton.Text = "Start";
			this.uiStartButton.Click += new System.EventHandler(this.uiStartButton_Click);
			// 
			// uiStopButton
			// 
			this.uiStopButton.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.uiStopButton.Location = new System.Drawing.Point(240, 33);
			this.uiStopButton.Name = "uiStopButton";
			this.uiStopButton.Size = new System.Drawing.Size(134, 26);
			this.uiStopButton.TabIndex = 13;
			this.uiStopButton.Text = "Stop";
			this.uiStopButton.Click += new System.EventHandler(this.uiStopButton_Click);
			// 
			// TrayIcon
			// 
			this.TrayIcon.ContextMenu = this.TrayMenu;
			this.TrayIcon.Icon = ((System.Drawing.Icon)(resources.GetObject("TrayIcon.Icon")));
			this.TrayIcon.Text = "Alchemi Manager";
			this.TrayIcon.Visible = true;
			this.TrayIcon.Click += new System.EventHandler(this.TrayIcon_Click);
			// 
			// TrayMenu
			// 
			this.TrayMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.tmExit});
			// 
			// tmExit
			// 
			this.tmExit.Index = 0;
			this.tmExit.Text = "Exit";
			this.tmExit.Click += new System.EventHandler(this.tmExit_Click);
			// 
			// MainMenu
			// 
			this.MainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.uiManagerMenuItem,
            this.uiHelpMenuItem});
			// 
			// uiManagerMenuItem
			// 
			this.uiManagerMenuItem.Index = 0;
			this.uiManagerMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.uiManagerUpdateMenuItem,
            this.uiManagerExitMenuItem});
			this.uiManagerMenuItem.Text = "Manager";
			// 
			// uiManagerUpdateMenuItem
			// 
			this.uiManagerUpdateMenuItem.Index = 0;
			this.uiManagerUpdateMenuItem.Text = "Maintenance...";
			this.uiManagerUpdateMenuItem.Click += new System.EventHandler(this.uiManagerUpdateMenuItem_Click);
			// 
			// uiManagerExitMenuItem
			// 
			this.uiManagerExitMenuItem.Index = 1;
			this.uiManagerExitMenuItem.Text = "Exit";
			this.uiManagerExitMenuItem.Click += new System.EventHandler(this.uiManagerExitMenuItem_Click);
			// 
			// uiHelpMenuItem
			// 
			this.uiHelpMenuItem.Index = 1;
			this.uiHelpMenuItem.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.uiHelpAboutMenuItem});
			this.uiHelpMenuItem.Text = "Help";
			// 
			// uiHelpAboutMenuItem
			// 
			this.uiHelpAboutMenuItem.Index = 0;
			this.uiHelpAboutMenuItem.Text = "About";
			this.uiHelpAboutMenuItem.Click += new System.EventHandler(this.uiHelpAboutMenuItem_Click);
			// 
			// uiActionsGroupBox
			// 
			this.uiActionsGroupBox.Controls.Add(this.uiLogMessagesLabel);
			this.uiActionsGroupBox.Controls.Add(this.uiStopButton);
			this.uiActionsGroupBox.Controls.Add(this.uiStartButton);
			this.uiActionsGroupBox.Controls.Add(this.uiLogMessagesTextBox);
			this.uiActionsGroupBox.Dock = System.Windows.Forms.DockStyle.Fill;
			this.uiActionsGroupBox.FlatStyle = System.Windows.Forms.FlatStyle.System;
			this.uiActionsGroupBox.Location = new System.Drawing.Point(0, 0);
			this.uiActionsGroupBox.Name = "uiActionsGroupBox";
			this.uiActionsGroupBox.Size = new System.Drawing.Size(434, 209);
			this.uiActionsGroupBox.TabIndex = 9;
			this.uiActionsGroupBox.TabStop = false;
			this.uiActionsGroupBox.Text = "Manager control";
			// 
			// uiLogMessagesLabel
			// 
			this.uiLogMessagesLabel.AutoSize = true;
			this.uiLogMessagesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.uiLogMessagesLabel.Location = new System.Drawing.Point(6, 73);
			this.uiLogMessagesLabel.Name = "uiLogMessagesLabel";
			this.uiLogMessagesLabel.Size = new System.Drawing.Size(54, 9);
			this.uiLogMessagesLabel.TabIndex = 16;
			this.uiLogMessagesLabel.Text = "Log Messages";
			this.uiLogMessagesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// uiLogMessagesTextBox
			// 
			this.uiLogMessagesTextBox.BackColor = System.Drawing.SystemColors.HighlightText;
			this.uiLogMessagesTextBox.Location = new System.Drawing.Point(6, 89);
			this.uiLogMessagesTextBox.Multiline = true;
			this.uiLogMessagesTextBox.Name = "uiLogMessagesTextBox";
			this.uiLogMessagesTextBox.ReadOnly = true;
			this.uiLogMessagesTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.uiLogMessagesTextBox.Size = new System.Drawing.Size(420, 109);
			this.uiLogMessagesTextBox.TabIndex = 15;
			this.uiLogMessagesTextBox.TabStop = false;
			// 
			// uiStatusBar
			// 
			this.uiStatusBar.Location = new System.Drawing.Point(0, 705);
			this.uiStatusBar.Name = "uiStatusBar";
			this.uiStatusBar.Size = new System.Drawing.Size(434, 25);
			this.uiStatusBar.TabIndex = 10;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.panel1);
			this.groupBox1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.groupBox1.Location = new System.Drawing.Point(0, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(434, 496);
			this.groupBox1.TabIndex = 11;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Grid overview";
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.monitorControl1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(3, 16);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(428, 477);
			this.panel1.TabIndex = 0;
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.uiActionsGroupBox);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel2.Location = new System.Drawing.Point(0, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(434, 209);
			this.panel2.TabIndex = 12;
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.groupBox1);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel3.Location = new System.Drawing.Point(0, 209);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(434, 496);
			this.panel3.TabIndex = 13;
			// 
			// monitorControl1
			// 
			this.monitorControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.monitorControl1.Location = new System.Drawing.Point(0, 0);
			this.monitorControl1.Margin = new System.Windows.Forms.Padding(2);
			this.monitorControl1.Name = "monitorControl1";
			this.monitorControl1.Size = new System.Drawing.Size(428, 477);
			this.monitorControl1.TabIndex = 12;
			// 
			// ManagerForm
			// 
			this.AcceptButton = this.uiStartButton;
			this.ClientSize = new System.Drawing.Size(434, 730);
			this.Controls.Add(this.panel3);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.uiStatusBar);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Menu = this.MainMenu;
			this.Name = "ManagerForm";
			this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Alchemi Manager";
			this.Load += new System.EventHandler(this.ManagerTemplateForm_Load);
			this.uiActionsGroupBox.ResumeLayout(false);
			this.uiActionsGroupBox.PerformLayout();
			this.groupBox1.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel2.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

        }
        #endregion

        //the children forms have their own load method.
        private void ManagerTemplateForm_Load(object sender, EventArgs e)
        {
            //this should normally not create any problems, but then during design time it doesnt work, so we need to catch any exceptions
            //that may occur during design time.
            AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(DefaultErrorHandler);
            Application.ThreadException += new ThreadExceptionEventHandler(Application_ThreadException);

            // avoid multiple instances
            bool isOnlyInstance = false;
            Mutex mtx = new Mutex(true, "AlcheuiManagerMenuItem_Mutex", out isOnlyInstance);
            if (!isOnlyInstance)
            {
                MessageBox.Show(this, "An instance of this application is already running. The program will now exit.", "Alchemi Manager", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                Application.Exit();
            }

            //normal startup. not a service
            _container = new ManagerContainer();
            // configuration en dur
            Configuration lConfig = new Configuration();
            EndPointConfiguration lManagerConfig = new EndPointConfiguration();
            lManagerConfig.RemotingMechanism = RemotingMechanism.TcpBinary;

			string lHostName = Dns.GetHostName(); ;
			IPHostEntry ipEntry = Dns.GetHostEntry(lHostName);
			IPAddress[] addr = ipEntry.AddressList;
			lManagerConfig.FriendlyName = lHostName;
			lManagerConfig.HostNameForPublishing = lHostName;
			lManagerConfig.Host = addr[0].ToString();
            lManagerConfig.Port = 9001;
            lConfig.EndPoints.Add("EndPoint", lManagerConfig);

            // ok la config est bonne :)
            lConfig.ConnectVerified = true;
            // set
            _container.Config = lConfig;

            // on lance le service d'update
            CaesarUpdater.Startup();

            // on lance direct le manager
            StartManager();

		

            // refresh
            RefreshUIControls(_container.Config);
            uiStartButton.Focus();
        }

        private void LogHandler(object sender, LogEventArgs e)
        {
            // Create a logger for use in this class
            ILog logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            switch (e.Level)
            {
                case LogLevel.Debug:
                    string message = e.Source + ":" + e.Member + " - " + e.Message;
                    logger.Debug(message, e.Exception);
                    break;
                case LogLevel.Info:
                    logger.Info(e.Message);
					break;
                case LogLevel.Error:
                    logger.Error(e.Message, e.Exception);
                    break;
                case LogLevel.Warn:
                    logger.Warn(e.Message, e.Exception);
                    break;
            }
        }

        protected bool Started
        {
            get
            {
                bool started = false;
                if (_container != null && _container.Started)
                {
                    started = true;
                }
                return started;
            }
        }
        protected void Exit()
        {
            StopManager();
            Application.Exit();
        }

        protected void StopManager()
        {
            if (Started)
            {
				// stop le monitor
				this.monitorControl1.Stop();

                uiStatusBar.Text = "Stopping Manager...";
                Log("Stopping Manager...");
                try
                {
                    _container.Stop();
                    _container = null;
                }
                catch (Exception ex)
                {
                    logger.Error("Error stopping manager", ex);
                }
                Log("Manager stopped.");
            }
            if (_container == null)
                _container = new ManagerContainer();

            RefreshUIControls(_container.Config);
        }

        protected void StartManager()
        {
            if (Started && _container != null)
            {
                RefreshUIControls(_container.Config);
                return;
            }

            uiStatusBar.Text = "Starting Manager...";

            Log("Attempting to start Manager...");

            if (_container == null)
                _container = new ManagerContainer();

            _container.RemotingConfigFile = Assembly.GetExecutingAssembly().Location + ".config";

            try
            {
                _container.Start();

                Log("Manager started");

                //for heirarchical stuff
                //				if (Config.Intermediate)
                //				{
                //					//Config.Id = Manager.Id;
                //					//Config.Dedicated = Manager.Dedicated;
                //				}

            }
            catch (Exception ex)
            {
                string errorMsg = string.Format("Could not start Manager. Reason: {0}{1}", Environment.NewLine, ex.Message);
                if (ex.InnerException != null)
                {
                    errorMsg += string.Format("{0}", ex.InnerException.Message);
                }
                Log(errorMsg);
                logger.Error(errorMsg, ex);
            }
			// strat le monitor
			this.monitorControl1.Start();

            RefreshUIControls(_container.Config);
        }


        #region UI Events

     

        private void uiStopButton_Click(object sender, EventArgs e)
        {
            StopManager();
        }

        private void uiStartButton_Click(object sender, EventArgs e)
        {
            StartManager();
        }

        private void tmExit_Click(object sender, EventArgs e)
        {
            Exit();
        }

        protected override void WndProc(ref Message m)
        {
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_CLOSE = 0xF060;
            if (m.Msg == WM_SYSCOMMAND & (int)m.WParam == SC_CLOSE)
            {
                // 'x' button clicked .. minimise to system tray
                Hide();
				// stop le monitor
				this.monitorControl1.Stop();
                return;
            }
            base.WndProc(ref m);
        }

        private void TrayIcon_Click(object sender, EventArgs e)
        {
            Restore();
        }

        private void uiManagerExitMenuItem_Click(object sender, EventArgs e)
        {
            Exit();
        }

		private void uiManagerUpdateMenuItem_Click(object sender, EventArgs e)
        {
			StorageMaintenanceForm maintenanceForm = new StorageMaintenanceForm(this.monitorControl1.Console);
			maintenanceForm.ShowDialog();

           
        }

        private void uiHelpAboutMenuItem_Click(object sender, EventArgs e)
        {
            new SplashScreen().ShowDialog();
        }

        private void uiLogMessagesTextBox_DoubleClick(object sender, EventArgs e)
        {
            uiLogMessagesTextBox.Clear();
        }


        #endregion

        #region Other Events

        static void DefaultErrorHandler(object sender, UnhandledExceptionEventArgs args)
        {
            Exception e = (Exception)args.ExceptionObject;
            HandleAllUnknownErrors(sender.ToString(), e);
        }

        public void Manager_StartStatusEvent(object sender, EventArgs e)
        {
           
        }

        private void Application_ThreadException(object sender, ThreadExceptionEventArgs e)
        {
            HandleAllUnknownErrors(sender.ToString(), e.Exception);
        }

        #endregion

        static void HandleAllUnknownErrors(string sender, Exception e)
        {
            logger.Error("Unknown Error from: " + sender, e);
        }

        protected void RefreshUIControls(Configuration Config)
        {
            //dont need to keep calling the property getter...
            //since it queries the status on each call.
            bool started = this.Started;

            if (started)
            {
                uiStartButton.Enabled = false;
                uiStopButton.Enabled = true;
                uiStatusBar.Text = "Manager Started.";
            }
            else
            {
                uiStartButton.Enabled = true;
                uiStopButton.Enabled = false;
                uiStatusBar.Text = "Manager Stopped.";
            }
        }

        private void Restore()
        {
            this.WindowState = FormWindowState.Normal;
            this.Show();
            this.Activate();
			// strat le monitor
			this.monitorControl1.Start();
        }

        protected void Log(string s)
        {
			this.BeginInvoke((MethodInvoker)delegate
			{
				if (uiLogMessagesTextBox != null)
				{
					if (uiLogMessagesTextBox.Text.Length + s.Length >= uiLogMessagesTextBox.MaxLength)
					{
						//remove all old stuff except the last N lines.
						int N = 20;
						string[] s1 = new string[N];
						for (int i = 0; i < N; i++)
						{
							s1[N - 1 -i] = uiLogMessagesTextBox.Lines[uiLogMessagesTextBox.Lines.Length - 1 - i];
						}
						uiLogMessagesTextBox.Lines = s1;
					}
					uiLogMessagesTextBox.AppendText(s + Environment.NewLine);
				}
			});
		}

       
    }


}