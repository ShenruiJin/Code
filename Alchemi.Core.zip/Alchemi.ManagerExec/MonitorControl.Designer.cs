﻿namespace Alchemi.ManagerExec
{
    partial class MonitorControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
			System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
			this.timerGraph = new System.Windows.Forms.Timer(this.components);
			this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
			this.panel1 = new System.Windows.Forms.Panel();
			this.labelNbThreads = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.labelNbExecutors = new System.Windows.Forms.Label();
			this.labelMaxPower = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.dataGridView1 = new System.Windows.Forms.DataGridView();
			this.ComlumnName = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColumnCPU = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.ColumnUsage = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridView2 = new System.Windows.Forms.DataGridView();
			this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
			this.buttonClearApp = new System.Windows.Forms.Button();
			this.panel2 = new System.Windows.Forms.Panel();
			this.buttonKillExec = new System.Windows.Forms.Button();
			this.buttonRestartExec = new System.Windows.Forms.Button();
			this.buttonClearExec = new System.Windows.Forms.Button();
			this.performanceGraph = new Alchemi.ManagerExec.PerformanceGraph();
			this.tableLayoutPanel1.SuspendLayout();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
			this.panel2.SuspendLayout();
			this.SuspendLayout();
			// 
			// timerGraph
			// 
			this.timerGraph.Interval = 2000;
			this.timerGraph.Tick += new System.EventHandler(this.timerGraph_Tick);
			// 
			// tableLayoutPanel1
			// 
			this.tableLayoutPanel1.ColumnCount = 1;
			this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
			this.tableLayoutPanel1.Controls.Add(this.performanceGraph, 0, 1);
			this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
			this.tableLayoutPanel1.Controls.Add(this.dataGridView1, 0, 2);
			this.tableLayoutPanel1.Controls.Add(this.dataGridView2, 0, 4);
			this.tableLayoutPanel1.Controls.Add(this.buttonClearApp, 0, 5);
			this.tableLayoutPanel1.Controls.Add(this.panel2, 0, 3);
			this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
			this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(2);
			this.tableLayoutPanel1.Name = "tableLayoutPanel1";
			this.tableLayoutPanel1.RowCount = 6;
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 70F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 30F));
			this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
			this.tableLayoutPanel1.Size = new System.Drawing.Size(362, 475);
			this.tableLayoutPanel1.TabIndex = 20;
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.labelNbThreads);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.labelNbExecutors);
			this.panel1.Controls.Add(this.labelMaxPower);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel1.Location = new System.Drawing.Point(2, 2);
			this.panel1.Margin = new System.Windows.Forms.Padding(2);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(358, 31);
			this.panel1.TabIndex = 21;
			// 
			// labelNbThreads
			// 
			this.labelNbThreads.AutoSize = true;
			this.labelNbThreads.Location = new System.Drawing.Point(249, 0);
			this.labelNbThreads.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelNbThreads.Name = "labelNbThreads";
			this.labelNbThreads.Size = new System.Drawing.Size(13, 13);
			this.labelNbThreads.TabIndex = 31;
			this.labelNbThreads.Text = "0";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(176, 0);
			this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(69, 13);
			this.label6.TabIndex = 30;
			this.label6.Text = "Nb Threads :";
			// 
			// labelNbExecutors
			// 
			this.labelNbExecutors.AutoSize = true;
			this.labelNbExecutors.Location = new System.Drawing.Point(76, 14);
			this.labelNbExecutors.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelNbExecutors.Name = "labelNbExecutors";
			this.labelNbExecutors.Size = new System.Drawing.Size(13, 13);
			this.labelNbExecutors.TabIndex = 29;
			this.labelNbExecutors.Text = "0";
			// 
			// labelMaxPower
			// 
			this.labelMaxPower.AutoSize = true;
			this.labelMaxPower.Location = new System.Drawing.Point(76, 0);
			this.labelMaxPower.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.labelMaxPower.Name = "labelMaxPower";
			this.labelMaxPower.Size = new System.Drawing.Size(13, 13);
			this.labelMaxPower.TabIndex = 28;
			this.labelMaxPower.Text = "0";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(2, 14);
			this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(77, 13);
			this.label2.TabIndex = 27;
			this.label2.Text = "Nb Executors :";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(14, 0);
			this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(66, 13);
			this.label1.TabIndex = 26;
			this.label1.Text = "Max Power :";
			// 
			// dataGridView1
			// 
			this.dataGridView1.AllowUserToAddRows = false;
			this.dataGridView1.AllowUserToDeleteRows = false;
			dataGridViewCellStyle1.BackColor = System.Drawing.Color.White;
			this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
			this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
			this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ComlumnName,
            this.ColumnCPU,
            this.ColumnUsage});
			this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView1.Location = new System.Drawing.Point(2, 107);
			this.dataGridView1.Margin = new System.Windows.Forms.Padding(2);
			this.dataGridView1.Name = "dataGridView1";
			this.dataGridView1.ReadOnly = true;
			this.dataGridView1.RowHeadersVisible = false;
			this.dataGridView1.RowTemplate.Height = 24;
			this.dataGridView1.Size = new System.Drawing.Size(358, 151);
			this.dataGridView1.TabIndex = 22;
			// 
			// ComlumnName
			// 
			this.ComlumnName.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.ComlumnName.FillWeight = 60F;
			this.ComlumnName.HeaderText = "Name";
			this.ComlumnName.Name = "ComlumnName";
			this.ComlumnName.ReadOnly = true;
			// 
			// ColumnCPU
			// 
			this.ColumnCPU.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.ColumnCPU.FillWeight = 20F;
			this.ColumnCPU.HeaderText = "CPU";
			this.ColumnCPU.Name = "ColumnCPU";
			this.ColumnCPU.ReadOnly = true;
			// 
			// ColumnUsage
			// 
			this.ColumnUsage.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.ColumnUsage.FillWeight = 20F;
			this.ColumnUsage.HeaderText = "Usage";
			this.ColumnUsage.Name = "ColumnUsage";
			this.ColumnUsage.ReadOnly = true;
			// 
			// dataGridView2
			// 
			this.dataGridView2.AllowUserToAddRows = false;
			this.dataGridView2.AllowUserToDeleteRows = false;
			dataGridViewCellStyle2.BackColor = System.Drawing.Color.White;
			this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle2;
			this.dataGridView2.BackgroundColor = System.Drawing.SystemColors.ControlLightLight;
			this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
			this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3});
			this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dataGridView2.Location = new System.Drawing.Point(2, 292);
			this.dataGridView2.Margin = new System.Windows.Forms.Padding(2);
			this.dataGridView2.Name = "dataGridView2";
			this.dataGridView2.ReadOnly = true;
			this.dataGridView2.RowHeadersVisible = false;
			this.dataGridView2.RowTemplate.Height = 24;
			this.dataGridView2.Size = new System.Drawing.Size(358, 151);
			this.dataGridView2.TabIndex = 23;
			// 
			// dataGridViewTextBoxColumn1
			// 
			this.dataGridViewTextBoxColumn1.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn1.FillWeight = 50F;
			this.dataGridViewTextBoxColumn1.HeaderText = "User name";
			this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
			this.dataGridViewTextBoxColumn1.ReadOnly = true;
			// 
			// dataGridViewTextBoxColumn2
			// 
			this.dataGridViewTextBoxColumn2.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn2.FillWeight = 20F;
			this.dataGridViewTextBoxColumn2.HeaderText = "Threads";
			this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
			this.dataGridViewTextBoxColumn2.ReadOnly = true;
			// 
			// dataGridViewTextBoxColumn3
			// 
			this.dataGridViewTextBoxColumn3.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill;
			this.dataGridViewTextBoxColumn3.FillWeight = 30F;
			this.dataGridViewTextBoxColumn3.HeaderText = "Started";
			this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
			this.dataGridViewTextBoxColumn3.ReadOnly = true;
			// 
			// buttonClearApp
			// 
			this.buttonClearApp.Location = new System.Drawing.Point(3, 448);
			this.buttonClearApp.Name = "buttonClearApp";
			this.buttonClearApp.Size = new System.Drawing.Size(125, 23);
			this.buttonClearApp.TabIndex = 25;
			this.buttonClearApp.Text = "Clear Applications";
			this.buttonClearApp.UseVisualStyleBackColor = true;
			this.buttonClearApp.Click += new System.EventHandler(this.buttonClearApp_Click);
			// 
			// panel2
			// 
			this.panel2.Controls.Add(this.buttonKillExec);
			this.panel2.Controls.Add(this.buttonRestartExec);
			this.panel2.Controls.Add(this.buttonClearExec);
			this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel2.Location = new System.Drawing.Point(3, 263);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(356, 24);
			this.panel2.TabIndex = 26;
			// 
			// buttonKillExec
			// 
			this.buttonKillExec.Location = new System.Drawing.Point(267, 1);
			this.buttonKillExec.Name = "buttonKillExec";
			this.buttonKillExec.Size = new System.Drawing.Size(86, 23);
			this.buttonKillExec.TabIndex = 27;
			this.buttonKillExec.Text = "Kill";
			this.buttonKillExec.UseVisualStyleBackColor = true;
			this.buttonKillExec.Click += new System.EventHandler(this.buttonKillExec_Click);
			// 
			// buttonRestartExec
			// 
			this.buttonRestartExec.Location = new System.Drawing.Point(153, 1);
			this.buttonRestartExec.Name = "buttonRestartExec";
			this.buttonRestartExec.Size = new System.Drawing.Size(108, 23);
			this.buttonRestartExec.TabIndex = 26;
			this.buttonRestartExec.Text = "Restart Executors";
			this.buttonRestartExec.UseVisualStyleBackColor = true;
			this.buttonRestartExec.Click += new System.EventHandler(this.buttonRestartExec_Click);
			// 
			// buttonClearExec
			// 
			this.buttonClearExec.Location = new System.Drawing.Point(4, 0);
			this.buttonClearExec.Name = "buttonClearExec";
			this.buttonClearExec.Size = new System.Drawing.Size(107, 23);
			this.buttonClearExec.TabIndex = 25;
			this.buttonClearExec.Text = "Clear Executors";
			this.buttonClearExec.UseVisualStyleBackColor = true;
			this.buttonClearExec.Click += new System.EventHandler(this.buttonClearExec_Click);
			// 
			// performanceGraph
			// 
			this.performanceGraph.BackColor = System.Drawing.Color.Black;
			this.performanceGraph.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.performanceGraph.Dock = System.Windows.Forms.DockStyle.Fill;
			this.performanceGraph.ForeColor = System.Drawing.SystemColors.ControlLightLight;
			this.performanceGraph.GridColor = System.Drawing.Color.Green;
			this.performanceGraph.GridPixels = 10;
			this.performanceGraph.InitialHeight = 100;
			this.performanceGraph.Location = new System.Drawing.Point(2, 37);
			this.performanceGraph.Margin = new System.Windows.Forms.Padding(2);
			this.performanceGraph.Name = "performanceGraph";
			this.performanceGraph.Size = new System.Drawing.Size(358, 66);
			this.performanceGraph.TabIndex = 20;
			// 
			// MonitorControl
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.Controls.Add(this.tableLayoutPanel1);
			this.Margin = new System.Windows.Forms.Padding(2);
			this.Name = "MonitorControl";
			this.Size = new System.Drawing.Size(362, 475);
			this.tableLayoutPanel1.ResumeLayout(false);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
			this.panel2.ResumeLayout(false);
			this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Timer timerGraph;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private PerformanceGraph performanceGraph;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label labelNbThreads;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label labelNbExecutors;
        private System.Windows.Forms.Label labelMaxPower;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn ComlumnName;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnCPU;
        private System.Windows.Forms.DataGridViewTextBoxColumn ColumnUsage;
		private System.Windows.Forms.DataGridView dataGridView2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
		private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
		private System.Windows.Forms.Button buttonClearApp;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button buttonClearExec;
		private System.Windows.Forms.Button buttonRestartExec;
		private System.Windows.Forms.Button buttonKillExec;
    }
}
