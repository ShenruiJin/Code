﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using Alchemi.Core.Manager.Storage;
using Alchemi.Core.Owner;
using Alchemi.Core;

namespace Alchemi.ManagerExec
{
    public partial class MonitorControl : UserControl
    {
        private ConsoleNode _console;
        public ConsoleNode Console
        {
            get {
				if (_console == null)
				{
					GConnection lConnection = new GConnection("127.0.0.1", 9001, "admin", "admin");
					_console = new ConsoleNode(lConnection);
				}
				return _console; 
			}
        }

        List<ExecutorStorageView> _dataView = new List<ExecutorStorageView>();
        public List<ExecutorStorageView> DataView
        {
            get { return _dataView; }
        }

        public MonitorControl()
        {
            InitializeComponent();
            // ajoute des graphs
            performanceGraph.CreateChart(Color.Red);
            performanceGraph.CreateChart(Color.Lime);
        }

		/// <summary>
		/// Un menu pour chaque executro
		/// </summary>
		/// <param name="N"></param>
		/// <returns></returns>
		private ContextMenuStrip ExecutorMenu(string ID)
		{
			ContextMenuStrip lMenu = new ContextMenuStrip();

			ToolStripMenuItem RestartMenu = new ToolStripMenuItem("Restart");
			RestartMenu.Name = "Restart";
			RestartMenu.Click += new EventHandler(RestartMenu_Click);
			RestartMenu.Tag = ID;

			ToolStripMenuItem KillMenu = new ToolStripMenuItem("Kill");
			KillMenu.Name = "Kill";
			KillMenu.Click += new EventHandler(KillMenu_Click);
			KillMenu.Tag = ID;

			ToolStripItem[] items = new ToolStripItem[] { RestartMenu, KillMenu};
			lMenu.Items.AddRange(items);

			return lMenu;
		}

		void RestartMenu_Click(object sender, EventArgs e)
		{
			try
			{
				string ID = (string) ((ToolStripMenuItem)sender).Tag;
				_console.Manager.Admon_RestartExecutor(_console.Credentials, ID);
			}
			catch {}
			RefreshExecutors();
		}

		void KillMenu_Click(object sender, EventArgs e)
		{
			try
			{
				string ID = (string)((ToolStripMenuItem)sender).Tag;
				_console.Manager.Admon_KillExecutor(_console.Credentials, ID);
			}
			catch {}
			RefreshExecutors();
		}

		/// <summary>
		/// Met à jour la liste des executor
		/// </summary>
		private void RefreshExecutors()
		{
			// on remplit la liste des executors
			ExecutorStorageView[] execs = Console.Manager.Admon_GetExecutors(Console.Credentials);
			this.dataGridView1.Rows.Clear();
			foreach (ExecutorStorageView view in execs)
			{
				int n = this.dataGridView1.Rows.Add();
				this.dataGridView1.Rows[n].Cells[0].Value = view.Architecture + " (" + view.Username + " " + view.HostName + ")";
				this.dataGridView1.Rows[n].Cells[1].Value = String.Format("{0} GHz", Math.Round(view.MaxCpu / 1000.0, 6));
				this.dataGridView1.Rows[n].Cells[2].Value = (100 - view.AvailableCpu).ToString() + "%";
				// si pas connecté alors on le grise
				if (!view.Connected)
				{
					this.dataGridView1.Rows[n].DefaultCellStyle.BackColor = Color.LightGray;
				}
				this.dataGridView1.Rows[n].ContextMenuStrip = ExecutorMenu(view.ExecutorId);
			}
		}

		private void RefreshApplications()
		{
			// idem pour les applications en cours
			ApplicationStorageView[] apps = Console.Manager.Admon_GetLiveApplicationList(Console.Credentials);
			this.dataGridView2.Rows.Clear();
			// on le fait en deux passes
			foreach (ApplicationStorageView app in apps)
			{
				// on ignore les applis terminées  
				if (app.StateString == "Finished")
					continue;

				int n = this.dataGridView2.Rows.Add();
				this.dataGridView2.Rows[n].Cells[0].Value = app.ApplicationName + " - " + app.StateString;
				this.dataGridView2.Rows[n].Cells[1].Value = (app.TotalThreads - app.UnfinishedThreads).ToString() + "/" + app.TotalThreads.ToString();
				this.dataGridView2.Rows[n].Cells[2].Value = app.TimeCreated.ToShortTimeString();
			}
			// les applis terminées
			foreach (ApplicationStorageView app in apps)
			{
				if (app.StateString != "Finished")
					continue;

				int n = this.dataGridView2.Rows.Add();
				this.dataGridView2.Rows[n].Cells[0].Value = app.ApplicationName + " - " + app.StateString;
				this.dataGridView2.Rows[n].Cells[1].Value = (app.TotalThreads - app.UnfinishedThreads).ToString() + "/" + app.TotalThreads.ToString();
				TimeSpan timer = (app.TimeCompleted - app.TimeCreated);
				string timeThread = String.Format("{0:00}m{1:00}s", timer.Minutes, timer.Seconds);
				this.dataGridView2.Rows[n].Cells[2].Value = app.TimeCompleted.ToShortDateString() + " (" + timeThread + ")";
				this.dataGridView2.Rows[n].DefaultCellStyle.BackColor = Color.LightGray;
			}
		}

		int _localCounterBeforePowerRefresh = 0;
		int _localCounterBeforeAppRefresh = 0;
		double powerUsage;
        double powerAvailable;
        private void timerGraph_Tick(object sender, EventArgs e)
        {
			_localCounterBeforePowerRefresh--;
			if (_localCounterBeforePowerRefresh < 0)
            {
				// affiche le powerMeter
                SystemSummary summary = Console.Manager.Admon_GetSystemSummary(Console.Credentials);
                powerUsage = summary.PowerUsage;
                powerAvailable = summary.PowerAvailable;
                labelMaxPower.Text = summary.MaxPower;
                labelNbExecutors.Text = summary.TotalExecutors.ToString();
                labelNbThreads.Text = summary.UnfinishedThreads.ToString();

				_localCounterBeforePowerRefresh = 8; // 8 * 2sec
            }

			// affiche le graph
            performanceGraph.UpdateChart(0, powerUsage);
            performanceGraph.UpdateChart(1, powerAvailable);

			// update les exec 
			_localCounterBeforeAppRefresh--;
			if (_localCounterBeforeAppRefresh < 0)
			{
				RefreshExecutors();
				RefreshApplications();

				_localCounterBeforeAppRefresh = 15; // 30 sec
			}
        }


		internal void Start()
		{
			timerGraph.Enabled = true;
		}

		internal void Stop()
		{
			timerGraph.Enabled = false;
		}

		// un peu de maintenance rapide
		private void buttonClearApp_Click(object sender, EventArgs e)
		{
			StorageMaintenanceParameters result = new StorageMaintenanceParameters();
			result.RemoveAllApplications = true;
			try
			{
				_console.Manager.Admon_PerformStorageMaintenance(_console.Credentials, result);
			}
			catch  
			{
			}
			_localCounterBeforePowerRefresh = 0;
			_localCounterBeforeAppRefresh = 0;
		}

		private void buttonClearExec_Click(object sender, EventArgs e)
		{
			StorageMaintenanceParameters result = new StorageMaintenanceParameters();
			result.RemoveAllExecutors = true;
			try
			{
				_console.Manager.Admon_PerformStorageMaintenance(_console.Credentials, result);
			}
			catch 
			{
			}
			_localCounterBeforePowerRefresh = 0;
			_localCounterBeforeAppRefresh = 0;
		}

		/// <summary>
		/// Kill
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void buttonKillExec_Click(object sender, EventArgs e)
		{
			ExecutorStorageView[] execs = Console.Manager.Admon_GetExecutors(Console.Credentials);
			foreach (ExecutorStorageView view in execs)
			{
				try
				{
                    _console.Manager.Admon_KillExecutor(_console.Credentials, view.ExecutorId);
				}
				catch
				{
				}
			}
			RefreshExecutors();
		}

		/// <summary>
		/// Restart
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void buttonRestartExec_Click(object sender, EventArgs e)
		{
			ExecutorStorageView[] execs = Console.Manager.Admon_GetExecutors(Console.Credentials);
			foreach (ExecutorStorageView view in execs)
			{
				try
				{
                    _console.Manager.Admon_RestartExecutor(_console.Credentials, view.ExecutorId);
				}
				catch
				{
				}
			}
			RefreshExecutors();
		}
	}
}
