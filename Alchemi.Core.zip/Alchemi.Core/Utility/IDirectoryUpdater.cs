﻿using System;
using System.Collections.Generic;
using System.Text;
using Alchemi.Core.Owner;
using System.IO;
using System.Collections;
using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting;
using System.Runtime.Serialization.Formatters;
using System.Runtime.Remoting.Channels.Tcp;

namespace Alchemi.Core.Utility
{
    /// <summary>
    /// Class permettant d'updater les fichiers statics
    /// </summary>
    public interface IDirectoryUpdater 
    {
        /// <summary>
        /// Retourne les fichiers a updater
        /// </summary>
        /// <param name="currentVersion">la version installée sur l'executor</param>
        /// <returns>les fichiers a mettre a jour (ensemble vide si pas necessaire)</returns>
        FileDependencyCollection GetFiles(int currentVersion);
         
    }
 
}
