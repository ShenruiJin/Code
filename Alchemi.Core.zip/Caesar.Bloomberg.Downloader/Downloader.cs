﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Caesar.Bloomberg.Downloader.Config;
using CaesarApplication.DataProvider;
using CaesarApplication.Service.Strategy;
using GlobalDerivativesApplications.DynamicDataExchange.V2.Fields;
using log4net;
using PricingBase.DataProvider;
using PricingBase.Index;
using CaesarApplication.DataProvider.Prism;
using CaesarApplication.Service.Configuration;
using CaesarExtensions.Indices.Parser;
using GlobalDerivativesApplications.Data.MarketData;
using MarketData;
using System.Globalization;
using CaesarApplication.Service.Mail;
using CaesarExtensions.Indices.UtilityFunctions;
using FuncFramework.Helpers;
using CaesarApplication;
using CaesarCommon.Configuration;
using CaesarApplication.DataProvider.Helpers;

namespace Caesar.Bloomberg.Downloader
{
    public class Downloader
    {
        private readonly ILog logger = LogManager.GetLogger(typeof(Downloader));
        private readonly int nbRetries;
        private readonly DealServerHelper dealServerHelper;
        private const int GroupSize = 10;


        private IList<Func<int>> loadMethods = new List<Func<int>>();

        public Downloader()
        {
            nbRetries = ConfigurationLoader.NbDlRetries;
            dealServerHelper = new DealServerHelper(this);
        }

        /// <summary>
        /// Get universe of tickers associated to a configuration
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        internal IList<string> GetUniverse(Configuration config)
        {
            var provider = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, false, true, false, true, dataHandlersToUse: config.DataHandlersToUse, saveAsDefault: config.SaveDefaultSource.GetValueOrDefault(true));

            DateTime startDate = DateTime.Today;
            DateTime endDate = DateTime.Today;

            if (config.IncrementalLagInDays != null)
            {
                startDate =
                    config.StartDate.GetValueOrDefault(DateTime.Today).AddDays(-config.HorizonInDays);
                endDate = DateTime.Today.AddDays(-config.IncrementalLagInDays.GetValueOrDefault(0));
            }
            else
            {
                startDate =
                    config.StartDate.GetValueOrDefault(DateTime.Today).AddDays(-config.HorizonInDays);
                endDate = config.EndDate.GetValueOrDefault(DateTime.Today);
            }

            logger.InfoFormat("Start download for [{0}]-[{1}]", startDate, endDate);

            var childTickers = new List<string>();

            if (config.SpecialMode == "All Universe")
            {
                var universeManager = new IndexUniverseManager();
                var universe = universeManager.GetIndexesTickers(startDate, endDate);
                childTickers.AddRange(universe);
            }
            else if (config.Universes != null)
            {
                foreach (var universe in config.Universes)
                {
                    try
                    {
                        logger.InfoFormat("Start download Composition for [{0}]-[{1}]-[{2}]", startDate, endDate,
                            universe);

                        if (SophisHelper.GetBloombergTicker(universe).EndsWith("Index"))
                        {
                            var universe1 = universe;
                            var compositions = new List<TimeSerieDB>();

                            if (config.UniverseDates != null && config.UniverseDates.Length != 0)
                            {
                                foreach (var universeDate in config.UniverseDates)
                                {
                                    var date = universeDate;
                                    compositions.AddRange(Load(() => provider.Load(universe1.AsArray(),
                                        DataFieldsEnum.IndexcomponentsWeightsAndPrices.AsArray(),
                                        date,
                                        date), 1));
                                }
                            }
                            else
                            {
                                compositions.AddRange(Load(() => provider.Load(universe1.AsArray(),
                                    DataFieldsEnum.IndexcomponentsWeightsAndPrices.AsArray(),
                                    startDate,
                                    endDate), 1));
                            }

                            childTickers.AddRange(
                                compositions.SelectMany(x => x.Y)
                                    .Cast<IIndexComponentList>()
                                    .SelectMany(x => x.Components)
                                    .Select(x => x.Reference).Distinct()
                                    .ToArray());
                        }
                        else
                        {
                            childTickers.Add(universe);
                        }

                        logger.InfoFormat("End download Composition for [{0}]-[{1}]-[{2}]", startDate, endDate,
                            universe);
                    }
                    catch (Exception ex)
                    {
                        logger.Error(
                            string.Format("Download Composition for [{0}]-[{1}]-[{2}] raises an exception",
                                startDate, endDate, universe),
                            ex);
                    }
                }
            }

            if (config.Tickers != null)
            {
                childTickers = childTickers.Union(config.Tickers).ToList();
            }

            return childTickers.Distinct().ToList();
        }

        /// <summary>
        /// Generate files to optimize Prism querying
        /// </summary>
        internal void GenerateUniverseFiles(IList<string> tickers, Configuration config, DateTime startDate, DateTime endDate)
        {
            bool fileSet = false;
            NonAdjustedPricesPrismByPollingExecutable pricesPrism = new NonAdjustedPricesPrismByPollingExecutable();
            CustomFieldsPrismExecutableByPolling customDoublePrism = new CustomFieldsPrismExecutableByPolling(new DoubleCustomFieldsPrismExecutable());
            CustomFieldsPrismExecutableByPolling customStringPrism = new CustomFieldsPrismExecutableByPolling(new StringCustomFieldsPrismExecutable());
            IndexComponentsPrismExecutable indexComponentsPrism = new IndexComponentsPrismExecutable(null);

            IEnumerable<DataFieldsEnum> fieldList = config.DataFields.Select(o => (DataFieldsEnum)Enum.Parse(typeof(DataFieldsEnum), o));

            tickers = tickers.Select(o => o + " Equity").ToList();

            DateTime rebalancingDate = new DateTime(2014, 01, 01);
            for (int i = 2014; i <= DateTime.Today.Year && rebalancingDate <= DateTime.Today; i++)
            {
                int dayRebalancing = 0;

                for (int j = 0; j <= 3; j++)
                {
                    if (rebalancingDate.Month == 12)
                    {
                        dayRebalancing = BusinessDate.FindDay(i, 3, DayOfWeek.Friday, 3);
                        rebalancingDate = new DateTime(i, 3, dayRebalancing + 3);
                    }
                    else
                    {
                        dayRebalancing = BusinessDate.FindDay(i, (j + 1) * 3, DayOfWeek.Friday, 3);
                        rebalancingDate = new DateTime(i, (j + 1) * 3, dayRebalancing + 3);
                    }

                    if (rebalancingDate <= DateTime.Today)
                    {
                        foreach (string index in config.Universes)
                        {
                            string dateRange = rebalancingDate.ToString("yyyyMMdd") + rebalancingDate.ToString("yyyyMMdd");
                            var contentIndex = indexComponentsPrism.GetIndexDescriptionRequestContent(index.AsArray(), rebalancingDate, rebalancingDate);
                            var fileNameIndex = "request_rebalancing_date_" + dateRange + "_" + index + "IndexComposition.xml";
                            File.WriteAllText(Path.Combine(new CaesarSettingsManager().PrismDirectoryPath, fileNameIndex), contentIndex);
                        }
                    }
                }
            }

            foreach (DateTime date in GetDatesInPeriod(startDate, endDate))
            {
                foreach (DataFieldsEnum field in fieldList)
                {
                    fileSet = false;

                    string content = string.Empty;
                    string fileName = string.Empty;

                    string dateRange = date.ToString("yyyyMMdd") + date.ToString("yyyyMMdd");

                    if (field == DataFieldsEnum.Last)
                    {
                        content = pricesPrism.GetRequest(tickers.ToArray(), date, date, new PrismRequestKeys(PrismConstants.ServiceUnadjustedPrice, PrismConstants.ProductEquity, true));
                        fileName = "request_" + dateRange + "Prices.xml";
                        fileSet = true;
                    }
                    else if (new[] { DataFieldsEnum.Volume, DataFieldsEnum.MarketCap, DataFieldsEnum.EarningYield, DataFieldsEnum.BookToMarketRatio, DataFieldsEnum.FreeCashFlowYield }.Contains(field))
                    {
                        content = customDoublePrism.GetRequest(tickers.ToArray(), field, date, date);
                        fileName = "request_" + field.ToString() + "_" + dateRange + "Custom.xml";
                        fileSet = true;
                    }
                    else if (new[] { DataFieldsEnum.ICB_INDUSTRY_NAME, DataFieldsEnum.Currency }.Contains(field))
                    {
                        content = customStringPrism.GetRequest(tickers.ToArray(), field, date, date);
                        fileName = "request_" + field.ToString() + "_" + dateRange + "Custom.xml";
                        fileSet = true;
                    }

                    if (fileSet)
                    {
                        File.WriteAllText(Path.Combine(new CaesarSettingsManager().PrismDirectoryPath, fileName), content);
                    }
                }
            }
        }

        protected IList<DateTime> GetDatesInPeriod(DateTime startDate, DateTime endDate, bool removeWeekend = true)
        {
            IList<DateTime> allDates = new List<DateTime>();

            for (DateTime date = startDate; date <= endDate; date = date.AddDays(1))
            {
                if (date != startDate && date.DayOfWeek != DayOfWeek.Sunday && date.DayOfWeek != DayOfWeek.Saturday)
                {
                    allDates.Add(date);
                }
            }

            return allDates;
        }

        /// <summary>
        /// Prepare tasks from a configuration
        /// </summary>
        /// <param name="config"></param>
        /// <returns></returns>
        private IList<Func<int>> PrepareLoadTask(Configuration config, int groupBy = 50)
        {
            IList<Func<int>> loadMethodsConfig = new List<Func<int>>();

            var universe = GetUniverse(config);

            var length = Math.Abs(universe.Count / groupBy) + 1;

            for (int i = 0; i < length; i++)
            {
                int countBatchTicker = universe.Count - i * groupBy;

                var batchTickers = universe.ToList().GetRange(i * groupBy, countBatchTicker < groupBy ? countBatchTicker : groupBy);

                loadMethodsConfig.Add(() => Load(config, batchTickers));
            }

            return loadMethodsConfig;
        }

        /// <summary>
        /// Loading data from configuration
        /// </summary>
        /// <param name="configuration"></param>
        /// <returns></returns>
        public int Load(DownloadConfig configuration)
        {
            var runningStatus = 0;

            foreach (Configuration config in configuration.Configurations)
            {
                loadMethods.AddRange(PrepareLoadTask(config));
            }

            logger.Info(loadMethods.Count + " to be loaded");


            var returnCodes = loadMethods.ToArray().AsParallel().WithDegreeOfParallelism(Environment.ProcessorCount - 1).Select(x => x()).ToArray();

            return returnCodes.FirstOrDefault(x => x != 0);
        }

        public int Load(Configuration config, IList<string> childTickers)
        {
            int runningStatus = 0;

            TimeSeriesProvider timeSeriesProvider = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree,
                false, true, false, true, dataHandlersToUse: config.DataHandlersToUse, saveAsDefault: config.SaveDefaultSource.GetValueOrDefault(true));

            timeSeriesProvider.AddExecutable("PRISM_ON_DEMAND", new PrismOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_ON_DEMAND", new PrismStringOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_SNAPSHOT_ON_DEMAND", new PrismSnapshotOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_SNAPSHOT_ON_DEMAND", new DatePrismSnapshotOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_SNAPSHOT_ON_DEMAND", new StringPrismSnapshotOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_SNAPSHOT_ON_DEMAND", new DoublePrismSnapshotOnDemandExecutable());
            timeSeriesProvider.AddExecutable("PRISM_SNAPSHOT_ON_DEMAND", new DoubleUnDatedSnapshotOnDemandExecutable());

            DateTime startDate = DateTime.Today;
            DateTime endDate = DateTime.Today;

            if (config.IncrementalLagInDays != null)
            {
                startDate =
                    config.StartDate.GetValueOrDefault(DateTime.Today).AddDays(-config.HorizonInDays);
                endDate = DateTime.Today.AddDays(-config.IncrementalLagInDays.GetValueOrDefault(0));
            }
            else
            {
                startDate =
                    config.StartDate.GetValueOrDefault(DateTime.Today).AddDays(-config.HorizonInDays);
                endDate = config.EndDate.GetValueOrDefault(DateTime.Today);
            }

            logger.InfoFormat("Start download for [{0}]-[{1}]", startDate, endDate);

            var nbTickersToCompute = childTickers.Count;
            var nbComputedTickers = 0;

            IEnumerable<DataFieldsEnum> fieldsToRequestAvailable = config.DataFields
                .Where(o => timeSeriesProvider.ManagedFieldsAsStrings.Contains(o))
                .Select(
                    x => (DataFieldsEnum)Enum.Parse(typeof(DataFieldsEnum), x));

            logger.Info("Load from ticker " + childTickers.First() + " to " + childTickers.Last());

            logger.Info("Following fields will be requested " + string.Join(", ", fieldsToRequestAvailable));

            foreach (var childrenGrp in childTickers.Distinct().Group(GroupSize))
            {
                var childrenGrpAsString = childrenGrp.Stringify(",");

                try
                {
                    nbComputedTickers++;
                    logger.InfoFormat("Start download for [{0}]-[{1}]-[{2}]  {3}/{4}", startDate, endDate,
                        childrenGrpAsString,
                        nbComputedTickers, nbTickersToCompute);

                    foreach (var dataField in fieldsToRequestAvailable)
                    {
                        logger.DebugFormat("Wait [{4}] download for [{0}]-[{1}]-[.{2}.{3}]", startDate, endDate,
                            childrenGrpAsString, dataField, config.Temporization);

                        Thread.Sleep(config.Temporization);

                        logger.InfoFormat("Start download for [{0}]-[{1}]-[{2}.{3}]", startDate, endDate,
                            childrenGrpAsString,
                            dataField);

                        try
                        {
                            var tickers = childrenGrp;
                            var field = dataField;
                            var timeSeries =
                                Load(
                                    () =>
                                        timeSeriesProvider.Load(tickers, field.AsArray(), startDate,
                                            endDate), tickers.Length);

                            // Break to the next instrument
                            if (Program.LastMissingBreak && timeSeries.Count == 0 && field == DataFieldsEnum.Last)
                            {
                                CaesarApplication.Service.Logging.LoggingService.Warn(GetType(), "LastMissingBreak flag setted to true and Last returned no data for instrument " + childrenGrpAsString + " passing to the next instrument");
                                break;
                            }

                            if (timeSeries != null)
                            {
                                tickers.ForEach(childTicker =>
                                {
                                    var childSeries = timeSeries.Where(x => x.Instrument == childTicker).ToList();
                                    if (childSeries.Count != 1)
                                    {
                                        runningStatus = UpdateRunningStatus(runningStatus, -20);
                                        logger.WarnFormat(
                                            "Download for [{0}]-[{1}]-[{2}.{3}] returns invalid TimeSeries count [{5}]",
                                            startDate, endDate, childTicker, dataField, childSeries.Count);
                                    }
                                    else
                                    {
                                        if (!childSeries[0].X.Any())
                                        {
                                            runningStatus = UpdateRunningStatus(runningStatus, -30);
                                            logger.WarnFormat(
                                                "Download for [{0}]-[{1}]-[{2}.{3}] returns a timeserie with no value",
                                                startDate, endDate, childTicker, dataField);
                                        }
                                        else
                                        {
                                            logger.InfoFormat(
                                                "Download for [{0}]-[{1}]-[{2}.{3}] returns a timeserie with [{4}] values",
                                                startDate, endDate, childTicker, dataField, childSeries[0].X.Count());
                                        }
                                    }
                                });
                            }
                            else
                            {
                                runningStatus = UpdateRunningStatus(runningStatus, -10);
                                logger.WarnFormat("Download for [{0}]-[{1}]-[{2}.{3}] returns null TimeSeries",
                                    startDate, endDate, childrenGrp, dataField);
                            }
                        }
                        catch (Exception ex)
                        {
                            logger.Error(
                                string.Format("Download for [{0}]-[{1}]-[{2}.{3}] raises an exception", startDate,
                                    endDate, childrenGrpAsString, dataField), ex);
                            runningStatus = UpdateRunningStatus(runningStatus, 200);
                        }

                        logger.InfoFormat("End download for [{0}]-[{1}]-[{2}.{3}] {4}/{5}", startDate, endDate,
                            childrenGrpAsString, dataField, nbComputedTickers, nbTickersToCompute);
                    }

                    logger.InfoFormat("End download for [{0}]-[{1}]-[{2}]", startDate, endDate, childrenGrpAsString);
                }
                catch (Exception ex)
                {
                    logger.ErrorFormat("End download for [{0}]-[{1}]-[{2}] {3}/{4}", startDate, endDate, childrenGrpAsString,
                        nbComputedTickers, nbTickersToCompute);
                    logger.Error(ex);
                    runningStatus = UpdateRunningStatus(runningStatus, 300);
                }
            }

            logger.Info("Download end for given configuration");

            return runningStatus;
        }

        private IList<TimeSerieDB> Load(Func<IList<TimeSerieDB>> loadFunc, int ndResultsExpected)
        {
            int nbTries = 0;
            Exception lastEx = null;

            while (nbTries < nbRetries)
            {
                try
                {
                    var ts = loadFunc();

                    if (ts[0].Count == 0)
                    {
                        Program.HasMissingData = true;

                        LogManager.GetLogger("MissingDataLogger")
                            .Error("Missing data for instrument : "
                                   + ts[0].Instrument
                                   + ", field : "
                                   + ts[0].FieldName
                                   + ", start date : "
                                   + ts[0].StartDate
                                   + ", end date : "
                                   + ts[0].EndDate);
                        return ts;
                    }
                    else if (nbTries < nbRetries - 1 && ts.Count < ndResultsExpected)
                    {
                        logger.DebugFormat("TimeSeries count [{0}] with first serie with [{1}] values", ts.Count, ts.Any() ? ts[0].Count.ToString() : "NaN");
                        if (Program.IsDealServerSlave)
                        {
                            RelaunchDealServer();
                        }
                    }
                    else
                    {
                        return ts;
                    }
                }
                catch (Exception ex)
                {
                    logger.Error(ex);

                    lastEx = ex;

                    if (Program.IsDealServerSlave)
                    {
                        RelaunchDealServer();
                    }

                    if (nbTries >= nbRetries)
                    {
                        throw;
                    }
                }

                nbTries++;
            }
            throw lastEx;
        }

        private void RelaunchDealServer()
        {
            var execPath = ConfigurationLoader.DealServerPath;

            logger.DebugFormat("Start error procedure");

            dealServerHelper.KillDealServer();

            logger.DebugFormat("Start new DealServer proc [{0}]", execPath);
            dealServerHelper.LaunchDealServer(execPath, Program.DealServerArguments);
            logger.DebugFormat("Started new DealServer proc [{0}]", execPath);

            logger.DebugFormat("Wait new DealServer proc [{0}]", execPath);
            Thread.Sleep(TimeSpan.FromSeconds(20));

            logger.DebugFormat("Reconnecting...");
            logger.DebugFormat("Reconnected");

            logger.WarnFormat("End error procedure");
        }

        private int UpdateRunningStatus(int currentErrorCode, int errorCode)
        {
            if (errorCode > currentErrorCode)
            {
                return errorCode;
            }

            return currentErrorCode;
        }

        public void DownloadAttachements(DownloadConfig configuration)
        {
            if (configuration.MailDownloads != null && configuration.MailDownloads.Any())
            {
                var mailDownloader = new MailDownloader();
                var attachementCopyer = new AttachementCopyer();

                foreach (var mailAttachementDownloadParameters in configuration.MailDownloads)
                {
                    var mails = mailDownloader.Download(mailAttachementDownloadParameters.Mail);

                    foreach (var attachementCopyParameters in mailAttachementDownloadParameters.Attachements)
                    {
                        attachementCopyer.Copy(mails, attachementCopyParameters);
                    }
                }
            }
        }

        public int LoadFromCsv(CsvImport[] csvImports)
        {
            List<TimeSerieDB> seriesToSave = new List<TimeSerieDB>();

            int returnCode = 0;
            int count = 0;
            var provider = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, false, true, false, true, dataHandlersToUse: new string[] { "Cache", "DB" });

            if (csvImports == null)
            {
                logger.ErrorFormat("No csv configurations found");
                return 250;
            }

            foreach (var csvImport in csvImports)
            {
                foreach (
                    var fileName in
                    GetFileNamesToTreat(csvImport))
                {
                    csvImport.FileLocation = fileName;

                    var parser = ParserFactory.GetCsvParser(csvImport.CsvFormatId);
                    ++count;
                    logger.InfoFormat("Currently importing serie {0}/{1}.", count, csvImports.Length);
                    if ((csvImport.Ticker == null && csvImport.TickerColumnName == null) || csvImport.DataField == null ||
                        csvImport.FileLocation == null)
                    {
                        logger.ErrorFormat(
                            " Fail To import data from {0}, ticker : {1}, DataField : {2}, Column name: {3} doesn't exist : DataField or Ticker or File location is null!}",
                            csvImport.FileLocation, csvImport.Ticker, csvImport.DataField, csvImport.CsvColumnName);
                        returnCode = returnCode != 0 ? returnCode : 200;
                        continue;
                    }
                    if (!File.Exists(csvImport.FileLocation) &&
                        !File.Exists(Path.Combine(Path.GetDirectoryName(csvImport.FileLocation),
                            Path.GetFileNameWithoutExtension(csvImport.FileLocation) + ".xlsx")))
                    {
                        logger.ErrorFormat("No file found, file {0} doesn't exist", csvImport.FileLocation);
                        returnCode = returnCode != 0 ? returnCode : 210;
                        continue;
                    }
                    DataFieldsEnum outField;
                    if (!Enum.TryParse<DataFieldsEnum>(csvImport.DataField, out outField))
                    {
                        logger.ErrorFormat(
                            "Fail To import data from {0}, ticker : {1}, DataField : {2}, Column name: {3} doesn't exist : DataField does not exits !}",
                            csvImport.FileLocation, csvImport.Ticker, csvImport.DataField, csvImport.CsvColumnName);
                        returnCode = returnCode != 0 ? returnCode : 230;
                        continue;
                    }

                    try
                    {
                        logger.InfoFormat("Import from {0}, ticker : {1}, DataField : {2}, Column name: {3}!",
                            csvImport.FileLocation, csvImport.Ticker, csvImport.DataField,
                            csvImport.CsvColumnName ?? string.Empty);
                        var seriesToImport = parser.Load(csvImport);

                        seriesToImport.ForEach(serie =>
                        {
                            serie.Source = csvImport.Source;
                            serie.Field = outField;
                            seriesToSave.Add(serie);
                            int nbValuesToImport = serie.Count;
                            logger.InfoFormat(
                                "Try saving {4} values from {0}, ticker : {1}, DataField : {2}, Column name: {3}!",
                                csvImport.FileLocation, serie.Instrument, csvImport.DataField,
                                csvImport.CsvColumnName ?? string.Empty, nbValuesToImport);
                        });

                        provider.Save(seriesToSave);

                        MoveToTreatedDirectory(csvImport, fileName);
                    }
                    catch (Exception ex)
                    {
                        returnCode = returnCode != 0 ? returnCode : 240;
                        logger.ErrorFormat(
                            "Fail To import data from {0}, ticker : {1}, DataField : {2}, Column name: {3} doesn't exist:\n {4}",
                            csvImport.FileLocation, csvImport.Ticker, csvImport.DataField, csvImport.CsvColumnName,
                            ex.Message);
                    }
                    finally
                    {
                        seriesToSave.Clear();
                    }
                }
            }

            return returnCode;
        }

        private static string[] GetFileNamesToTreat(CsvImport csvImport)
        {
            var res = !string.IsNullOrEmpty(csvImport.DirectoryLocation) ?
                new DirectoryInfo(csvImport.DirectoryLocation).GetFileSystemInfos().Where(x => x.Attributes != FileAttributes.Directory).OrderBy(x => x.LastWriteTime).ToArray()
                : new FileInfo(csvImport.FileLocation).AsArray();

            var fileNamesToExclude = !string.IsNullOrEmpty(csvImport.TreatedDirectory) &&
                                     Directory.Exists(csvImport.TreatedDirectory)
                ? new DirectoryInfo(csvImport.TreatedDirectory).GetFileSystemInfos().Where(x => x.Attributes != FileAttributes.Directory).ToArray() : new FileSystemInfo[] { };

            return res.Where(x => !fileNamesToExclude.Any(fte => Path.GetFileName(x.FullName) == Path.GetFileName(fte.FullName) && fte.LastWriteTime >= x.LastWriteTime)).Select(x => x.FullName).ToArray();
        }

        private void MoveToTreatedDirectory(CsvImport csvImport, string fileName)
        {
            if (!string.IsNullOrEmpty(csvImport.TreatedDirectory))
            {
                var destinationFile = Path.Combine(csvImport.TreatedDirectory, Path.GetFileName(fileName));

                try
                {
                    if (!Directory.Exists(csvImport.TreatedDirectory))
                    {
                        Directory.CreateDirectory(csvImport.TreatedDirectory);
                    }

                    File.Copy(fileName, destinationFile, true);
                }
                catch (Exception ex)
                {
                    logger.ErrorFormat("Fail to copy {0} to {1} : {2}", fileName, destinationFile, ex);
                }
            }
        }

        /// <summary>
        /// Import CSV file - specific to BNPIHDUG to be factorized
        /// </summary>
        public static void ImportCSV(IList<string> filePaths, IList<string> fieldsToRetrieve)
        {
            TimeSerieDB indexQuote = new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(),
                string.Empty, DataFieldsEnum.Last);

            TimeSerieDB index = new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(),
                string.Empty, DataFieldsEnum.IndexcomponentsWeightsAndPrices);

            TimeSerieDB indexSpecialized = new TimeSerieDB(new List<KeyValuePair<DateTime, IMarketData>>(),
                string.Empty, DataFieldsEnum.IndexcomponentsWeightsAndPricesSpecialized);

            foreach (string filePath in filePaths)
            {
                var fileShare = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

                using (StreamReader sr = new StreamReader(fileShare))
                {
                    string line = sr.ReadToEnd();
                    string[] lines = line.Split("\r\n".AsArray(), StringSplitOptions.None);
                    string[][] valuesMatrix = lines.Select(o => o.Split(',')).ToArray();
                    string[] header = valuesMatrix[9];
                    DateTime date;
                    DateTime.TryParse(valuesMatrix[5][1], out date);
                    double quote;
                    double.TryParse(valuesMatrix[6][1], NumberStyles.Number, CultureInfo.InvariantCulture, out quote);
                    string referenceBloomberg = valuesMatrix[2][1].Replace(" Index", string.Empty);

                    IndexComponents indexComponents = new IndexComponents(referenceBloomberg);
                    IndexComponents indexComponentsSpecialized = new IndexComponents(referenceBloomberg);
                    for (int i = 10; i < valuesMatrix.Length; i++)
                    {
                        if (valuesMatrix[i].Length >= 15)
                        {
                            string[] dataArray = valuesMatrix[i];

                            double weight;
                            double.TryParse(dataArray[14], NumberStyles.Number, CultureInfo.InvariantCulture, out weight);
                            double value;
                            double.TryParse(dataArray[16], NumberStyles.Number, CultureInfo.InvariantCulture, out value);

                            IndexComponent indexComponent = new IndexComponent(dataArray[3], weight, value, 1.0);
                            indexComponents.Components.Add(indexComponent);

                            double nosh;
                            double nosh_dayafter;
                            double price;
                            double r_factor;
                            double r_factor_dayafter;
                            double fxspot;
                            double af_daybefore;
                            double af;
                            double af_dayafter;
                            double subweight;
                            double subweight_dayafter;
                            double marketvalue;
                            double marketvalue_dayafter;
                            double.TryParse(dataArray[5], NumberStyles.Number, CultureInfo.InvariantCulture, out nosh);
                            double.TryParse(dataArray[6], NumberStyles.Number, CultureInfo.InvariantCulture, out nosh_dayafter);
                            double.TryParse(dataArray[7], NumberStyles.Number, CultureInfo.InvariantCulture, out price);
                            double.TryParse(dataArray[8], NumberStyles.Number, CultureInfo.InvariantCulture, out r_factor);
                            double.TryParse(dataArray[9], NumberStyles.Number, CultureInfo.InvariantCulture, out r_factor_dayafter);
                            double.TryParse(dataArray[10], NumberStyles.Number, CultureInfo.InvariantCulture, out fxspot);
                            double.TryParse(dataArray[11], NumberStyles.Number, CultureInfo.InvariantCulture, out af_daybefore);
                            double.TryParse(dataArray[12], NumberStyles.Number, CultureInfo.InvariantCulture, out af);
                            double.TryParse(dataArray[13], NumberStyles.Number, CultureInfo.InvariantCulture, out af_dayafter);
                            double.TryParse(dataArray[14], NumberStyles.Number, CultureInfo.InvariantCulture, out subweight);
                            double.TryParse(dataArray[15], NumberStyles.Number, CultureInfo.InvariantCulture, out subweight_dayafter);
                            double.TryParse(dataArray[16], NumberStyles.Number, CultureInfo.InvariantCulture, out marketvalue);
                            double.TryParse(dataArray[17], NumberStyles.Number, CultureInfo.InvariantCulture, out marketvalue_dayafter);

                            IndexComponentSpecialized indexComponentSpecialized = new IndexComponentSpecialized(
                                dataArray[3],
                                weight,
                                value,
                                dataArray[0],
                                dataArray[1],
                                dataArray[2],
                                dataArray[4],
                                nosh,
                                nosh_dayafter,
                                price,
                                r_factor,
                                r_factor_dayafter,
                                fxspot,
                                af_daybefore,
                                af,
                                af_dayafter,
                                subweight,
                                subweight_dayafter,
                                marketvalue,
                                marketvalue_dayafter,
                                dataArray[18],
                                dataArray[19]);
                            indexComponentsSpecialized.Components.Add(indexComponentSpecialized);
                        }
                    }

                    indexQuote.Add(new KeyValuePair<DateTime, IMarketData>(date, new MarketDataDouble(quote)));
                    index.Add(new KeyValuePair<DateTime, IMarketData>(date, indexComponents));
                    indexSpecialized.Add(new KeyValuePair<DateTime, IMarketData>(date, indexComponentsSpecialized));

                    if (string.IsNullOrWhiteSpace(indexQuote.Instrument))
                    {
                        indexQuote.Instrument = indexComponents.Name;
                    }

                    if (string.IsNullOrWhiteSpace(index.Instrument))
                    {
                        index.Instrument = indexComponents.Name;
                    }

                    if (string.IsNullOrWhiteSpace(indexSpecialized.Instrument))
                    {
                        indexSpecialized.Instrument = indexComponents.Name;
                    }
                }
            }

            TimeSeriesProvider provider = new TimeSeriesProvider(MarketDataService.CurrentOverloadedMarketDataTree, false, true, false, true);
            provider.Save(index.AsArray());
            provider.Save(indexSpecialized.AsArray());
            provider.Save(indexQuote.AsArray());
        }

        /// <summary>
        /// Get last file created in a folder by pattern
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static string FindLastFile(string folderPath, string pattern = null)
        {
            var directory = new DirectoryInfo(folderPath);
            var files = directory.GetFiles(pattern).OrderByDescending(o => o.CreationTime);

            if (files != null)
            {
                return files.First().FullName;
            }

            return string.Empty;
        }

        /// <summary>
        /// Get files in a folder for a period by pattern
        /// </summary>
        /// <param name="folderPath"></param>
        /// <param name="startDate"></param>
        /// <param name="endDate"></param>
        /// <param name="pattern"></param>
        /// <returns></returns>
        public static IList<string> FindFiles(string folderPath, DateTime startDate, DateTime endDate, string pattern = null)
        {
            var directory = new DirectoryInfo(folderPath);
            var files = directory.GetFiles(pattern).OrderByDescending(o => o.CreationTime);

            if (files != null)
            {
                return files.Where(o => DateTime.ParseExact(o.Name.Split('_')[1].Remove(8), "yyyyMMdd", CultureInfo.InvariantCulture) >= startDate && DateTime.ParseExact(o.Name.Split('_')[1].Remove(8), "yyyyMMdd", CultureInfo.InvariantCulture) <= endDate).Select(o => o.FullName).ToList();
            }

            return new List<string>();
        }
    }
}
