﻿using System;
using System.Configuration;
using System.IO;
using System.Runtime.Serialization;
using CaesarApplication.Service.Mail;

namespace Caesar.Bloomberg.Downloader.Config
{
    [DataContract]
    public class DownloadConfig
    {
        /// <summary>
        /// Configurations
        /// </summary>
        [DataMember(Order = 0)]
        public Configuration[] Configurations { get; set; }

        [DataMember(Order = 1)]
        public CsvImport[] CsvImports { get; set; }

        [DataMember(Order = 2)]
        public MailAttachementDownloadParameters[] MailDownloads { get; set; }

        public static DownloadConfig Load(string filePath = null)
        {
            string defaultConfigPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "DownloadConfig.xml");

            using (var fs = File.OpenRead(filePath ?? ConfigurationManager.AppSettings["Caesar.Bloomberg.Downloader.DownloadConfig"] ?? defaultConfigPath))
            {
                return (DownloadConfig)new DataContractSerializer(typeof(DownloadConfig)).ReadObject(fs);
            }
        }

        public void Save(string filePath)
        {
            using (var fs = File.OpenWrite(filePath ?? ConfigurationManager.AppSettings["DownloadConfig"]))
            {
                new DataContractSerializer(typeof(DownloadConfig)).WriteObject(fs, this);
            }
        }
    }

    [DataContract]
    public class Configuration
    {
        /// <summary>
        /// Instrument tickers to download
        /// </summary>
        [DataMember(Order = 7)]
        public string[] Tickers { get; set; }

        /// <summary>
        /// Index with components downloaded inside
        /// </summary>
        [DataMember(Order = 9)]
        public string[] Universes { get; set; }

        /// <summary>
        /// If not defined use all dataHandlers otherwise use only mandatory and mentioned DataHandlers
        /// </summary>
        [DataMember(Order = 10)]
        public string[] DataHandlersToUse { get; set; }

        /// <summary>
        /// If not defined data are stored regardless source
        /// </summary>
        [DataMember(Order = 11)]
        public bool? SaveDefaultSource { get; set; }

        /// <summary>
        /// Dates where compositions will be requested
        /// </summary>
        [DataMember(Order = 8)]
        public DateTime[] UniverseDates { get; set; }

        /// <summary>
        /// DataFields
        /// </summary>
        [DataMember(Order=1)]
        public string[] DataFields { get; set; }

        /// <summary>
        /// When set, incremental mod is activated
        /// The number of days is applied to the End Date
        /// </summary>
        [DataMember(Order = 5)]
        public int? IncrementalLagInDays { get; set; }

        /// <summary>
        /// Horizon downloaded
        /// </summary>
        [DataMember(Order = 4)]
        public int HorizonInDays { get; set; }

        /// <summary>
        /// Timespan between two requests
        /// </summary>
        [DataMember(Order = 6)]
        public TimeSpan Temporization { get; set; }

        /// <summary>
        /// Start download date if not specified StartDate = DateTime.Today - HorizonInDays
        /// </summary>
        [DataMember(Order=2)]
        public DateTime? StartDate { get; set; }

        /// <summary>
        /// End download date if not specified EndDate = DateTime.Today
        /// </summary>
        [DataMember(Order = 3)]
        public DateTime? EndDate { get; set; }

        /// <summary>
        /// SpecialMode if "All Universe", it will define ticker to download using tickers currently used
        /// </summary>
        [DataMember(Order = 13)]
        public string SpecialMode { get; set; }

    }
}
