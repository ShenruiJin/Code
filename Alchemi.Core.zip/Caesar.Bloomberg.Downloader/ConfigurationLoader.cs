﻿using System.Configuration;
using System.IO;

namespace Caesar.Bloomberg.Downloader
{
    public static class ConfigurationLoader
    {
        public static string DealServerPath
        {
            get { return new FileInfo(ConfigurationManager.AppSettings["Caesar.Bloomberg.Downloader.DealServerPath"]).FullName; }
        }

        public static int NbDlRetries
        {
            get
            {
                int configNbRetries;

                if (int.TryParse(ConfigurationManager.AppSettings["Caesar.Bloomberg.Downloader.NbDlRetries"], out configNbRetries))
                {
                    return configNbRetries;
                }

                return 5;
            }
        }
    }
}
