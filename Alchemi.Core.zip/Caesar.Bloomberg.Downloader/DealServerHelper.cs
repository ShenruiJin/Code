using System;
using System.Diagnostics;
using System.IO;
using log4net;

namespace Caesar.Bloomberg.Downloader
{
    public class DealServerHelper
    {
        private Downloader downloader;
        private ILog logger = LogManager.GetLogger(typeof(DealServerHelper));

        public DealServerHelper(Downloader downloader)
        {
            this.downloader = downloader;
        }


        public void LaunchDealServer(string execPath, string arguments = null)
        {
            Process.Start(new ProcessStartInfo
            {
                FileName = execPath,
                WorkingDirectory = Path.GetDirectoryName(execPath),
                Arguments = arguments
            });
        }

        public void KillDealServer()
        {
            foreach (var proc in Process.GetProcessesByName("DealServer"))
            {
                try
                {
                    logger.DebugFormat("Kill proc [{0}]", proc.Id);
                    proc.Kill();
                }
                catch (Exception)
                {
                    logger.ErrorFormat("Kill failed proc [{0}]", proc.Id);
                }
            }
        }
    }
}