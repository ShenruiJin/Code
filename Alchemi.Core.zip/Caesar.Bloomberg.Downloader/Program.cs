﻿using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading;
using Caesar.Bloomberg.Downloader.Config;
using CaesarApplication.Service.Connection;
using CaesarApplication.Service.Strategy;
using log4net;
using log4net.Config;
using MarketDataMgr.Trees;
using GlobalDerivativesApplications;
using System.Collections.Generic;
using CaesarApplication;
using CaesarApplication.DataConsistency;
using CaesarApplication.Service.Reporting;
using FuncFramework.Business;
using GlobalDerivativesApplications.Reporting;
using CaesarApplication.DataProvider.Helpers;
using CaesarApplication.Service.Persistance;
using CaesarApplication.Service.Configuration;

namespace Caesar.Bloomberg.Downloader
{
    class Program
    {
        private static ILog logger = LogManager.GetLogger(typeof(Downloader));

        /// <summary>
        /// Flag for missing data
        /// </summary>
        public static bool HasMissingData = false;

        /// <summary>
        /// When set, if last is missing it break the load of each fields and pass to the instrument
        /// </summary>
        public static bool LastMissingBreak;

        /// <summary>
        /// When true, this process launch itself the DealServer
        /// </summary>
        public static bool IsDealServerSlave;

        /// <summary>
        /// Arguments sent to the DealServer
        /// </summary>
        public static string DealServerArguments;

        /// <summary>
        /// If not defined use the one defined in the configuration file
        /// </summary>
        private static string configFilePath;

        /// <summary>
        /// When set, the batch will prepare query to be executed by Prism
        /// </summary>
        public static bool PrepareUniversePrism;

        /// <summary>
        /// When set, import BNPIHDUG from folder
        /// </summary>
        public static bool ImportBNPIHDUG;

        /// <summary>
        /// When set, send reports about data conistency
        /// </summary>
        public static bool TestDataConsistency;

        /// <summary>
        /// When set, send reports about data conistency
        /// </summary>
        public static bool TestPricingConsistency;

        /// <summary>
        /// When set, create a file with universe inside
        /// </summary>
        public static bool ExportUniverse;

        /// <summary>
        /// When set, create a file with universe inside
        /// </summary>
        public static bool ExportDataUniverse;

        /// <summary>
        /// When set, create a file with quotation calendars
        /// </summary>
        public static bool ExportQuotationCalendars;

        /// <summary>
        /// When set, create a file with universe inside
        /// </summary>
        public static bool ExportUniverseByIndex;

        /// <summary>
        /// Send a report comparing Published caesar values and BBG
        /// </summary>
        public static bool CompareCeasarBBGReport;

        /// <summary>
        /// When set, get published indexes and DL data about it 
        /// </summary>
        public static bool ExportAndDLPublishedIndexUniverse;

        /// <summary>
        /// When set, comapre Ceasar vs MDM on lasts
        /// </summary>
        public static bool CompareLastCaesarVsMDM;

        /// <summary>
        /// When set, create a file with calendar available
        /// </summary>
        public static bool ExportCalendar;

        /// <summary>
        /// When process generate file, it will have this path
        /// </summary>
        public static string OutputPath;

        /// <summary>
        /// If set override horizon in configuration
        /// </summary>
        public static int Horizon = 0;

        /// <summary>
        /// Cache Sophis data (Instruments and currencies)
        /// </summary>
        public static bool SophisCaching = false;

        /// <summary>
        /// Sales contained in reports
        /// </summary>
        public static string ReportSales;

        private static DateTime ReferenceDate;
        private static string mailDests;

        static int Main(string[] args)
        {
            args.Consume("waitDebugger", opt =>
            {
                Console.WriteLine("Waiting for debugger to attach");
                while (!Debugger.IsAttached)
                {
                    Thread.Sleep(100);
                }
                Console.WriteLine("Debugger attached");
            })
            .Consume("deal-server-slave", (key, value) =>
            {
                IsDealServerSlave = value == "1";
            })
            .Consume("last-missing-break", (key, value) =>
            {
                LastMissingBreak = value == "1";
            })
            .Consume("configFile", (key, value) =>
            {
                configFilePath = value;
            })
            .Consume("prepare-universe-prism", (key, value) =>
            {
                bool.TryParse(value, out PrepareUniversePrism);
            })
            .Consume("horizon", (key, value) =>
            {
                int.TryParse(value, out Horizon);
            })
            .Consume("outputPath", (key, value) =>
            {
                OutputPath = value;
            })
            .Consume("import-BNPIHDUG", (key, value) =>
            {
                bool.TryParse(value, out ImportBNPIHDUG);
            })
            .Consume("exportUniverse", (key, value) =>
            {
                bool.TryParse(value, out ExportUniverse);
            }).Consume("exportDataUniverse", (key, value) =>
            {
                bool.TryParse(value, out ExportDataUniverse);
            }).Consume("exportCalendar", (key, value) =>
            {
                bool.TryParse(value, out ExportCalendar);
            }).Consume("exportUniverseByIndex", (key, value) =>
            {
                bool.TryParse(value, out ExportUniverseByIndex);
            })
            .Consume("compareCeasarBBGReport", (key, value) =>
            {
                bool.TryParse(value, out CompareCeasarBBGReport);
            })
             .Consume("compareLastCaesarVsMDM", (key, value) =>
             {
                 bool.TryParse(value, out CompareLastCaesarVsMDM);
             })
             .Consume("pricing-consistency", (key, value) =>
             {
                 bool.TryParse(value, out TestPricingConsistency);
             })
             .Consume("exportQuotationCalendars", (key, value) =>
             {
                 bool.TryParse(value, out ExportQuotationCalendars);
             })
             .Consume("exportAndDLPublishedIndexUniverse", (key, value) =>
             {
                 bool.TryParse(value, out ExportAndDLPublishedIndexUniverse);
             })
             .Consume("referenceDate", (key, value) =>
             {
                 DateTime.TryParse(value, out ReferenceDate);
             }).Consume("mailDests", (key, value) =>
             {
                 mailDests = value;
             }).Consume("reportSales", (key, value) =>
             {
                 ReportSales = value;
             }).Consume("sophisCaching", (key, value) =>
             {
                 bool.TryParse(value, out SophisCaching);
             }).Consume("bpipe-server", (key, value) =>
             {
                 CaesarApplication.DataProvider.Bloomberg.SimpleBloombergExecutable.BPipeServer = value;
                 CaesarApplication.DataProvider.Bloomberg.SimpleBloombergExecutable.BPipeApp = "natixis:caesar";
             });

            args = ConnectionService.ConfigureFromCommandLine(args);

            // Start local DealServer
            if (IsDealServerSlave)
            {
                if (!Process.GetProcessesByName("DealServer").Any())
                {
                    Process.Start(new ProcessStartInfo
                    {
                        WorkingDirectory = Path.GetDirectoryName(ConfigurationLoader.DealServerPath),
                        FileName = ConfigurationLoader.DealServerPath,
                        Arguments = string.Join(" ", args.Where(o => o.Contains("port") || o.Contains("deal-server-address")))
                    });
                }

                Thread.Sleep(5000);
            }

            // Set log4net property
            GlobalContext.Properties["username"] = Environment.UserName;
            // Launch log4net engine
            XmlConfigurator.Configure();
            logger = LogManager.GetLogger(typeof(Downloader));

            // Server
            ConnectionService.ConnectToDealServer();

            // L'arbre de stockage
            MarketDataService.CurrentMarketDataTree = new MarketDataTree();

            logger.Info("Download start");

            int returnCode = 0;

            DownloadConfig config = null;
            try
            {
                LogManager.GetLogger("MissingDataLogger").Info("Start download : Data missing for date " + DateTime.Now);

                config = DownloadConfig.Load(configFilePath);

                if (Horizon != 0)
                {
                    config.Configurations.ForEach(o => o.HorizonInDays = Horizon);
                }

                logger.Info("Configuration loaded");

                var downloader = new Downloader();

                if (ExportAndDLPublishedIndexUniverse)
                {
                    var refDate = ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate;

                    logger.InfoFormat("Populate {0} with published tickers between {1} and {2}", configFilePath, refDate.AddDays(Horizon), refDate);

                    var downloadConfig = config;

                    var tasks = PersistanceService.IndexProvider.GetCurrentTasks(null, false, refDate.AddDays(-Horizon), refDate, UserService.CaesarSession);
                    var publishedTasks = tasks.AddedItems.Where(t => t.Type == DealIndexDataTransferObject.Blotter.TaskType.Publication && t.Completed).ToArray();

                    logger.InfoFormat("{0} published tasks", publishedTasks.Count());

                    var tickers = publishedTasks.Select(t => t.BBGTicker).Distinct().OrderBy(x => x).ToArray();

                    logger.InfoFormat("{0} tickers", tickers.Count());

                    tickers.ForEach(t => logger.Info(t));

                    downloadConfig.Configurations.ForEach(x => x.Tickers = tickers);
                }

                if (TestDataConsistency)
                {
                    var dscc = new DataScopeConsitencyChecker(ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate, Horizon, ReportSales);

                    dscc.SendDataReports();
                }
                else if (ExportDataUniverse)
                {
                    var dscc = new DataScopeConsitencyChecker(ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate, Horizon, ReportSales);

                    dscc.ExportDataScope(OutputPath);
                }
                else if (CompareLastCaesarVsMDM)
                {
                    var dscc = new DataScopeConsitencyChecker(ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate, Horizon, ReportSales);

                    dscc.ExportCaesarVsMDMComparisonReport(OutputPath);
                }
                else if (TestPricingConsistency)
                {
                    var dscc = new DataScopeConsitencyChecker(ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate, Horizon, ReportSales);

                    dscc.SendPricingReports();
                }
                else if (ExportUniverse)
                {
                    var mgr = new IndexUniverseManager();
                    var tickers = mgr.GetIndexesTickersWithDependencies(DateTime.Today.AddDays(-(Horizon != 0 ? Horizon : 30)), DateTime.Today);

                    if (File.Exists(OutputPath))
                    {
                        File.Delete(OutputPath);
                    }

                    File.WriteAllLines(OutputPath, tickers.ToArray());
                }
                else if (ExportUniverseByIndex)
                {
                    var mgr = new IndexUniverseManager();
                    var tickers = mgr.GetTickersPerIndeWithDependencies(DateTime.Today.AddDays(-(Horizon != 0 ? Horizon : 30)), DateTime.Today, true);

                    if (File.Exists(OutputPath))
                    {
                        File.Delete(OutputPath);
                    }

                    File.WriteAllLines(OutputPath,
                        "IndexName,INDEX_BBG_Ticker,COMPONENT_BBG_Ticker".AsArray()
                        .Concat(tickers.SelectMany(t => t.Value.Select(tickerValue => string.Format("{0},{1},{2}", IndexPathHelper.Combine(t.Key.Key.project_name, t.Key.Value.ticker), t.Key.Value.bloomberg_ticker ?? "", tickerValue)).ToArray())));
                }
                else if (SophisCaching)
                {
                    IndexUniverseManager universeManager = new IndexUniverseManager();
                    var tickers = universeManager.GetIndexesTickers(DateTime.Today.AddDays(Horizon == 0 ? -160 : Horizon), DateTime.Today);

                    SophisHelper.SaveInstruments(SophisHelper.InstrumentsCacheFilePath, tickers.ToArray());
                    SophisHelper.SaveCurrencies(SophisHelper.CurrenciesCacheFilePath);
                }
                else if (PrepareUniversePrism)
                {
                    //IList<string> tickerUniverse = new List<string>();
                    //
                    //config.Configurations.ForEach(o => tickerUniverse.AddRange(downloader.GetUniverse(o)));
                    //
                    //tickerUniverse = tickerUniverse.Distinct().Where(o => !string.IsNullOrWhiteSpace(o)).ToList();
                    //
                    //DateTime startDate = DateTime.Today;
                    //DateTime endDate = DateTime.Today;
                    //
                    //startDate = startDate.AddDays(-config.Configurations.Max(o => o.HorizonInDays) - config.Configurations.Max(o => o.IncrementalLagInDays) ?? 0);
                    //endDate = endDate.AddDays(-config.Configurations.Max(o => o.IncrementalLagInDays) ?? 0);
                    //
                    //foreach (Configuration conf in config.Configurations)
                    //{
                    //    downloader.GenerateUniverseFiles(tickerUniverse, conf, startDate, endDate);
                    //}

                    returnCode = 0;
                }
                else if (ExportCalendar)
                {
                    new CalendarScopeReporting(OutputPath).Export();
                }
                else if (ExportQuotationCalendars)
                {
                    new QuotationCalendarReporting(OutputPath).Export(DateTime.Today, DateTime.Today.AddYears(3));
                }
                else if (config.CsvImports != null && config.CsvImports.Any())
                {
                    logger.Info("Start importing csv");
                    var dl = new Downloader();

                    dl.DownloadAttachements(config);

                    returnCode = dl.LoadFromCsv(config.CsvImports);
                }
                else if (ImportBNPIHDUG)
                {
                    logger.Info("Start import BNPIHDUG components");
                    var filePaths = Downloader.FindFiles(@"\\cib.net\shareNy\Salle\Services\PropIndex\production\data\BNP_PORT_DATA", DateTime.Today.AddDays(-1).AddDays(-Horizon), DateTime.Today.AddDays(-1), "BNPIHDUG_*.csv");
                    Downloader.ImportCSV(filePaths, null);
                    logger.Info("End import BNPIHDUG components");
                }
                else
                {
                    var dl = new Downloader();

                    dl.DownloadAttachements(config);
                    returnCode = downloader.Load(config);
                }

                if (CompareCeasarBBGReport)
                {
                    var refDate = ReferenceDate == DateTime.MinValue ? DateTime.Today : ReferenceDate;

                    new BBGvsCaesarReporting(refDate.AddDays(-Horizon), refDate).Report();
                }
            }
            catch (Exception ex)
            {
                logger.Error("Fail to download data", ex);
                returnCode = -1000;
            }

            logger.InfoFormat("Processus finished");

            return returnCode;
        }

        /// <summary>
        /// Send an containing reporting on missing data during process execution
        /// </summary>
        private static void SendEmail()
        {
            logger.InfoFormat("Sending email containing data missing");

            string body = "Please find data failed to be retrieved in the file(s) attached.\n\n";

            var emailAddress = System.Configuration.ConfigurationManager.AppSettings["SenderEmailAddress"] ?? "eda25-desk-quant-applications@natixis.com";

            DirectoryInfo hdDirectoryInWhichToSearch = new DirectoryInfo(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location) + @"\Log");
            FileInfo[] filesInDir = hdDirectoryInWhichToSearch.GetFiles("*MissingData*");

            IList<string> attachments = filesInDir.Where(o => o.LastWriteTime >= DateTime.Now.AddHours(-15)).Select(o => o.FullName).ToList();

            Tools.System.SendEmailEWS(emailAddress,
                new[] { System.Configuration.ConfigurationManager.AppSettings["MissingDataMailingList"] },
                "[CaesarIndex downloader] - Missing data report", body, attachments: attachments, impersonatedAddress: emailAddress, userName: "nt_eqd_sos", password: "Ba13h,7j");
        }
    }
}
